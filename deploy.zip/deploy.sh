#!/bin/bash
set -e

# ========================================================
# Broteach.com Production Deployment Script
# Target: Docker Container on Port 8083 -> NPM (broteach.com)
# ========================================================

echo "🚀 Starting Broteach Production Deployment..."

# 1. Ensure runtime storage directory exists with correct permissions for Next.js user (UID 1001)
echo "📁 Setting up persistent storage directory (.data, .data/backups & .data/uploads)..."
mkdir -p .data/backups .data/uploads
# 1001:1001 is the nextjs user created in Dockerfile
chmod -R 775 .data || true
if [ "$(id -u)" -eq 0 ]; then
    chown -R 1001:1001 .data || true
fi

# 2. Check and synchronize environment file (.env and .env.local)
if [ ! -f .env.local ] && [ ! -f .env ]; then
    echo "⚠️  No .env.local or .env found. Creating from .env.example..."
    cp .env.example .env.local
    cp .env.example .env
fi

# Clean Windows carriage return line endings (\r) that break environment variables
sed -i 's/\r$//' .env .env.local .env.example 2>/dev/null || true

# Keep .env and .env.local in sync so Docker Compose always receives values
if [ -f .env.local ] && [ ! -f .env ]; then
    cp .env.local .env
elif [ -f .env ] && [ ! -f .env.local ]; then
    cp .env .env.local
elif [ -f .env.local ] && [ -f .env ]; then
    # If .env.local is newer, sync to .env
    if [ .env.local -nt .env ]; then
        cp .env.local .env
    else
        cp .env .env.local
    fi
fi

# 3. Build and launch container in detached mode
echo "🐳 Building and starting Docker container on port 8083..."
docker compose down || true
docker compose --env-file .env up -d --build --remove-orphans

# 4. Wait for health check
echo "⏳ Waiting for container to become healthy..."
sleep 5

# 5. Check container status
docker compose ps

echo "========================================================"
echo "✅ Broteach is running!"
echo "🌐 Local/Direct URL: http://217.216.54.187:8083"
echo "🌐 Health Check:    curl http://127.0.0.1:8083/api/content"
echo "🌐 Domain URL:      https://broteach.com (via Nginx Proxy Manager)"
echo "========================================================"
