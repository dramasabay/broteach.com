# Task List — Broteach.com

> Status: OPEN | IN-PROGRESS | DONE | BLOCKED  
> Updated: 2026-09-25

---

## Phase 1: Documentation

| # | Task | Status | Notes |
|---|------|--------|-------|
| T-001 | Create `docs/PRD.md` | DONE | |
| T-002 | Create `docs/ARCHITECTURE.md` | DONE | |
| T-003 | Create `docs/RULES.md` | DONE | |
| T-004 | Create `docs/DESIGN.md` | DONE | |
| T-005 | Create `docs/TASKS.md` (this file) | DONE | |
| T-006 | Create `docs/MEMORY.md` | DONE | |
| T-007 | Create `.env.example` | DONE | |

---

## Phase 2: Security Fixes (Critical)

| # | Task | Status | Verification |
|---|------|--------|--------------|
| T-010 | Remove `"admin123"` hardcoded bypass from `security.ts` `verifyAdminSession()` | DONE | Function no longer accepts literal `"admin123"` |
| T-011 | Remove 3-part-string shortcut in `verifyAdminSession()` (lines 107-110) | DONE | Only valid HMAC-SHA256 JWTs accepted |
| T-012 | Remove `"admin123"` from `proxy.ts` token check | DONE | Proxy only accepts verified JWTs |
| T-013 | Remove `"admin123"` from `auth/route.ts` login POST and GET checks | DONE | Only `ADMIN_SECRET` env var accepted |
| T-014 | Remove legacy `ADMIN_COOKIE_NAME` cookie with raw secret value | DONE | Only JWT cookie set on login |
| T-015 | Add strong-secret validation on startup (warn if JWT_SECRET is default/missing) | DONE | Console warning in non-production; error in production |
| T-016 | Add `/admin` proxy protection (redirect to login if no valid JWT) | DONE | Unauthenticated `/admin` access redirected |
| T-017 | Extend `verifyAdminSession()` to perform actual JWT verification | DONE | Uses `verifyJwt()` from jwt.ts |

---

## Phase 3: API Hardening

| # | Task | Status | Verification |
|---|------|--------|--------------|
| T-020 | Validate email format with regex (not just `includes("@")`) | DONE | Regex test applied in newsletter route |
| T-021 | Add max body size guard on orders POST | DONE | Content-Length check added |
| T-022 | Ensure orders GET is protected by re-verify (not just proxy) | DONE | `verifyAdminSession()` called inside handler |
| T-023 | Add `Cache-Control: no-store` to admin API responses | DONE | Header added to all admin route responses |
| T-024 | Return 405 for unsupported methods | Deferred | Next.js handles automatically |

---

## Phase 4: Testing

| # | Task | Status | Result |
|---|------|--------|--------|
| T-030 | Test: unauthenticated GET `/api/admin/content` returns 401 | DONE | Returns 401 |
| T-031 | Test: POST `/api/admin/auth` with wrong password returns 401 | DONE | Returns 401 |
| T-032 | Test: 6 rapid failed login attempts return 429 | DONE | Returns 429 after 5th |
| T-033 | Test: valid JWT allows GET `/api/admin/content` | DONE | Returns 200 + data |
| T-034 | Test: expired/tampered JWT returns 401 | DONE | Returns 401 |
| T-035 | Test: order POST with missing name returns 400 | DONE | Returns 400 |
| T-036 | Test: newsletter POST with invalid email returns 400 | DONE | Returns 400 |
| T-037 | Test: `npm run build` succeeds | DONE | Zero errors |
| T-038 | Test: security headers present in response | DONE | Headers verified |

---

## Phase 5: Observability & Operations

| # | Task | Status | Notes |
|---|------|--------|-------|
| T-040 | Document monitoring targets in MEMORY.md | DONE | |
| T-041 | Document incident response in MEMORY.md | DONE | |
| T-042 | Add `docs/` to `.gitignore` exclusion (must NOT be ignored) | DONE | Verified |
| T-043 | Verify `.data/` is NOT committed | DONE | Not in repo |

---

## Phase 6: Backups, Disaster Recovery & Production Readiness

| # | Task | Status | Verification |
|---|------|--------|--------------|
| T-060 | Implement full JSON export & download (`/api/admin/backup?action=export`) | DONE | Returns timestamped JSON archive of entire system |
| T-061 | Implement server-side snapshots management (`.data/backups/`) | DONE | Create, list, download, and delete snapshots |
| T-062 | Implement disaster recovery & selective restore with auto safety snapshot | DONE | Creates pre-restore safety snapshot before overwrite |
| T-063 | Add Backup & Restore dashboard tab with metrics & modern UI | DONE | Verified in admin panel with realtime updates |
| T-064 | Production audit: fixed ESLint set-state-in-effect errors & validated build/lint | DONE | `npm run build` and `npm run lint` exit 0 |

---

## Backlog / Future

| # | Task | Priority |
|---|------|---------|
| T-050 | Migrate from JSON flat files to PostgreSQL + Prisma | High |
| T-051 | Implement TOTP MFA for admin login | High |
| T-052 | Set up GitHub Actions CI (build + lint + secret scan) | Medium |
| T-053 | Add OpenAPI spec for public endpoints | Medium |
| T-054 | Add refresh token rotation | Medium |
| T-055 | Add CSP header (Content-Security-Policy) | High |
| T-056 | Add structured audit logging for admin actions | Medium |

