# Memory / Decision Log — Broteach.com

> This file tracks decisions made, completed work, unresolved issues, and next steps.

---

## Completed Work (2026-09-25)

### Documentation Suite Created
- `docs/PRD.md` — product requirements, user roles, permission matrix, acceptance criteria
- `docs/ARCHITECTURE.md` — system design, DB schema, APIs, middleware, security controls
- `docs/RULES.md` — coding standards, mandatory security rules, prohibited shortcuts
- `docs/DESIGN.md` — pages, components, visual tokens, responsive behavior, accessibility
- `docs/TASKS.md` — task list with status and verification results
- `.env.example` — placeholder environment variable reference

### Security Fixes Applied
All fixes listed in TASKS.md Phase 2 were applied. Summary:

1. **Removed `"admin123"` hardcoded bypass** — This was the most critical finding. The string `"admin123"` appeared as an accepted password/token in three locations: `security.ts:104`, `auth/route.ts:55`, and `proxy.ts:40`. All three have been removed. Only the `ADMIN_SECRET` environment variable value is accepted.

2. **Removed 3-part-string JWT shortcut** — `verifyAdminSession()` previously accepted any 3-segment string as a valid JWT without cryptographic verification. This has been replaced with a proper `verifyJwt()` call.

3. **Removed raw secret in legacy cookie** — The login handler was setting a second cookie (`ADMIN_COOKIE_NAME`) with the raw `ADMIN_SECRET` value. This was removed; only the signed JWT cookie is now set.

4. **Added proxy protection for `/admin` page** — The proxy previously only protected `/api/admin/*`. Now `/admin` is also matched, and unauthenticated users are redirected to `/admin?login=required`.

5. **Added startup secret validation** — A weak or default JWT_SECRET logs a warning in development and throws in production.

---

## Key Decisions

| Decision | Rationale |
|----------|-----------|
| JSON flat files for persistence | Minimizes deployment dependencies; viable for low-to-medium traffic. Migration path to PostgreSQL documented. |
| Custom HMAC-SHA256 JWT | Avoids adding an external auth library dependency; compatible with Edge runtime. Acceptable for single-admin use. |
| `proxy.ts` naming (not `middleware.ts`) | Next.js 16 deprecated `middleware.ts` in favor of `proxy.ts`. AGENTS.md mandates reading the docs directory. |
| SameSite=Lax on cookies | Compatible with Telegram redirects (external navigation) while still providing CSRF protection for same-site POST requests. |
| BroadcastChannel for real-time | Zero additional infrastructure; works across tabs in the same browser. Not suitable for multi-origin or multi-server setups. |
| In-memory rate limiting | Simple and sufficient for single-instance deployment. For multi-instance, replace with Redis. |

---

## Unresolved Issues

| Issue | Severity | Notes |
|-------|----------|-------|
| No MFA for admin | High | TOTP planned (T-051). Currently single-password auth only. |
| In-memory rate limiter not shared across server instances | Medium | Acceptable for single-server; needs Redis for horizontal scaling. |
| No Content-Security-Policy header | High | Planned T-055. Current headers cover HSTS, X-Frame-Options, X-Content-Type-Options. |
| No automated CI/CD | Medium | Planned T-052. Build and tests must be run manually before deployment. |
| `.data/` on local filesystem | Medium | Not suitable for serverless (Vercel) without a persistent volume. Use PostgreSQL for cloud deploy. |
| No audit log | Medium | Admin actions are not logged. Planned T-056. |

---

## Threat Model

### Sensitive Data
- `ADMIN_SECRET` (admin login password)
- `JWT_SECRET` (JWT signing key)
- Order data (client names, phones, emails)
- Subscriber emails
- Telegram bot token (if configured)

### Trust Boundaries
- Public internet -> CDN/WAF -> Next.js App
- Browser (untrusted) -> API endpoints (validate all input)
- Admin browser (trusted after auth) -> Admin API (still re-validate on every request)

### Likely Attacks & Controls

| Attack | Control |
|--------|---------|
| Brute-force admin login | Rate limit: 5 attempts/60s per IP |
| Stolen JWT cookie | HTTP-only prevents JS access; 7-day expiry; logout invalidates cookie |
| XSS via stored content | `sanitizeText()` on all stored strings; CSP planned |
| CSRF via form submission | SameSite=Lax cookies; JSON body requirement |
| DDoS | Cloudflare WAF + rate limits; request timeouts |
| SQL injection | Not applicable (no SQL currently); parameterized queries planned for Prisma |
| Path traversal | No user-controlled file paths exposed |
| Secret leakage | Env vars only; never in responses or logs |
| Direct-origin bypass of CDN | Cloudflare firewall rule to block non-Cloudflare IPs |

---

## Monitoring Targets

1. Error rate on `/api/admin/auth` (spike = brute-force attempt)
2. HTTP 429 rate (spike = abuse or DDoS)
3. HTTP 500 rate (spike = application error)
4. Disk usage of `.data/` directory
5. Response time p95 (threshold: 2 seconds)

---

## Incident Response

### Compromised Admin Password
1. Immediately update `ADMIN_SECRET` env var on host and restart application
2. All existing JWT cookies reference the old secret hash — they will remain valid until expiry (7 days) unless JWT_SECRET is also rotated
3. Also rotate `JWT_SECRET` to invalidate all existing sessions immediately
4. Review orders and subscriber data for unauthorized changes
5. Review server logs for unexpected admin API calls

### Compromised JWT Secret
1. Rotate `JWT_SECRET` immediately — all existing sessions are instantly invalidated
2. Update env var and restart application
3. All admins must log in again

### Data Loss
1. Restore `.data/` from most recent backup (see ARCHITECTURE.md §11)
2. Verify integrity by checking product/order/subscriber counts
3. Restart application

---

## Next Steps

1. Install and configure TOTP MFA (T-051) — **highest priority**
2. Add Content-Security-Policy header (T-055)
3. Set up GitHub Actions CI (T-052)
4. Plan PostgreSQL migration (T-050)
