# Product Requirements Document — Broteach.com

> **Version:** 1.0  
> **Date:** 2026-09-25  
> **Status:** Active

---

## 1. Project Overview

**Broteach** is a Cambodian web-development and cloud-hosting agency website. It serves as the primary commercial storefront and lead-capture platform for the business. The site is bilingual (Khmer / English), displays products and pricing, collects order inquiries, and provides administrators with a CMS dashboard.

---

## 2. Goals

| # | Goal |
|---|------|
| G1 | Showcase products and pricing clearly to convert visitors into leads |
| G2 | Capture order inquiries and newsletter subscriptions securely |
| G3 | Provide admins a full CMS to manage products, pricing, content, orders, and subscribers |
| G4 | Rank on Cambodian Google searches (SEO foundation) |
| G5 | Load in under 1 second on mobile (performance) |
| G6 | Protect all admin data and operations behind authentication |

---

## 3. Users / Roles

| Role | Description | Permissions |
|------|-------------|-------------|
| **Visitor** | Unauthenticated public user | Read public content, submit orders, subscribe to newsletter |
| **Admin** | Authenticated operator | Full CMS: read/write/delete products, pricing, sections, settings, orders, subscribers |

### Permission Matrix

| Resource | Visitor (read) | Visitor (write) | Admin (read) | Admin (write) | Admin (delete) |
|----------|:--------------:|:---------------:|:------------:|:-------------:|:--------------:|
| Site settings | Yes (via /api/content) | No | Yes | Yes | No |
| Products | Yes (active only) | No | Yes (all) | Yes | Yes |
| Pricing plans | Yes | No | Yes | Yes | Yes |
| Content sections | Yes (active only) | No | Yes (all) | Yes | Yes |
| Orders | No | Yes (submit own) | Yes | Yes (status) | Yes |
| Newsletter subscribers | No | Yes (subscribe own email) | Yes | No | Yes |

---

## 4. Pages

| Page | Path | Auth | Description |
|------|------|------|-------------|
| Home | `/` | Public | Hero, products, highlights, pricing, CMS sections, newsletter, footer |
| About Us | `/about` | Public | Company story, mission, team |
| Products | `/products` | Public | Product listing with detail modal |
| Productions | `/productions` | Public | Portfolio / showcase |
| Admin Dashboard | `/admin` | Admin only | Full CMS dashboard |

---

## 5. Features

### 5.1 Public Features
- Bilingual UI (Khmer / English) with flag switcher
- Dynamic hero section (title, subtitle, announcement banner)
- Product grid (filter by category, detail modal)
- Pricing section with order/demo buttons
- Dynamic CMS-managed content sections (cards, features, stats, FAQ, banner layouts)
- Newsletter subscription form
- Demo/Order inquiry modal (captures name, phone, email, Telegram, notes)
- Floating Telegram support button
- Real-time content polling (10s interval + BroadcastChannel)
- SEO: meta tags, Open Graph, JSON-LD structured data, sitemap, robots

### 5.2 Admin Features (all behind JWT auth)
- Login with password - JWT issued as HTTP-only cookie
- Dashboard overview (order count, subscriber count, product count)
- Products CRUD (create, edit, delete, toggle active, reorder)
- Pricing plans CRUD
- Content sections CRUD + reorder
- Site settings editor (hero text, announcement, contact info, SEO, About Us fields)
- Orders management (view, update status, delete)
- Subscribers management (view, delete)
- SEO preview (Khmer / English toggle)

---

## 6. Main Workflows

### Visitor Order Flow
1. Visitor browses products or pricing
2. Clicks "Order Now" or "Demo" -> modal opens
3. Fills name, phone, email, optional Telegram and notes -> submits
4. POST `/api/orders` -> order stored -> Telegram notification sent (if configured)
5. Admin views and follows up via `/admin` dashboard

### Newsletter Subscription Flow
1. Visitor enters email in newsletter banner
2. POST `/api/newsletter` -> email validated -> stored
3. Admin can view and delete subscribers in `/admin`

### Admin CMS Flow
1. Navigate to `/admin` -> login form shown
2. POST `/api/admin/auth` with password -> JWT cookie set (7-day, HTTP-only, Secure, SameSite=Lax)
3. Admin edits content -> PUT/DELETE to `/api/admin/*`
4. BroadcastChannel event fired -> all open tabs refresh public content
5. Admin logs out -> DELETE `/api/admin/auth` -> cookies cleared

---

## 7. Acceptance Criteria

| ID | Criterion |
|----|-----------|
| AC-1 | Unauthenticated requests to `/api/admin/*` (except auth POST) return HTTP 401 |
| AC-2 | Admin login with correct password returns a signed JWT cookie |
| AC-3 | Admin login with wrong password returns HTTP 401; after 5 attempts in 60s returns HTTP 429 |
| AC-4 | Orders endpoint validates name and phone; missing fields return HTTP 400 |
| AC-5 | Newsletter endpoint rejects invalid email format with HTTP 400 |
| AC-6 | `/admin` page redirects unauthenticated users to login |
| AC-7 | All API responses use consistent `{ success, message }` JSON envelope |
| AC-8 | Security headers (HSTS, X-Frame-Options, etc.) are present on every response |
| AC-9 | Production build succeeds with `npm run build` |
| AC-10 | No secrets committed to the repository |
