# Coding Rules — Broteach.com

> These rules are mandatory. They apply to all contributors and AI assistants.  
> No exceptions without explicit, documented approval.

---

## 1. Language & Framework

- All source code is TypeScript (strict mode enabled in `tsconfig.json`)
- Framework: Next.js 16 App Router
- In Next.js 16, `middleware.ts` is **deprecated** and renamed to `proxy.ts`; always use `proxy.ts` and export `proxy` (not `middleware`)
- Server Components are the default; add `"use client"` only where required
- Use `NextRequest` / `NextResponse` from `next/server` in Route Handlers and the proxy

---

## 2. Security Rules (Mandatory)

### 2.1 Authentication
- Never accept a hardcoded fallback password (e.g., `"admin123"`) in any code path that reaches production
- `JWT_SECRET` must be set as an environment variable; the application must refuse to start with a weak or missing secret in production
- Never accept a token merely because it has three dots (three-part structure check is not a valid verification)
- Always call `verifyJwt()` and check `result.valid === true` before granting access
- The proxy performs an early check; every protected Route Handler must independently re-verify the session

### 2.2 Input Validation
- Validate **type**, **length**, **format**, and **allowed values** of every field on the server
- Use `sanitizeText()` for string inputs before storing or returning them
- Reject requests whose body exceeds reasonable size limits
- Never use user-supplied data in file paths, shell commands, or SQL without proper escaping/parameterization

### 2.3 Output / Error Handling
- Return only generic error messages to clients; log full details server-side
- Never include stack traces, internal paths, or secret values in API responses
- Use consistent JSON response envelope: `{ success: boolean, message: string, data?: unknown }`

### 2.4 Secrets
- Store all secrets (JWT_SECRET, ADMIN_SECRET, bot tokens) in server-side environment variables only
- Never commit `.env` files; `.env.example` must use placeholder values only
- Never log secrets, tokens, passwords, or personal data

### 2.5 Cookies
- Admin session cookies must be: `httpOnly: true`, `secure: true` (production), `sameSite: "lax"`, `path: "/"`
- Never store session tokens in localStorage or sessionStorage

### 2.6 CSRF
- All state-mutating endpoints require a JSON body with `Content-Type: application/json`
- SameSite=Lax on cookies provides baseline CSRF protection for same-site form submissions

### 2.7 Rate Limiting
- Apply `checkRateLimit()` to every public form endpoint (login, orders, newsletter, search)
- Login: maximum 5 attempts per IP per 60 seconds
- Order/newsletter: maximum 15 per IP per 10 minutes

---

## 3. Prohibited Shortcuts

- No hardcoded passwords or tokens in source code
- No backdoor accounts, universal admin passwords, or secret debug routes
- No authentication bypass based on a frontend-only check
- No `eval()` or dynamic code execution
- No `dangerouslySetInnerHTML` unless the content is sanitized and explicitly reviewed
- No disabling TypeScript (`// @ts-ignore`, `any` casts) without a documented reason
- No committing `node_modules/`, `.env`, or `.data/` directories

---

## 4. Code Style

- Use named exports for Route Handlers and components
- Keep Route Handlers focused: validate, check auth, call business logic, return response
- Keep business logic in `/src/lib/`; keep UI in `/src/components/`
- Use `async`/`await`; avoid raw `.then()` chains for readability
- Run `npm run lint` before committing

---

## 5. File Naming

| Type | Convention |
|------|------------|
| Components | PascalCase (e.g., `ProductCard.tsx`) |
| Route Handlers | `route.ts` in appropriate `app/api/` directory |
| Library modules | camelCase (e.g., `contentStore.ts`) |
| Types | `index.ts` in `/src/types/` |
| Proxy | `proxy.ts` in `/src/` |

---

## 6. Git Hygiene

- Commit the `package-lock.json` lockfile on every dependency change
- Write clear commit messages: `fix(auth): remove hardcoded admin123 bypass`
- Do not commit production credentials or `.data/` directory contents
- Run a secret-scanning check before pushing (see `docs/TASKS.md` — CI setup)
