# Architecture Document — Broteach.com

> **Version:** 1.0  
> **Date:** 2026-09-25

---

## 1. System Design

```
Browser
  |
  |-- HTTPS (TLS 1.2+)
  v
CDN / WAF (Cloudflare recommended)
  |
  v
Next.js 16 Application (Node.js)
  |-- /src/proxy.ts        (request interception, early auth checks)
  |-- /src/app/            (App Router pages + route handlers)
  |-- /src/lib/            (server-side business logic)
  |-- /src/components/     (React UI components)
  |
  v
.data/ directory (JSON flat-file persistence)
  (Replace with PostgreSQL + Prisma for production scale)
```

**Runtime:** Node.js 20+ on a single server or PaaS (Vercel, Railway, Render).  
**Current database:** JSON flat files in `.data/` (read from disk, in-memory fallback).  
**Planned upgrade path:** PostgreSQL + Prisma ORM (see §3).

---

## 2. Database Schema

### Current (JSON flat files)

| File | Contents |
|------|----------|
| `.data/site_settings.json` | `SiteSettings` object |
| `.data/products.json` | `ProductItem[]` |
| `.data/pricing_plans.json` | `PricingPlan[]` |
| `.data/content_sections.json` | `ContentSection[]` |
| `.data/orders.json` | `OrderSubmission[]` |
| `.data/subscribers.json` | `NewsletterSubscriber[]` |

### Planned PostgreSQL Schema (Prisma)

```prisma
model SiteSettings {
  id        Int      @id @default(1)
  data      Json
  updatedAt DateTime @updatedAt
}

model Product {
  id              String   @id @default(cuid())
  titleKm         String
  titleEn         String
  category        String
  price           Float
  isActive        Boolean  @default(true)
  sortOrder       Int
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt
}

model PricingPlan {
  id          String  @id @default(cuid())
  nameKm      String
  nameEn      String
  price       Float
  isPopular   Boolean @default(false)
}

model Order {
  id         String   @id @default(cuid())
  planId     String
  planName   String
  price      Float
  clientName String
  email      String
  phone      String
  telegram   String?
  notes      String?
  status     String   @default("pending")
  createdAt  DateTime @default(now())
}

model Subscriber {
  id           String   @id @default(cuid())
  email        String   @unique
  subscribedAt DateTime @default(now())
}
```

---

## 3. API Endpoints

All routes under `/api/admin/*` require a valid JWT (issued by `/api/admin/auth`).

| Method | Path | Auth | Purpose |
|--------|------|------|---------|
| GET | `/api/content` | Public | Fetch all public CMS data |
| POST | `/api/orders` | Public | Submit an order inquiry |
| GET | `/api/orders` | Admin | List all orders |
| POST | `/api/newsletter` | Public | Subscribe email |
| GET | `/api/newsletter` | Admin | List subscribers |
| DELETE | `/api/newsletter?id=` | Admin | Delete subscriber |
| POST | `/api/admin/auth` | Public | Admin login (password -> JWT) |
| GET | `/api/admin/auth` | Admin | Verify current session |
| DELETE | `/api/admin/auth` | Admin | Logout (clear cookies) |
| GET | `/api/admin/content` | Admin | Get all CMS data (including inactive) |
| PUT | `/api/admin/content` | Admin | Update site settings |
| GET | `/api/admin/products` | Admin | List all products |
| POST | `/api/admin/products` | Admin | Create / update product |
| DELETE | `/api/admin/products?id=` | Admin | Delete product |
| GET | `/api/admin/pricing` | Admin | List pricing plans |
| POST | `/api/admin/pricing` | Admin | Create / update plan |
| DELETE | `/api/admin/pricing?id=` | Admin | Delete plan |
| GET | `/api/admin/sections` | Admin | List all sections |
| POST | `/api/admin/sections` | Admin | Create / update section |
| DELETE | `/api/admin/sections?id=` | Admin | Delete section |

---

## 4. Middleware / Proxy

`/src/proxy.ts` (Next.js 16 renamed from `middleware.ts`):
- Matches `/api/admin/:path*`
- Allows `POST /api/admin/auth` unauthenticated
- All other `/api/admin/*` requests must present a valid signed JWT (cookie or Bearer header)
- JWT is verified with HMAC-SHA256; any verification failure returns 401
- On success, injects `x-admin-authenticated: true` and `x-admin-role: admin` headers
- **Not relied on alone**: every Route Handler also re-verifies the session independently

---

## 5. Authentication & Authorization

- **Algorithm:** HMAC-SHA256 JWT (custom Web Crypto implementation, compatible with Edge runtime)
- **Cookie:** `broteach_admin_jwt` — HTTP-only, Secure (production), SameSite=Lax, 7-day maxAge
- **Password:** Hashed or compared server-side only; stored as `ADMIN_SECRET` env var
- **No MFA currently** — planned for admin accounts managing sensitive data
- **Session invalidation:** DELETE `/api/admin/auth` clears both JWT and legacy cookies
- **Rate limit on login:** 5 attempts per IP per 60 seconds

### Authorization layers
1. **Proxy (early check):** rejects requests without valid JWT
2. **Route Handler (deep check):** `verifyAdminSession()` re-checks every protected handler
3. **Data layer:** reads/writes happen only after auth is confirmed

---

## 6. Data Flow

```
Public visitor request:
  Browser -> CDN -> Next.js -> /api/content -> contentStore.ts -> .data/*.json -> JSON response

Order submission:
  Browser -> Next.js -> rate limiter -> /api/orders -> sanitize -> storage.ts -> .data/orders.json
                                                                  -> Telegram bot notification (optional)

Admin mutation:
  Admin browser -> JWT cookie -> proxy.ts (JWT verify) -> /api/admin/* handler (re-verify)
                             -> contentStore.ts -> .data/*.json -> BroadcastChannel event
```

---

## 7. Security Controls

| Control | Implementation |
|---------|----------------|
| Transport security | HSTS header, HTTPS enforced in production |
| Authentication | HMAC-SHA256 JWT, HTTP-only cookie |
| Authorization | Proxy early check + per-handler re-check |
| Input validation | `sanitizeText()`, length checks, type assertions |
| Rate limiting | In-memory sliding window (login: 5/min, orders: 15/10min) |
| XSS prevention | `sanitizeText()` strips script/style/event-handler tags |
| CSRF mitigation | SameSite=Lax cookies; state-mutating endpoints require JSON body |
| Security headers | X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy, HSTS |
| Secret management | All secrets in server-side env vars; never in client bundles or logs |
| Error messages | Generic messages returned to clients; details logged server-side only |

---

## 8. Integrations

| Service | Purpose | Required |
|---------|---------|---------|
| Google Fonts (Kantumruy Pro, Inter) | Typography | Yes (CDN) |
| Telegram Bot API | Order notifications | Optional |
| Google Analytics | Traffic analytics | Optional |
| Google Search Console | SEO verification | Optional |
| Cloudflare | CDN, WAF, DDoS mitigation | Recommended |

---

## 9. Environment Variables

See `.env.example` for the full list. **Never commit real values.**

| Variable | Purpose | Required |
|----------|---------|---------|
| `JWT_SECRET` | Signs admin JWT tokens (min 32 chars) | Yes |
| `ADMIN_SECRET` | Admin login password | Yes |
| `NEXT_PUBLIC_SITE_URL` | Canonical site URL | Yes |
| `TELEGRAM_BOT_TOKEN` | Telegram notifications | Optional |
| `TELEGRAM_CHAT_ID` | Destination chat for notifications | Optional |
| `NODE_ENV` | `production` / `development` | Yes |

---

## 10. Deployment

### Recommended Stack
- **Host:** Vercel / Railway / VPS with Node 20+
- **CDN + WAF:** Cloudflare (free tier or Pro)
- **HTTPS:** Managed by host or Cloudflare
- **Backups:** Daily snapshot of `.data/` to S3-compatible storage

### Steps
1. Set all env vars on host (never in `.env` committed to repo)
2. Run `npm run build` — verify zero errors
3. Deploy built artifact
4. Configure Cloudflare: proxy enabled, SSL=Full Strict, WAF enabled
5. Set Cloudflare firewall rule to block requests to origin IP directly (force through CDN)
6. Verify security headers with securityheaders.com
7. Test auth, orders, newsletter end-to-end

---

## 11. Backup & Restore

```bash
# Backup (run daily via cron)
cp -r .data/ backups/data-$(date +%Y%m%d)/

# Restore
cp -r backups/data-20260101/ .data/
# Restart application
```

For PostgreSQL (planned):
```bash
pg_dump $DATABASE_URL > backup-$(date +%Y%m%d).sql
psql $DATABASE_URL < backup-20260101.sql
```
