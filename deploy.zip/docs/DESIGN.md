# Design Document — Broteach.com

> **Version:** 1.0  
> **Date:** 2026-09-25

---

## 1. Visual Style

### Color Palette

| Token | Value | Usage |
|-------|-------|-------|
| Background | `#030d1a` | Page/body background (deep navy) |
| Surface | `#051628` / `#0a1f35` | Card backgrounds |
| Primary | `#06b6d4` (cyan-500) | CTAs, highlights |
| Primary glow | `rgba(6,182,212,0.4)` | Shadow/glow effects |
| Accent | `#3b82f6` (blue-500) | Secondary buttons |
| Success | `#10b981` (emerald-500) | Success states |
| Text primary | `#f1f5f9` (slate-100) | Headings |
| Text secondary | `#94a3b8` (slate-400) | Body copy |
| Border | `rgba(6,182,212,0.2)` | Card borders, separators |

### Typography

| Font | Variable | Usage |
|------|----------|-------|
| Kantumruy Pro | `--font-kantumruy` | Khmer text, primary headings |
| Inter | `--font-inter` | Latin/English text, UI elements |

- Base size: 16px
- Scale: Tailwind CSS v4 responsive utilities (`text-sm`, `text-base`, `text-lg`, `text-xl`, `text-2xl`, `text-4xl`, `text-6xl`)
- Line height: `leading-relaxed` for body text

### Effects

- **Glassmorphism:** `backdrop-blur-md`, semi-transparent backgrounds on cards/modals
- **Glow shadows:** `shadow-[0_0_25px_rgba(6,182,212,0.5)]` on primary CTAs
- **Gradients:** `bg-gradient-to-tr from-cyan-500 to-blue-600` for primary elements
- **Micro-animations:** `transition-all`, `hover:scale-105`, `animate-ping` for live indicators
- **Selection:** `selection:bg-cyan-500 selection:text-white`

---

## 2. Pages

### 2.1 Home (`/`)

**Sections (top to bottom):**
1. `<Navbar>` — sticky, solid dark background, bilingual flag switcher, Telegram link, app download button
2. `<HeroSection>` — full-viewport, animated stats counters, announcement banner, dual CTA buttons
3. `<ProductsSection>` — grid (4/row desktop, 2/row mobile), category filter tabs, detail modal
4. `<RocketSection>` — reliability / server uptime feature showcase
5. `<HighlightsSection>` — 3D glassmorphic feature cards
6. `<PricingSection>` — horizontal pricing cards, order/demo action buttons
7. `<DynamicSections>` — CMS-managed sections (cards, FAQ, stats, banner)
8. `<NewsletterBanner>` — email capture
9. `<Footer>` — links, contact info, social
10. `<DemoOrderModal>` — overlay order form
11. Floating Telegram FAB

### 2.2 About (`/about`)

- Company story, mission, team introduction
- Data sourced from `SiteSettings.about*` CMS fields

### 2.3 Products (`/products`)

- Full product listing with `<ProductDetailModal>`
- Category filter tabs identical to home products section

### 2.4 Admin (`/admin`)

- Login screen with password field (hidden by default)
- Dashboard tabs: Overview | Products | Sections | Pricing | SEO | Settings | Orders | Subscribers
- Bilingual admin UI toggle (Khmer/English)
- Inline modals for product/section/pricing creation/editing
- Feedback toasts (success/error)

---

## 3. Components

| Component | Location | Description |
|-----------|----------|-------------|
| `Navbar` | `/src/components/Navbar.tsx` | Top navigation with language switcher |
| `HeroSection` | `/src/components/HeroSection.tsx` | Main hero with animated stats |
| `ProductsSection` | `/src/components/ProductsSection.tsx` | Product grid with category filter |
| `RocketSection` | `/src/components/RocketSection.tsx` | Server reliability section |
| `HighlightsSection` | `/src/components/HighlightsSection.tsx` | 3D highlight cards |
| `PricingSection` | `/src/components/PricingSection.tsx` | Pricing plans |
| `DynamicSections` | `/src/components/DynamicSections.tsx` | CMS-driven content sections |
| `NewsletterBanner` | `/src/components/NewsletterBanner.tsx` | Email subscription |
| `Footer` | `/src/components/Footer.tsx` | Site footer |
| `DemoOrderModal` | `/src/components/DemoOrderModal.tsx` | Order/demo inquiry form modal |
| `ProductDetailModal` | `/src/components/ProductDetailModal.tsx` | Product detail overlay |
| `LiveChatWidget` | `/src/components/LiveChatWidget.tsx` | Chat widget (unused per requirement) |
| `LanguageContext` | `/src/components/LanguageContext.tsx` | Global language state provider |
| `FlagIcons` | `/src/components/FlagIcons.tsx` | SVG flag icon components |

---

## 4. Responsive Behavior

| Breakpoint | Products grid | Navbar | Pricing |
|------------|---------------|--------|---------|
| Mobile (`< 640px`) | 2 columns | Hamburger / compact | Stacked cards |
| Tablet (`640px–1024px`) | 3 columns | Partial items | 2-column |
| Desktop (`> 1024px`) | 4 columns (5 on toggle) | Full nav | Row layout |

- All touch targets are minimum 44×44 px
- Modals scroll independently on mobile
- Footer collapses to single column on mobile

---

## 5. Accessibility

- Semantic HTML: `<nav>`, `<main>`, `<section>`, `<footer>`, `<h1>`–`<h6>` hierarchy
- `aria-label` on icon-only buttons
- `role="dialog"` and `aria-modal="true"` on modals
- Focus trap in open modals (keyboard accessible)
- Sufficient color contrast: text meets WCAG AA (4.5:1 minimum)
- `lang="km"` on `<html>` (matches primary language)
- All images include `alt` text
