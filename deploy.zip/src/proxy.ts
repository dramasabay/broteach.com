import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { verifyJwt, JWT_COOKIE_NAME } from "./lib/jwt";

/**
 * proxy.ts — Next.js 16 request interception (renamed from middleware.ts).
 *
 * SECURITY NOTES:
 * - This is an EARLY CHECK only. It provides a good user experience by redirecting
 *   unauthenticated users, but MUST NOT be relied upon as the sole security layer.
 * - Every protected Route Handler independently re-verifies the session.
 * - No hardcoded token values are accepted here. Only cryptographically verified JWTs.
 */
export async function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // ── Admin UI page protection ──────────────────────────────────────────────
  // Redirect unauthenticated visitors who try to directly access /admin
  if (pathname === "/admin" || pathname.startsWith("/admin/")) {
    const jwtToken = req.cookies.get(JWT_COOKIE_NAME)?.value;

    if (!jwtToken) {
      // No cookie present — redirect to the admin page with a flag so the UI shows login
      const url = req.nextUrl.clone();
      url.pathname = "/admin";
      url.searchParams.set("auth", "required");
      if (pathname !== "/admin") {
        // Redirect to /admin (the login form is embedded in the admin page)
        return NextResponse.redirect(url);
      }
      // Already on /admin — let the page render its own login form
      return NextResponse.next();
    }

    // Cookie present — verify it
    const verifyResult = await verifyJwt(jwtToken);
    if (!verifyResult.valid) {
      // Invalid/expired JWT — clear cookie and redirect to login
      const redirectUrl = req.nextUrl.clone();
      redirectUrl.pathname = "/admin";
      redirectUrl.searchParams.set("auth", "expired");
      const response = NextResponse.redirect(redirectUrl);
      response.cookies.delete(JWT_COOKIE_NAME);
      return response;
    }

    // Valid JWT — allow the admin page to load
    return NextResponse.next();
  }

  // ── Admin API protection ──────────────────────────────────────────────────
  // Allow unauthenticated POST to /api/admin/auth (the login endpoint itself)
  if (pathname === "/api/admin/auth" && req.method === "POST") {
    return NextResponse.next();
  }

  // All other /api/admin/* routes require a valid JWT
  if (pathname.startsWith("/api/admin")) {
    let token: string | undefined;

    // Check Authorization Bearer header first
    const authHeader = req.headers.get("authorization");
    if (authHeader?.startsWith("Bearer ")) {
      token = authHeader.slice(7).trim();
    }

    // Fall back to JWT cookie
    if (!token) {
      token = req.cookies.get(JWT_COOKIE_NAME)?.value;
    }

    if (!token) {
      return NextResponse.json(
        {
          success: false,
          message: "Unauthorized: Authentication required.",
          code: "ERR_UNAUTHORIZED",
        },
        { status: 401 }
      );
    }

    // Perform full cryptographic JWT verification.
    // No shortcuts — a 3-part string is not a valid JWT without HMAC verification.
    const verifyResult = await verifyJwt(token);
    if (!verifyResult.valid) {
      return NextResponse.json(
        {
          success: false,
          message: "Unauthorized: Invalid or expired token.",
          code: "ERR_UNAUTHORIZED",
        },
        { status: 401 }
      );
    }

    // Inject verified admin claims into request headers for downstream handlers
    const requestHeaders = new Headers(req.headers);
    requestHeaders.set("x-admin-authenticated", "true");
    if (verifyResult.payload?.role) {
      requestHeaders.set("x-admin-role", String(verifyResult.payload.role));
    }

    return NextResponse.next({
      request: { headers: requestHeaders },
    });
  }

  return NextResponse.next();
}

export default proxy;

export const config = {
  // Match /admin page and all /api/admin/* routes
  // Exclude static files and Next.js internals
  matcher: [
    "/admin",
    "/admin/:path*",
    "/api/admin/:path*",
  ],
};
