"use client";

import React, { useState, useEffect } from "react";
import { Cookie, X, Check } from "lucide-react";
import { useLanguage } from "./LanguageContext";

export const CookieConsent: React.FC = () => {
  const { language } = useLanguage();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    try {
      const consent = localStorage.getItem("broteach_cookie_consent");
      if (!consent) {
        // Small delay so page loads smoothly before showing banner
        const timer = setTimeout(() => setIsVisible(true), 1200);
        return () => clearTimeout(timer);
      }
    } catch {
      // localStorage may fail in private mode
    }
  }, []);

  const handleAccept = () => {
    try {
      localStorage.setItem("broteach_cookie_consent", "accepted");
    } catch {}
    setIsVisible(false);
  };

  const handleDecline = () => {
    try {
      localStorage.setItem("broteach_cookie_consent", "essential_only");
    } catch {}
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div
      role="region"
      aria-label="Cookie Consent Banner"
      className="fixed bottom-20 sm:bottom-6 left-3 sm:left-6 right-3 sm:right-auto max-w-lg z-50 animate-in fade-in slide-in-from-bottom-5 duration-300"
    >
      <div className="relative rounded-2xl bg-[#07162c]/95 backdrop-blur-xl border border-cyan-500/40 p-4 sm:p-5 shadow-[0_15px_40px_rgba(3,13,26,0.8)] text-white">
        {/* Glow corner */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 flex-shrink-0 shadow-md">
            <Cookie className="w-5 h-5" />
          </div>

          <div className="flex-1 space-y-1.5 pr-4">
            <h4 className="text-sm font-black text-white flex items-center gap-1.5">
              <span>{language === "km" ? "ការយល់ព្រមប្រើប្រាស់ Cookie" : "Cookie Preferences"}</span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              {language === "km"
                ? "យើងប្រើប្រាស់ខូឃីដើម្បីបង្កើនបទពិសោធន៍រុករករបស់អ្នក ធានាសុវត្ថិភាព និងចងចាំជម្រើសភាសា។"
                : "We use cookies to improve your browsing experience, provide security, and remember your language preferences."}
            </p>

            <div className="flex flex-wrap items-center gap-2 pt-2.5">
              <button
                type="button"
                onClick={handleAccept}
                className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold text-xs shadow-md shadow-cyan-600/30 flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Check className="w-3.5 h-3.5 stroke-[3]" />
                <span>{language === "km" ? "យល់ព្រមទាំងអស់" : "Accept All"}</span>
              </button>

              <button
                type="button"
                onClick={handleDecline}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
              >
                <span>{language === "km" ? "ចាំបាច់ប៉ុណ្ណោះ" : "Essential Only"}</span>
              </button>
            </div>
          </div>

          <button
            type="button"
            onClick={handleDecline}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
