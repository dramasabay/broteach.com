"use client";

import React from "react";
import { Check, Sparkles, ExternalLink, Send } from "lucide-react";
import { useLanguage } from "./LanguageContext";
import { PricingPlan } from "@/types";
import { getTelegramOrderUrl } from "@/lib/telegram";

interface PricingSectionProps {
  onSelectPlan?: (plan: PricingPlan) => void;
  telegramUsername?: string;
  plans?: PricingPlan[];
}

export const PricingSection: React.FC<PricingSectionProps> = ({
  telegramUsername = "broteach_support",
  plans: dynamicPlans,
}) => {
  const { language, t, plans: contextPlans } = useLanguage();
  const plans = dynamicPlans && dynamicPlans.length > 0 ? dynamicPlans : contextPlans;

  return (
    <section id="pricing" className="py-14 sm:py-20 bg-[#030d1a] text-white relative overflow-hidden border-t border-cyan-950/60">
      {/* Ambient Lighting Orbs */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[500px] h-[300px] bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-64 h-64 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center space-y-3 mb-10 sm:mb-12">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 text-xs font-bold shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>{language === "km" ? "កញ្ចប់តម្លៃមានតម្លាភាព" : "Transparent Pricing"}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white">
            {t.pricing.title}
          </h2>

          <p className="text-xs sm:text-sm text-slate-400 max-w-lg mx-auto">
            {t.pricing.subTitle}
          </p>
        </div>

        {/* Pricing Cards Grid — 2 col on mobile, 4 on lg */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5 items-stretch max-w-6xl mx-auto">
          {plans.map((plan) => {
            const isCompany = plan.id === "company" || plan.isPopular;
            const planName = language === "km" ? plan.nameKm : plan.nameEn;
            const period = language === "km" ? plan.periodKm : plan.periodEn;
            const features = language === "km" ? plan.featuresKm : plan.featuresEn;

            const telegramUrl =
              plan.orderUrl ||
              getTelegramOrderUrl({
                itemName: planName,
                price: plan.price,
                itemType: "plan",
                telegramUsername,
                lang: language,
              });

            const demoUrl = plan.demoUrl || "https://demo.broteach.com";

            return (
              <div
                key={plan.id}
                suppressHydrationWarning
                className={`relative rounded-xl sm:rounded-2xl flex flex-col justify-between transition-all duration-200 overflow-hidden ${
                  isCompany
                    ? "bg-gradient-to-b from-[#0e223d] to-[#071324] border-2 border-red-500/80 shadow-[0_10px_35px_rgba(239,68,68,0.2)] md:-translate-y-2 z-20"
                    : "bg-[#07162c]/90 border border-slate-800 hover:border-cyan-500/50 shadow-lg hover:-translate-y-1"
                }`}
              >
                {/* Popular Corner Ribbon */}
                {plan.isPopular && (
                  <div className="absolute top-2 right-2 sm:top-3 sm:right-3 z-30">
                    <div className="bg-gradient-to-r from-red-600 to-rose-600 text-white text-[9px] sm:text-[10px] font-black px-2 sm:px-2.5 py-0.5 rounded-full shadow-md flex items-center gap-1 uppercase tracking-wider">
                      <Sparkles className="w-2 sm:w-2.5 h-2 sm:h-2.5 fill-white" />
                      <span>{t.pricing.popularRibbon}</span>
                    </div>
                  </div>
                )}

                <div>
                  {/* Card Header */}
                  <div className="pt-4 px-3 sm:pt-5 sm:px-6">
                    <div
                      suppressHydrationWarning
                      className={`inline-block py-0.5 px-2 sm:py-1 sm:px-3 rounded-full font-black text-[10px] sm:text-[11px] uppercase tracking-wider shadow-sm mb-2 sm:mb-3 truncate max-w-full ${
                        plan.colorScheme === "red"
                          ? "bg-red-600/30 border border-red-500/50 text-red-300"
                          : "bg-slate-800 border border-slate-700 text-slate-300"
                      }`}
                    >
                      {planName}
                    </div>

                    {/* Price Display */}
                    <div className="flex items-baseline gap-0.5 mt-0.5 sm:mt-1">
                      <span className="text-base sm:text-xl font-bold text-cyan-400">$</span>
                      <span className="text-2xl sm:text-4xl lg:text-5xl font-black text-cyan-400 tracking-tight">
                        {plan.price}
                      </span>
                    </div>
                    <p className="text-[10px] sm:text-[11px] font-semibold text-slate-400 mt-0.5 uppercase tracking-wider">
                      {period}
                    </p>
                  </div>

                  {/* Divider */}
                  <div className="my-3 sm:my-4 border-t border-slate-800/80 px-3 sm:px-6" />

                  {/* Features Checklist */}
                  <div className="px-3 sm:px-6 space-y-1.5 sm:space-y-2 mb-4 sm:mb-6">
                    {features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-1.5 sm:gap-2 text-[11px] sm:text-xs text-slate-300">
                        <div className="flex-shrink-0 w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mt-0.5 shadow-sm">
                          <Check className="w-2 sm:w-2.5 h-2 sm:h-2.5 stroke-[3]" />
                        </div>
                        <span className="leading-tight sm:leading-snug">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Bottom Actions: responsive column on mobile, row on larger */}
                <div className="p-2.5 sm:p-5 pt-0 border-t border-slate-800/60 mt-auto">
                  <div className="flex flex-col sm:grid sm:grid-cols-2 gap-1.5 sm:gap-2 pt-2 sm:pt-3">
                    {/* Order Button */}
                    <a
                      href={telegramUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`py-1.5 sm:py-2 px-2 sm:px-2.5 rounded-lg sm:rounded-xl font-bold sm:font-black text-[11px] sm:text-xs shadow-md flex items-center justify-center gap-1 sm:gap-1.5 transition-all cursor-pointer truncate ${
                        isCompany
                          ? "bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white shadow-red-600/30"
                          : "bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-cyan-600/30"
                      }`}
                      title={t.pricing.orderButton}
                    >
                      <Send className="w-2.5 h-2.5 sm:w-3 sm:h-3 fill-current flex-shrink-0" />
                      <span className="truncate">{t.pricing.orderButton}</span>
                    </a>

                    {/* Live Demo Button */}
                    <a
                      href={demoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-1.5 sm:py-2 px-2 sm:px-2.5 rounded-lg sm:rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 hover:text-white border border-slate-700 hover:border-cyan-500/40 text-[11px] sm:text-xs font-semibold sm:font-bold transition-all flex items-center justify-center gap-1 sm:gap-1.5 cursor-pointer truncate"
                      title={t.pricing.demoButton}
                    >
                      <span className="truncate">{t.pricing.demoButton}</span>
                      <ExternalLink className="w-2.5 h-2.5 sm:w-3 sm:h-3 flex-shrink-0 opacity-80" />
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
