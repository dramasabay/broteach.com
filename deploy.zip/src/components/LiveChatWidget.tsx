"use client";

import React, { useState, useEffect, useRef } from "react";
import { MessageSquare, X, Send, Bot, User, Loader2, Sparkles } from "lucide-react";
import { ChatMessage } from "@/types";
import { useLanguage } from "./LanguageContext";

interface LiveChatWidgetProps {
  isOpen: boolean;
  onToggle: () => void;
  onOpenOrderModal?: () => void;
}

const initialKmMessage: ChatMessage = {
  id: "w-1",
  sender: "bot",
  text: "សួស្តីបាទ! ស្វាគមន៍មកកាន់ Broteach ។ តើខ្ញុំអាចជួយផ្តល់ព័ត៌មានអ្វីខ្លះទាក់ទងនឹងសេវាកម្មគេហទំព័រ ឬ Hosting ជូនលោកអ្នក?",
  timestamp: "10:00 AM",
  options: [
    { label: "សួរតម្លៃកញ្ចប់គេហទំព័រ", action: "សួរតម្លៃកញ្ចប់គេហទំព័រ" },
    { label: "សួរពី Hosting & Domain", action: "សួរពីសេវាកម្ម Hosting" },
    { label: "សុំការប្រឹក្សាផ្ទាល់", action: "ចង់បានការប្រឹក្សាផ្ទាល់" },
  ],
};

const initialEnMessage: ChatMessage = {
  id: "w-1",
  sender: "bot",
  text: "Hello! Welcome to Broteach. How can we assist you with our professional website design or cloud hosting packages today?",
  timestamp: "10:00 AM",
  options: [
    { label: "Website Pricing Plans", action: "Tell me about your pricing plans" },
    { label: "Hosting & Domain Specs", action: "What are your hosting specs?" },
    { label: "Contact Specialist", action: "I need direct consultation" },
  ],
};

export const LiveChatWidget: React.FC<LiveChatWidgetProps> = ({
  isOpen,
  onToggle,
  onOpenOrderModal,
}) => {
  const { language } = useLanguage();
  const [messages, setMessages] = useState<ChatMessage[]>([
    language === "km" ? initialKmMessage : initialEnMessage,
  ]);
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const idCounter = useRef(100);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const message = textToSend || inputText;
    if (!message.trim()) return;

    idCounter.current += 1;
    const currentId = idCounter.current;
    const timeString = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

    const userMsg: ChatMessage = {
      id: `u-${currentId}`,
      sender: "user",
      text: message,
      timestamp: timeString,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText("");
    setIsLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, lang: language }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        idCounter.current += 1;
        const botMsg: ChatMessage = {
          id: `b-${idCounter.current}`,
          sender: "bot",
          text: data.text,
          timestamp: data.timestamp || timeString,
          options: data.options,
        };
        setMessages((prev) => [...prev, botMsg]);
      }
    } catch {
      idCounter.current += 1;
      const errorMsg: ChatMessage = {
        id: `err-${idCounter.current}`,
        sender: "bot",
        text:
          language === "km"
            ? "សូមអភ័យទោស! មានបញ្ហាតភ្ជាប់ សូមព្យាយាមម្តងទៀត ឬទាក់ទងមកកាន់ 098 765 432 ។"
            : "Connection error. Please call (+855) 098 765 432.",
        timestamp: timeString,
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleOptionClick = (option: { label: string; action: string }) => {
    if (option.action === "order_now" || option.action === "select_plan_company") {
      onOpenOrderModal?.();
      return;
    }
    handleSendMessage(option.action);
  };

  return (
    <>
      {/* Floating Chat Trigger Button (Bottom Right - Matches Screenshot) */}
      <button
        onClick={onToggle}
        aria-label="Open Live Chat"
        className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-gradient-to-tr from-cyan-600 via-blue-600 to-indigo-600 text-white shadow-[0_10px_25px_rgba(6,182,212,0.5)] hover:shadow-[0_15px_35px_rgba(6,182,212,0.7)] hover:scale-110 active:scale-95 transition-all flex items-center justify-center cursor-pointer group"
      >
        <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-slate-900" />
        <MessageSquare className="w-6 h-6 group-hover:rotate-6 transition-transform" />
      </button>

      {/* Floating Chat Drawer Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-4 sm:right-8 z-50 w-[92vw] max-w-sm sm:max-w-md h-[520px] bg-[#0b1329] border border-cyan-500/40 rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-slideUp">
          {/* Header */}
          <div className="p-4 bg-gradient-to-r from-[#071329] to-[#0d2247] border-b border-cyan-900/40 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md">
                <Bot className="w-5 h-5" />
                <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-[#0b1329]" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <span>Broteach Support</span>
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                </h4>
                <p className="text-[11px] text-emerald-400 font-medium flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  {language === "km" ? "អនឡាញ ២៤/៧" : "Online 24/7"}
                </p>
              </div>
            </div>

            <button
              onClick={onToggle}
              className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-[#081022]/70">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${
                  msg.sender === "user" ? "justify-end" : "justify-start"
                }`}
              >
                {msg.sender === "bot" && (
                  <div className="w-7 h-7 rounded-full bg-cyan-600 flex items-center justify-center text-white flex-shrink-0 mt-1 shadow-sm">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div className="max-w-[80%] space-y-2">
                  <div
                    className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed whitespace-pre-wrap ${
                      msg.sender === "user"
                        ? "bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-br-xs shadow-md"
                        : "bg-[#14213d] text-slate-100 border border-slate-700/70 rounded-bl-xs shadow-sm"
                    }`}
                  >
                    {msg.text}
                  </div>

                  {/* Suggestion Options */}
                  {msg.options && msg.options.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {msg.options.map((opt, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleOptionClick(opt)}
                          className="px-2.5 py-1 rounded-lg bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-500/30 text-cyan-300 text-[11px] font-semibold transition-colors text-left"
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  )}

                  <span className="block text-[10px] text-slate-500 px-1">
                    {msg.timestamp}
                  </span>
                </div>

                {msg.sender === "user" && (
                  <div className="w-7 h-7 rounded-full bg-slate-700 flex items-center justify-center text-white flex-shrink-0 mt-1 shadow-sm">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}

            {isLoading && (
              <div className="flex items-center gap-2 text-xs text-cyan-400 bg-[#14213d] p-3 rounded-2xl w-32 border border-slate-700">
                <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
                <span>Typing...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Chat Input Bar */}
          <div className="p-3 border-t border-slate-800 bg-[#070e20]">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={
                  language === "km"
                    ? "សរសេរសាររបស់អ្នកនៅទីនេះ..."
                    : "Type your message here..."
                }
                className="flex-1 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 text-xs sm:text-sm focus:outline-none focus:border-cyan-400"
              />
              <button
                type="submit"
                disabled={!inputText.trim() || isLoading}
                className="p-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors disabled:opacity-50 cursor-pointer"
              >
                <Send className="w-4 h-4 fill-slate-950" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
