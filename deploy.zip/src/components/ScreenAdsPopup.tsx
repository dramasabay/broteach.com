"use client";

import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { X, Gift, ArrowRight, Clock } from "lucide-react";
import { useLanguage } from "./LanguageContext";

interface ScreenAdsPopupProps {
  settings?: {
    popupActive?: boolean;
    popupTitleKm?: string;
    popupTitleEn?: string;
    popupDescKm?: string;
    popupDescEn?: string;
    popupBadgeKm?: string;
    popupBadgeEn?: string;
    popupImageUrl?: string;
    popupButtonTextKm?: string;
    popupButtonTextEn?: string;
    popupButtonUrl?: string;
    popupCooldownMinutes?: number;
    popupAutoCloseSeconds?: number;
    popupTriggerScrollPx?: number;
  };
}

export const ScreenAdsPopup: React.FC<ScreenAdsPopupProps> = ({ settings: propSettings }) => {
  const pathname = usePathname();
  const { language } = useLanguage();
  const [fetchedSettings, setFetchedSettings] = useState<ScreenAdsPopupProps["settings"] | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const [countdown, setCountdown] = useState<number>(5);
  const [isHovered, setIsHovered] = useState(false);
  const triggeredRef = useRef<boolean>(false);

  const settings = propSettings || fetchedSettings;

  // Fetch updated settings if not passed via props
  useEffect(() => {
    if (propSettings) return;

    let mounted = true;
    fetch(`/api/content?t=${Date.now()}`)
      .then((res) => res.json())
      .then((data) => {
        if (mounted && data.settings) {
          setFetchedSettings(data.settings);
        }
      })
      .catch(() => {});

    return () => {
      mounted = false;
    };
  }, [propSettings]);

  // Check scroll trigger and 30-minute (or dashboard-configured) cooldown
  useEffect(() => {
    if (pathname && pathname.startsWith("/admin")) return;
    if (!settings || !settings.popupActive) return;

    const cooldownMinutes = settings.popupCooldownMinutes ?? 30;
    const cooldownMs = cooldownMinutes * 60 * 1000;
    const triggerPx = settings.popupTriggerScrollPx ?? 200;

    const checkAndTrigger = () => {
      if (triggeredRef.current) return;

      const lastShown = typeof window !== "undefined" ? localStorage.getItem("broteach_popup_last_shown_time") : null;
      if (lastShown) {
        const elapsed = Date.now() - parseInt(lastShown, 10);
        if (elapsed < cooldownMs) {
          return;
        }
      }

      if (window.scrollY >= triggerPx) {
        triggeredRef.current = true;
        const autoCloseSec = settings.popupAutoCloseSeconds ?? 5;
        setCountdown(autoCloseSec);
        setIsOpen(true);
        if (typeof window !== "undefined") {
          localStorage.setItem("broteach_popup_last_shown_time", Date.now().toString());
        }
      }
    };

    window.addEventListener("scroll", checkAndTrigger, { passive: true });
    checkAndTrigger();

    return () => {
      window.removeEventListener("scroll", checkAndTrigger);
    };
  }, [settings, pathname]);

  // Auto-close countdown timer
  useEffect(() => {
    if (!isOpen || isHovered) return;

    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsOpen(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, isHovered]);

  if (!isOpen || !settings || !settings.popupActive || (pathname && pathname.startsWith("/admin"))) {
    return null;
  }

  const isKm = language === "km";
  const title = isKm ? (settings.popupTitleKm || settings.popupTitleEn) : (settings.popupTitleEn || settings.popupTitleKm);
  const desc = isKm ? (settings.popupDescKm || settings.popupDescEn) : (settings.popupDescEn || settings.popupDescKm);
  const badge = isKm ? (settings.popupBadgeKm || settings.popupBadgeEn || "🎁 កាដូពិសេស") : (settings.popupBadgeEn || settings.popupBadgeKm || "🎁 SPECIAL OFFER");
  const buttonText = isKm ? (settings.popupButtonTextKm || "ពិនិត្យមើលឥឡូវនេះ") : (settings.popupButtonTextEn || "Explore Now");
  const buttonUrl = settings.popupButtonUrl || "/pricing";
  const totalSeconds = settings.popupAutoCloseSeconds ?? 5;
  const progressPercent = Math.max(0, Math.min(100, (countdown / totalSeconds) * 100));

  if (!title) return null;

  const handleClose = () => {
    setIsOpen(false);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-300"
      onClick={handleClose}
    >
      <div
        className="relative w-full max-w-lg bg-gradient-to-b from-[#0f233f] via-[#07162c] to-[#030d1a] border border-cyan-500/40 rounded-3xl p-6 sm:p-8 shadow-[0_0_60px_rgba(6,182,212,0.35)] text-center overflow-hidden"
        onClick={(e) => e.stopPropagation()}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Glow decoration */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-cyan-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-red-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Top bar: Auto-close timer indicator & Close Button */}
        <div className="flex items-center justify-between gap-2 mb-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold bg-slate-800/80 border border-slate-700/60 text-slate-300">
            <Clock className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
            <span>
              {isKm
                ? `បិទដោយស្វ័យប្រវត្តិក្នុង ${countdown}វិនាទី`
                : `Auto close in ${countdown}s`}
            </span>
          </div>

          <button
            onClick={handleClose}
            className="p-1.5 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700/60"
            aria-label="Close popup"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Badge */}
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-gradient-to-r from-red-500/25 to-amber-500/25 text-yellow-300 border border-yellow-400/40 mb-3.5 shadow-sm">
          <Gift className="w-3.5 h-3.5 text-yellow-400 animate-bounce" />
          <span>{badge}</span>
        </div>

        {/* Image if provided */}
        {settings.popupImageUrl && (
          <div className="mb-4 rounded-2xl overflow-hidden border border-cyan-500/30 max-h-48 flex items-center justify-center bg-black/40">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={settings.popupImageUrl}
              alt="Promo"
              className="w-full h-full object-cover max-h-48"
            />
          </div>
        )}

        {/* Title */}
        <h3 className="text-xl sm:text-2xl font-black text-white mb-2.5 tracking-tight leading-snug">
          {title}
        </h3>

        {/* Description */}
        {desc && (
          <p className="text-xs sm:text-sm text-slate-300 mb-6 leading-relaxed">
            {desc}
          </p>
        )}

        {/* Action Button & Dismiss Button */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link
            href={buttonUrl}
            onClick={handleClose}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 text-white font-bold text-sm shadow-[0_0_20px_rgba(6,182,212,0.4)] hover:brightness-110 active:scale-95 transition-all"
          >
            <span>{buttonText}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
          <button
            onClick={handleClose}
            className="w-full sm:w-auto px-5 py-3 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800/50 transition-colors"
          >
            {isKm ? "បិទផ្ទាំងនេះ" : "Dismiss"}
          </button>
        </div>

        {/* Animated Countdown Progress Bar at Bottom */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-slate-800 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 transition-all duration-1000 ease-linear"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>
    </div>
  );
};
