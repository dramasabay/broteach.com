"use client";

import React, { createContext, useContext, useState, useSyncExternalStore } from "react";
import { Language } from "@/types";
import { siteContent, pricingPlans } from "@/lib/data";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  t: typeof siteContent.km;
  plans: typeof pricingPlans;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const listeners = new Set<() => void>();

function subscribe(callback: () => void) {
  listeners.add(callback);
  window.addEventListener("storage", callback);
  return () => {
    listeners.delete(callback);
    window.removeEventListener("storage", callback);
  };
}

function getSnapshot(): Language {
  if (typeof window === "undefined") return "km";
  try {
    const saved = localStorage.getItem("broteach_lang") as Language;
    return saved === "km" || saved === "en" ? saved : "km";
  } catch {
    return "km";
  }
}

function getServerSnapshot(): Language {
  return "km";
}

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const clientLanguage = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  const [overrideLanguage, setOverrideLanguage] = useState<Language | null>(null);

  const language = overrideLanguage ?? clientLanguage;

  const setLanguage = (lang: Language) => {
    setOverrideLanguage(lang);
    try {
      localStorage.setItem("broteach_lang", lang);
      if (typeof document !== "undefined") {
        document.documentElement.lang = lang;
      }
      listeners.forEach((listener) => listener());
    } catch {}
  };

  const toggleLanguage = () => {
    const next = language === "km" ? "en" : "km";
    setLanguage(next);
  };

  const t = siteContent[language];

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        toggleLanguage,
        t,
        plans: pricingPlans,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
