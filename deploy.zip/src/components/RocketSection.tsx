"use client";

import React, { useState } from "react";
import {
  Shield,
  Cpu,
  Activity,
  Zap,
  CheckCircle2,
  Radio,
} from "lucide-react";
import { useLanguage } from "./LanguageContext";

export const RocketSection: React.FC = () => {
  const { language } = useLanguage();
  const [activeTab, setActiveTab] = useState<"compute" | "security">("compute");

  const telemetryNodes = [
    { nameKm: "ភ្នំពេញ", nameEn: "Phnom Penh", ping: "8ms", color: "emerald" },
    { nameKm: "បាងកក", nameEn: "Bangkok", ping: "19ms", color: "emerald" },
    { nameKm: "សិង្ហបុរី", nameEn: "Singapore", ping: "24ms", color: "cyan" },
    { nameKm: "តូក្យូ", nameEn: "Tokyo", ping: "52ms", color: "cyan" },
  ];

  const architectureDetails = {
    compute: {
      titleKm: "ម៉ាស៊ីនមេ Cloud NVMe Gen4 & CPU កម្រិតខ្ពស់",
      titleEn: "Enterprise Cloud NVMe Gen4 & High-Frequency Compute",
      descKm:
        "ដំណើរការដោយអង្គគណនា AMD EPYC™ ជំនាន់ចុងក្រោយ និងថាសរឹង PCIe 4.0 NVMe RAID-10 ដែលធានាបាននូវល្បឿនអាន/សរសេរទិន្នន័យលឿនរហូតដល់ ៧,០០០ MB/s និងការឆ្លើយតបយ៉ាងរហ័សចំពោះរាល់ការស្នើសុំពីអ្នកប្រើប្រាស់។",
      descEn:
        "Powered by latest-generation AMD EPYC™ enterprise processors and PCIe 4.0 NVMe RAID-10 enterprise arrays, delivering blistering throughput up to 7,000 MB/s and instant request processing under heavy traffic.",
      specs: [
        { labelKm: "អង្គគណនា (CPU)", labelEn: "Processor", val: "AMD EPYC™ / Xeon 3.4GHz+ Turbo" },
        { labelKm: "ថាសរឹង (Storage)", labelEn: "Storage", val: "Enterprise PCIe Gen4 NVMe RAID-10" },
        { labelKm: "អង្គចងចាំ (RAM)", labelEn: "Memory", val: "DDR5 ECC Registered High-Bandwidth" },
        { labelKm: "ល្បឿនបណ្តាញ", labelEn: "Network Uplink", val: "40 Gbps Redundant Fiber Backbone" },
      ],
      icon: Cpu,
    },
    security: {
      titleKm: "ខែលការពារ DDoS L3/L4/L7 & Web Application Firewall",
      titleEn: "Multi-Layer DDoS Scrubbing & Next-Gen WAF Protection",
      descKm:
        "ការពារគេហទំព័ររបស់អ្នកពីការវាយប្រហារបណ្តាញគ្រប់ទម្រង់ ជាមួយប្រព័ន្ធស្រូបទាញ និងកម្ចាត់ចរាចរណ៍ក្លែងក្លាយទំហំរហូតដល់ 3.2 Tbps រួមទាំងប្រព័ន្ធត្រួតពិនិត្យកូដ និងវិញ្ញាបនបត្រ SSL ស្វ័យប្រវត្តិ។",
      descEn:
        "Enterprise DDoS mitigation capable of absorbing up to 3.2 Tbps volumetric attacks across Layer 3, 4, and 7, coupled with real-time Web Application Firewall (WAF) blocking SQL injection and XSS.",
      specs: [
        { labelKm: "សមត្ថភាព DDoS", labelEn: "DDoS Capacity", val: "3.2 Tbps Anycast Scrubbing" },
        { labelKm: "ជញ្ជាំងភ្លើង (WAF)", labelEn: "Web App Firewall", val: "OWASP Top-10 Rule Enforcement" },
        { labelKm: "វិញ្ញាបនបត្រ SSL", labelEn: "SSL / TLS", val: "Auto-Renewing 256-Bit SSL Free" },
        { labelKm: "ត្រួតពិនិត្យ AI", labelEn: "Threat Monitoring", val: "24/7 AI-Powered Intrusion Detection" },
      ],
      icon: Shield,
    },
  };

  const currentTabInfo = architectureDetails[activeTab];
  const TabIcon = currentTabInfo.icon;

  return (
    <section id="hosting" className="py-20 md:py-28 bg-[#020914] text-white relative overflow-hidden border-t border-cyan-950/60">
      {/* Background */}
      <div className="absolute top-1/4 left-1/4 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-600/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-10 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(#0891b2_1px,transparent_1px)] [background-size:32px_32px] opacity-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-semibold shadow-lg">
            <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span>{language === "km" ? "ហេដ្ឋារចនាសម្ព័ន្ធបច្ចេកវិទ្យា" : "Enterprise Technology Infrastructure"}</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-cyan-200 leading-snug">
            {language === "km"
              ? "ម៉ាស៊ីនបម្រើ Cloud NVMe ល្បឿនលឿន & ប្រព័ន្ធសុវត្ថិភាព"
              : "High-Speed NVMe Cloud & Enterprise Security"}
          </h2>

          <p className="text-sm sm:text-base text-slate-300/90 max-w-3xl mx-auto leading-relaxed">
            {language === "km"
              ? "បង្កើតឡើងដើម្បីធានាថាគេហទំព័ររបស់អ្នកដំណើរការលឿន សុវត្ថិភាព ១០០% គ្មានការផ្អាក និងឆ្លើយតបបានលើអ្នកប្រើប្រាស់រាប់ពាន់នាក់ក្នុងពេលដំណាលគ្នា។"
              : "Engineered on enterprise-grade hardware for lightning-fast loading, 99.99% uptime, multi-layer DDoS mitigation, and uninterrupted operations."}
          </p>
        </div>

        {/* 2-Tab Navigation — responsive scroll on mobile */}
        <div className="flex justify-center mb-10">
          <div className="inline-flex p-1.5 rounded-2xl bg-[#041122] border border-cyan-500/30 shadow-xl gap-2">
            {(["compute", "security"] as const).map((tab) => {
              const info = architectureDetails[tab];
              const Icon = info.icon;
              const isActive = activeTab === tab;
              return (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-bold transition-all cursor-pointer ${
                    isActive
                      ? "bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-lg shadow-cyan-600/30"
                      : "text-slate-400 hover:text-white hover:bg-white/5"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab === "compute"
                    ? (language === "km" ? "Cloud & NVMe" : "NVMe Compute")
                    : (language === "km" ? "សុវត្ថិភាព & DDoS" : "DDoS & Security")
                  }</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          {/* Left: Datacenter Rack */}
          <div className="lg:col-span-6 space-y-5">
            <div className="relative rounded-3xl bg-gradient-to-b from-[#06152a] to-[#030d1d] border border-cyan-500/30 p-6 shadow-[0_20px_50px_rgba(0,0,0,0.8)] overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

              {/* Server Rack Top Bar */}
              <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div className="w-3 h-3 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
                    Tier-3 Data Center Cluster
                  </span>
                </div>
                <div className="flex items-center gap-2 text-[11px] text-cyan-400 font-mono bg-cyan-950/70 border border-cyan-500/30 px-2.5 py-1 rounded-full">
                  <Activity className="w-3 h-3" />
                  <span>SLA 99.99%</span>
                </div>
              </div>

              {/* 3 Blade Server Units */}
              <div className="space-y-3">
                {[1, 2, 3].map((blade) => (
                  <div
                    key={blade}
                    className="p-3.5 rounded-2xl bg-[#030a16] border border-slate-800/80 hover:border-cyan-500/40 transition-all flex items-center justify-between shadow-inner"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex flex-col gap-1">
                        <div className="w-2 h-2 rounded-full bg-emerald-400 animate-led" />
                        <div className="w-2 h-2 rounded-full bg-cyan-400 animate-led delay-150" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-bold text-white">
                            NODE-0{blade}.BROTEACH.CLOUD
                          </span>
                          <span className="text-[10px] px-2 rounded bg-emerald-500/20 text-emerald-300 font-semibold">
                            ACTIVE
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                          AMD EPYC • 64 Cores • NVMe RAID-10 • 40GbE
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {[...Array(4)].map((_, i) => (
                        <div
                          key={i}
                          className={`w-2 h-5 rounded-sm ${
                            i % 2 === 0 ? "bg-cyan-500/80 animate-pulse" : "bg-emerald-500/70 animate-led"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {/* Regional Latency */}
              <div className="mt-5 pt-4 border-t border-slate-800">
                <div className="flex items-center gap-1.5 mb-3">
                  <Radio className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="text-xs font-bold text-slate-300">
                    {language === "km" ? "ល្បឿនបញ្ជូនទិន្នន័យក្នុងតំបន់" : "Regional Edge Latency"}
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {telemetryNodes.map((node, i) => (
                    <div key={i} className="p-2.5 rounded-xl bg-[#020712] border border-slate-800 text-center">
                      <p className="text-sm font-mono font-black text-cyan-400">{node.ping}</p>
                      <p className="text-[10px] text-slate-300 font-medium truncate mt-0.5">
                        {language === "km" ? node.nameKm : node.nameEn}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Right: Architecture Details */}
          <div className="lg:col-span-6 space-y-6">
            {/* Active Tab Icon Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 text-xs font-semibold">
              <TabIcon className="w-3.5 h-3.5 text-cyan-400" />
              <span>{language === "km" ? "លក្ខណៈបច្ចេកវិទ្យាស្នូល" : "Core Architecture Specs"}</span>
            </div>

            <h3 className="text-2xl sm:text-3xl font-black text-white leading-tight">
              {language === "km" ? currentTabInfo.titleKm : currentTabInfo.titleEn}
            </h3>

            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              {language === "km" ? currentTabInfo.descKm : currentTabInfo.descEn}
            </p>

            {/* Spec Grid: 2-col on all sizes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
              {currentTabInfo.specs.map((spec, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-2xl bg-[#061427]/80 border border-slate-800 hover:border-cyan-500/40 transition-all group"
                >
                  <div className="flex items-center gap-2 mb-1">
                    <CheckCircle2 className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                    <span className="text-xs font-bold text-slate-400 group-hover:text-cyan-300 transition-colors">
                      {language === "km" ? spec.labelKm : spec.labelEn}
                    </span>
                  </div>
                  <p className="text-sm font-black text-white pl-6">{spec.val}</p>
                </div>
              ))}
            </div>

            {/* Performance Assurance Banner */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-[#0b213f] to-[#07172c] border border-cyan-500/40 flex items-center gap-3 shadow-lg">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/50 flex items-center justify-center text-cyan-400 flex-shrink-0">
                <Zap className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  {language === "km" ? "ការធានាល្បឿន & គុណភាព" : "Performance & Reliability SLA"}
                </h4>
                <p className="text-xs text-slate-300 mt-0.5">
                  {language === "km"
                    ? "ល្បឿនផ្ទុកទំព័រក្រោម ១ វិនាទី និងការបម្រុងទុកទិន្នន័យប្រចាំថ្ងៃ"
                    : "Sub-second load times & automated daily disaster recovery backups."}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Reliability Stats Strip */}
        <div className="mt-14 pt-8 grid grid-cols-2 lg:grid-cols-4 gap-4 border-t border-slate-800/80">
          {[
            { val: "99.99%", label: "Uptime SLA", sub: language === "km" ? "ធានាមិនរអាក់រអួល" : "High Availability", color: "text-cyan-400" },
            { val: "< 0.4s", label: "Avg TTFB", sub: language === "km" ? "ល្បឿនផ្ទុកទំព័រ" : "Blazing Fast", color: "text-emerald-400" },
            { val: "Zero", label: "Downtime Migration", sub: language === "km" ? "ផ្ទេរទិន្នន័យគ្មានបាត់" : "Seamless Transfer", color: "text-amber-400" },
            { val: "24/7", label: "NOC Support", sub: language === "km" ? "គាំទ្របច្ចេកទេស" : "Direct Support", color: "text-purple-400" },
          ].map((s, i) => (
            <div key={i} className="p-5 rounded-2xl bg-gradient-to-b from-[#06162d]/90 to-[#030d1d] border border-slate-800 text-center hover:border-cyan-500/40 transition-all">
              <p className={`text-2xl sm:text-3xl font-black ${s.color}`}>{s.val}</p>
              <p className="text-xs text-slate-300 font-bold mt-1">{s.label}</p>
              <p className="text-[11px] text-slate-500 mt-0.5">{s.sub}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
