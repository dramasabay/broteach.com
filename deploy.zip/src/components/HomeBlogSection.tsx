"use client";

import React from "react";
import Link from "next/link";
import { BookOpen, Clock, ArrowRight, Calendar, Sparkles } from "lucide-react";
import { BlogPostItem } from "@/types";
import { useLanguage } from "./LanguageContext";

interface HomeBlogSectionProps {
  posts?: BlogPostItem[];
}

export const HomeBlogSection: React.FC<HomeBlogSectionProps> = ({ posts = [] }) => {
  const { language } = useLanguage();

  // Show up to 3 published posts on homepage (or default)
  const displayPosts = posts
    .filter((p) => p.isPublished !== false)
    .slice(0, 3);

  if (displayPosts.length === 0) {
    return null;
  }

  return (
    <section id="blog" className="py-20 md:py-28 bg-[#030d1a] relative overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/70 border border-cyan-500/30 text-cyan-300 text-xs font-semibold shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>{language === "km" ? "ចំណេះដឹង & អត្ថបទឌីជីថល" : "Knowledge & Insights"}</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white">
              {language === "km" ? "អត្ថបទ និងបច្ចេកវិទ្យាថ្មីៗ" : "Latest Articles & News"}
            </h2>
            <p className="text-sm sm:text-base text-slate-400 max-w-2xl leading-relaxed">
              {language === "km"
                ? "ស្វែងយល់ពីគន្លឹះបង្កើតគេហទំព័រ សុវត្ថិភាព Cloud Hosting និងដំណោះស្រាយអាជីវកម្មឌីជីថល"
                : "Explore our latest web engineering guides, cloud performance optimizations, and digital insights."}
            </p>
          </div>

          <Link
            href="/blog"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-cyan-500/30 bg-cyan-950/40 hover:bg-cyan-900/50 text-cyan-300 hover:text-white font-semibold text-xs sm:text-sm transition-all shadow-md group shrink-0 self-start md:self-end"
          >
            <BookOpen className="w-4 h-4 text-cyan-400" />
            <span>{language === "km" ? "មើលអត្ថបទទាំងអស់" : "View All Articles"}</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {/* Blog Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {displayPosts.map((post) => {
            const title = (language === "km" ? post.titleKm : post.titleEn) || post.titleEn;
            const excerpt = (language === "km" ? post.excerptKm : post.excerptEn) || post.excerptEn;
            const category = (language === "km" ? post.categoryKm : post.categoryEn) || post.category;
            const readTime = post.readTime || `${post.readingTime || 5} min read`;

            return (
              <article
                key={post.id || post.slug}
                className="group relative flex flex-col rounded-2xl bg-[#061528]/90 border border-slate-800/80 hover:border-cyan-500/50 transition-all duration-300 overflow-hidden shadow-lg hover:shadow-[0_10px_30px_rgba(6,182,212,0.15)] hover:-translate-y-1"
              >
                {/* Visual Header / Cover */}
                <div
                  className={`h-44 sm:h-48 w-full relative overflow-hidden bg-gradient-to-br ${
                    post.coverGradient || "from-cyan-700 via-blue-800 to-indigo-950"
                  } p-6 flex flex-col justify-between`}
                >
                  {post.coverImage ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={post.coverImage}
                      alt={title}
                      className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-500"
                    />
                  ) : (
                    <div className="absolute inset-0 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px] opacity-25" />
                  )}

                  <div className="relative z-10 flex items-center justify-between">
                    <span className="px-3 py-1 rounded-full bg-slate-950/70 backdrop-blur-md border border-white/10 text-cyan-300 text-[11px] font-bold tracking-wider uppercase">
                      {category}
                    </span>
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-950/60 backdrop-blur-md text-slate-300 text-[11px]">
                      <Clock className="w-3 h-3 text-cyan-400" />
                      <span>{readTime}</span>
                    </span>
                  </div>

                  <div className="relative z-10 text-3xl select-none">{post.icon || "💡"}</div>
                </div>

                {/* Card Body */}
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2.5">
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <Calendar className="w-3.5 h-3.5 text-slate-500" />
                      <span>{post.date}</span>
                    </div>

                    <Link href={`/blog/${post.slug}`}>
                      <h3 className="text-lg sm:text-xl font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-2 leading-snug">
                        {title}
                      </h3>
                    </Link>

                    <p className="text-xs sm:text-sm text-slate-400 line-clamp-3 leading-relaxed">
                      {excerpt}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between">
                    <span className="text-xs text-slate-400 font-medium">
                      {post.author || "Broteach Team"}
                    </span>

                    <Link
                      href={`/blog/${post.slug}`}
                      className="inline-flex items-center gap-1.5 text-xs font-bold text-cyan-400 group-hover:text-cyan-300 group-hover:translate-x-0.5 transition-all"
                    >
                      <span>{language === "km" ? "អានបន្ត" : "Read More"}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
};
