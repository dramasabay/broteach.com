"use client";

import React from "react";
import { Headphones, ShieldCheck, Zap, Sparkles, Award, ArrowRight } from "lucide-react";
import { useLanguage } from "./LanguageContext";

export const HighlightsSection: React.FC = () => {
  const { language, t } = useLanguage();

  const cards = [
    {
      key: 0,
      accent: "purple",
      gradientFrom: "#7c3aed",
      gradientTo: "#4f46e5",
      borderColor: "border-purple-500/40",
      glowColor: "shadow-purple-500/20",
      badgeBg: "bg-purple-500/15 border-purple-500/30",
      badgeText: "text-purple-300",
      titleHover: "group-hover:text-purple-300",
      icon: Headphones,
      tagBg: "bg-purple-900/60",
      tagText: "text-purple-300",
      tagBorder: "border-purple-500/40",
      svgRings: {
        outer: "url(#pedestal1)",
        outerStroke: "#c084fc",
        inner: "#581c87",
      },
      badge: language === "km" ? "ការគាំទ្រ ២៤/៧" : "24/7 Support",
    },
    {
      key: 1,
      accent: "pink",
      gradientFrom: "#ec4899",
      gradientTo: "#be185d",
      borderColor: "border-pink-500/40",
      glowColor: "shadow-pink-500/20",
      badgeBg: "bg-pink-500/15 border-pink-500/30",
      badgeText: "text-pink-300",
      titleHover: "group-hover:text-pink-300",
      icon: ShieldCheck,
      tagBg: "bg-rose-900/60",
      tagText: "text-rose-300",
      tagBorder: "border-rose-500/40",
      svgRings: {
        outer: "url(#pedestal2)",
        outerStroke: "#f472b6",
        inner: "#831843",
      },
      badge: "100% Guaranteed",
      featured: true,
    },
    {
      key: 2,
      accent: "cyan",
      gradientFrom: "#06b6d4",
      gradientTo: "#3b82f6",
      borderColor: "border-cyan-500/40",
      glowColor: "shadow-cyan-500/20",
      badgeBg: "bg-cyan-500/15 border-cyan-500/30",
      badgeText: "text-cyan-300",
      titleHover: "group-hover:text-cyan-300",
      icon: Zap,
      tagBg: "bg-cyan-900/60",
      tagText: "text-cyan-300",
      tagBorder: "border-cyan-500/40",
      svgRings: {
        outer: "url(#pedestal3)",
        outerStroke: "#38bdf8",
        inner: "#164e63",
      },
      badge: language === "km" ? "ល្បឿនលឿន" : "Lightning Speed",
    },
  ];

  return (
    <section id="features" className="py-20 md:py-32 purple-section-bg text-white relative overflow-hidden">
      {/* Background Lighting */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-purple-600/12 rounded-full blur-[130px] pointer-events-none" />
      <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-purple-500/50 to-transparent" />
      <div className="absolute bottom-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-purple-500/40 to-transparent" />
      {/* Extra ambient orbs */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-pink-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-20 right-10 w-72 h-72 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Heading */}
        <div className="text-center space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-900/50 border border-purple-500/40 text-purple-300 text-xs font-semibold backdrop-blur-sm shadow-lg shadow-purple-900/30">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>{language === "km" ? "គុណសម្បត្តិលេចធ្លោ" : "Core Competencies"}</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-200 via-white to-pink-200 tracking-tight">
            {t.highlights.sectionTitle}
          </h2>

          <p className="text-sm text-purple-200/70 max-w-xl mx-auto leading-relaxed">
            {language === "km"
              ? "ប្រព័ន្ធគ្រប់គ្រងគេហទំព័រ ហេដ្ឋារចនាសម្ព័ន្ធ Cloud និងការគាំទ្រប្រកបដោយជំនាញ"
              : "Website management, cloud infrastructure and expert support — all in one."}
          </p>

          <div className="flex items-center justify-center gap-3 pt-1">
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-purple-500" />
            <div className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
            <div className="h-px w-16 bg-gradient-to-r from-purple-500 to-pink-500" />
            <div className="w-2 h-2 rounded-full bg-pink-400 animate-pulse" />
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-pink-500" />
          </div>
        </div>

        {/* 3 Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {cards.map((card) => {
            const MetricIcon = card.icon;
            const isFeatured = card.featured;
            return (
              <div
                key={card.key}
                className={`relative rounded-3xl p-8 flex flex-col items-center text-center transition-all duration-300 hover:-translate-y-3 group cursor-default overflow-hidden
                  ${isFeatured
                    ? `glass-card-purple border-2 ${card.borderColor} shadow-2xl ${card.glowColor} md:-translate-y-2`
                    : `glass-card-purple border ${card.borderColor} shadow-xl ${card.glowColor}`
                  }`}
              >
                {/* Featured top ribbon */}
                {isFeatured && (
                  <div className="absolute -top-0 left-0 right-0 h-1 bg-gradient-to-r from-pink-500 via-rose-400 to-pink-500 rounded-t-3xl" />
                )}
                {isFeatured && (
                  <div className="absolute top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-pink-500 to-rose-500 text-white text-[11px] font-bold tracking-wider shadow-lg uppercase whitespace-nowrap">
                    100% Guaranteed
                  </div>
                )}

                {/* Top ambient glow */}
                <div
                  className="absolute -top-20 left-1/2 -translate-x-1/2 w-48 h-48 rounded-full blur-3xl opacity-30 pointer-events-none"
                  style={{ background: `radial-gradient(circle, ${card.gradientFrom}, transparent)` }}
                />

                {/* 3D Hologram SVG */}
                <div className={`w-36 h-36 relative flex items-center justify-center mb-6 ${isFeatured ? "mt-6" : ""}`}>
                  <svg viewBox="0 0 160 160" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
                    <defs>
                      {card.key === 0 && (
                        <>
                          <linearGradient id="pedestal1" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" stopColor="#a855f7" stopOpacity="0.8" />
                            <stop offset="100%" stopColor="#6b21a8" stopOpacity="0.4" />
                          </linearGradient>
                          <linearGradient id="shieldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stopColor="#38bdf8" />
                            <stop offset="100%" stopColor="#6366f1" />
                          </linearGradient>
                        </>
                      )}
                      {card.key === 1 && (
                        <>
                          <linearGradient id="pedestal2" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" stopColor="#ec4899" stopOpacity="0.8" />
                            <stop offset="100%" stopColor="#9d174d" stopOpacity="0.4" />
                          </linearGradient>
                          <linearGradient id="badgeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stopColor="#fbbf24" />
                            <stop offset="100%" stopColor="#f59e0b" />
                          </linearGradient>
                        </>
                      )}
                      {card.key === 2 && (
                        <>
                          <linearGradient id="pedestal3" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.8" />
                            <stop offset="100%" stopColor="#0e7490" stopOpacity="0.4" />
                          </linearGradient>
                          <linearGradient id="boltGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stopColor="#22d3ee" />
                            <stop offset="100%" stopColor="#3b82f6" />
                          </linearGradient>
                        </>
                      )}
                    </defs>

                    <ellipse cx="80" cy="115" rx="55" ry="20" fill={card.svgRings.outer} stroke={card.svgRings.outerStroke} strokeWidth="2" />
                    <ellipse cx="80" cy="110" rx="45" ry="15" fill={card.svgRings.inner} fillOpacity="0.6" />
                    <polygon points="45,110 115,110 95,45 65,45"
                      fill={card.key === 0 ? "#a855f7" : card.key === 1 ? "#ec4899" : "#06b6d4"} fillOpacity="0.15" />

                    {/* Icon Symbols */}
                    {card.key === 0 && (
                      <g className="animate-float" transform="translate(48, 25)">
                        <path d="M32 5 L56 16 C56 38 46 54 32 62 C18 54 8 38 8 16 Z"
                          fill="url(#shieldGrad)" stroke="#e0e7ff" strokeWidth="2"
                          filter="drop-shadow(0 8px 16px rgba(99,102,241,0.5))" />
                        <circle cx="32" cy="32" r="14" fill="#0f172a" fillOpacity="0.4" stroke="#ffffff" strokeWidth="1.5" />
                        <polyline points="32,24 32,32 38,32" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" />
                      </g>
                    )}
                    {card.key === 1 && (
                      <g className="animate-float" transform="translate(48, 22)">
                        <polygon points="32,8 56,22 56,48 32,62 8,48 8,22"
                          fill="url(#badgeGrad)" stroke="#fef08a" strokeWidth="2"
                          filter="drop-shadow(0 8px 16px rgba(245,158,11,0.5))" />
                        <path d="M32 20 L35 28 L44 28 L37 34 L40 42 L32 37 L24 42 L27 34 L20 28 L29 28 Z" fill="#ffffff" />
                      </g>
                    )}
                    {card.key === 2 && (
                      <g className="animate-float" transform="translate(48, 20)">
                        <polygon points="36,4 12,34 30,34 26,62 52,28 34,28"
                          fill="url(#boltGrad)" stroke="#e0f2fe" strokeWidth="2"
                          filter="drop-shadow(0 8px 16px rgba(6,182,212,0.6))" />
                      </g>
                    )}
                  </svg>
                </div>

                {/* Content */}
                <h3 className={`text-xl sm:text-2xl font-black text-white mb-3 tracking-wide ${card.titleHover} transition-colors`}>
                  {t.highlights.cards[card.key].title}
                </h3>

                <p className="text-sm text-purple-200/80 leading-relaxed mb-5 flex-1">
                  {t.highlights.cards[card.key].desc}
                </p>

                {/* Metric Badge */}
                <span className={`inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-bold border ${card.badgeBg} ${card.badgeText}`}>
                  <MetricIcon className="w-3.5 h-3.5" />
                  {t.highlights.cards[card.key].metric}
                </span>

                {/* Bottom CTA */}
                <button className={`mt-4 flex items-center gap-1 text-xs font-semibold ${card.badgeText} opacity-0 group-hover:opacity-100 transition-opacity duration-200`}>
                  {language === "km" ? "ស្វែងយល់បន្ថែម" : "Learn more"}
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                {/* Bottom border accent */}
                <div
                  className="absolute bottom-0 left-6 right-6 h-px opacity-60"
                  style={{ background: `linear-gradient(to right, transparent, ${card.gradientFrom}, transparent)` }}
                />
              </div>
            );
          })}
        </div>

        {/* Trust Bar */}
        <div className="mt-16 flex flex-wrap items-center justify-center gap-6 text-center">
          {[
            { icon: Award, label: language === "km" ? "ចំណាត់ថ្នាក់ #1 នៅកម្ពុជា" : "#1 Ranked in Cambodia", color: "text-amber-400" },
            { icon: ShieldCheck, label: language === "km" ? "ប្រើប្រាស់ SSL ១០០%" : "100% SSL Secured", color: "text-emerald-400" },
            { icon: Zap, label: language === "km" ? "ល្បឿន NVMe Gen4" : "NVMe Gen4 Speed", color: "text-cyan-400" },
          ].map((item, i) => {
            const Icon = item.icon;
            return (
              <div key={i} className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10">
                <Icon className={`w-4 h-4 ${item.color}`} />
                <span className="text-xs text-slate-300 font-medium">{item.label}</span>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
