"use client";

import React, { useState, useEffect } from "react";
import { createPortal } from "react-dom";
import {
  X,
  Check,
  ExternalLink,
  Send,
  Zap,
  ShoppingBag,
  Briefcase,
  Home,
  GraduationCap,
  Utensils,
  Server,
  Sparkles,
  Smartphone,
  ShieldCheck,
  Layers,
} from "lucide-react";
import { ProductItem } from "@/types";
import { useLanguage } from "./LanguageContext";
import { getTelegramOrderUrl } from "@/lib/telegram";

interface ProductDetailModalProps {
  product: ProductItem | null;
  onClose: () => void;
  telegramUsername?: string;
}

const emptySubscribe = () => () => {};

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  telegramUsername = "broteach_support",
}) => {
  const { language } = useLanguage();
  const [activeTab, setActiveTab] = useState<"details" | "features" | "support">("details");
  const mounted = React.useSyncExternalStore(emptySubscribe, () => true, () => false);

  // Lock background scroll when modal is active
  useEffect(() => {
    if (!product) return;
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = originalOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [product, onClose]);

  if (!product || !mounted) return null;

  const title = language === "km" ? product.titleKm : product.titleEn;
  const desc = language === "km" ? product.descKm : product.descEn;
  const features = language === "km" ? product.featuresKm : product.featuresEn;
  const categoryLabel = language === "km" ? product.categoryLabelKm : product.categoryLabelEn;
  const author = product.author || "Broteach";
  const badge =
    language === "km"
      ? product.badgeKm || "ពេញនិយម"
      : product.badgeEn || "POPULAR";

  const telegramUrl = getTelegramOrderUrl({
    itemName: title,
    price: product.price,
    itemType: "product",
    telegramUsername,
    lang: language,
  });

  const demoUrl = product.demoUrl || "https://demo.broteach.com";

  const renderProductIcon = (iconName?: string) => {
    switch (iconName) {
      case "ShoppingBag":
        return <ShoppingBag className="w-10 h-10 text-white" />;
      case "Briefcase":
        return <Briefcase className="w-10 h-10 text-white" />;
      case "Home":
        return <Home className="w-10 h-10 text-white" />;
      case "GraduationCap":
        return <GraduationCap className="w-10 h-10 text-white" />;
      case "Utensils":
        return <Utensils className="w-10 h-10 text-white" />;
      case "Server":
        return <Server className="w-10 h-10 text-white" />;
      case "Smartphone":
        return <Smartphone className="w-10 h-10 text-white" />;
      default:
        return <Sparkles className="w-10 h-10 text-white" />;
    }
  };

  return createPortal(
    <div
      onClick={onClose}
      className="fixed inset-0 z-[9999] flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-5xl bg-[#061528] border border-cyan-500/40 rounded-3xl shadow-2xl overflow-hidden m-auto max-h-[92vh] flex flex-col text-slate-100"
      >
        {/* Top Header Bar */}
        <div className="p-4 sm:p-6 bg-[#041021] border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 flex items-center justify-center shadow-md">
              <span className="text-white font-black text-sm">B</span>
            </div>
            <div>
              <span className="text-xs text-cyan-400 font-bold uppercase tracking-wider">
                {categoryLabel}
              </span>
              <h2 className="text-base sm:text-xl font-black text-white line-clamp-1">
                {title}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="overflow-y-auto flex-1 p-4 sm:p-6 space-y-6">
          {/* Metadata Row */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs sm:text-sm pb-4 border-b border-slate-800">
            <div className="flex flex-wrap items-center gap-2 sm:gap-4 text-slate-300">
              <span className="text-slate-400">
                {language === "km" ? "ដោយ" : "By"}{" "}
                <strong className="text-cyan-400">{author}</strong>
              </span>
              <span>•</span>
              <span className="inline-flex items-center gap-1 text-emerald-400 font-semibold">
                <Check className="w-3.5 h-3.5 stroke-[3]" />
                <span>{language === "km" ? "ទើបធ្វើបច្ចុប្បន្នភាព" : "Recently Updated"}</span>
              </span>
              <span>•</span>
              <span className="inline-flex items-center gap-1 text-emerald-400 font-semibold">
                <Check className="w-3.5 h-3.5 stroke-[3]" />
                <span>{language === "km" ? "មានឯកសារណែនាំ" : "Well Documented"}</span>
              </span>
            </div>
          </div>

          {/* Two-Column Grid: Preview Left vs License Sidebar Right */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column (8 cols): Mockup Image & Tabs */}
            <div className="lg:col-span-8 space-y-5">
              {/* Preview Banner Mockup */}
              <div className="relative rounded-2xl bg-gradient-to-br from-[#0c1f38] to-[#081324] border border-cyan-500/30 overflow-hidden group shadow-lg">
                {/* Flash badge */}
                <div className="absolute top-3 left-3 z-20">
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-cyan-500 text-slate-950 text-xs font-black shadow-md">
                    <Zap className="w-3.5 h-3.5 fill-slate-950" />
                    <span>{badge}</span>
                  </span>
                </div>

                {/* Banner Graphics or Real Image */}
                {product.thumbnailUrl ? (
                  <div className="relative h-64 sm:h-80 w-full overflow-hidden flex items-center justify-center bg-slate-950">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={product.thumbnailUrl}
                      alt={title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#041021] via-transparent to-black/30 pointer-events-none" />
                    <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between z-10">
                      <div>
                        <span className="text-xs text-cyan-400 font-bold uppercase tracking-wider block drop-shadow-md">
                          {categoryLabel}
                        </span>
                        <h3 className="text-xl sm:text-2xl font-black text-white drop-shadow-md">
                          {title}
                        </h3>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="h-64 sm:h-80 flex flex-col items-center justify-center p-6 text-center bg-[radial-gradient(#0891b2_1px,transparent_1px)] [background-size:24px_24px] relative">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center shadow-xl shadow-cyan-600/30 mb-4 group-hover:scale-105 transition-transform">
                      {renderProductIcon(product.icon)}
                    </div>
                    <h3 className="text-xl sm:text-2xl font-black text-white max-w-md">
                      {title}
                    </h3>
                    <p className="text-xs sm:text-sm text-cyan-300 mt-1 max-w-sm">
                      {categoryLabel} • Enterprise UI/UX • ABA KHQR Ready
                    </p>
                  </div>
                )}

                {/* Live Preview Button Bar Under Preview */}
                <div className="p-3.5 bg-[#030d1a] border-t border-slate-800 flex items-center justify-between gap-3">
                  <a
                    href={demoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>{language === "km" ? "ទស្សនាគំរូផ្សាយផ្ទាល់ (Live Preview)" : "Live Preview"}</span>
                  </a>
                  <a
                    href={telegramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold text-xs flex items-center gap-1.5 transition-colors"
                  >
                    <Send className="w-3.5 h-3.5 fill-current" />
                    <span>Telegram</span>
                  </a>
                </div>
              </div>

              {/* Detail Tabs */}
              <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                <button
                  type="button"
                  onClick={() => setActiveTab("details")}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeTab === "details"
                      ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {language === "km" ? "ព័ត៌មានលម្អិត" : "Item Details"}
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab("features")}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeTab === "features"
                      ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {language === "km" ? "លក្ខណៈពិសេស & Specs" : "Features & Specs"}
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab("support")}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeTab === "support"
                      ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {language === "km" ? "ការគាំទ្រ & ធានា" : "Support & Warranty"}
                </button>
              </div>

              {/* Tab Content */}
              {activeTab === "details" && (
                <div className="space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
                  <p>{desc}</p>
                  <h4 className="text-sm font-bold text-white pt-2">
                    {language === "km" ? "ចំណុចសំខាន់ៗដែលទទួលបាន៖" : "Key Included Highlights:"}
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {features.map((f, i) => (
                      <div key={i} className="flex items-start gap-2 text-slate-200">
                        <Check className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                        <span>{f}</span>
                      </div>
                    ))}
                  </div>

                  {product.techStack && product.techStack.length > 0 && (
                    <div className="pt-3">
                      <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                        {language === "km" ? "បច្ចេកវិទ្យាប្រើប្រាស់" : "Tech Stack"}
                      </h5>
                      <div className="flex flex-wrap gap-1.5">
                        {product.techStack.map((tech, idx) => (
                          <span
                            key={idx}
                            className="px-2.5 py-1 rounded-md bg-slate-800 border border-slate-700 text-cyan-300 text-xs font-semibold"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {activeTab === "features" && (
                <div className="space-y-3 text-xs sm:text-sm text-slate-300">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-slate-400 block text-[11px]">Framework</span>
                      <strong className="text-white">Next.js 16 (App Router)</strong>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-slate-400 block text-[11px]">Styling</span>
                      <strong className="text-white">TailwindCSS + Responsive</strong>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-slate-400 block text-[11px]">Payment</span>
                      <strong className="text-white">ABA KHQR & Bakong Ready</strong>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-slate-400 block text-[11px]">Database / CMS</span>
                      <strong className="text-white">Admin CMS Dashboard Included</strong>
                    </div>
                  </div>

                  {product.featuresEn && product.featuresEn.length > 0 && (
                    <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 space-y-2">
                      <div className="flex items-center gap-2 text-white font-bold text-xs">
                        <Layers className="w-4 h-4 text-cyan-400" />
                        <span>{language === "km" ? "សមត្ថភាពប្រព័ន្ធពេញលេញ" : "Complete Architecture"}</span>
                      </div>
                      <p className="text-xs text-slate-400">
                        {language === "km"
                          ? "កូដស្អាតតាមបែប Clean Architecture ងាយស្រួលពង្រីក (Scalable) និងមានការការពារ Firewall សុវត្ថិភាពខ្ពស់។"
                          : "Production-ready clean code architecture, fully scalable with automated backups and security firewalls."}
                      </p>
                    </div>
                  )}
                </div>
              )}

              {activeTab === "support" && (
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 text-xs text-slate-300">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                    <ShieldCheck className="w-5 h-5" />
                    <span>{language === "km" ? "ការគាំទ្របច្ចេកទេសផ្ទាល់ ២៤/៧" : "24/7 Dedicated Engineering Support"}</span>
                  </div>
                  <p>
                    {language === "km"
                      ? "រាល់កញ្ចប់សេវាកម្មទាំងអស់រួមបញ្ចូលការជួយដំឡើងលើ Server ការកែសម្រួលព័ត៌មាន និងការធានាថែទាំឥតគិតថ្លៃ។"
                      : "Includes full installation, custom branding deployment on your cloud hosting, and continuous bug fixes."}
                  </p>
                  <div className="pt-2 border-t border-slate-800 flex items-center gap-2 text-cyan-400">
                    <Send className="w-3.5 h-3.5" />
                    <span>Telegram: @{telegramUsername.replace("@", "")}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Right Column (4 cols): ThemeForest Regular License Card */}
            <div className="lg:col-span-4 space-y-4">
              <div className="p-5 rounded-2xl bg-[#030d1a] border border-cyan-500/40 shadow-xl space-y-4">
                <div className="flex items-baseline justify-between border-b border-slate-800 pb-3">
                  <div>
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                      Regular License
                    </span>
                    <span className="text-[11px] text-slate-500">
                      {language === "km" ? "អាជ្ញាប័ណ្ណពេញលេញ" : "Full Production License"}
                    </span>
                  </div>
                  <div className="flex items-baseline gap-0.5">
                    <span className="text-cyan-400 font-bold text-lg">$</span>
                    <span className="text-4xl font-black text-cyan-400 tracking-tight">
                      {product.price}
                    </span>
                  </div>
                </div>

                {/* Benefits Checklist */}
                <div className="space-y-2 text-xs text-slate-300">
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>Quality checked by Broteach</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>Future updates included</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>6 months dedicated support</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>Free SSL & Cloud setup</span>
                  </div>
                </div>

                {/* Action Buttons: Direct Telegram Order and Live Demo */}
                <div className="pt-2 space-y-2">
                  <a
                    href={telegramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-cyan-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold text-xs sm:text-sm shadow-lg shadow-cyan-600/25 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Send className="w-4 h-4 fill-current" />
                    <span>{language === "km" ? "កុម្ម៉ង់តាម Telegram ភ្លាមៗ" : "Order via Telegram"}</span>
                  </a>

                  <a
                    href={demoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 px-4 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-cyan-300 hover:text-white border border-cyan-500/30 text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>{language === "km" ? "មើលគំរូ Demo ផ្សាយផ្ទាល់" : "Live Preview Demo"}</span>
                  </a>
                </div>

                <p className="text-[11px] text-slate-500 text-center">
                  Price in USD. No hidden fees. Instant setup on Telegram.
                </p>
              </div>

              {/* Author Info Card */}
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white font-black text-sm flex-shrink-0">
                  B
                </div>
                <div className="text-xs">
                  <span className="font-bold text-white block">Broteach Engineering</span>
                  <span className="text-slate-400 block text-[11px]">
                    Verified Elite Developer • Phnom Penh
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
};
