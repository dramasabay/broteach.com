"use client";

import React, { useState, useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";
import { Home, Layers, DollarSign, BookOpen } from "lucide-react";
import { useLanguage } from "./LanguageContext";

export const MobileBottomNav: React.FC = () => {
  const { language } = useLanguage();
  const pathname = usePathname();
  const router = useRouter();
  const [scrollSection, setScrollSection] = useState<string>("home");

  const activeSection =
    pathname === "/products" || pathname === "/productions"
      ? "products"
      : pathname === "/blog" || pathname.startsWith("/blog/")
      ? "blog"
      : pathname === "/"
      ? scrollSection
      : "";

  // Scroll spy on home page to highlight active section in Telegram-like dock
  useEffect(() => {
    if (pathname !== "/") return;

    const handleScroll = () => {
      const scrollPos = window.scrollY + 250;
      const pricingEl = document.getElementById("pricing");
      const productsEl = document.getElementById("products");

      if (pricingEl && scrollPos >= pricingEl.offsetTop) {
        setScrollSection("pricing");
      } else if (productsEl && scrollPos >= productsEl.offsetTop) {
        setScrollSection("products");
      } else {
        setScrollSection("home");
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, [pathname]);

  const navItems = [
    {
      id: "home",
      name: language === "km" ? "ទំព័រដើម" : "Home",
      icon: Home,
      path: "/",
    },
    {
      id: "products",
      name: language === "km" ? "ផលិតផល" : "Product",
      icon: Layers,
      path: "/products",
    },
    {
      id: "pricing",
      name: language === "km" ? "តម្លៃ" : "Price",
      icon: DollarSign,
      path: "/pricing",
    },
    {
      id: "blog",
      name: language === "km" ? "អត្ថបទ" : "Blogs",
      icon: BookOpen,
      path: "/blog",
    },
  ];

  const handleItemClick = (
    e: React.MouseEvent,
    item: { id: string; path?: string; targetId?: string }
  ) => {
    e.preventDefault();

    if (item.id === "home") {
      if (pathname === "/") {
        window.scrollTo({ top: 0, behavior: "smooth" });
        setScrollSection("home");
      } else {
        router.push("/");
      }
      return;
    }

    if (item.path) {
      router.push(item.path);
      return;
    }

    if (item.targetId) {
      if (pathname === "/") {
        const el = document.getElementById(item.targetId);
        if (el) {
          el.scrollIntoView({ behavior: "smooth" });
          setScrollSection(item.id);
        }
      } else {
        router.push("/pricing");
      }
      return;
    }
  };

  const isItemActive = (id: string) => {
    if (id === "pricing" && pathname === "/pricing") return true;
    if (id === "products" && (pathname === "/products" || pathname === "/productions")) return true;
    if (id === "blog" && (pathname === "/blog" || pathname.startsWith("/blog/"))) return true;
    if (pathname === "/") return activeSection === id;
    return false;
  };

  if (pathname.startsWith("/admin")) {
    return null;
  }

  return (
    <nav
      aria-label="Mobile Navigation"
      className="fixed bottom-0 inset-x-0 z-50 lg:hidden bg-[#040e1d]/95 backdrop-blur-2xl border-t border-cyan-500/25 shadow-[0_-5px_25px_rgba(0,0,0,0.7)] px-2 pt-1.5 pb-[max(0.5rem,env(safe-area-inset-bottom))] animate-slide-up-nav"
    >
      <div className="grid grid-cols-4 items-center max-w-md mx-auto">
        {navItems.map((item) => {
          const active = isItemActive(item.id);
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={(e) => handleItemClick(e, item)}
              className="relative flex flex-col items-center justify-center py-1 transition-all duration-200 cursor-pointer active:scale-90 select-none group"
            >
              {/* Telegram-style Active Glow Capsule */}
              <div
                className={`flex items-center justify-center px-4 py-1 rounded-full transition-all duration-300 ${
                  active
                    ? "bg-gradient-to-r from-cyan-500/25 to-blue-500/25 border border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.4)]"
                    : "bg-transparent group-hover:bg-white/5 border border-transparent"
                }`}
              >
                <Icon
                  className={`w-5 h-5 transition-transform duration-200 ${
                    active
                      ? "text-cyan-400 scale-110 stroke-[2.5]"
                      : "text-slate-400 group-hover:text-slate-200 stroke-[1.8]"
                  }`}
                />
              </div>

              {/* Label */}
              <span
                className={`text-[10px] font-bold tracking-tight transition-colors duration-200 mt-0.5 leading-none ${
                  active
                    ? "text-cyan-400 font-black drop-shadow-[0_0_8px_rgba(6,182,212,0.6)]"
                    : "text-slate-400 group-hover:text-slate-200"
                }`}
              >
                {item.name}
              </span>

              {/* Telegram-style Top Indicator Dot */}
              {active && (
                <span className="absolute -top-1 w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_6px_rgba(6,182,212,0.9)] animate-pulse" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
