"use client";

import React, { useState } from "react";
import {
  ShoppingBag,
  Briefcase,
  Home as HomeIcon,
  GraduationCap,
  Utensils,
  Server,
  Sparkles,
  ExternalLink,
  Zap,
  Eye,
  LayoutGrid,
} from "lucide-react";
import { ProductItem } from "@/types";
import { defaultProducts } from "@/lib/data";
import { useLanguage } from "./LanguageContext";
import { ProductDetailModal } from "./ProductDetailModal";

interface ProductsSectionProps {
  products?: ProductItem[];
  telegramUsername?: string;
  onOpenDemo?: (planId?: string) => void;
}

export const ProductsSection: React.FC<ProductsSectionProps> = ({
  products = [],
  telegramUsername = "broteach_support",
}) => {
  const { language } = useLanguage();
  const [gridColumns, setGridColumns] = useState<4 | 5>(4); // Default 4 per row, toggleable to 5 per row
  const [selectedProduct, setSelectedProduct] = useState<ProductItem | null>(null);

  const rawProducts = products && products.length > 0 ? products : defaultProducts;
  const displayProducts = rawProducts.filter((p) => p.isActive !== false);
  const filtered = displayProducts;

  const renderIcon = (iconName: string) => {
    switch (iconName) {
      case "ShoppingBag":
        return <ShoppingBag className="w-5 h-5 text-rose-400" />;
      case "Briefcase":
        return <Briefcase className="w-5 h-5 text-cyan-400" />;
      case "Home":
        return <HomeIcon className="w-5 h-5 text-amber-400" />;
      case "GraduationCap":
        return <GraduationCap className="w-5 h-5 text-purple-400" />;
      case "Utensils":
        return <Utensils className="w-5 h-5 text-emerald-400" />;
      case "Server":
        return <Server className="w-5 h-5 text-blue-400" />;
      default:
        return <Sparkles className="w-5 h-5 text-cyan-400" />;
    }
  };

  return (
    <section id="products" className="py-20 md:py-28 bg-[#040e1d] text-white relative overflow-hidden">
      {/* Glow Backdrops */}
      <div className="absolute top-1/3 left-0 w-80 h-80 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center space-y-4 mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>{language === "km" ? "ផលិតផលគុណភាពខ្ពស់" : "Premium Products"}</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-cyan-200">
            {language === "km" ? "ផលិតផល & ដំណោះស្រាយឌីជីថល" : "Our Products & Digital Solutions"}
          </h2>
        </div>

        {/* Clean Sub-header without category filter bar */}
        <div className="flex items-center justify-between gap-4 mb-8 pb-3 border-b border-slate-800/80">
          <p className="text-xs text-slate-400">
            {language === "km"
              ? `បង្ហាញផលិតផលទាំងអស់ (${displayProducts.length} គម្រោង)`
              : `Showing all productions & solutions (${displayProducts.length} items)`}
          </p>

          {/* Desktop Grid Columns Toggle (4 vs 5 per row) */}
          <div className="hidden lg:flex items-center gap-1.5 bg-slate-900/80 border border-slate-800 p-1 rounded-xl text-xs">
            <span className="text-slate-400 px-2 font-medium flex items-center gap-1">
              <LayoutGrid className="w-3.5 h-3.5 text-cyan-400" />
              <span>{language === "km" ? "ជួរ:" : "View:"}</span>
            </span>
            <button
              type="button"
              onClick={() => setGridColumns(4)}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                gridColumns === 4
                  ? "bg-cyan-600 text-white shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              4 / {language === "km" ? "ជួរ" : "Row"}
            </button>
            <button
              type="button"
              onClick={() => setGridColumns(5)}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                gridColumns === 5
                  ? "bg-cyan-600 text-white shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              5 / {language === "km" ? "ជួរ" : "Row"}
            </button>
          </div>
        </div>

        {/* ThemeForest Product Cards Grid:
            - Mobile: 2 per row (grid-cols-2)
            - Tablet: 2 per row (sm:grid-cols-2)
            - Desktop: 4 per row default or 5 per row when toggled
        */}
        <div
          className={`grid grid-cols-2 sm:grid-cols-2 ${
            gridColumns === 5 ? "lg:grid-cols-4 xl:grid-cols-5" : "lg:grid-cols-4"
          } gap-3 sm:gap-5`}
        >
          {filtered.map((product) => {
            const title = language === "km" ? product.titleKm : product.titleEn;
            const categoryLabel = language === "km" ? product.categoryLabelKm : product.categoryLabelEn;
            const author = product.author || "Broteach";
            const demoUrl = product.demoUrl || "https://demo.broteach.com";

            return (
              <div
                key={product.id}
                className="group relative rounded-2xl bg-[#061528] border border-slate-800 hover:border-cyan-500/50 flex flex-col justify-between transition-all duration-200 hover:-translate-y-1 hover:shadow-[0_12px_30px_rgba(6,182,212,0.15)] overflow-hidden"
              >
                <div>
                  {/* Top Thumbnail Banner (ThemeForest style) - Full edge-to-edge, NO padding, NO margin */}
                  <div
                    onClick={() => setSelectedProduct(product)}
                    className="relative w-full h-36 sm:h-48 bg-gradient-to-tr from-[#091b33] to-[#0d284c] flex items-center justify-center p-0 m-0 cursor-pointer overflow-hidden border-b border-slate-800/80"
                  >
                    {/* Flash Bolt Badge ⚡ */}
                    <div className="absolute top-2 left-2 z-10 pointer-events-none">
                      <span className="w-5 h-5 rounded-md bg-cyan-500 text-slate-950 flex items-center justify-center shadow-md">
                        <Zap className="w-3 h-3 fill-slate-950" />
                      </span>
                    </div>

                    {/* Real Image or Icon Graphic */}
                    {product.thumbnailUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={product.thumbnailUrl}
                        alt={title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 block m-0 p-0"
                      />
                    ) : (
                      <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                        {renderIcon(product.icon)}
                      </div>
                    )}

                    {/* Quick View Hover Overlay */}
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                      <span className="px-3 py-1.5 rounded-full bg-cyan-600 text-white text-xs font-bold flex items-center gap-1 shadow-lg">
                        <Eye className="w-3.5 h-3.5" />
                        <span>{language === "km" ? "មើលលម្អិត" : "Details"}</span>
                      </span>
                    </div>
                  </div>

                  {/* Body Info */}
                  <div className="p-3 sm:p-4 space-y-2">
                    {/* Title */}
                    <h3
                      onClick={() => setSelectedProduct(product)}
                      className="text-xs sm:text-sm font-bold text-white line-clamp-1 group-hover:text-cyan-400 transition-colors cursor-pointer"
                      title={title}
                    >
                      {title}
                    </h3>

                    {/* By Author & Category (ThemeForest italic subtitle) */}
                    <p className="text-[11px] text-slate-400 italic truncate">
                      by <span className="text-slate-300 font-medium">{author}</span> in{" "}
                      <span className="text-cyan-400">{categoryLabel}</span>
                    </p>

                    {/* Price in Bold */}
                    <div className="pt-1 flex items-baseline gap-0.5">
                      <span className="text-base sm:text-xl font-black text-cyan-400">
                        ${product.price}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Bottom Action Row: View Details & Live Preview (NO Add to Cart!) */}
                <div className="p-3 sm:p-4 pt-0 flex items-center gap-1.5 sm:gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedProduct(product)}
                    className="p-2 sm:px-2.5 sm:py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center justify-center transition-colors cursor-pointer"
                    title="View Details"
                  >
                    <Eye className="w-3.5 h-3.5" />
                  </button>

                  <a
                    href={demoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-1.5 sm:py-2 px-2.5 sm:px-3 rounded-xl border border-cyan-500/50 hover:border-cyan-400 bg-cyan-950/40 hover:bg-cyan-600/30 text-cyan-300 hover:text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-sm cursor-pointer truncate"
                  >
                    <span className="truncate">{language === "km" ? "Live Preview" : "Live Preview"}</span>
                    <ExternalLink className="w-3 h-3 flex-shrink-0" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ThemeForest Product Detail Modal */}
      {selectedProduct && (
        <ProductDetailModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          telegramUsername={telegramUsername}
        />
      )}
    </section>
  );
};
