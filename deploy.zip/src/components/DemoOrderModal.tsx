"use client";

import React, { useState } from "react";
import { createPortal } from "react-dom";
import { X, CheckCircle2, Monitor, ShoppingBag, Briefcase, Send, Loader2, Sparkles } from "lucide-react";
import { PricingPlan } from "@/types";
import { useLanguage } from "./LanguageContext";

interface DemoOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPlan: PricingPlan | null;
  telegramUsername?: string;
}

const emptySubscribe = () => () => {};

export const DemoOrderModal: React.FC<DemoOrderModalProps> = ({
  isOpen,
  onClose,
  selectedPlan,
}) => {
  const { language } = useLanguage();
  const mounted = React.useSyncExternalStore(emptySubscribe, () => true, () => false);
  const [activeTab, setActiveTab] = useState<"demo" | "order">("order");
  const [demoTemplate, setDemoTemplate] = useState<"corporate" | "ecommerce" | "agency">("corporate");

  // Order form state
  const [clientName, setClientName] = useState("");
  const [phone, setPhone] = useState("");
  const [telegram, setTelegram] = useState("");
  const [email, setEmail] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [successResult, setSuccessResult] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState("");

  if (!isOpen || !mounted) return null;

  const planName = selectedPlan
    ? language === "km"
      ? selectedPlan.nameKm
      : selectedPlan.nameEn
    : language === "km"
    ? "កញ្ចប់ទូទៅ"
    : "Standard Consultation";

  const price = selectedPlan ? selectedPlan.price : 450;

  const handleOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName.trim() || !phone.trim()) {
      setErrorMsg(
        language === "km"
          ? "សូមបំពេញឈ្មោះ និងលេខទូរស័ព្ទ!"
          : "Please enter your name and phone number!"
      );
      return;
    }

    setLoading(true);
    setErrorMsg("");

    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          planId: selectedPlan?.id || "custom",
          planName: `${planName} ($${price})`,
          price,
          clientName,
          phone,
          telegram,
          email,
          notes,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setSuccessResult(data.order?.id || "ORD-SUCCESS");
      } else {
        setErrorMsg(data.message || "Failed to submit order");
      }
    } catch {
      setErrorMsg("Network error, please try again.");
    } finally {
      setLoading(false);
    }
  };

  return createPortal(
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-[#0b1329] border border-cyan-500/30 rounded-3xl shadow-2xl overflow-hidden flex flex-col m-auto max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#070e20]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center text-white font-black text-sm">
              B
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>{planName}</span>
                <span className="text-cyan-400 font-extrabold">${price}</span>
              </h3>
              <p className="text-xs text-slate-400">
                {language === "km"
                  ? "សាកល្បងមើល Demo ឬកុម្ម៉ង់បង្កើតគេហទំព័រ"
                  : "Preview interactive demo or submit project quote"}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Buttons */}
        <div className="flex border-b border-slate-800 bg-[#070e20]/60">
          <button
            onClick={() => setActiveTab("order")}
            className={`flex-1 py-3 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-colors ${
              activeTab === "order"
                ? "text-cyan-400 border-b-2 border-cyan-400 bg-cyan-500/5"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Send className="w-4 h-4" />
            <span>{language === "km" ? "កុម្ម៉ង់ឥឡូវនេះ / ស្នើសុំតម្លៃ" : "Request Order / Quote"}</span>
          </button>
          <button
            onClick={() => setActiveTab("demo")}
            className={`flex-1 py-3 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-colors ${
              activeTab === "demo"
                ? "text-cyan-400 border-b-2 border-cyan-400 bg-cyan-500/5"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Monitor className="w-4 h-4" />
            <span>{language === "km" ? "សាកល្បងមើល Demo ផ្ទាល់" : "Live Demo Mockup"}</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1">
          {activeTab === "order" ? (
            successResult ? (
              <div className="text-center py-10 space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="text-xl font-bold text-white">
                  {language === "km" ? "ទទួលបានការកុម្ម៉ង់ដោយជោគជ័យ!" : "Inquiry Received Successfully!"}
                </h4>
                <p className="text-sm text-slate-300 max-w-md mx-auto">
                  {language === "km"
                    ? `លេខសម្គាល់គម្រោង៖ ${successResult}។ ក្រុមការងារ Broteach នឹងទាក់ទងមកលោកអ្នកតាមរយៈលេខ ${phone} ក្នុងពេលឆាប់ៗ!`
                    : `Inquiry ID: ${successResult}. Our technical team will reach out to you at ${phone} promptly!`}
                </p>
                <div className="pt-4">
                  <button
                    onClick={onClose}
                    className="px-6 py-2.5 rounded-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm"
                  >
                    {language === "km" ? "យល់ព្រម" : "Done"}
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleOrderSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {language === "km" ? "ឈ្មោះរបស់អ្នក *" : "Your Name *"}
                    </label>
                    <input
                      type="text"
                      required
                      value={clientName}
                      onChange={(e) => setClientName(e.target.value)}
                      placeholder={language === "km" ? "ឧ. សុខ ហេង" : "e.g. Sok Heng"}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {language === "km" ? "លេខទូរស័ព្ទ *" : "Phone Number *"}
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="098 765 432"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {language === "km" ? "ឈ្មោះ Telegram (ប្រសិនបើមាន)" : "Telegram Username"}
                    </label>
                    <input
                      type="text"
                      value={telegram}
                      onChange={(e) => setTelegram(e.target.value)}
                      placeholder="@username"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {language === "km" ? "អាសយដ្ឋានអ៊ីមែល" : "Email Address"}
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@company.com"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {language === "km" ? "ព័ត៌មានលម្អិតបន្ថែម ឬតម្រូវការពិសេស" : "Project Details / Special Requests"}
                  </label>
                  <textarea
                    rows={3}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder={
                      language === "km"
                        ? "រៀបរាប់ពីប្រភេទគេហទំព័រ ឬមុខងារដែលលោកអ្នកត្រូវការ..."
                        : "Describe your website features or business goals..."
                    }
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400"
                  />
                </div>

                {errorMsg && (
                  <p className="text-xs text-rose-400 font-semibold">{errorMsg}</p>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-red-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-sm shadow-lg shadow-red-600/30 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>{language === "km" ? "កំពុងដំណើរការ..." : "Submitting..."}</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>{language === "km" ? "បញ្ជាក់ការកុម្ម៉ង់ឥឡូវនេះ" : "Confirm Project Order"}</span>
                    </>
                  )}
                </button>
              </form>
            )
          ) : (
            <div className="space-y-4">
              {/* Template Selectors */}
              <div className="flex gap-2">
                <button
                  onClick={() => setDemoTemplate("corporate")}
                  className={`flex-1 p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                    demoTemplate === "corporate"
                      ? "border-cyan-400 bg-cyan-950/60 text-cyan-300"
                      : "border-slate-800 bg-slate-900 text-slate-400"
                  }`}
                >
                  <Briefcase className="w-3.5 h-3.5" />
                  <span>Corporate Business</span>
                </button>
                <button
                  onClick={() => setDemoTemplate("ecommerce")}
                  className={`flex-1 p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                    demoTemplate === "ecommerce"
                      ? "border-cyan-400 bg-cyan-950/60 text-cyan-300"
                      : "border-slate-800 bg-slate-900 text-slate-400"
                  }`}
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>E-commerce Shop</span>
                </button>
              </div>

              {/* Mockup Browser Window */}
              <div className="rounded-2xl border border-slate-700 bg-slate-900 overflow-hidden shadow-inner">
                <div className="px-4 py-2 bg-slate-800 border-b border-slate-700 flex items-center gap-2">
                  <div className="flex gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  </div>
                  <div className="flex-1 text-center">
                    <span className="text-[11px] text-slate-400 font-mono bg-slate-900 px-4 py-0.5 rounded-full border border-slate-700">
                      https://demo.broteach.com/{demoTemplate}
                    </span>
                  </div>
                </div>

                <div className="p-5 space-y-4">
                  {demoTemplate === "corporate" ? (
                    <div className="space-y-3">
                      <div className="h-28 rounded-xl bg-gradient-to-r from-blue-950 to-cyan-950 p-4 border border-cyan-800/40 flex flex-col justify-center">
                        <span className="text-xs text-cyan-400 font-bold uppercase tracking-wider">
                          Corporate Portal
                        </span>
                        <h5 className="text-base font-bold text-white mt-1">
                          Premier Business Solutions 2024
                        </h5>
                        <p className="text-xs text-slate-300 mt-1">
                          Clean responsive architecture with high-speed caching and SEO optimization.
                        </p>
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-center">
                        <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700">
                          <p className="text-xs font-bold text-white">Services</p>
                          <p className="text-[10px] text-slate-400">Consulting & IT</p>
                        </div>
                        <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700">
                          <p className="text-xs font-bold text-white">Portfolio</p>
                          <p className="text-[10px] text-slate-400">120+ Projects</p>
                        </div>
                        <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700">
                          <p className="text-xs font-bold text-white">Contact</p>
                          <p className="text-[10px] text-slate-400">Direct Booking</p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="h-24 rounded-xl bg-gradient-to-r from-purple-950 to-pink-950 p-4 border border-purple-800/40 flex flex-col justify-center">
                        <span className="text-xs text-pink-400 font-bold uppercase tracking-wider">
                          Online Store & Payments
                        </span>
                        <h5 className="text-base font-bold text-white mt-1">
                          Modern Khmer E-commerce
                        </h5>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div className="p-2 rounded-lg bg-slate-800/80 border border-slate-700 flex items-center gap-2">
                          <div className="w-10 h-10 rounded bg-slate-700 flex-shrink-0" />
                          <div>
                            <p className="text-xs font-bold text-white">Product Item A</p>
                            <p className="text-xs text-emerald-400 font-bold">$29.00</p>
                          </div>
                        </div>
                        <div className="p-2 rounded-lg bg-slate-800/80 border border-slate-700 flex items-center gap-2">
                          <div className="w-10 h-10 rounded bg-slate-700 flex-shrink-0" />
                          <div>
                            <p className="text-xs font-bold text-white">Product Item B</p>
                            <p className="text-xs text-emerald-400 font-bold">$49.00</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="text-center pt-2">
                    <button
                      onClick={() => setActiveTab("order")}
                      className="px-6 py-2 rounded-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs"
                    >
                      {language === "km" ? "ខ្ញុំចង់បានគេហទំព័របែបនេះ" : "I Want This Website Template"}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>,
    document.body
  );
};
