"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { SiteSettings } from "@/types";
import { subscribeCmsUpdates } from "@/lib/realtime";

interface SiteSettingsContextType {
  settings: SiteSettings;
  setSettings: React.Dispatch<React.SetStateAction<SiteSettings>>;
  updateLocalSettings: (patch: Partial<SiteSettings>) => void;
}

const SiteSettingsContext = createContext<SiteSettingsContextType | undefined>(undefined);

export function SiteSettingsProvider({
  children,
  initialSettings,
}: {
  children: React.ReactNode;
  initialSettings: SiteSettings;
}) {
  const [settings, setSettings] = useState<SiteSettings>(initialSettings);

  const [prevInitial, setPrevInitial] = useState(initialSettings);
  if (initialSettings !== prevInitial) {
    setPrevInitial(initialSettings);
    setSettings(initialSettings);
  }

  // Real-time synchronization when settings are updated in Admin or other tabs
  useEffect(() => {
    const fetchLatest = async () => {
      try {
        const res = await fetch(`/api/content?t=${Date.now()}`);
        if (res.ok) {
          const data = await res.json();
          if (data.settings) {
            setSettings(data.settings);
          }
        }
      } catch (err) {
        console.error("Failed to sync site settings:", err);
      }
    };

    const unsubscribe = subscribeCmsUpdates(() => {
      fetchLatest();
    });

    return () => unsubscribe();
  }, []);

  const updateLocalSettings = (patch: Partial<SiteSettings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  };

  return (
    <SiteSettingsContext.Provider value={{ settings, setSettings, updateLocalSettings }}>
      {children}
    </SiteSettingsContext.Provider>
  );
}

export function useSiteSettings(): SiteSettingsContextType {
  const context = useContext(SiteSettingsContext);
  if (!context) {
    throw new Error("useSiteSettings must be used within a SiteSettingsProvider");
  }
  return context;
}
