"use client";

import React, { useState, useEffect } from "react";
import { ThumbsUp, Heart, MessageCircle, Share2, Send, Check } from "lucide-react";
import { useLanguage } from "./LanguageContext";

interface Comment {
  id: string;
  author: string;
  avatarColor: string;
  text: string;
  timeAgoKm: string;
  timeAgoEn: string;
  likes: number;
  isLiked?: boolean;
}

const DEFAULT_COMMENTS: Record<string, Comment[]> = {
  "cloud-hosting-cambodia-guide": [
    {
      id: "c1",
      author: "Sokha Chan",
      avatarColor: "from-blue-600 to-cyan-500",
      text: "សេវាកម្ម Cloud Hosting ល្បឿនលឿនណាស់! ខ្ញុំបានសាកល្បងជាមួយ WordPress ផ្ទុកលឿនជាងមុនឆ្ងាយ។ អរគុណសម្រាប់ការចែករំលែក 👍",
      timeAgoKm: "20 នាទីមុន",
      timeAgoEn: "20m ago",
      likes: 5,
    },
    {
      id: "c2",
      author: "Dara Technology",
      avatarColor: "from-purple-600 to-pink-500",
      text: "Does this cloud hosting support auto-scaling for high traffic during promotion events?",
      timeAgoKm: "1 ម៉ោងមុន",
      timeAgoEn: "1h ago",
      likes: 3,
    },
    {
      id: "c3",
      author: "Broteach Support",
      avatarColor: "from-red-600 to-amber-500",
      text: "Yes, absolutely Dara! Our NVMe Cloud infrastructure supports elastic scaling and instant RAM/vCPU upgrades with zero downtime.",
      timeAgoKm: "45 នាទីមុន",
      timeAgoEn: "45m ago",
      likes: 7,
    },
  ],
  default: [
    {
      id: "cd1",
      author: "Vireak Bun",
      avatarColor: "from-emerald-600 to-teal-500",
      text: "អត្ថបទនេះល្អខ្លាំងណាស់ ខ្លីខ្លឹម និងងាយយល់សម្រាប់អ្នកចាប់ផ្តើមអាជីវកម្ម online! 🔥",
      timeAgoKm: "15 នាទីមុន",
      timeAgoEn: "15m ago",
      likes: 4,
    },
    {
      id: "cd2",
      author: "Kosal Meng",
      avatarColor: "from-amber-600 to-orange-500",
      text: "Great insights! Very helpful for building websites in Cambodia with local payments.",
      timeAgoKm: "2 ម៉ោងមុន",
      timeAgoEn: "2h ago",
      likes: 2,
    },
  ],
};

interface BlogInteractionsProps {
  postSlug: string;
  postTitle: string;
}

export const BlogInteractions: React.FC<BlogInteractionsProps> = ({
  postSlug,
  postTitle,
}) => {
  const { language } = useLanguage();

  // Likes State
  const [likesCount, setLikesCount] = useState(24);
  const [userReaction, setUserReaction] = useState<string | null>(null);
  const [showReactionsPop, setShowReactionsPop] = useState(false);

  // Comments State
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState("");
  const [authorName, setAuthorName] = useState("");
  const [copiedShare, setCopiedShare] = useState(false);

  // Initialize from LocalStorage or defaults
  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        const savedLikes = localStorage.getItem(`broteach_likes_${postSlug}`);
        if (savedLikes) {
          const parsed = JSON.parse(savedLikes);
          setLikesCount(parsed.count || 24);
          setUserReaction(parsed.reaction || null);
        } else {
          // Pseudo-random initial count based on slug length
          setLikesCount(18 + (postSlug.length % 15));
        }

        const savedComments = localStorage.getItem(`broteach_comments_${postSlug}`);
        if (savedComments) {
          setComments(JSON.parse(savedComments));
        } else {
          setComments(DEFAULT_COMMENTS[postSlug] || DEFAULT_COMMENTS.default);
        }
      } catch {
        setComments(DEFAULT_COMMENTS.default);
      }
    }, 0);

    return () => clearTimeout(timer);
  }, [postSlug]);

  // Handle Like Toggle
  const handleToggleLike = (reaction: string = "like") => {
    if (userReaction === reaction) {
      // Unlike
      const nextCount = Math.max(0, likesCount - 1);
      setLikesCount(nextCount);
      setUserReaction(null);
      localStorage.setItem(
        `broteach_likes_${postSlug}`,
        JSON.stringify({ count: nextCount, reaction: null })
      );
    } else {
      // Like / React
      const nextCount = userReaction ? likesCount : likesCount + 1;
      setLikesCount(nextCount);
      setUserReaction(reaction);
      localStorage.setItem(
        `broteach_likes_${postSlug}`,
        JSON.stringify({ count: nextCount, reaction })
      );
    }
    setShowReactionsPop(false);
  };

  // Handle Comment Submission
  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    const gradients = [
      "from-cyan-500 to-blue-600",
      "from-purple-500 to-pink-600",
      "from-emerald-500 to-teal-600",
      "from-amber-500 to-orange-600",
      "from-rose-500 to-red-600",
    ];
    const randomGrad = gradients[Math.floor(Math.random() * gradients.length)];

    const created: Comment = {
      id: "c_" + Date.now(),
      author: authorName.trim() || (language === "km" ? "ភ្ញៀវ (Guest)" : "Guest User"),
      avatarColor: randomGrad,
      text: newComment.trim(),
      timeAgoKm: "ទើបតែឥឡូវ",
      timeAgoEn: "Just now",
      likes: 0,
    };

    const updated = [created, ...comments];
    setComments(updated);
    setNewComment("");
    try {
      localStorage.setItem(`broteach_comments_${postSlug}`, JSON.stringify(updated));
    } catch {
      // Storage fallback
    }
  };

  // Like a specific comment
  const handleLikeComment = (commentId: string) => {
    const updated = comments.map((c) => {
      if (c.id === commentId) {
        const isLiked = !c.isLiked;
        return {
          ...c,
          isLiked,
          likes: isLiked ? c.likes + 1 : Math.max(0, c.likes - 1),
        };
      }
      return c;
    });
    setComments(updated);
    try {
      localStorage.setItem(`broteach_comments_${postSlug}`, JSON.stringify(updated));
    } catch {
      // Ignore
    }
  };

  // Share link
  const handleShare = () => {
    if (typeof window !== "undefined") {
      if (navigator.share) {
        navigator.share({ title: postTitle, url: window.location.href });
      } else {
        navigator.clipboard.writeText(window.location.href);
        setCopiedShare(true);
        setTimeout(() => setCopiedShare(false), 2000);
      }
    }
  };

  return (
    <div className="mt-10 pt-6 border-t border-slate-800/80">
      {/* Facebook-style Reactions Count Summary Bar */}
      <div className="flex items-center justify-between text-xs text-slate-400 pb-3 border-b border-slate-800/60">
        <div className="flex items-center gap-1.5">
          <span className="flex -space-x-1 items-center">
            <span className="w-5 h-5 rounded-full bg-blue-600 flex items-center justify-center text-[10px] shadow-sm">
              👍
            </span>
            <span className="w-5 h-5 rounded-full bg-red-600 flex items-center justify-center text-[10px] shadow-sm">
              ❤️
            </span>
          </span>
          <span className="font-semibold text-slate-300">
            {likesCount} {language === "km" ? "នាក់" : "reactions"}
          </span>
        </div>

        <div className="flex items-center gap-3 text-slate-400">
          <span>
            {comments.length} {language === "km" ? "មតិយោបល់" : "comments"}
          </span>
          <span>•</span>
          <span>12 {language === "km" ? "ចែករំលែក" : "shares"}</span>
        </div>
      </div>

      {/* Facebook-style 3 Action Buttons (Like / Comment / Share) */}
      <div className="relative grid grid-cols-3 py-1.5 border-b border-slate-800/80 my-1">
        {/* Floating Reactions Popover on Hover / Hold */}
        {showReactionsPop && (
          <div
            onMouseEnter={() => setShowReactionsPop(true)}
            onMouseLeave={() => setShowReactionsPop(false)}
            className="absolute -top-12 left-2 flex items-center gap-2 bg-[#06152a] border border-cyan-500/40 rounded-full px-3 py-1.5 shadow-2xl z-30 animate-in fade-in zoom-in-95 duration-150"
          >
            {[
              { id: "like", emoji: "👍", label: "Like" },
              { id: "love", emoji: "❤️", label: "Love" },
              { id: "fire", emoji: "🔥", label: "Fire" },
              { id: "rocket", emoji: "🚀", label: "Rocket" },
            ].map((rx) => (
              <button
                key={rx.id}
                onClick={() => handleToggleLike(rx.id)}
                className="text-lg hover:scale-135 transition-transform p-1 cursor-pointer"
                title={rx.label}
              >
                {rx.emoji}
              </button>
            ))}
          </div>
        )}

        {/* Like Button */}
        <button
          onClick={() => handleToggleLike(userReaction || "like")}
          onMouseEnter={() => setShowReactionsPop(true)}
          className={`flex items-center justify-center gap-1.5 sm:gap-2 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
            userReaction
              ? "text-cyan-400 bg-cyan-950/40"
              : "text-slate-400 hover:text-white hover:bg-slate-800/50"
          }`}
        >
          {userReaction === "love" ? (
            <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
          ) : (
            <ThumbsUp
              className={`w-4 h-4 ${
                userReaction ? "fill-cyan-400 text-cyan-400 scale-110" : ""
              }`}
            />
          )}
          <span>
            {userReaction
              ? language === "km"
                ? "បានចូលចិត្ត"
                : "Liked"
              : language === "km"
              ? "ចូលចិត្ត"
              : "Like"}
          </span>
        </button>

        {/* Comment Button */}
        <button
          onClick={() => {
            const input = document.getElementById("comment-input-box");
            if (input) input.focus();
          }}
          className="flex items-center justify-center gap-1.5 sm:gap-2 py-2 rounded-xl text-xs sm:text-sm font-bold text-slate-400 hover:text-white hover:bg-slate-800/50 transition-all cursor-pointer"
        >
          <MessageCircle className="w-4 h-4" />
          <span>{language === "km" ? "មតិយោបល់" : "Comment"}</span>
        </button>

        {/* Share Button */}
        <button
          onClick={handleShare}
          className="flex items-center justify-center gap-1.5 sm:gap-2 py-2 rounded-xl text-xs sm:text-sm font-bold text-slate-400 hover:text-white hover:bg-slate-800/50 transition-all cursor-pointer"
        >
          {copiedShare ? (
            <>
              <Check className="w-4 h-4 text-emerald-400" />
              <span className="text-emerald-400">
                {language === "km" ? "បានចម្លង" : "Copied!"}
              </span>
            </>
          ) : (
            <>
              <Share2 className="w-4 h-4" />
              <span>{language === "km" ? "ចែករំលែក" : "Share"}</span>
            </>
          )}
        </button>
      </div>

      {/* Realtime Comment Box (Facebook Style) */}
      <div className="pt-4 space-y-4">
        <form onSubmit={handleSubmitComment} className="flex gap-2.5 items-start">
          {/* User Avatar */}
          <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center font-bold text-white text-xs flex-shrink-0 shadow-md">
            {authorName.trim() ? authorName.trim()[0].toUpperCase() : "U"}
          </div>

          <div className="flex-1 space-y-2">
            <input
              type="text"
              value={authorName}
              onChange={(e) => setAuthorName(e.target.value)}
              placeholder={
                language === "km" ? "ឈ្មោះរបស់អ្នក (Your Name)..." : "Your Name (Optional)..."
              }
              className="w-full sm:w-64 px-3 py-1.5 rounded-lg bg-[#051628] border border-cyan-500/25 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-cyan-400"
            />

            <div className="relative flex items-center">
              <input
                id="comment-input-box"
                type="text"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder={
                  language === "km"
                    ? "សរសេរមតិយោបល់របស់អ្នក..."
                    : "Write a public comment..."
                }
                className="w-full pl-4 pr-12 py-2.5 rounded-2xl bg-[#051628] border border-cyan-500/30 text-white text-xs sm:text-sm placeholder-slate-400 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all shadow-inner"
              />
              <button
                type="submit"
                disabled={!newComment.trim()}
                className={`absolute right-2 p-1.5 rounded-xl transition-all cursor-pointer ${
                  newComment.trim()
                    ? "bg-cyan-500 text-slate-950 hover:bg-cyan-400 scale-105"
                    : "text-slate-600 cursor-not-allowed"
                }`}
                title="Post comment"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </form>

        {/* Realtime Comments List (Facebook Bubble Style) */}
        <div className="space-y-3 pt-2">
          {comments.map((comment) => (
            <div key={comment.id} className="flex items-start gap-2.5 group">
              {/* Commenter Avatar */}
              <div
                className={`w-8 h-8 rounded-full bg-gradient-to-tr ${comment.avatarColor} flex items-center justify-center font-bold text-white text-xs flex-shrink-0 shadow-md mt-0.5`}
              >
                {comment.author[0].toUpperCase()}
              </div>

              {/* Comment Bubble & Actions */}
              <div className="flex-1 space-y-1">
                {/* Bubble */}
                <div className="inline-block max-w-[92%] sm:max-w-[85%] rounded-2xl bg-[#06182f] border border-cyan-500/20 px-3.5 py-2 shadow-md">
                  <p className="text-xs font-black text-cyan-300 tracking-tight">
                    {comment.author}
                  </p>
                  <p className="text-xs sm:text-[13px] text-slate-200 leading-relaxed mt-0.5 whitespace-pre-wrap">
                    {comment.text}
                  </p>
                </div>

                {/* Sub-actions: Like / Time / Count */}
                <div className="flex items-center gap-3 text-[11px] text-slate-400 pl-2">
                  <button
                    onClick={() => handleLikeComment(comment.id)}
                    className={`font-bold hover:underline cursor-pointer ${
                      comment.isLiked ? "text-cyan-400 font-black" : "hover:text-slate-200"
                    }`}
                  >
                    {language === "km" ? "ចូលចិត្ត" : "Like"}
                  </button>
                  <span>•</span>
                  <span>{language === "km" ? comment.timeAgoKm : comment.timeAgoEn}</span>
                  {comment.likes > 0 && (
                    <>
                      <span>•</span>
                      <span className="flex items-center gap-1 text-slate-300 font-semibold bg-cyan-950/80 px-1.5 py-0.2 rounded-full border border-cyan-500/30 text-[10px]">
                        👍 {comment.likes}
                      </span>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
