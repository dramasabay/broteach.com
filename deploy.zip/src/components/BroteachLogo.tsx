"use client";

import React, { useState } from "react";

export interface BroteachLogoProps {
  className?: string;
  size?: number | string;
}

/**
 * Broteach Official Vector Emblem
 * Clean, human-crafted vector geometry:
 * A rich royal-blue rounded badge with the white letter structure and glowing cyan `<` coding chevron.
 */
export const BroteachLogo: React.FC<BroteachLogoProps> = ({
  className = "w-9 h-9",
  size,
}) => {
  const sizeStyle = size ? { width: size, height: size } : undefined;

  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 select-none ${className}`}
      style={sizeStyle}
    >
      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-sm transition-transform duration-200 group-hover:scale-105"
      >
        <defs>
          {/* Confident Royal Blue Brand Gradient */}
          <linearGradient id="btRoyalBlue" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#256bf5" />
            <stop offset="100%" stopColor="#1856dc" />
          </linearGradient>

          {/* Clean Electric Cyan for the Code Chevron */}
          <linearGradient id="btCyanCode" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#38bdf8" />
            <stop offset="100%" stopColor="#00e5ff" />
          </linearGradient>
        </defs>

        {/* Outer Rounded Square Badge with Subtle 1px Highlight */}
        <rect
          x="2"
          y="2"
          width="96"
          height="96"
          rx="22"
          fill="url(#btRoyalBlue)"
          stroke="#60a5fa"
          strokeWidth="0.8"
          strokeOpacity="0.4"
        />

        {/* White Outer Body (Top bar, continuous right spine curve, bottom bar) */}
        <path
          fill="#ffffff"
          d="
            M 24 17
            L 62 17
            C 77 17, 81 28, 81 50
            C 81 72, 77 83, 62 83
            L 24 83
            L 24 71
            L 60 71
            C 67 71, 70 66, 70 50
            C 70 34, 67 29, 60 29
            L 24 29
            Z
          "
        />

        {/* Middle White Tongue embracing the Cyan Chevron */}
        <polygon
          fill="#ffffff"
          points="
            37,50
            46,43
            65,43
            67,46
            67,54
            65,57
            46,57
          "
        />

        {/* Cyan Code Chevron `<` */}
        <polygon
          fill="url(#btCyanCode)"
          points="
            20,50
            48,29
            48,39
            34,50
            48,61
            48,71
          "
        />
      </svg>
    </div>
  );
};

export interface BroteachBrandProps {
  logoUrl?: string | null;
  brandName?: string;
  brandSubtitle?: string;
  brandDotColor?: string;
  borderStyle?: "none" | "blue" | "cyan-glow" | "pill" | "glass" | string;
  size?: "sm" | "md" | "lg";
  className?: string;
}

/**
 * Broteach Brand Component
 * Tastefully styled without artificial gimmicks.
 * Renders the logo emblem and customizable text with zero flickering.
 */
export const BroteachBrand: React.FC<BroteachBrandProps> = ({
  logoUrl,
  brandName = "broteach",
  brandSubtitle = "Digital & Cloud",
  brandDotColor = "#ef4444",
  borderStyle = "none",
  size = "md",
  className = "",
}) => {
  const [imageError, setImageError] = useState(false);

  const iconDim = size === "sm" ? "w-8 h-8" : size === "lg" ? "w-11 h-11" : "w-9 h-9";
  const nameSize = size === "sm" ? "text-lg" : size === "lg" ? "text-2xl sm:text-3xl" : "text-xl sm:text-2xl";
  const subSize = size === "sm" ? "text-[8.5px]" : size === "lg" ? "text-[11px]" : "text-[9.5px]";

  // Normalize full localhost URLs to clean relative paths
  const cleanLogoUrl = logoUrl ? logoUrl.replace(/^https?:\/\/[^/]+(?=\/uploads\/)/, "") : null;

  // Clean, professional border frames (not raw/cheesy outlines)
  let borderClasses = "";
  if (borderStyle === "blue" || borderStyle === "blue-solid") {
    borderClasses = "border border-blue-500/70 rounded-lg px-2.5 py-1 bg-blue-950/20";
  } else if (borderStyle === "cyan-glow") {
    borderClasses = "border border-cyan-500/40 rounded-lg px-2.5 py-1 bg-cyan-950/20 shadow-[0_0_10px_rgba(6,182,212,0.15)]";
  } else if (borderStyle === "glass") {
    borderClasses = "border border-slate-700/60 rounded-lg px-2.5 py-1 bg-white/5 backdrop-blur-xs";
  } else if (borderStyle === "pill") {
    borderClasses = "border border-slate-700/80 rounded-full px-3 py-1 bg-[#051428]";
  }

  return (
    <div className={`flex items-center gap-2.5 group cursor-pointer transition-all ${className}`}>
      {/* Icon: Custom Uploaded Logo (if available & valid) OR Native Crisp Vector SVG */}
      {cleanLogoUrl && !imageError ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={cleanLogoUrl}
          alt={brandName}
          onError={() => setImageError(true)}
          className={`${iconDim} object-contain rounded-xl shadow-xs transition-transform duration-200 group-hover:scale-105`}
          style={{ imageRendering: "auto" }}
        />
      ) : (
        <BroteachLogo className={iconDim} />
      )}

      {/* Brand Typography */}
      <div className={`flex flex-col transition-all ${borderClasses}`}>
        <span className={`${nameSize} font-black tracking-tight flex items-center leading-none text-white`}>
          {brandName}
          <span
            className="text-2xl sm:text-3xl leading-none ml-0.5"
            style={{ color: brandDotColor || "#ef4444" }}
          >
            .
          </span>
        </span>
        <span className={`${subSize} text-cyan-400 font-semibold tracking-[0.16em] uppercase mt-1`}>
          {brandSubtitle}
        </span>
      </div>
    </div>
  );
};
