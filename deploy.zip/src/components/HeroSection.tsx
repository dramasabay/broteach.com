"use client";

import React, { useState, useEffect, useMemo } from "react";
import { Play, ArrowRight, Bell } from "lucide-react";
import { useLanguage } from "./LanguageContext";
import { SiteSettings } from "@/types";

interface HeroSectionProps {
  onGetStarted?: () => void;
  settings?: SiteSettings;
  titleKm?: string;
  titleEn?: string;
  subtitleKm?: string;
  subtitleEn?: string;
  announcementKm?: string;
  announcementEn?: string;
  showAnnouncement?: boolean;
  telegramUsername?: string;
}

// The SVG server graphic as an inline component
const ServerSvg = ({ className }: { className?: string }) => (
  <svg
    viewBox="0 0 600 480"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <defs>
      <linearGradient id="cloudGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
        <stop offset="100%" stopColor="#cffafe" stopOpacity="0.85" />
      </linearGradient>
      <linearGradient id="rackGrad" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#0891b2" />
        <stop offset="50%" stopColor="#0e7490" />
        <stop offset="100%" stopColor="#155e75" />
      </linearGradient>
      <linearGradient id="rackFront" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#0284c7" />
        <stop offset="100%" stopColor="#0369a1" />
      </linearGradient>
      <linearGradient id="glowLine" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#38bdf8" />
        <stop offset="100%" stopColor="#22d3ee" stopOpacity="0.2" />
      </linearGradient>
    </defs>

    {/* Isometric Platform Floor Grid */}
    <path
      d="M300 410 L480 320 L300 230 L120 320 Z"
      fill="#03213b"
      fillOpacity="0.5"
      stroke="#0891b2"
      strokeWidth="1.5"
      strokeDasharray="4 4"
    />

    {/* Connecting Glowing Data Lines */}
    <path
      d="M300 230 L300 130"
      stroke="url(#glowLine)"
      strokeWidth="3"
      strokeDasharray="6 4"
      className="animate-pulse"
    />
    <path
      d="M210 320 L300 370 L390 320"
      stroke="#38bdf8"
      strokeWidth="2"
      fill="none"
      strokeDasharray="5 5"
    />
    <path
      d="M450 170 C410 210, 370 240, 340 280"
      stroke="#38bdf8"
      strokeWidth="2.5"
      fill="none"
      strokeDasharray="4 4"
    />

    {/* 3D Isometric Server Rack */}
    <g transform="translate(40, -10)">
      <polygon points="260,190 320,160 380,190 320,220" fill="#38bdf8" />
      <polygon points="260,190 320,220 320,380 260,350" fill="url(#rackFront)" />
      <polygon points="320,220 380,190 380,350 320,380" fill="url(#rackGrad)" />

      {[0, 1, 2, 3, 4, 5].map((i) => {
        const y = 230 + i * 22;
        return (
          <g key={i}>
            <line x1="270" y1={y - 15} x2="310" y2={y + 5} stroke="#022c43" strokeWidth="3" />
            <circle cx={275} cy={y - 12} r="2.5" fill="#4ade80" className="animate-led" />
            <circle cx={283} cy={y - 8} r="2.5" fill="#38bdf8" />
            <circle cx={291} cy={y - 4} r="2" fill="#facc15" />
            <line x1="298" y1={y} x2="308" y2={y + 5} stroke="#38bdf8" strokeWidth="1" strokeOpacity="0.6" />
          </g>
        );
      })}
    </g>

    {/* Database Cylinder */}
    <g transform="translate(-10, 30)">
      <ellipse cx="200" cy="330" rx="35" ry="16" fill="#0284c7" />
      <path d="M165 330 C165 338 235 338 235 330 L235 360 C235 368 165 368 165 360 Z" fill="#0369a1" />
      <ellipse cx="200" cy="360" rx="35" ry="16" fill="#0284c7" />

      <path d="M165 295 C165 303 235 303 235 295 L235 325 C235 333 165 333 165 325 Z" fill="#0891b2" />
      <ellipse cx="200" cy="295" rx="35" ry="16" fill="#22d3ee" />

      <path d="M165 260 C165 268 235 268 235 260 L235 290 C235 298 165 290 165 290 Z" fill="#0e7490" />
      <ellipse cx="200" cy="260" rx="35" ry="16" fill="#67e8f9" />

      <circle cx="200" cy="295" r="3" fill="#22c55e" className="animate-ping" />
    </g>

    {/* Mobile / Tablet Isometric Screen */}
    <g transform="translate(18, 50)">
      <polygon points="380,300 450,265 490,290 420,325" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />
      <polygon points="388,300 445,272 478,290 421,318" fill="#1e293b" />
      <line x1="400" y1="298" x2="435" y2="280" stroke="#38bdf8" strokeWidth="2" />
      <line x1="405" y1="306" x2="450" y2="284" stroke="#4ade80" strokeWidth="1.5" />
      <line x1="412" y1="312" x2="465" y2="286" stroke="#94a3b8" strokeWidth="1" />
    </g>

    {/* Floating Cloud Storage */}
    <g transform="translate(340, 70)" className="animate-float-slow">
      <path
        d="M35 60 C25 60 15 50 18 40 C20 30 30 25 40 28 C45 15 65 10 80 20 C90 10 110 12 115 25 C125 25 132 35 130 45 C135 55 125 65 115 65 L35 65 Z"
        fill="url(#cloudGrad)"
        stroke="#38bdf8"
        strokeWidth="2"
      />
      <path d="M72 38 L62 48 L68 48 L68 56 L76 56 L76 48 L82 48 Z" fill="#0284c7" />
      <path d="M84 45 L94 35 L88 35 L88 27 L80 27 L80 35 L74 35 Z" fill="#06b6d4" opacity="0.8" />
    </g>

    {/* Floating Tech Badges */}
    <g transform="translate(70, 160)" className="animate-float">
      <rect width="110" height="34" rx="17" fill="#041f38" stroke="#06b6d4" strokeWidth="1.5" />
      <circle cx="20" cy="17" r="7" fill="#06b6d4" />
      <text x="35" y="21" fill="#cffafe" fontSize="11" fontWeight="600" fontFamily="sans-serif">
        99.9% UPTIME
      </text>
    </g>

    <g transform="translate(410, 360)" className="animate-float-slow">
      <rect width="120" height="34" rx="17" fill="#041f38" stroke="#10b981" strokeWidth="1.5" />
      <circle cx="20" cy="17" r="7" fill="#10b981" />
      <text x="35" y="21" fill="#a7f3d0" fontSize="11" fontWeight="600" fontFamily="sans-serif">
        SSL 256-BIT
      </text>
    </g>
  </svg>
);

// Animated Typing component with Intl.Segmenter for flawless Khmer grapheme rendering
const TypingHeroTitle: React.FC<{ text: string }> = ({ text }) => {
  const [displayedCount, setDisplayedCount] = useState<number>(0);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const mounted = React.useSyncExternalStore(
    () => () => {},
    () => true,
    () => false
  );

  const [prevText, setPrevText] = useState(text);
  if (prevText !== text) {
    setPrevText(text);
    setDisplayedCount(0);
    setIsDeleting(false);
  }

  // Parse grapheme clusters so Khmer compound vowels and subscript characters never split
  const graphemes = useMemo(() => {
    if (typeof Intl !== "undefined" && "Segmenter" in Intl) {
      try {
        const segmenter = new Intl.Segmenter("km", { granularity: "grapheme" });
        return Array.from(segmenter.segment(text), (s) => s.segment);
      } catch {
        return Array.from(text);
      }
    }
    return Array.from(text);
  }, [text]);

  useEffect(() => {
    if (!mounted) return;

    let timer: ReturnType<typeof setTimeout>;

    if (!isDeleting) {
      if (displayedCount < graphemes.length) {
        // Natural typing rhythm ~85ms
        timer = setTimeout(() => {
          setDisplayedCount((prev) => prev + 1);
        }, 85);
      } else {
        // Full phrase displayed: pause for 3.5s so users can read comfortably
        timer = setTimeout(() => {
          setIsDeleting(true);
        }, 3500);
      }
    } else {
      if (displayedCount > 0) {
        // Backspacing speed ~40ms
        timer = setTimeout(() => {
          setDisplayedCount((prev) => prev - 1);
        }, 40);
      } else {
        // Brief pause before typing again
        timer = setTimeout(() => {
          setIsDeleting(false);
        }, 500);
      }
    }

    return () => clearTimeout(timer);
  }, [displayedCount, isDeleting, graphemes.length, mounted]);

  // SSR & initial client render fallback ensures perfect hydration and SEO indexing
  if (!mounted) {
    return (
      <span className="relative inline-block">
        <span>{text}</span>
        <span
          aria-hidden="true"
          className="inline-block w-1 sm:w-1.5 h-6 sm:h-9 lg:h-11 ml-1.5 bg-gradient-to-b from-cyan-300 to-cyan-500 rounded-sm animate-pulse align-middle shadow-[0_0_10px_rgba(6,182,212,0.8)]"
        />
      </span>
    );
  }

  const currentText = graphemes.slice(0, displayedCount).join("");

  return (
    <span className="relative inline-block min-h-[1.3em]">
      <span>{currentText}</span>
      <span
        aria-hidden="true"
        className="inline-block w-1 sm:w-1.5 h-6 sm:h-9 lg:h-11 ml-1.5 bg-gradient-to-b from-cyan-300 to-cyan-500 rounded-sm animate-pulse align-middle shadow-[0_0_10px_rgba(6,182,212,0.8)]"
      />
    </span>
  );
};

export const HeroSection: React.FC<HeroSectionProps> = ({
  onGetStarted,
  settings,
  titleKm,
  titleEn,
  subtitleKm,
  subtitleEn,
  announcementKm,
  announcementEn,
  showAnnouncement,
  telegramUsername,
}) => {
  const { language, t } = useLanguage();

  const finalTitleKm = titleKm || settings?.heroTitleKm;
  const finalTitleEn = titleEn || settings?.heroTitleEn;
  const heroTitle =
    (language === "km" ? finalTitleKm : finalTitleEn) || t.hero.title;

  const finalSubtitleKm = subtitleKm || settings?.heroSubtitleKm;
  const finalSubtitleEn = subtitleEn || settings?.heroSubtitleEn;
  const heroSubtitle =
    (language === "km" ? finalSubtitleKm : finalSubtitleEn) || t.hero.subtitle;

  const finalShowAnnouncement =
    showAnnouncement !== undefined ? showAnnouncement : settings?.showAnnouncement;
  const finalAnnounceKm = announcementKm || settings?.announcementTextKm;
  const finalAnnounceEn = announcementEn || settings?.announcementTextEn;
  const announcement =
    finalShowAnnouncement && (language === "km" ? finalAnnounceKm : finalAnnounceEn);

  const heroBadge =
    (language === "km" ? settings?.heroBadgeKm : settings?.heroBadgeEn) ||
    (language === "km" ? "សេវាកម្មកម្រិតស្តង់ដារអន្តរជាតិ" : "Enterprise Standard Solutions");

  const ctaText =
    (language === "km" ? settings?.heroCtaTextKm : settings?.heroCtaTextEn) ||
    t.hero.getStarted;

  const rawTg = settings?.heroCtaTelegramUrl || telegramUsername || settings?.telegramUsername || "broteach_support";
  const cleanTg = rawTg.replace(/^@/, "").replace(/^https?:\/\/t\.me\//, "");
  const telegramUrl = rawTg.startsWith("http") ? rawTg : `https://t.me/${cleanTg}`;

  const secBtnText =
    (language === "km" ? settings?.heroSecondaryBtnTextKm : settings?.heroSecondaryBtnTextEn) ||
    (language === "km" ? "មើលផលិតផល & សេវា" : "Explore Products");
  const secBtnUrl = settings?.heroSecondaryBtnUrl || "/products";

  const stat1Num = settings?.heroStat1Number || t.hero.stats.uptime;
  const stat1Label =
    (language === "km" ? settings?.heroStat1LabelKm : settings?.heroStat1LabelEn) ||
    t.hero.stats.uptimeLabel;

  const stat2Num = settings?.heroStat2Number || t.hero.stats.clients;
  const stat2Label =
    (language === "km" ? settings?.heroStat2LabelKm : settings?.heroStat2LabelEn) ||
    t.hero.stats.clientsLabel;

  const stat3Num = settings?.heroStat3Number || t.hero.stats.support;
  const stat3Label =
    (language === "km" ? settings?.heroStat3LabelKm : settings?.heroStat3LabelEn) ||
    t.hero.stats.supportLabel;

  return (
    <section
      id="home"
      className="relative pt-28 pb-16 md:pt-36 md:pb-24 overflow-hidden hero-gradient"
    >
      {/* Cyber Grid Background */}
      <div className="absolute inset-0 bg-[radial-gradient(#0891b2_1px,transparent_1px)] [background-size:28px_28px] opacity-15 pointer-events-none" />
      <div className="absolute top-1/4 -left-24 w-96 h-96 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Dynamic Announcement Ticker */}
        {announcement && (
          <div className="mb-6 flex justify-center">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-red-950/60 border border-red-500/40 text-red-300 text-xs font-semibold shadow-lg animate-pulse">
              <Bell className="w-3.5 h-3.5 text-red-400" />
              <span>{announcement}</span>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Text & CTA with Server SVG as background on mobile */}
          <div className="relative lg:col-span-6 space-y-6 text-center lg:text-left animate-fade-in-up">
            {/* Server graphic as responsive background on mobile behind this content */}
            <div className="absolute inset-0 -top-6 -bottom-6 flex items-center justify-center lg:hidden pointer-events-none overflow-hidden opacity-20 -z-10">
              <ServerSvg className="w-[320px] sm:w-[420px] max-w-none transform scale-110 drop-shadow-none" />
            </div>

            {/* Top Tag Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/70 border border-cyan-500/30 text-cyan-300 text-xs font-medium shadow-sm">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              <span>{heroBadge}</span>
            </div>

            {/* Main Title with Typing Animation */}
            <h1
              className="text-2xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-snug sm:leading-tight lg:leading-[1.2]"
              suppressHydrationWarning
            >
              <TypingHeroTitle text={heroTitle} />
            </h1>

            {/* Subtitle */}
            <p className="text-sm sm:text-base text-slate-300/90 leading-relaxed max-w-xl mx-auto lg:mx-0">
              {heroSubtitle}
            </p>

            {/* CTA Buttons — sleek and smart on mobile */}
            <div className="pt-2 flex flex-row items-center justify-center lg:justify-start gap-2.5 sm:gap-3 flex-wrap">
              {/* Primary: Get Started - Opens Telegram directly */}
              <a
                href={telegramUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  if (onGetStarted) onGetStarted();
                }}
                id="hero-get-started"
                className="group relative inline-flex items-center justify-center gap-2 sm:gap-3 px-5 sm:px-7 py-2.5 sm:py-3.5 rounded-full bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 text-slate-950 font-bold sm:font-extrabold text-xs sm:text-base shadow-[0_6px_20px_-2px_rgba(245,158,11,0.4)] hover:shadow-[0_12px_28px_-4px_rgba(245,158,11,0.6)] hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer"
              >
                <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-slate-950/15 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Play className="w-3 h-3 sm:w-3.5 sm:h-3.5 fill-slate-950 text-slate-950 ml-0.5" />
                </div>
                <span>{ctaText}</span>
              </a>

              {/* Secondary: Explore Products */}
              <a
                href={secBtnUrl}
                className="inline-flex items-center justify-center gap-1.5 px-4 sm:px-5 py-2.5 sm:py-3.5 rounded-full border border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/10 hover:text-white text-xs sm:text-sm font-semibold transition-all backdrop-blur-sm bg-cyan-950/30"
              >
                <span>{secBtnText}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Quick Metrics Bar */}
            <div className="pt-6 border-t border-cyan-900/40 grid grid-cols-3 gap-4 max-w-md mx-auto lg:mx-0">
              <div>
                <p className="text-xl sm:text-2xl font-black text-cyan-400">{stat1Num}</p>
                <p className="text-xs text-slate-400">{stat1Label}</p>
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-black text-white">{stat2Num}</p>
                <p className="text-xs text-slate-400">{stat2Label}</p>
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-black text-amber-400">{stat3Num}</p>
                <p className="text-xs text-slate-400">{stat3Label}</p>
              </div>
            </div>
          </div>

          {/* Right Column: Server SVG — visible only on desktop */}
          <div className="hidden lg:flex lg:col-span-6 relative items-center justify-center animate-fade-in-up delay-200">
            <div className="relative w-full max-w-[520px] aspect-[5/4] flex items-center justify-center">
              <div className="absolute -bottom-6 w-3/4 h-24 bg-cyan-500/20 rounded-[100%] blur-2xl pointer-events-none animate-pulse-glow" />
              <ServerSvg className="w-full h-full drop-shadow-[0_20px_35px_rgba(0,0,0,0.5)] animate-float" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
