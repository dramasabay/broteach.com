"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { Sparkles, ArrowRight, X } from "lucide-react";
import { useLanguage } from "./LanguageContext";

interface HeaderAnnouncementProps {
  settings?: {
    headerBannerActive?: boolean;
    headerBannerTextKm?: string;
    headerBannerTextEn?: string;
    headerBannerBadgeKm?: string;
    headerBannerBadgeEn?: string;
    headerBannerLink?: string;
  };
}

export const HeaderAnnouncement: React.FC<HeaderAnnouncementProps> = ({ settings: propSettings }) => {
  const { language } = useLanguage();
  const [fetchedSettings, setFetchedSettings] = useState<HeaderAnnouncementProps["settings"] | null>(null);
  const [isDismissed, setIsDismissed] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      try {
        return sessionStorage.getItem("broteach_header_ads_dismissed") === "true";
      } catch {
        return false;
      }
    }
    return false;
  });

  useEffect(() => {
    if (propSettings) return;

    let mounted = true;
    fetch(`/api/content?t=${Date.now()}`)
      .then((res) => res.json())
      .then((data) => {
        if (mounted && data.settings) {
          setFetchedSettings(data.settings);
        }
      })
      .catch(() => {});

    return () => {
      mounted = false;
    };
  }, [propSettings]);

  const settings = propSettings || fetchedSettings;

  if (isDismissed || !settings || settings.headerBannerActive === false) {
    return null;
  }

  const isKm = language === "km";
  const text = isKm ? (settings.headerBannerTextKm || settings.headerBannerTextEn) : (settings.headerBannerTextEn || settings.headerBannerTextKm);
  const badge = isKm ? (settings.headerBannerBadgeKm || settings.headerBannerBadgeEn || "🎉 ព្រឹត្តិការណ៍") : (settings.headerBannerBadgeEn || settings.headerBannerBadgeKm || "🎉 EVENT");
  const link = settings.headerBannerLink || "/pricing";

  if (!text) return null;

  const handleDismiss = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsDismissed(true);
    if (typeof window !== "undefined") {
      try {
        sessionStorage.setItem("broteach_header_ads_dismissed", "true");
      } catch {}
    }
  };

  return (
    <div className="relative bg-gradient-to-r from-red-600 via-amber-600 to-rose-600 text-white text-xs sm:text-sm font-medium py-2 px-3 sm:px-4 shadow-lg border-b border-red-400/30 z-50 overflow-hidden">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Fixed Badge on left */}
        {badge && (
          <div className="shrink-0 flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-black uppercase tracking-wider bg-black/40 border border-white/20 text-yellow-300 shadow-xs z-10">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300 animate-pulse shrink-0" />
            <span className="whitespace-nowrap">{badge}</span>
          </div>
        )}

        {/* Continuous Looping Marquee Ticker (Right to Left) */}
        <div className="flex-1 overflow-hidden relative cursor-pointer group">
          <Link
            href={link}
            className="animate-marquee-rtl flex items-center gap-8 py-0.5 font-bold text-white drop-shadow-xs"
          >
            {[0, 1, 2, 3, 4, 5].map((idx) => (
              <span key={idx} className="flex items-center gap-3 shrink-0 group-hover:underline">
                <span>{text}</span>
                <ArrowRight className="w-3.5 h-3.5 text-yellow-200 shrink-0" />
                <span className="text-yellow-300 opacity-60">✦</span>
              </span>
            ))}
          </Link>
        </div>

        {/* Dismiss Button on right */}
        <button
          onClick={handleDismiss}
          className="shrink-0 p-1 rounded-md text-white/80 hover:text-white hover:bg-black/20 transition-colors z-10"
          title="Close announcement"
          aria-label="Close announcement"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
