"use client";

import React from "react";
import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import { Phone, Mail, MapPin, BookOpen } from "lucide-react";
import { useLanguage } from "./LanguageContext";
import { SiteSettings } from "@/types";
import { BroteachBrand } from "./BroteachLogo";
import { useSiteSettings } from "./SiteSettingsContext";

interface FooterProps {
  onOpenChat?: () => void;
  telegramUsername?: string;
  phone1?: string;
  phone2?: string;
  settings?: SiteSettings | null;
}

export const Footer: React.FC<FooterProps> = ({
  phone1: propPhone1,
  phone2: propPhone2,
  settings: propSettings,
}) => {
  const { language, t } = useLanguage();
  const router = useRouter();
  const pathname = usePathname();
  const { settings: globalSettings } = useSiteSettings();
  const cmsSettings = propSettings || globalSettings;

  const phone1 = cmsSettings?.phone1 || propPhone1 || "(+855) 098 765 432";
  const phone2 = cmsSettings?.phone2 || propPhone2 || "";
  const email = cmsSettings?.email || t.footer.email;
  const address = (language === "km" ? cmsSettings?.addressKm : cmsSettings?.addressEn) || t.footer.address;
  const logoUrl = cmsSettings?.siteLogoUrl;
  const desc =
    (language === "km" ? cmsSettings?.footerDescKm : cmsSettings?.footerDescEn) ||
    (language === "km"
      ? "សេវាកម្មបង្កើតគេហទំព័រអាជីវកម្មតាមបែបស្តង់ដារ ហាងទំនិញ E-Commerce និង Cloud Hosting NVMe SSD ល្បឿនលឿន និងសុវត្ថិភាពខ្ពស់នៅកម្ពុជា។"
      : "Standard business websites, E-commerce with automated ABA KHQR, and NVMe SSD cloud hosting in Cambodia.");
  const copyright =
    (language === "km" ? cmsSettings?.footerCopyrightKm : cmsSettings?.footerCopyrightEn) ||
    (language === "km"
      ? "© 2026 Broteach Digital Solutions. រក្សាសិទ្ធិគ្រប់យ៉ាង។"
      : "© 2026 Broteach Digital Solutions. All Rights Reserved.");
  const fbUrl = cmsSettings?.facebookUrl || "https://facebook.com/broteach";
  const ytUrl = cmsSettings?.youtubeUrl || "https://youtube.com/@broteach";

  const contactHeading =
    (language === "km" ? cmsSettings?.footerContactHeadingKm : cmsSettings?.footerContactHeadingEn) ||
    t.footer.haveQuestion;

  const servicesTitle =
    (language === "km" ? cmsSettings?.footerServicesTitleKm : cmsSettings?.footerServicesTitleEn) ||
    t.footer.services;

  const quickLinksTitle =
    (language === "km" ? cmsSettings?.footerQuickLinksTitleKm : cmsSettings?.footerQuickLinksTitleEn) ||
    t.footer.quickLinks;

  const service1Text = (language === "km" ? cmsSettings?.footerService1Km : cmsSettings?.footerService1En) || (language === "km" ? "ផលិតផលគេហទំព័រ" : "Web Products");
  const service1Url = cmsSettings?.footerService1Url || "/products";

  const service2Text = (language === "km" ? cmsSettings?.footerService2Km : cmsSettings?.footerService2En) || (language === "km" ? "បង្កើតគេហទំព័រ" : "Web Design");
  const service2Url = cmsSettings?.footerService2Url === "/#pricing" || !cmsSettings?.footerService2Url ? "/pricing" : cmsSettings.footerService2Url;

  const service3Text = (language === "km" ? cmsSettings?.footerService3Km : cmsSettings?.footerService3En) || (language === "km" ? "Cloud VPS Hosting" : "Cloud Hosting");
  const service3Url = cmsSettings?.footerService3Url || "/products";

  const service4Text = (language === "km" ? cmsSettings?.footerService4Km : cmsSettings?.footerService4En) || (language === "km" ? "E-commerce & KHQR" : "E-commerce");
  const service4Url = cmsSettings?.footerService4Url || "/products";

  const quickLink1Text = (language === "km" ? cmsSettings?.footerQuickLink1Km : cmsSettings?.footerQuickLink1En) || (language === "km" ? "អំពីយើង" : "About Us");
  const quickLink1Url = cmsSettings?.footerQuickLink1Url || "/about";

  const quickLink2Text = (language === "km" ? cmsSettings?.footerQuickLink2Km : cmsSettings?.footerQuickLink2En) || (language === "km" ? "ព័ត៌មាន & Blog" : "Blog & Articles");
  const quickLink2Url = cmsSettings?.footerQuickLink2Url || "/blog";

  const quickLink3Text = (language === "km" ? cmsSettings?.footerQuickLink3Km : cmsSettings?.footerQuickLink3En) || (language === "km" ? "គំរូផ្សាយផ្ទាល់" : "Live Previews");
  const quickLink3Url = cmsSettings?.footerQuickLink3Url || "/products";

  const quickLink4Text = (language === "km" ? cmsSettings?.footerQuickLink4Km : cmsSettings?.footerQuickLink4En) || (language === "km" ? "កញ្ចប់តម្លៃ" : "Pricing");
  const quickLink4Url = cmsSettings?.footerQuickLink4Url === "/#pricing" || !cmsSettings?.footerQuickLink4Url ? "/pricing" : cmsSettings.footerQuickLink4Url;

  const scrollToSection = (sectionId: string) => {
    if (pathname === "/") {
      const el = document.getElementById(sectionId);
      if (el) {
        el.scrollIntoView({ behavior: "smooth" });
      }
    } else {
      router.push("/");
      setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) {
          el.scrollIntoView({ behavior: "smooth" });
        }
      }, 300);
    }
  };

  const renderLinkItem = (url: string, text: string, icon?: React.ReactNode) => {
    if (url.startsWith("/#") || url.startsWith("#")) {
      const target = url.replace(/^\/?#/, "");
      return (
        <button
          type="button"
          onClick={() => scrollToSection(target)}
          className="hover:text-cyan-400 transition-colors text-left cursor-pointer flex items-center gap-1.5"
        >
          {icon}
          <span>{text}</span>
        </button>
      );
    }
    return (
      <Link href={url} className="hover:text-cyan-400 transition-colors flex items-center gap-1.5">
        {icon}
        <span>{text}</span>
      </Link>
    );
  };

  return (
    <footer id="about" className="hidden lg:block bg-[#030a16] text-slate-400 pt-16 pb-12 border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pb-12 border-b border-slate-800/60">
          {/* Col 1: Brand & Contacts */}
          <div className="lg:col-span-6 space-y-5">
            {/* Logo */}
            <Link href="/" className="inline-flex items-center group">
              <BroteachBrand
                logoUrl={logoUrl}
                brandName={cmsSettings?.siteBrandName || "broteach"}
                brandSubtitle={cmsSettings?.siteBrandSubtitle || "Digital & Cloud"}
                brandDotColor={cmsSettings?.siteBrandDotColor || "#ef4444"}
                borderStyle={cmsSettings?.siteBrandBorderStyle || "none"}
                size="md"
              />
            </Link>

            {/* Dynamic Footer Description */}
            <p className="text-xs sm:text-sm text-slate-400 max-w-md leading-relaxed">
              {desc}
            </p>

            {/* Contact heading */}
            <div className="space-y-2 pt-1">
              <h4 className="text-sm font-bold text-white tracking-wide">
                {contactHeading}
              </h4>
              <div className="flex flex-col sm:flex-row gap-3 pt-0.5">
                {[phone1, phone2].filter(Boolean).map((phone, idx) => (
                  <a
                    key={idx}
                    href={`tel:${phone.replace(/\s+/g, "")}`}
                    className="inline-flex items-center gap-2 text-cyan-400 hover:text-cyan-300 font-bold text-sm transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5 text-cyan-500" />
                    <span>{phone}</span>
                  </a>
                ))}
              </div>
            </div>

            {/* Contact Details */}
            <div className="space-y-2 text-xs sm:text-sm">
              <a
                href={`mailto:${email}`}
                className="flex items-center gap-2.5 text-slate-300 hover:text-white transition-colors"
              >
                <Mail className="w-3.5 h-3.5 text-rose-400 flex-shrink-0" />
                <span>{email}</span>
              </a>

              <div className="flex items-start gap-2.5 text-slate-400">
                <MapPin className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                <span className="leading-relaxed">{address}</span>
              </div>
            </div>

            {/* Social Icons */}
            <div className="flex items-center gap-3 pt-1">
              {fbUrl && (
                <a
                  href={fbUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-9 h-9 rounded-full bg-blue-600/90 text-white flex items-center justify-center hover:scale-110 transition-transform shadow-md"
                  title="Facebook"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                  </svg>
                </a>
              )}
              {ytUrl && (
                <a
                  href={ytUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-9 h-9 rounded-full bg-red-600 text-white flex items-center justify-center hover:scale-110 transition-transform shadow-md"
                  title="YouTube"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                  </svg>
                </a>
              )}
            </div>
          </div>

          {/* Services & Quick Links */}
          <div className="lg:col-span-6 grid grid-cols-2 gap-4 sm:gap-8">
            {/* Services Column */}
            <div className="space-y-3 sm:space-y-4">
              <h5 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-white">
                {servicesTitle}
              </h5>
              <ul className="space-y-2 sm:space-y-2.5 text-xs sm:text-sm">
                <li>{renderLinkItem(service1Url, service1Text)}</li>
                <li>{renderLinkItem(service2Url, service2Text)}</li>
                <li>{renderLinkItem(service3Url, service3Text)}</li>
                <li>{renderLinkItem(service4Url, service4Text)}</li>
              </ul>
            </div>

            {/* Quick Links Column */}
            <div className="space-y-3 sm:space-y-4">
              <h5 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-white">
                {quickLinksTitle}
              </h5>
              <ul className="space-y-2 sm:space-y-2.5 text-xs sm:text-sm">
                <li>{renderLinkItem(quickLink1Url, quickLink1Text)}</li>
                <li>{renderLinkItem(quickLink2Url, quickLink2Text, <BookOpen className="w-3 h-3 text-cyan-400" />)}</li>
                <li>{renderLinkItem(quickLink3Url, quickLink3Text)}</li>
                <li>{renderLinkItem(quickLink4Url, quickLink4Text)}</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-slate-500 text-center sm:text-left">
            {copyright}
          </p>
        </div>
      </div>
    </footer>
  );
};
