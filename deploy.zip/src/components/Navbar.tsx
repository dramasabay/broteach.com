"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Sparkles,
  Layers,
  Info,
  DollarSign,
  Home as HomeIcon,
} from "lucide-react";
import { useLanguage } from "./LanguageContext";
import { CambodiaFlag, UKFlag } from "./FlagIcons";

import { HeaderAnnouncement } from "./HeaderAnnouncement";
import { BroteachBrand } from "./BroteachLogo";
import { useSiteSettings } from "./SiteSettingsContext";

interface NavbarProps {
  onOpenChat?: () => void;
  onOpenDemo?: (planId?: string) => void;
  telegramUsername?: string;
  logoUrl?: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  logoUrl: propLogoUrl,
}) => {
  const { language, setLanguage } = useLanguage();
  const pathname = usePathname();
  const router = useRouter();
  const [scrollSection, setScrollSection] = useState<string>("home");
  const { settings: globalSettings } = useSiteSettings();
  const activeLogoUrl = propLogoUrl || globalSettings.siteLogoUrl;
  const brandName = globalSettings.siteBrandName || "broteach";
  const brandSubtitle = globalSettings.siteBrandSubtitle || "Digital & Cloud";
  const brandDotColor = globalSettings.siteBrandDotColor || "#ef4444";
  const brandBorderStyle = globalSettings.siteBrandBorderStyle || "none";

  const activeSection =
    pathname === "/about"
      ? "about"
      : pathname === "/pricing"
      ? "pricing"
      : pathname.startsWith("/product")
      ? "products"
      : pathname === "/blog" || pathname.startsWith("/blog/")
      ? "blog"
      : pathname === "/"
      ? scrollSection
      : "";

  // Navigation Links for Desktop
  const navLinks = [
    {
      id: "home",
      name: language === "km" ? "ទំព័រដើម" : "Home",
      path: "/",
      icon: HomeIcon,
    },
    {
      id: "products",
      name: language === "km" ? "ផលិតផល & សេវាកម្ម" : "Products",
      path: "/products",
      icon: Layers,
    },
    {
      id: "pricing",
      name: language === "km" ? "តម្លៃ" : "Pricing",
      path: "/pricing",
      icon: DollarSign,
    },
    {
      id: "blog",
      name: language === "km" ? "អត្ថបទ" : "Blog",
      path: "/blog",
      icon: Sparkles,
    },
    {
      id: "about",
      name: language === "km" ? "អំពីយើង" : "About Us",
      path: "/about",
      icon: Info,
    },
  ];

  // Scroll spy on home page
  useEffect(() => {
    if (pathname !== "/") return;

    const handleScrollSpy = () => {
      const scrollPos = window.scrollY + 220;
      const sections = ["pricing", "products", "home"];

      for (const sec of sections) {
        const el = document.getElementById(sec);
        if (el) {
          const top = el.offsetTop;
          if (scrollPos >= top) {
            setScrollSection(sec);
            return;
          }
        }
      }

      if (window.scrollY < 200) {
        setScrollSection("home");
      }
    };

    window.addEventListener("scroll", handleScrollSpy, { passive: true });
    handleScrollSpy();
    return () => window.removeEventListener("scroll", handleScrollSpy);
  }, [pathname]);

  // Desktop link click handler
  const handleNavClick = (
    e: React.MouseEvent,
    link: { id: string; path?: string; targetId?: string }
  ) => {
    e.preventDefault();

    if (link.id === "home") {
      if (pathname === "/") {
        window.scrollTo({ top: 0, behavior: "smooth" });
        setScrollSection("home");
      } else {
        router.push("/");
      }
      return;
    }

    if (link.path) {
      router.push(link.path);
      return;
    }

    if (link.targetId) {
      if (pathname === "/") {
        const el = document.getElementById(link.targetId);
        if (el) {
          el.scrollIntoView({ behavior: "smooth" });
          setScrollSection(link.id);
        }
      } else {
        router.push(`/#${link.targetId}`);
      }
    }
  };

  const isLinkActive = (id: string) => {
    if (id === "about" && pathname === "/about") return true;
    if (id === "pricing" && pathname === "/pricing") return true;
    if (id === "products" && (pathname === "/products" || pathname === "/productions")) return true;
    if (id === "blog" && (pathname === "/blog" || pathname.startsWith("/blog/"))) return true;
    if (pathname === "/") return activeSection === id;
    return false;
  };

  return (
    <div className="fixed top-0 left-0 right-0 z-50 transition-all">
      <HeaderAnnouncement />
      <header className="h-16 bg-[#030d1a]/95 backdrop-blur-md border-b border-cyan-950/80 flex items-center shadow-[0_4px_25px_rgba(0,0,0,0.5)] transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link
            href="/"
            className="group cursor-pointer"
            onClick={(e) => {
              if (pathname === "/") {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: "smooth" });
              }
            }}
          >
            <BroteachBrand
              logoUrl={activeLogoUrl || undefined}
              brandName={brandName}
              brandSubtitle={brandSubtitle}
              brandDotColor={brandDotColor}
              borderStyle={brandBorderStyle}
              size="md"
            />
          </Link>

          {/* Desktop Navigation Links (Hidden on mobile) */}
          <nav className="hidden lg:flex items-center space-x-1 border px-3 py-1.5 rounded-full shadow-[inset_0_1px_3px_rgba(6,182,212,0.15)] bg-[#051428]/90 border-cyan-500/20">
            {navLinks.map((link) => {
              const active = isLinkActive(link.id);
              const Icon = link.icon;
              return (
                <button
                  key={link.id}
                  onClick={(e) => handleNavClick(e, link)}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold tracking-wide rounded-full transition-all duration-200 cursor-pointer ${
                    active
                      ? "bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-400 border border-cyan-500/60 shadow-[0_0_14px_rgba(6,182,212,0.35)] scale-105 font-black"
                      : "text-slate-300 hover:text-white hover:bg-white/5 border border-transparent"
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${active ? "text-cyan-400" : "text-slate-400"}`} />
                  <span>{link.name}</span>
                </button>
              );
            })}
          </nav>

          {/* Dual Flag Language Switcher (Visible on both Desktop and Mobile, no hamburger menu) */}
          <div className="flex items-center">
            <div className="flex items-center p-0.5 sm:p-1 rounded-full border shadow-inner bg-[#020b17] border-cyan-500/30">
              <button
                type="button"
                onClick={() => setLanguage("km")}
                className={`flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full text-[11px] sm:text-xs font-black transition-all cursor-pointer ${
                  language === "km"
                    ? "bg-gradient-to-r from-red-600 to-rose-600 text-white shadow-md shadow-red-900/50 scale-105"
                    : "text-slate-400 hover:text-white"
                }`}
                title="Khmer Language (ភាសាខ្មែរ)"
              >
                <CambodiaFlag className="w-3.5 sm:w-4 h-2.5 sm:h-3 shadow-xs" />
                <span>KH</span>
              </button>
              <button
                type="button"
                onClick={() => setLanguage("en")}
                className={`flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full text-[11px] sm:text-xs font-black transition-all cursor-pointer ${
                  language === "en"
                    ? "bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-900/50 scale-105"
                    : "text-slate-400 hover:text-white"
                }`}
                title="English Language"
              >
                <UKFlag className="w-3.5 sm:w-4 h-2.5 sm:h-3 shadow-xs" />
                <span>EN</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  </div>
  );
};

