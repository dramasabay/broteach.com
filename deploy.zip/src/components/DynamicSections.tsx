"use client";

import React, { useState } from "react";
import {
  Sparkles,
  Zap,
  Smartphone,
  ShieldCheck,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Send,
  Star,
  Layers,
  Cpu,
  Globe,
} from "lucide-react";
import { ContentSection } from "@/types";
import { useLanguage } from "./LanguageContext";

interface DynamicSectionsProps {
  sections: ContentSection[];
  telegramUsername?: string;
}

export const DynamicSections: React.FC<DynamicSectionsProps> = ({
  sections,
  telegramUsername = "broteach_support",
}) => {
  const { language } = useLanguage();
  const [openFaq, setOpenFaq] = useState<Record<string, boolean>>({});

  if (!sections || sections.length === 0) return null;

  const toggleFaq = (itemId: string) => {
    setOpenFaq((prev) => ({ ...prev, [itemId]: !prev[itemId] }));
  };

  const renderIcon = (iconName?: string) => {
    switch (iconName) {
      case "Zap":
        return <Zap className="w-6 h-6 text-amber-400" />;
      case "Smartphone":
        return <Smartphone className="w-6 h-6 text-cyan-400" />;
      case "ShieldCheck":
        return <ShieldCheck className="w-6 h-6 text-emerald-400" />;
      case "Star":
        return <Star className="w-6 h-6 text-yellow-400" />;
      case "Layers":
        return <Layers className="w-6 h-6 text-purple-400" />;
      case "Cpu":
        return <Cpu className="w-6 h-6 text-rose-400" />;
      case "Globe":
        return <Globe className="w-6 h-6 text-blue-400" />;
      default:
        return <Sparkles className="w-6 h-6 text-cyan-400" />;
    }
  };

  return (
    <>
      {sections.map((section) => {
        const title = language === "km" ? section.titleKm : section.titleEn;
        const subtitle = language === "km" ? section.subtitleKm : section.subtitleEn;
        const badge = language === "km" ? section.badgeKm : section.badgeEn;

        return (
          <section
            key={section.id}
            id={section.anchorId || section.id}
            className="py-16 md:py-24 bg-[#030d1a] text-white relative overflow-hidden border-t border-cyan-950/40"
          >
            {/* Ambient Lighting */}
            <div className="absolute top-1/2 left-1/3 -translate-y-1/2 w-96 h-96 bg-cyan-600/5 rounded-full blur-3xl pointer-events-none" />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
              {/* Section Header */}
              <div className="text-center space-y-3 mb-12">
                {badge && (
                  <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 text-xs font-semibold">
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{badge}</span>
                  </div>
                )}

                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white">
                  {title}
                </h2>

                {subtitle && (
                  <p className="text-sm sm:text-base text-slate-400 max-w-2xl mx-auto leading-relaxed">
                    {subtitle}
                  </p>
                )}
              </div>

              {/* Layout: CARDS (Grid of Feature Cards) */}
              {section.layoutType === "cards" && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {section.items.map((item) => {
                    const itemTitle = language === "km" ? item.titleKm : item.titleEn;
                    const itemDesc = language === "km" ? item.descKm : item.descEn;
                    const itemBadge = language === "km" ? item.badgeKm : item.badgeEn;

                    return (
                      <div
                        key={item.id}
                        className="group relative rounded-3xl bg-[#07162c]/90 border border-slate-800 hover:border-cyan-500/50 p-6 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_15px_35px_rgba(6,182,212,0.15)] overflow-hidden"
                      >
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <div className="w-12 h-12 rounded-2xl bg-slate-800/90 border border-slate-700/80 flex items-center justify-center group-hover:scale-110 transition-transform">
                              {renderIcon(item.icon)}
                            </div>

                            {itemBadge && (
                              <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-cyan-950 text-cyan-300 border border-cyan-500/30 uppercase tracking-wider">
                                {itemBadge}
                              </span>
                            )}
                          </div>

                          <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors">
                            {itemTitle}
                          </h3>

                          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                            {itemDesc}
                          </p>
                        </div>

                        {item.metric && (
                          <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between">
                            <span className="text-xs text-slate-400 font-semibold uppercase">Performance</span>
                            <span className="text-sm font-black text-cyan-400">{item.metric}</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Layout: FAQ (Collapsible Accordion) */}
              {section.layoutType === "faq" && (
                <div className="max-w-3xl mx-auto space-y-3">
                  {section.items.map((item) => {
                    const itemTitle = language === "km" ? item.titleKm : item.titleEn;
                    const itemDesc = language === "km" ? item.descKm : item.descEn;
                    const isOpen = !!openFaq[item.id];

                    return (
                      <div
                        key={item.id}
                        className="rounded-2xl bg-[#07162c]/90 border border-slate-800 overflow-hidden transition-all duration-200 hover:border-slate-700"
                      >
                        <button
                          type="button"
                          onClick={() => toggleFaq(item.id)}
                          className="w-full py-4 px-5 sm:px-6 flex items-center justify-between gap-4 text-left cursor-pointer"
                        >
                          <span className="text-sm sm:text-base font-bold text-white flex items-center gap-3">
                            <HelpCircle className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                            <span>{itemTitle}</span>
                          </span>
                          <span className="w-8 h-8 rounded-full bg-slate-800/80 flex items-center justify-center text-slate-300 flex-shrink-0">
                            {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </span>
                        </button>

                        {isOpen && (
                          <div className="px-5 sm:px-6 pb-5 pt-1 text-xs sm:text-sm text-slate-300 leading-relaxed border-t border-slate-800/60 animate-in fade-in-50">
                            {itemDesc}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Layout: STATS */}
              {section.layoutType === "stats" && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {section.items.map((item) => {
                    const itemTitle = language === "km" ? item.titleKm : item.titleEn;
                    const itemDesc = language === "km" ? item.descKm : item.descEn;

                    return (
                      <div
                        key={item.id}
                        className="rounded-2xl bg-[#07162c]/80 border border-slate-800 p-5 text-center space-y-2 hover:border-cyan-500/40 transition-colors"
                      >
                        <p className="text-3xl sm:text-4xl font-black text-cyan-400">
                          {item.metric || "100%"}
                        </p>
                        <h4 className="text-sm font-bold text-white">{itemTitle}</h4>
                        {itemDesc && <p className="text-xs text-slate-400">{itemDesc}</p>}
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Layout: BANNER */}
              {section.layoutType === "banner" && (
                <div className="rounded-3xl bg-gradient-to-r from-cyan-950/80 via-blue-950/70 to-purple-950/80 border border-cyan-500/40 p-8 sm:p-12 text-center space-y-6 shadow-2xl relative overflow-hidden">
                  <div className="max-w-2xl mx-auto space-y-3">
                    <h3 className="text-2xl sm:text-3xl font-black text-white">{title}</h3>
                    {subtitle && <p className="text-sm sm:text-base text-slate-300">{subtitle}</p>}
                  </div>

                  <div className="flex flex-wrap justify-center gap-4">
                    <a
                      href={`https://t.me/${telegramUsername.replace("@", "")}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-6 py-3 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold text-xs sm:text-sm shadow-lg shadow-cyan-600/30 transition-all flex items-center gap-2"
                    >
                      <Send className="w-4 h-4 fill-current" />
                      <span>{language === "km" ? "ទំនាក់ទំនងតាម Telegram" : "Contact via Telegram"}</span>
                    </a>
                  </div>
                </div>
              )}
            </div>
          </section>
        );
      })}
    </>
  );
};
