import React from "react";

export const CambodiaFlag: React.FC<{ className?: string }> = ({ className = "w-5 h-3.5" }) => (
  <svg
    viewBox="0 0 640 480"
    className={`${className} rounded-[2px] shadow-sm inline-block flex-shrink-0`}
    xmlns="http://www.w3.org/2000/svg"
    aria-label="Cambodia Flag"
  >
    {/* Blue top and bottom bands */}
    <rect width="640" height="120" fill="#032EA1" />
    <rect y="360" width="640" height="120" fill="#032EA1" />
    {/* Red center band */}
    <rect y="120" width="640" height="240" fill="#E00025" />
    {/* White Angkor Wat icon */}
    <g fill="#FFFFFF">
      {/* Base towers and temple walls */}
      <path d="M210 270h220v25H210zM230 240h180v30H230zm15-20h150v20H245zm15-15h120v15H260z" />
      {/* Central main tower */}
      <polygon points="320,160 305,185 335,185" />
      <rect x="307" y="185" width="26" height="20" />
      {/* Left tower */}
      <polygon points="275,175 262,195 288,195" />
      <rect x="264" y="195" width="22" height="15" />
      {/* Right tower */}
      <polygon points="365,175 352,195 378,195" />
      <rect x="354" y="195" width="22" height="15" />
      {/* Small outer spires */}
      <polygon points="245,190 235,205 255,205" />
      <polygon points="395,190 385,205 405,205" />
    </g>
  </svg>
);

export const UKFlag: React.FC<{ className?: string }> = ({ className = "w-5 h-3.5" }) => (
  <svg
    viewBox="0 0 640 480"
    className={`${className} rounded-[2px] shadow-sm inline-block flex-shrink-0`}
    xmlns="http://www.w3.org/2000/svg"
    aria-label="English / UK Flag"
  >
    <clipPath id="uk-clip">
      <path d="M0 0h640v480H0z" />
    </clipPath>
    <g clipPath="url(#uk-clip)">
      <path fill="#012169" d="M0 0h640v480H0z" />
      {/* White Diagonals */}
      <path stroke="#FFF" strokeWidth="60" d="M0 0l640 480M640 0L0 480" />
      {/* Red Diagonals */}
      <path stroke="#C8102E" strokeWidth="40" d="M0 0l640 480M640 0L0 480" />
      {/* White Cross */}
      <path stroke="#FFF" strokeWidth="100" d="M320 0v480M0 240h640" />
      {/* Red Cross */}
      <path stroke="#C8102E" strokeWidth="60" d="M320 0v480M0 240h640" />
    </g>
  </svg>
);
