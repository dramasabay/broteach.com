"use client";

import React, { useState } from "react";
import { Send, CheckCircle2, AlertCircle, Loader2, Mail, Sparkles, ShieldCheck } from "lucide-react";
import { useLanguage } from "./LanguageContext";

export const NewsletterBanner: React.FC = () => {
  const { language, t } = useLanguage();
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [feedbackMsg, setFeedbackMsg] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes("@")) {
      setStatus("error");
      setFeedbackMsg(
        language === "km"
          ? "សូមបញ្ចូលអាសយដ្ឋានអ៊ីមែលត្រឹមត្រូវ!"
          : "Please enter a valid email address!"
      );
      return;
    }

    setStatus("loading");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setStatus("success");
        setFeedbackMsg(data.message || t.newsletter.success);
        setEmail("");
      } else {
        setStatus("error");
        setFeedbackMsg(data.message || "Failed to subscribe");
      }
    } catch {
      setStatus("error");
      setFeedbackMsg("Connection error, please try again.");
    }
  };

  return (
    <section className="relative w-full py-16 sm:py-20 bg-gradient-to-b from-[#030d1a] via-[#051833] to-[#030d1a] border-t border-cyan-950/80 text-white overflow-hidden">
      {/* Dynamic Background Glow Effects spanning full screen */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[550px] h-[350px] bg-cyan-600/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute top-1/2 right-1/4 -translate-y-1/2 w-[450px] h-[300px] bg-indigo-600/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Decorative Grid Mesh */}
      <div className="absolute inset-0 bg-[radial-gradient(rgba(6,182,212,0.12)_1px,transparent_1px)] [background-size:28px_28px] opacity-40 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="relative rounded-3xl bg-gradient-to-r from-[#061730]/95 via-[#0b2447]/95 to-[#061730]/95 border border-cyan-500/35 p-6 sm:p-10 lg:p-12 shadow-[0_20px_60px_rgba(6,182,212,0.12)] overflow-hidden backdrop-blur-xl">
          {/* Inner Accent Light */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-3 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-bold shadow-sm">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>
                  {language === "km"
                    ? "ដំណឹងបច្ចេកវិទ្យា & ការបញ្ចុះតម្លៃ"
                    : "Exclusive Tech News & Offers"}
                </span>
              </div>

              <h3 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight leading-tight">
                {t.newsletter.title}
              </h3>

              <p className="text-sm sm:text-base text-slate-300 max-w-xl leading-relaxed">
                {t.newsletter.subtitle}
              </p>

              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-1 text-xs text-slate-400">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>{language === "km" ? "គ្មាន Spam ១០០%" : "100% No Spam"}</span>
                </span>
                <span className="text-slate-600">•</span>
                <span>{language === "km" ? "អាចលុបការជាវបានគ្រប់ពេល" : "Unsubscribe anytime"}</span>
              </div>
            </div>

            {/* Right Form */}
            <div className="lg:col-span-5 w-full">
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2.5">
                <div className="relative flex-1">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (status !== "idle") setStatus("idle");
                    }}
                    placeholder={t.newsletter.placeholder}
                    className="w-full pl-10 pr-4 py-3.5 rounded-2xl bg-white/10 border border-cyan-500/30 text-white placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:bg-white/15 focus:border-cyan-400 transition-all shadow-inner"
                  />
                </div>

                <button
                  type="submit"
                  disabled={status === "loading"}
                  className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold text-sm shadow-lg shadow-cyan-600/30 hover:shadow-cyan-600/50 transition-all duration-200 flex items-center justify-center gap-2 active:scale-95 disabled:opacity-70 flex-shrink-0 cursor-pointer"
                >
                  {status === "loading" ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>{t.newsletter.submitting}</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 fill-white" />
                      <span>{t.newsletter.submit}</span>
                    </>
                  )}
                </button>
              </form>

              {/* Status Message */}
              {status === "success" && (
                <div className="mt-3 flex items-center gap-2 text-xs font-semibold text-emerald-300 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-400" />
                  <span>{feedbackMsg}</span>
                </div>
              )}

              {status === "error" && (
                <div className="mt-3 flex items-center gap-2 text-xs font-semibold text-rose-300 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
                  <span>{feedbackMsg}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
