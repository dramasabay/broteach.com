export type Language = "km" | "en";

export interface HomeSectionItemConfig {
  id: string; // "hero" | "products" | "pricing" | "blog" | "dynamic_sections" | "newsletter"
  labelKm: string;
  labelEn: string;
  enabled: boolean;
  order: number;
}

export const DEFAULT_HOME_SECTIONS: HomeSectionItemConfig[] = [
  { id: "hero", labelKm: "ផ្ទាំង Hero (ក្បាលទំព័រ)", labelEn: "Hero Section", enabled: true, order: 0 },
  { id: "products", labelKm: "ផលិតផល Premium Products", labelEn: "Premium Products", enabled: true, order: 1 },
  { id: "pricing", labelKm: "កញ្ចប់តម្លៃ (Pricing Plans)", labelEn: "Pricing Plans", enabled: true, order: 2 },
  { id: "blog", labelKm: "អត្ថបទ & Blog Posts", labelEn: "Blog Posts & Articles", enabled: true, order: 3 },
  { id: "dynamic_sections", labelKm: "ផ្នែកបន្ថែម CMS (Why Us, FAQ)", labelEn: "Dynamic CMS Sections", enabled: true, order: 4 },
  { id: "newsletter", labelKm: "ចុះឈ្មោះ Newsletter", labelEn: "Newsletter Banner", enabled: true, order: 5 },
];

export interface PricingPlan {
  id: string;
  nameKm: string;
  nameEn: string;
  badgeKm?: string;
  badgeEn?: string;
  isPopular?: boolean;
  price: number;
  periodKm: string;
  periodEn: string;
  colorScheme: "red" | "silver";
  featuresKm: string[];
  featuresEn: string[];
  recommended?: boolean;
  demoUrl?: string;
  orderUrl?: string;
}

export interface ProductItem {
  id: string;
  titleKm: string;
  titleEn: string;
  category: "all" | "webapp" | "ecommerce" | "hosting" | "enterprise";
  categoryLabelKm: string;
  categoryLabelEn: string;
  price: number;
  badgeKm?: string;
  badgeEn?: string;
  descKm: string;
  descEn: string;
  featuresKm: string[];
  featuresEn: string[];
  icon: string;
  demoUrl?: string;
  isActive: boolean;
  sortOrder: number;
  salesCount?: number;
  rating?: number;
  ratingCount?: number;
  thumbnailUrl?: string;
  author?: string;
  screenshots?: string[];
  techStack?: string[];
}

export interface SiteSettings {
  heroTitleKm: string;
  heroTitleEn: string;
  heroSubtitleKm: string;
  heroSubtitleEn: string;
  announcementTextKm: string;
  announcementTextEn: string;
  showAnnouncement: boolean;
  telegramUsername: string;
  phone1: string;
  phone2: string;
  email: string;
  addressKm: string;
  addressEn: string;
  lastUpdated: string;
  // Hero Customization Fields
  heroBadgeKm?: string;
  heroBadgeEn?: string;
  heroCtaTextKm?: string;
  heroCtaTextEn?: string;
  heroCtaTelegramUrl?: string;
  heroSecondaryBtnTextKm?: string;
  heroSecondaryBtnTextEn?: string;
  heroSecondaryBtnUrl?: string;
  heroStat1Number?: string;
  heroStat1LabelKm?: string;
  heroStat1LabelEn?: string;
  heroStat2Number?: string;
  heroStat2LabelKm?: string;
  heroStat2LabelEn?: string;
  heroStat3Number?: string;
  heroStat3LabelKm?: string;
  heroStat3LabelEn?: string;
  // Home Page Layout & Section Ordering
  homeSections?: HomeSectionItemConfig[];
  // Branding & Assets
  siteLogoUrl?: string;
  siteIconUrl?: string;
  siteBrandName?: string;
  siteBrandSubtitle?: string;
  siteBrandDotColor?: string;
  siteBrandBorderStyle?: string;
  // External App/Software Download Link
  downloadAppLink?: string;
  // SEO & Google Console
  seoTitleKm?: string;
  seoTitleEn?: string;
  seoDescKm?: string;
  seoDescEn?: string;
  seoKeywords?: string;
  seoImageUrl?: string;
  googleConsoleVerification?: string;
  googleAnalyticsId?: string;
  // Footer CMS Fields
  footerDescKm?: string;
  footerDescEn?: string;
  footerCopyrightKm?: string;
  footerCopyrightEn?: string;
  footerContactHeadingKm?: string;
  footerContactHeadingEn?: string;
  facebookUrl?: string;
  youtubeUrl?: string;
  telegramChannelUrl?: string;
  tiktokUrl?: string;
  // Footer Columns (Services & Quick Links)
  footerServicesTitleKm?: string;
  footerServicesTitleEn?: string;
  footerService1Km?: string;
  footerService1En?: string;
  footerService1Url?: string;
  footerService2Km?: string;
  footerService2En?: string;
  footerService2Url?: string;
  footerService3Km?: string;
  footerService3En?: string;
  footerService3Url?: string;
  footerService4Km?: string;
  footerService4En?: string;
  footerService4Url?: string;

  footerQuickLinksTitleKm?: string;
  footerQuickLinksTitleEn?: string;
  footerQuickLink1Km?: string;
  footerQuickLink1En?: string;
  footerQuickLink1Url?: string;
  footerQuickLink2Km?: string;
  footerQuickLink2En?: string;
  footerQuickLink2Url?: string;
  footerQuickLink3Km?: string;
  footerQuickLink3En?: string;
  footerQuickLink3Url?: string;
  footerQuickLink4Km?: string;
  footerQuickLink4En?: string;
  footerQuickLink4Url?: string;
  // About Us Page CMS Fields
  aboutTitleKm?: string;
  aboutTitleEn?: string;
  aboutSubtitleKm?: string;
  aboutSubtitleEn?: string;
  aboutStoryKm?: string;
  aboutStoryEn?: string;
  aboutMissionKm?: string;
  aboutMissionEn?: string;
  // Telegram Bot Integration
  telegramBotToken?: string;
  telegramChatId?: string;
  // Header Event & Announcement Ads
  headerBannerActive?: boolean;
  headerBannerTextKm?: string;
  headerBannerTextEn?: string;
  headerBannerBadgeKm?: string;
  headerBannerBadgeEn?: string;
  headerBannerLink?: string;
  // Screen Ads Popup
  popupActive?: boolean;
  popupTitleKm?: string;
  popupTitleEn?: string;
  popupDescKm?: string;
  popupDescEn?: string;
  popupBadgeKm?: string;
  popupBadgeEn?: string;
  popupImageUrl?: string;
  popupButtonTextKm?: string;
  popupButtonTextEn?: string;
  popupButtonUrl?: string;
  popupCooldownMinutes?: number; // Cooldown between popups in minutes (default 30)
  popupAutoCloseSeconds?: number; // Auto close delay in seconds (default 5)
  popupTriggerScrollPx?: number; // Scroll distance to trigger popup in px (default 200)
}

export interface TrashItem {
  id: string;
  itemType: "product" | "post" | "section" | "plan" | "media";
  originalId: string;
  title: string;
  data: unknown;
  deletedAt: string;
  expiresAt: string; // 7 days from deletion
}

export interface OrderSubmission {
  id: string;
  planId: string;
  planName: string;
  price: number;
  clientName: string;
  email: string;
  phone: string;
  telegram?: string;
  notes?: string;
  createdAt: string;
  status: "pending" | "contacted" | "completed";
}

export interface NewsletterSubscriber {
  id: string;
  email: string;
  subscribedAt: string;
}

export interface ChatMessage {
  id: string;
  sender: "user" | "bot";
  text: string;
  timestamp: string;
  options?: { label: string; action: string }[];
}

export interface SectionItem {
  id: string;
  titleKm: string;
  titleEn: string;
  descKm: string;
  descEn: string;
  icon?: string;
  badgeKm?: string;
  badgeEn?: string;
  metric?: string;
  imageUrl?: string;
  linkUrl?: string;
  linkTextKm?: string;
  linkTextEn?: string;
}

export interface ContentSection {
  id: string;
  titleKm: string;
  titleEn: string;
  subtitleKm?: string;
  subtitleEn?: string;
  badgeKm?: string;
  badgeEn?: string;
  layoutType: "cards" | "features" | "stats" | "faq" | "banner";
  items: SectionItem[];
  isActive: boolean;
  sortOrder: number;
  anchorId?: string;
}

export interface BlogPostItem {
  id?: string;
  slug: string;
  titleKm: string;
  titleEn: string;
  excerptKm: string;
  excerptEn: string;
  contentKm?: string;
  contentEn?: string;
  category: string;
  categoryKm?: string;
  categoryEn?: string;
  tagKm?: string;
  tagEn?: string;
  readingTime?: number;
  readTime?: string;
  date: string;
  featured?: boolean;
  coverGradient?: string;
  coverImage?: string;
  image?: string;
  icon?: string;
  author?: string;
  isPublished?: boolean;
}
