import { Metadata } from "next";
import PricingClientPage from "./PricingClientPage";

export const metadata: Metadata = {
  title: "តម្លៃកញ្ចប់គេហទំព័រ & សេវាកម្ម | Broteach Pricing Plans",
  description:
    "កញ្ចប់តម្លៃសេវាកម្មបង្កើតគេហទំព័រអាជីវកម្មតាមបែបស្តង់ដារ និង Cloud Hosting ល្បឿនលឿន NVMe SSD តម្លៃសមរម្យ និងគ្មានថ្លៃលាក់កំបាំង។",
  alternates: {
    canonical: "/pricing",
  },
};

export default function PricingPage() {
  return <PricingClientPage />;
}
