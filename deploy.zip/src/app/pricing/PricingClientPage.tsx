"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { ArrowLeft, Sparkles, Send, ShieldCheck, Zap } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { PricingSection } from "@/components/PricingSection";
import { DemoOrderModal } from "@/components/DemoOrderModal";
import { useLanguage } from "@/components/LanguageContext";
import { PricingPlan, SiteSettings } from "@/types";
import { pricingPlans as defaultPlans } from "@/lib/data";
import { subscribeCmsUpdates } from "@/lib/realtime";

export default function PricingClientPage() {
  const { language } = useLanguage();
  const [plans, setPlans] = useState<PricingPlan[]>(defaultPlans);
  const [settings, setSettings] = useState<SiteSettings | undefined>(undefined);
  const [selectedPlan, setSelectedPlan] = useState<PricingPlan | null>(null);

  useEffect(() => {
    const fetchContent = async () => {
      try {
        const res = await fetch(`/api/content?t=${Date.now()}`);
        if (res.ok) {
          const data = await res.json();
          if (data.pricing && data.pricing.length > 0) {
            setPlans(data.pricing);
          }
          if (data.settings) {
            setSettings(data.settings);
          }
        }
      } catch (err) {
        console.error("Failed to load pricing:", err);
      }
    };

    fetchContent();
    const unsubscribe = subscribeCmsUpdates(() => {
      fetchContent();
    });

    const interval = setInterval(fetchContent, 10000);
    return () => {
      unsubscribe();
      clearInterval(interval);
    };
  }, []);

  const telegramUser = settings?.telegramUsername || "broteach_support";
  const cleanTg = telegramUser.replace("@", "");

  return (
    <div className="min-h-screen bg-[#030d1a] text-white flex flex-col selection:bg-cyan-500 selection:text-white">
      <Navbar />

      {/* Hero Header */}
      <section className="pt-28 pb-10 sm:pt-36 sm:pb-14 bg-gradient-to-b from-[#051428] via-[#030d1a] to-[#030d1a] border-b border-cyan-950/60 relative overflow-hidden">
        <div className="absolute top-10 left-1/3 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-10 w-80 h-80 bg-red-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 animate-fade-in-up">
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-6">
            <Link href="/" className="hover:text-cyan-400 transition-colors flex items-center gap-1">
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{language === "km" ? "ទំព័រដើម" : "Home"}</span>
            </Link>
            <span>/</span>
            <span className="text-cyan-400 font-semibold">
              {language === "km" ? "កញ្ចប់តម្លៃ (Pricing)" : "Pricing Plans"}
            </span>
          </div>

          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 text-xs font-bold shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>{language === "km" ? "តម្លៃមានតម្លាភាព ១០០%" : "100% Transparent Pricing"}</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white leading-tight">
              {language === "km"
                ? "កញ្ចប់តម្លៃសេវាកម្មគេហទំព័រ & Cloud Hosting"
                : "Transparent Website & Cloud Hosting Pricing"}
            </h1>

            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              {language === "km"
                ? "ជ្រើសរើសកញ្ចប់តម្លៃដែលសមស្របតាមទំហំអាជីវកម្មរបស់អ្នក។ មិនមានតម្លៃលាក់កំបាំង ភ្ជាប់ជាមួយ Free Domain និង Cloud Hosting ឥតគិតថ្លៃ ១ ឆ្នាំពេញ។"
                : "Choose the optimal plan tailored for your business scale. No hidden fees, with free domain and 1-Year NVMe SSD cloud hosting included."}
            </p>
          </div>
        </div>
      </section>

      {/* Main Pricing Section */}
      <main className="flex-1">
        <PricingSection
          plans={plans}
          telegramUsername={telegramUser}
          onSelectPlan={(plan) => setSelectedPlan(plan)}
        />

        {/* Guarantees Strip */}
        <section className="py-12 bg-[#020914] border-t border-slate-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-5 rounded-2xl bg-[#061528] border border-slate-800 flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 flex-shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">
                    {language === "km" ? "សុវត្ថិភាពខ្ពស់ & SSL ឥតគិតថ្លៃ" : "Free SSL & Advanced Security"}
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    {language === "km"
                      ? "រាល់គេហទំព័រត្រូវបានការពារដោយ SSL Certificate ២៥៦-bit និងប្រព័ន្ធការពារ DDoS ២៤/៧។"
                      : "Every website includes 256-bit SSL encryption and 24/7 DDoS shield protection."}
                  </p>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-[#061528] border border-slate-800 flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 flex-shrink-0">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">
                    {language === "km" ? "ល្បឿនផ្ទុកក្រោម ១ វិនាទី" : "Sub-second Page Load"}
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    {language === "km"
                      ? "ម៉ាស៊ីនបម្រើ Cloud NVMe SSD ជំនាន់ថ្មី ធានាល្បឿនផ្ទុកទំព័រលឿនបំផុត។"
                      : "Powered by Next-Gen NVMe SSD cloud infrastructure for blazing fast responsiveness."}
                  </p>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-[#061528] border border-slate-800 flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 flex-shrink-0">
                  <Send className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">
                    {language === "km" ? "គាំទ្របច្ចេកទេស ២៤/៧" : "24/7 Live Agent Support"}
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    {language === "km"
                      ? "ក្រុមការងារបច្ចេកទេសប្រចាំការជួយដោះស្រាយបញ្ហា ២៤ ម៉ោងតាម Telegram។"
                      : "Dedicated technical assistance ready around the clock via direct Telegram."}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Floating Telegram Support */}
      <div className="fixed bottom-20 right-4 lg:bottom-6 lg:right-6 z-40">
        <a
          href={`https://t.me/${cleanTg}`}
          target="_blank"
          rel="noopener noreferrer"
          className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 text-white shadow-[0_0_25px_rgba(6,182,212,0.5)] hover:scale-110 transition-all cursor-pointer"
          title="Direct Support on Telegram"
        >
          <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-400 border-2 border-[#030d1a]"></span>
          </span>
          <Send className="w-6 h-6 fill-current group-hover:rotate-12 transition-transform" />
        </a>
      </div>

      {selectedPlan && (
        <DemoOrderModal
          isOpen={!!selectedPlan}
          selectedPlan={selectedPlan}
          onClose={() => setSelectedPlan(null)}
          telegramUsername={telegramUser}
        />
      )}

      <Footer />
    </div>
  );
}
