import { NextResponse } from "next/server";
import fs from "fs";
import { getUploadedFilePath } from "@/lib/storageManager";

export const dynamic = "force-dynamic";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ file: string[] }> }
) {
  const resolvedParams = await params;
  const filePathArray = resolvedParams.file || [];
  const filename = filePathArray.join("/");

  if (!filename) {
    return new NextResponse("File not specified", { status: 400 });
  }

  const fileInfo = getUploadedFilePath(filename);
  if (!fileInfo) {
    return new NextResponse("File not found", { status: 404 });
  }

  try {
    const fileBuffer = fs.readFileSync(fileInfo.filePath);
    return new NextResponse(fileBuffer, {
      status: 200,
      headers: {
        "Content-Type": fileInfo.mimeType,
        "Content-Length": fileBuffer.length.toString(),
        "Cache-Control": "public, max-age=31536000, immutable",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch (error) {
    console.error("Error serving uploaded file:", error);
    return new NextResponse("Internal Server Error", { status: 500 });
  }
}
