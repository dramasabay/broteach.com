"use client";

import React, { useState, useEffect } from "react";
import { Send } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { HeroSection } from "@/components/HeroSection";
import { ProductsSection } from "@/components/ProductsSection";
import { PricingSection } from "@/components/PricingSection";
import { NewsletterBanner } from "@/components/NewsletterBanner";
import { Footer } from "@/components/Footer";
import { DemoOrderModal } from "@/components/DemoOrderModal";
import { DynamicSections } from "@/components/DynamicSections";
import { HomeBlogSection } from "@/components/HomeBlogSection";
import { PricingPlan, ProductItem, ContentSection, BlogPostItem, DEFAULT_HOME_SECTIONS } from "@/types";
import { pricingPlans as defaultPlans, defaultProducts } from "@/lib/data";
import { subscribeCmsUpdates } from "@/lib/realtime";
import { useSiteSettings } from "@/components/SiteSettingsContext";

export default function Home() {
  const [isDemoModalOpen, setIsDemoModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<PricingPlan | null>(defaultPlans[1]);

  // Dynamic CMS States
  const { settings, setSettings } = useSiteSettings();
  const [products, setProducts] = useState<ProductItem[]>(defaultProducts);
  const [sections, setSections] = useState<ContentSection[]>([]);
  const [pricingPlans, setPricingPlans] = useState<PricingPlan[]>([]);
  const [posts, setPosts] = useState<BlogPostItem[]>([]);

  // Fetch live CMS content on mount & real-time updates
  useEffect(() => {
    const fetchContent = async () => {
      try {
        const res = await fetch(`/api/content?t=${Date.now()}`);
        if (res.ok) {
          const data = await res.json();
          if (data.settings) setSettings(data.settings);
          if (data.products && data.products.length > 0) setProducts(data.products);
          if (data.sections && data.sections.length > 0) setSections(data.sections);
          if (data.pricing && data.pricing.length > 0) setPricingPlans(data.pricing);
          if (data.posts && data.posts.length > 0) setPosts(data.posts);
        }
      } catch {
        // Fallback to static data
      }
    };

    fetchContent();

    // Real-time broadcast listener
    const unsubscribe = subscribeCmsUpdates(() => {
      fetchContent();
    });

    // Real-time background poll every 10 seconds
    const interval = setInterval(fetchContent, 10000);

    return () => {
      unsubscribe();
      clearInterval(interval);
    };
  }, [setSettings]);

  const handleOpenDemoModal = (planOrProd?: PricingPlan | string) => {
    if (typeof planOrProd === "object" && planOrProd !== null) {
      setSelectedPlan(planOrProd);
    } else if (typeof planOrProd === "string") {
      const match = defaultPlans.find((p) => p.id === planOrProd);
      if (match) setSelectedPlan(match);
    }
    setIsDemoModalOpen(true);
  };

  const telegramUser = settings?.telegramUsername || "broteach_support";
  const cleanTg = telegramUser.replace("@", "");

  const homeSections = (
    settings?.homeSections && settings.homeSections.length > 0
      ? settings.homeSections
      : DEFAULT_HOME_SECTIONS
  )
    .slice()
    .sort((a, b) => a.order - b.order);

  return (
    <div className="min-h-screen bg-[#030d1a] flex flex-col selection:bg-cyan-500 selection:text-white">
      {/* Sticky Solid Navbar (Clean URL routing, SVG flag switcher) */}
      <Navbar
        telegramUsername={telegramUser}
      />

      <main className="flex-1 animate-page-enter">
        {homeSections.map((sec) => {
          if (!sec.enabled) return null;

          switch (sec.id) {
            case "hero":
              return (
                <HeroSection
                  key="hero"
                  settings={settings}
                  titleKm={settings?.heroTitleKm}
                  titleEn={settings?.heroTitleEn}
                  subtitleKm={settings?.heroSubtitleKm}
                  subtitleEn={settings?.heroSubtitleEn}
                  announcementKm={settings?.announcementTextKm}
                  announcementEn={settings?.announcementTextEn}
                  showAnnouncement={settings?.showAnnouncement}
                  telegramUsername={telegramUser}
                />
              );

            case "products":
              return (
                <ProductsSection
                  key="products"
                  products={products}
                  telegramUsername={telegramUser}
                  onOpenDemo={(prodId) => handleOpenDemoModal(prodId)}
                />
              );

            case "pricing":
              return (
                <PricingSection
                  key="pricing"
                  plans={pricingPlans}
                  onSelectPlan={(plan) => handleOpenDemoModal(plan)}
                  telegramUsername={telegramUser}
                />
              );

            case "blog":
              return <HomeBlogSection key="blog" posts={posts} />;

            case "dynamic_sections":
              return (
                <DynamicSections
                  key="dynamic_sections"
                  sections={sections}
                  telegramUsername={telegramUser}
                />
              );

            case "newsletter":
              return <NewsletterBanner key="newsletter" />;

            default:
              return null;
          }
        })}
      </main>

      {/* Footer with 1-row mobile layout and About Us link */}
      <Footer
        telegramUsername={telegramUser}
        phone1={settings?.phone1}
        phone2={settings?.phone2}
      />

      {/* Interactive Demo & Order Modal */}
      <DemoOrderModal
        isOpen={isDemoModalOpen}
        onClose={() => setIsDemoModalOpen(false)}
        selectedPlan={selectedPlan}
      />

      {/* Floating Direct Telegram Support Action */}
      <div className="fixed bottom-20 right-4 lg:bottom-6 lg:right-6 z-40">
        <a
          href={`https://t.me/${cleanTg}`}
          target="_blank"
          rel="noopener noreferrer"
          className="group relative flex items-center justify-center w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 text-white shadow-[0_0_25px_rgba(6,182,212,0.5)] hover:scale-110 transition-all cursor-pointer"
          title="Direct Support on Telegram"
        >
          <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-400 border-2 border-[#030d1a]"></span>
          </span>
          <Send className="w-5 h-5 sm:w-6 sm:h-6 fill-current group-hover:rotate-12 transition-transform" />
        </a>
      </div>
    </div>
  );
}
