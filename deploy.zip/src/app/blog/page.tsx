import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Blog | Broteach Cambodia",
  description:
    "អត្ថបទ ចំណេះដឹង និងព័ត៌មានថ្មីៗពី Broteach ស្តីពីការបង្កើតគេហទំព័រ Cloud Hosting និង E-commerce នៅកម្ពុជា។",
  openGraph: {
    title: "Blog | Broteach Cambodia",
    description: "Articles, guides and updates on web design, cloud hosting, and e-commerce in Cambodia.",
    type: "website",
  },
};

export { default } from "./BlogPageClient";
