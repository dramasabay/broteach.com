"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { useLanguage } from "@/components/LanguageContext";
import { Clock, ArrowRight, Search, Star, Sparkles, ChevronLeft, ChevronRight } from "lucide-react";
import { BLOG_POSTS } from "@/lib/blogData";
import { BlogPostItem } from "@/types";
import { subscribeCmsUpdates } from "@/lib/realtime";

const CATEGORIES = ["All", "Hosting", "E-commerce", "Design", "SEO", "Security", "News"];

export default function BlogPageClient() {
  const { language } = useLanguage();
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const [posts, setPosts] = useState<BlogPostItem[]>(() =>
    BLOG_POSTS.map((p, idx) => ({
      id: `post-${idx + 1}`,
      slug: p.slug,
      titleKm: p.titleKm,
      titleEn: p.titleEn,
      excerptKm: p.excerptKm,
      excerptEn: p.excerptEn,
      contentKm: p.contentKm,
      contentEn: p.contentEn,
      category: p.category,
      tagKm: p.tagKm,
      tagEn: p.tagEn,
      readingTime: p.readingTime,
      date: p.date,
      featured: p.featured,
      coverGradient: p.coverGradient,
      icon: p.icon,
      author: "Broteach Team",
      isPublished: true,
    }))
  );

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const res = await fetch(`/api/content?t=${Date.now()}`);
        if (res.ok) {
          const data = await res.json();
          if (data.posts && data.posts.length > 0) {
            setPosts(data.posts);
          }
        }
      } catch {}
    };
    fetchPosts();
    const unsubscribe = subscribeCmsUpdates(() => {
      fetchPosts();
    });
    return () => unsubscribe();
  }, []);

  const [currentPage, setCurrentPage] = useState(1);
  const [prevFilter, setPrevFilter] = useState({ search, activeCategory });
  if (prevFilter.search !== search || prevFilter.activeCategory !== activeCategory) {
    setPrevFilter({ search, activeCategory });
    setCurrentPage(1);
  }
  const POSTS_PER_PAGE = 6;

  const filtered = posts.filter((p) => {
    const matchCat = activeCategory === "All" || p.category === activeCategory;
    const q = search.toLowerCase();
    const matchSearch =
      !q ||
      (language === "km" ? p.titleKm : p.titleEn).toLowerCase().includes(q) ||
      (language === "km" ? p.excerptKm : p.excerptEn).toLowerCase().includes(q);
    return matchCat && matchSearch;
  });

  const totalPages = Math.ceil(filtered.length / POSTS_PER_PAGE) || 1;
  const validCurrentPage = Math.min(Math.max(1, currentPage), totalPages);
  const startIndex = (validCurrentPage - 1) * POSTS_PER_PAGE;
  const paginatedPosts = filtered.slice(startIndex, startIndex + POSTS_PER_PAGE);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    const gridEl = document.getElementById("blog-grid");
    if (gridEl) {
      gridEl.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <div className="min-h-screen bg-[#030d1a] flex flex-col selection:bg-cyan-500 selection:text-white">
      {/* Sticky Header Navbar */}
      <Navbar />

      <main className="flex-1 pb-28 sm:pb-20 animate-page-enter">
        {/* Hero Section */}
        <section className="relative pt-24 pb-12 sm:pt-28 sm:pb-16 overflow-hidden border-b border-cyan-950/60 bg-[#030e1d]">
          {/* Cyber Ambient Lighting */}
          <div className="absolute inset-0 bg-[radial-gradient(#0891b2_1px,transparent_1px)] [background-size:28px_28px] opacity-15 pointer-events-none" />
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[320px] bg-cyan-600/12 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 right-10 w-72 h-72 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4 animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 text-xs font-semibold shadow-md">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>{language === "km" ? "ចំណេះដឹង & បច្ចេកវិទ្យា ២០២៦" : "Tech Knowledge & Insights"}</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
              {language === "km" ? "អត្ថបទ & មគ្គុទ្ទេសក៍" : "Articles & Guides"}
            </h1>

            <p className="text-slate-300/80 max-w-xl mx-auto text-xs sm:text-base leading-relaxed">
              {language === "km"
                ? "ស្វែងយល់ការណែនាំបច្ចេកវិទ្យា Cloud Hosting, Web Design, E-commerce KHQR, និង SEO ទំនើបសម្រាប់អាជីវកម្មនៅកម្ពុជា"
                : "Explore actionable guides on Cloud Hosting, Web Design, E-commerce KHQR, and modern SEO for Cambodia businesses"}
            </p>

            {/* Search Input */}
            <div className="relative max-w-md mx-auto mt-6">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-400" />
              <input
                type="text"
                id="blog-search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={language === "km" ? "ស្វែងរកអត្ថបទតាមចំណងជើង..." : "Search articles..."}
                className="w-full pl-10 pr-4 py-2.5 rounded-full bg-[#051628] border border-cyan-500/30 text-white text-xs sm:text-sm placeholder-slate-400 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 shadow-inner transition-all"
              />
            </div>
          </div>
        </section>

        {/* Content Container */}
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-8 sm:py-12 animate-fade-in-up delay-100">
          {/* Category Tabs */}
          <div className="flex flex-wrap gap-1.5 sm:gap-2 mb-8 sm:mb-12 justify-center">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 sm:px-4 py-1.5 rounded-full text-[11px] sm:text-xs font-bold transition-all cursor-pointer ${
                  activeCategory === cat
                    ? "bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-900/40 scale-105"
                    : "bg-[#051628] border border-slate-700/80 text-slate-300 hover:text-white hover:border-cyan-500/40"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Modern Blog Articles Grid — 2 COLUMNS ON MOBILE, 3 ON DESKTOP */}
          <div id="blog-grid" className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 items-stretch scroll-mt-24">
            {paginatedPosts.map((post) => (
              <article
                key={post.slug}
                className="group relative flex flex-col justify-between rounded-xl sm:rounded-2xl bg-gradient-to-b from-[#091e38]/90 via-[#06172d]/90 to-[#041122]/95 border border-slate-800 hover:border-cyan-500/60 shadow-lg hover:shadow-[0_12px_35px_rgba(6,182,212,0.2)] hover:-translate-y-1 transition-all duration-300 overflow-hidden"
              >
                <Link href={`/blog/${post.slug}`} className="flex flex-col h-full">
                  {/* Modern Gradient Visual Header */}
                  <div className={`relative h-28 sm:h-44 w-full bg-gradient-to-br ${post.coverGradient} flex items-center justify-center overflow-hidden`}>
                    {/* Cyber Grid Texture */}
                    <div className="absolute inset-0 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px] opacity-15" />
                    {/* Glowing Core */}
                    <div className="absolute w-20 h-20 sm:w-28 sm:h-28 rounded-full bg-white/20 blur-xl pointer-events-none group-hover:scale-125 transition-transform duration-500" />

                    {/* Tech Icon / Avatar */}
                    <span className="relative z-10 text-3xl sm:text-5xl transform group-hover:scale-110 transition-transform duration-300 filter drop-shadow-md">
                      {post.icon}
                    </span>

                    {/* Category Tag Badge */}
                    <div className="absolute top-2 left-2 sm:top-3 sm:left-3 z-20">
                      <span className="px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-full text-[9px] sm:text-[10px] font-black uppercase tracking-wider bg-slate-950/60 backdrop-blur-md border border-white/20 text-white shadow-sm">
                        {language === "km" ? post.tagKm : post.tagEn}
                      </span>
                    </div>

                    {/* Reading Time Badge */}
                    <div className="absolute bottom-2 right-2 sm:bottom-3 sm:right-3 z-20">
                      <span className="inline-flex items-center gap-1 px-1.5 py-0.5 sm:px-2 sm:py-0.5 rounded-full text-[9px] sm:text-[10px] font-semibold bg-slate-950/70 backdrop-blur-md text-cyan-300 border border-cyan-500/30">
                        <Clock className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-cyan-400" />
                        <span>{post.readingTime}m</span>
                      </span>
                    </div>

                    {/* Featured Ribbon */}
                    {post.featured && (
                      <div className="absolute top-2 right-2 sm:top-3 sm:right-3 z-20">
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 sm:px-2 sm:py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-amber-500/90 text-slate-950 shadow-md">
                          <Star className="w-2.5 h-2.5 fill-current" />
                          <span className="hidden sm:inline">Featured</span>
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Card Content Body */}
                  <div className="p-3 sm:p-5 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Date Indicator */}
                      <p className="text-[10px] sm:text-xs text-slate-400 font-medium mb-1.5">
                        {post.date}
                      </p>

                      {/* Post Title */}
                      <h2 className="text-xs sm:text-base font-black text-white group-hover:text-cyan-300 transition-colors leading-snug line-clamp-2 mb-1.5 sm:mb-2">
                        {language === "km" ? post.titleKm : post.titleEn}
                      </h2>

                      {/* Post Excerpt */}
                      <p className="text-[11px] sm:text-xs text-slate-400 line-clamp-2 leading-relaxed">
                        {language === "km" ? post.excerptKm : post.excerptEn}
                      </p>
                    </div>

                    {/* Interactive Bottom Micro-Bar */}
                    <div className="pt-2 sm:pt-3 border-t border-slate-800/80 mt-3 sm:mt-4 flex items-center justify-between text-cyan-400 text-[11px] sm:text-xs font-bold">
                      <span className="group-hover:text-cyan-300 transition-colors">
                        {language === "km" ? "អានអត្ថបទ" : "Read Article"}
                      </span>
                      <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center group-hover:translate-x-1 group-hover:bg-cyan-500 group-hover:text-slate-950 transition-all">
                        <ArrowRight className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                      </div>
                    </div>
                  </div>
                </Link>
              </article>
            ))}
          </div>

          {/* Pagination Controls — When posts > 6 */}
          {totalPages > 1 && (
            <div className="mt-10 sm:mt-14 pt-6 sm:pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
              <p className="text-xs text-slate-400 font-medium text-center sm:text-left">
                {language === "km"
                  ? `បង្ហាញ ${startIndex + 1} - ${Math.min(startIndex + POSTS_PER_PAGE, filtered.length)} នៃ ${filtered.length} អត្ថបទ (ទំព័រ ${validCurrentPage} នៃ ${totalPages})`
                  : `Showing ${startIndex + 1} - ${Math.min(startIndex + POSTS_PER_PAGE, filtered.length)} of ${filtered.length} articles (Page ${validCurrentPage} of ${totalPages})`}
              </p>

              <div className="inline-flex items-center gap-1.5 p-1 rounded-2xl bg-[#061528] border border-slate-800 shadow-xl">
                {/* Previous Button */}
                <button
                  type="button"
                  onClick={() => handlePageChange(validCurrentPage - 1)}
                  disabled={validCurrentPage <= 1}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold text-slate-300 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed hover:bg-slate-800/80 transition-all flex items-center gap-1 cursor-pointer"
                  aria-label="Previous Page"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span className="hidden sm:inline">{language === "km" ? "មុន" : "Prev"}</span>
                </button>

                {/* Page Number Buttons */}
                <div className="flex items-center gap-1">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
                    <button
                      key={pageNum}
                      type="button"
                      onClick={() => handlePageChange(pageNum)}
                      className={`w-8 h-8 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center justify-center ${
                        validCurrentPage === pageNum
                          ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md shadow-cyan-600/40 scale-105"
                          : "text-slate-400 hover:text-white hover:bg-slate-800/80"
                      }`}
                    >
                      {pageNum}
                    </button>
                  ))}
                </div>

                {/* Next Button */}
                <button
                  type="button"
                  onClick={() => handlePageChange(validCurrentPage + 1)}
                  disabled={validCurrentPage >= totalPages}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold text-slate-300 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed hover:bg-slate-800/80 transition-all flex items-center gap-1 cursor-pointer"
                  aria-label="Next Page"
                >
                  <span className="hidden sm:inline">{language === "km" ? "បន្ទាប់" : "Next"}</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Empty Search Result State */}
          {filtered.length === 0 && (
            <div className="text-center py-20 space-y-3">
              <div className="w-16 h-16 rounded-full bg-cyan-950/50 border border-cyan-500/30 flex items-center justify-center mx-auto text-2xl">
                🔍
              </div>
              <h3 className="text-base font-bold text-white">
                {language === "km" ? "រកមិនឃើញអត្ថបទដែលត្រូវគ្នាទេ" : "No matching articles found"}
              </h3>
              <p className="text-slate-400 text-xs sm:text-sm">
                {language === "km"
                  ? "សូមសាកល្បងស្វែងរកជាមួយពាក្យគន្លឹះផ្សេងទៀត"
                  : "Please try searching with different keywords"}
              </p>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
