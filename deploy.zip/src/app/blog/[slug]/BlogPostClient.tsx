"use client";

import React from "react";
import Link from "next/link";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { useLanguage } from "@/components/LanguageContext";
import { Clock, ArrowLeft, Tag, Calendar, Share2, Check } from "lucide-react";
import { BLOG_POSTS } from "@/lib/blogData";

// Sample expanded content per post (in production this would come from CMS/DB)
const POST_CONTENT: Record<string, { km: string; en: string }> = {
  "cloud-hosting-cambodia-guide": {
    km: `## Cloud Hosting ជាអ្វី?

Cloud Hosting គឺជាប្រព័ន្ធ Hosting ដែលប្រើម៉ាស៊ីនបម្រើ Virtual ជាច្រើនរួមគ្នា ជំនួសបំប្លែងជំនួស Physical Server តែមួយ។ ការប្រើ Cloud Hosting ធានាបាន:

- **ល្បឿនលឿន** — NVMe SSD ល្បឿនដល់ 7,000 MB/s
- **99.99% Uptime** — SLA ធានាក្នុង Contract
- **Scalable** — ពង្រីក Resource ភ្លាមៗ
- **DDoS Protection** — ការការពារ 3.2 Tbps

## ហេតុអ្វីត្រូវប្រើ Cloud Hosting?

ប្រសិនបើអ្នកជាម្ចាស់អាជីវកម្ម SME នៅកម្ពុជា Cloud Hosting ផ្តល់ជូននូវ:

1. ការផ្ទុកទំព័រក្នុង < 1 Second
2. SSL Certificate ឥតគិតថ្លៃ
3. Backup ស្វ័យប្រវត្តិប្រចាំថ្ងៃ
4. Support ២៤/៧

## Broteach Cloud Hosting

Broteach ផ្តល់ Cloud Hosting ដោយ AMD EPYC™ CPU, PCIe Gen4 NVMe RAID-10, DDR5 RAM ល្បឿនខ្ពស់ជាមួយ Edge Node នៅ ភ្នំពេញ, Singapore, Tokyo។`,
    en: `## What is Cloud Hosting?

Cloud Hosting is a hosting system that uses multiple virtual servers together, replacing a single physical server. Using Cloud Hosting ensures:

- **Fast Speed** — NVMe SSD up to 7,000 MB/s
- **99.99% Uptime** — SLA guaranteed in contract
- **Scalable** — Instantly expand resources
- **DDoS Protection** — 3.2 Tbps mitigation capacity

## Why Use Cloud Hosting?

If you're an SME business owner in Cambodia, Cloud Hosting provides:

1. Page loading in < 1 Second
2. Free SSL Certificate
3. Automated daily backups
4. 24/7 Support

## Broteach Cloud Hosting

Broteach provides Cloud Hosting powered by AMD EPYC™ CPU, PCIe Gen4 NVMe RAID-10, DDR5 RAM with Edge Nodes in Phnom Penh, Singapore, and Tokyo.`,
  },
};

import { BlogPostItem } from "@/types";

interface BlogPostClientProps {
  post: BlogPostItem;
}

function renderMarkdownOrHtml(text: string): React.ReactNode {
  // If the content contains HTML elements, process markdown headers & render rich HTML
  if (/<[a-z][\s\S]*>/i.test(text)) {
    const htmlContent = text
      .replace(/^### (.*$)/gim, '<h3 class="text-lg font-black text-cyan-300 mt-6 mb-3">$1</h3>')
      .replace(/^## (.*$)/gim, '<h2 class="text-xl sm:text-2xl font-black text-white mt-8 mb-4">$1</h2>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

    return (
      <div
        className="prose prose-invert max-w-none text-slate-300 text-sm sm:text-base leading-relaxed space-y-4"
        dangerouslySetInnerHTML={{ __html: htmlContent }}
      />
    );
  }

  // Standard Markdown fallback
  const lines = text.split("\n");
  return (
    <div className="space-y-2">
      {lines.map((line, i) => {
        if (line.startsWith("## ")) {
          return (
            <h2 key={i} className="text-xl sm:text-2xl font-black text-white mt-8 mb-4">
              {line.slice(3)}
            </h2>
          );
        }
        if (line.startsWith("### ")) {
          return (
            <h3 key={i} className="text-lg font-black text-cyan-300 mt-6 mb-3">
              {line.slice(4)}
            </h3>
          );
        }
        if (line.match(/^\d+\. /)) {
          return (
            <li key={i} className="text-slate-300 text-sm leading-relaxed ml-4">
              {line.replace(/^\d+\. /, "")}
            </li>
          );
        }
        if (line.startsWith("- ")) {
          const content = line.slice(2).replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
          return (
            <li
              key={i}
              className="text-slate-300 text-sm leading-relaxed ml-4 list-disc"
              dangerouslySetInnerHTML={{ __html: content }}
            />
          );
        }
        if (line.trim() === "") return <br key={i} />;
        return (
          <p key={i} className="text-slate-300 text-sm sm:text-base leading-relaxed">
            {line}
          </p>
        );
      })}
    </div>
  );
}

export default function BlogPostClient({ post }: BlogPostClientProps) {
  const { language } = useLanguage();
  const [copied, setCopied] = React.useState(false);
  const content = (post.contentKm || post.contentEn) 
    ? { km: post.contentKm || post.excerptKm || "", en: post.contentEn || post.excerptEn || "" }
    : (POST_CONTENT[post.slug] || { km: post.excerptKm || "", en: post.excerptEn || "" });
  const related = BLOG_POSTS.filter((p) => p.slug !== post.slug && p.category === post.category).slice(0, 3);


  const handleCopyLink = () => {
    if (typeof window !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <div className="min-h-screen bg-[#030d1a] flex flex-col selection:bg-cyan-500 selection:text-white">
      <Navbar />
      <main className="flex-1 pt-16 pb-20 animate-page-enter">
        {/* Hero */}
        <div className={`relative pt-8 pb-12 sm:pt-10 sm:pb-14 bg-gradient-to-br ${post.coverGradient} overflow-hidden`}>
        <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 animate-fade-in-up">
          <Link
            href="/blog"
            className="inline-flex items-center gap-2 text-white/70 hover:text-white text-xs font-semibold mb-6 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            {language === "km" ? "ត្រឡប់ទៅ Blog" : "Back to Blog"}
          </Link>

          <div className="flex items-center gap-3 mb-4">
            <span className="px-3 py-1 rounded-full bg-white/20 text-white text-[10px] font-bold uppercase tracking-wider backdrop-blur-md">
              {language === "km" ? post.tagKm : post.tagEn}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight leading-snug mb-4">
            {language === "km" ? post.titleKm : post.titleEn}
          </h1>

          <div className="flex items-center gap-4 text-white/60 text-xs">
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              {post.date}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              {post.readingTime} {language === "km" ? "នាទី" : "min read"}
            </span>
            <span className="flex items-center gap-1">
              <Tag className="w-3.5 h-3.5" />
              {post.category}
            </span>
          </div>
        </div>
      </div>

      {/* Article Body */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 pb-28 lg:pb-16 animate-fade-in-up delay-100">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Content */}
          <article className="lg:col-span-8">
            {/* Featured Image */}
            {post.image && (
              <div className="mb-8 rounded-2xl overflow-hidden border border-slate-700/60 shadow-xl max-h-[420px] bg-slate-900">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={post.image}
                  alt={language === "km" ? post.titleKm : post.titleEn}
                  className="w-full h-full object-cover max-h-[420px]"
                />
              </div>
            )}

            {/* Excerpt */}
            <div className="p-4 rounded-2xl bg-cyan-950/30 border border-cyan-500/20 text-slate-300 text-sm leading-relaxed mb-8 italic">
              {language === "km" ? post.excerptKm : post.excerptEn}
            </div>

            {/* Body */}
            {content ? (
              <div className="prose prose-invert max-w-none space-y-2">
                {renderMarkdownOrHtml(language === "km" ? content.km : content.en)}
              </div>
            ) : (
              <div className="space-y-6 text-slate-300 text-sm leading-relaxed">
                <div className="p-5 rounded-2xl bg-cyan-950/20 border border-cyan-500/20 space-y-3">
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <span className="text-cyan-400">⚡</span>
                    {language === "km" ? "ចំណុចគន្លឹះសំខាន់ៗ" : "Key Insights & Takeaways"}
                  </h3>
                  <ul className="space-y-2 text-xs sm:text-sm text-slate-300 list-disc list-inside">
                    <li>
                      {language === "km"
                        ? "ការអនុវត្តតាមស្តង់ដារបច្ចេកវិទ្យាទំនើបឆ្នាំ ២០២៦ សម្រាប់ល្បឿន និងសុវត្ថិភាព"
                        : "Implementation following modern 2026 tech standards for maximum speed and security"}
                    </li>
                    <li>
                      {language === "km"
                        ? "ការបង្កើនប្រសិទ្ធភាព SEO និងទិន្នន័យដើម្បីទទួលបានចំណាត់ថ្នាក់ខ្ពស់លើ Google"
                        : "SEO optimization and performance engineering to rank higher on Google search results"}
                    </li>
                    <li>
                      {language === "km"
                        ? "ការគាំទ្រហេដ្ឋារចនាសម្ព័ន្ធ Cloud NVMe ល្បឿនលឿន ជាមួយ Uptime 99.99%"
                        : "Ultra-fast NVMe Cloud infrastructure support backed by 99.99% uptime guarantee"}
                    </li>
                  </ul>
                </div>

                <p className="text-slate-300 leading-relaxed">
                  {language === "km"
                    ? `សម្រាប់ព័ត៌មានលម្អិតបន្ថែម ឬការពិគ្រោះយោបល់លើ ${post.titleKm} ក្រុមការងារបច្ចេកទេស Broteach ត្រៀមខ្លួនជួយសម្របសម្រួលអាជីវកម្មរបស់អ្នក ២៤/៧។`
                    : `For more in-depth consultations regarding ${post.titleEn}, the Broteach engineering team is available 24/7 to empower your business infrastructure.`}
                </p>
              </div>
            )}

            {/* Clean Share & Return Bar (No like, no comments) */}
            <div className="mt-10 pt-6 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-4">
              <Link
                href="/blog"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs font-semibold text-slate-300 hover:text-cyan-400 hover:border-cyan-500/40 transition-all"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                {language === "km" ? "ត្រឡប់ទៅបញ្ជី Blog" : "Back to Blog List"}
              </Link>

              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-400 flex items-center gap-1.5">
                  <Share2 className="w-3.5 h-3.5 text-cyan-400" />
                  {language === "km" ? "ចែករំលែកអត្ថបទ:" : "Share Article:"}
                </span>
                <button
                  onClick={handleCopyLink}
                  className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/70 border border-cyan-500/30 text-cyan-300 hover:text-white text-xs font-semibold hover:bg-cyan-900/50 hover:border-cyan-400 transition-all cursor-pointer shadow-sm"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">{language === "km" ? "បានចម្លង!" : "Copied!"}</span>
                    </>
                  ) : (
                    <>
                      <span>🔗</span>
                      <span>{language === "km" ? "ចម្លង Link" : "Copy Link"}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </article>

          {/* Sidebar */}
          <aside className="lg:col-span-4 space-y-6">
            {/* CTA Card */}
            <div className="p-5 rounded-2xl bg-gradient-to-b from-[#06152a] to-[#030d1d] border border-cyan-500/30 text-center space-y-3 sticky top-24 card-hover-effect animate-scale-in delay-200">
              <div className="text-3xl">🚀</div>
              <h3 className="text-sm font-black text-white">
                {language === "km" ? "ត្រូវការ Cloud Hosting?" : "Need Cloud Hosting?"}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {language === "km"
                  ? "ទំនាក់ទំនង Broteach សម្រាប់ Cloud Hosting NVMe ល្បឿនខ្ពស់ ជាមួយ SLA 99.99%"
                  : "Contact Broteach for high-speed NVMe Cloud Hosting with 99.99% SLA."}
              </p>
              <Link
                href="/pricing"
                className="block py-2 rounded-full bg-gradient-to-r from-cyan-600 to-blue-600 text-white text-xs font-bold hover:opacity-90 transition-opacity"
              >
                {language === "km" ? "មើលតម្លៃ" : "View Pricing"}
              </Link>
            </div>

            {/* Related Posts */}
            {related.length > 0 && (
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  {language === "km" ? "អត្ថបទពាក់ព័ន្ធ" : "Related Articles"}
                </h4>
                {related.map((r) => (
                  <Link
                    key={r.slug}
                    href={`/blog/${r.slug}`}
                    className="block p-3 rounded-xl bg-[#051628] border border-slate-800 hover:border-cyan-500/30 transition-all text-xs"
                  >
                    <span className="text-lg mr-2">{r.icon}</span>
                    <span className="text-slate-300 hover:text-white leading-snug">
                      {language === "km" ? r.titleKm : r.titleEn}
                    </span>
                  </Link>
                ))}
              </div>
            )}
          </aside>
        </div>
      </div>
    </main>
    <Footer />
  </div>
);
}
