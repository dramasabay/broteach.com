"use client";

import React, { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import {
  Lock,
  Unlock,
  ShieldCheck,
  Plus,
  Trash2,
  Edit,
  Save,
  CheckCircle,
  AlertCircle,
  AlertTriangle,
  Loader2,
  Package,
  Layers,
  Settings,
  ShoppingCart,
  Users,
  ArrowLeft,
  LogOut,
  RefreshCw,
  LayoutGrid,
  ExternalLink,
  Sparkles,
  ChevronRight,
  Eye,
  Check,
  X,
  Copy,
  Search,
  Globe,
  SearchCheck,
  FileText,
  Image as ImageIcon,
  BookOpen,
  PenSquare,
  Database,
  Download,
  Upload,
  HardDrive,
  RotateCcw,
  FileArchive,
  CheckCircle2,
  FolderOpen,
  UploadCloud,
  File as FileIcon,
  Megaphone,
  Send,
  Undo2,
  Clock,
  Trash,
  EyeOff,
  Menu,
  GripVertical,
  ArrowUp,
  ArrowDown,
  Play,
} from "lucide-react";
import {
  ProductItem,
  SiteSettings,
  PricingPlan,
  OrderSubmission,
  NewsletterSubscriber,
  ContentSection,
  SectionItem,
  BlogPostItem,
  TrashItem,
  HomeSectionItemConfig,
  DEFAULT_HOME_SECTIONS,
} from "@/types";
import { broadcastCmsUpdate } from "@/lib/realtime";
import { CambodiaFlag, UKFlag } from "@/components/FlagIcons";
import { SnapshotItem, BackupData } from "@/lib/backup";
import { MediaFileItem } from "@/lib/storageManager";
import { BroteachBrand } from "@/components/BroteachLogo";


export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [passwordInput, setPasswordInput] = useState("");
  const [authError, setAuthError] = useState("");
  const [authLoading, setAuthLoading] = useState(false);

  // Admin Language
  const [adminLang, setAdminLang] = useState<"km" | "en">("km");

  // Tabs
  const [activeTab, setActiveTab] = useState<
    "overview" | "homelayout" | "storage" | "backup" | "posts" | "products" | "sections" | "pricing" | "ads" | "trash" | "telegram" | "seo" | "settings" | "orders" | "subscribers"
  >("overview");
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [seoPreviewLang, setSeoPreviewLang] = useState<"km" | "en">("km");
  const [draggedSectionIndex, setDraggedSectionIndex] = useState<number | null>(null);

  // CMS Data States
  const [posts, setPosts] = useState<BlogPostItem[]>([]);
  const [products, setProducts] = useState<ProductItem[]>([]);
  const [sections, setSections] = useState<ContentSection[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [pricing, setPricing] = useState<PricingPlan[]>([]);
  const [orders, setOrders] = useState<OrderSubmission[]>([]);
  const [subscribers, setSubscribers] = useState<NewsletterSubscriber[]>([]);
  const [loadingData, setLoadingData] = useState(false);
  const [feedback, setFeedback] = useState<{ type: "success" | "error"; msg: string } | null>(null);

  // Trash & 5-Second Undo State
  const [trashItems, setTrashItems] = useState<TrashItem[]>([]);
  const [loadingTrash, setLoadingTrash] = useState(false);
  const [undoToast, setUndoToast] = useState<{
    trashId: string;
    title: string;
    itemType: string;
    secondsRemaining: number;
    restoreHandler: () => Promise<void>;
  } | null>(null);

  // Telegram Integration State
  const [telegramTesting, setTelegramTesting] = useState(false);
  const [telegramTestStatus, setTelegramTestStatus] = useState<{ success: boolean; message: string } | null>(null);
  const [showTokenSecret, setShowTokenSecret] = useState(false);

  // Styled Delete Confirmation Modal State
  const [deleteConfirmModal, setDeleteConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    itemTitle: string;
    itemTypeLabel: string;
    warningMessage?: string;
    isPermanent?: boolean;
    onConfirm: () => Promise<void>;
  }>({
    isOpen: false,
    title: "",
    itemTitle: "",
    itemTypeLabel: "",
    warningMessage: "",
    isPermanent: false,
    onConfirm: async () => {},
  });
  const [deleteSubmitting, setDeleteSubmitting] = useState(false);

  // Pagination States for Dashboard Lists
  const [ordersPage, setOrdersPage] = useState(1);
  const [subscribersPage, setSubscribersPage] = useState(1);
  const [productsPage, setProductsPage] = useState(1);
  const [postsPage, setPostsPage] = useState(1);
  const [sectionsPage, setSectionsPage] = useState(1);
  const [mediaPage, setMediaPage] = useState(1);
  const [trashPage, setTrashPage] = useState(1);
  const [mountTime] = useState(() => Date.now());

  // Posts / Blog CMS State
  const [isPostModalOpen, setIsPostModalOpen] = useState(false);
  const [postPreviewMode, setPostPreviewMode] = useState<"edit" | "preview">("edit");
  const [postSearch, setPostSearch] = useState("");
  const [postCategoryFilter, setPostCategoryFilter] = useState("all");
  const [editingPost, setEditingPost] = useState<Partial<BlogPostItem>>({
    slug: "",
    titleKm: "",
    titleEn: "",
    category: "Web Development",
    categoryKm: "ការអភិវឌ្ឍគេហទំព័រ",
    categoryEn: "Web Development",
    author: "Broteach Team",
    date: "Mar 15, 2026",
    readTime: "5 min",
    image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1200&q=80",
    excerptKm: "",
    excerptEn: "",
    contentKm: "",
    contentEn: "",
    featured: false,
  });

  // Edit / Add Product Modal State
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Partial<ProductItem>>({
    titleKm: "",
    titleEn: "",
    category: "webapp",
    categoryLabelKm: "គេហទំព័រអាជីវកម្ម",
    categoryLabelEn: "Web App",
    price: 350,
    badgeKm: "ថ្មី",
    badgeEn: "New",
    descKm: "",
    descEn: "",
    featuresKm: ["រចនាបទ Responsive លើគ្រប់ឧបករណ៍", "ល្បឿនផ្ទុកលឿន", "Free Domain & Hosting 1 ឆ្នាំ"],
    featuresEn: ["Fully Responsive on all devices", "Fast page loading", "Free Domain & Hosting 1 Year"],
    icon: "Briefcase",
    demoUrl: "",
    isActive: true,
  });
  const [newFeatureKm, setNewFeatureKm] = useState("");
  const [newFeatureEn, setNewFeatureEn] = useState("");

  // Edit / Add Content Section Modal State
  const [isSectionModalOpen, setIsSectionModalOpen] = useState(false);
  const [editingSection, setEditingSection] = useState<Partial<ContentSection>>({
    titleKm: "",
    titleEn: "",
    subtitleKm: "",
    subtitleEn: "",
    badgeKm: "",
    badgeEn: "",
    layoutType: "cards",
    items: [],
    isActive: true,
    sortOrder: 1,
    anchorId: "",
  });

  // Edit / Add Pricing Plan Modal State
  const [isPricingModalOpen, setIsPricingModalOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<Partial<PricingPlan>>({
    nameKm: "",
    nameEn: "",
    badgeKm: "",
    badgeEn: "",
    price: 39,
    periodKm: "/ខែ",
    periodEn: "/month",
    colorScheme: "red",
    featuresKm: [],
    featuresEn: [],
    recommended: false,
    demoUrl: "",
    orderUrl: "",
  });
  const [newPlanFeatureKm, setNewPlanFeatureKm] = useState("");
  const [newPlanFeatureEn, setNewPlanFeatureEn] = useState("");

  // Subscribers Search & Copy State
  const [subscriberSearch, setSubscriberSearch] = useState("");
  const [copiedEmails, setCopiedEmails] = useState(false);

  // Backup & Restore CMS State
  const [snapshots, setSnapshots] = useState<SnapshotItem[]>([]);
  const [loadingBackups, setLoadingBackups] = useState(false);
  const [snapshotTagInput, setSnapshotTagInput] = useState("");
  const [isCreatingSnapshot, setIsCreatingSnapshot] = useState(false);
  const [restoreModalOpen, setRestoreModalOpen] = useState(false);
  const [restoreSource, setRestoreSource] = useState<"upload" | "snapshot">("upload");
  const [selectedSnapshotFile, setSelectedSnapshotFile] = useState<SnapshotItem | null>(null);
  const [uploadedBackupData, setUploadedBackupData] = useState<BackupData | null>(null);
  const [uploadedFileName, setUploadedFileName] = useState("");
  const [isRestoring, setIsRestoring] = useState(false);
  const [selectiveRestore, setSelectiveRestore] = useState<Record<string, boolean>>({
    settings: true,
    products: true,
    pricing: true,
    sections: true,
    posts: true,
    orders: true,
    subscribers: true,
  });

  // Media & Storage CMS State
  const [mediaFiles, setMediaFiles] = useState<MediaFileItem[]>([]);
  const [loadingMedia, setLoadingMedia] = useState(false);
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const [mediaFilter, setMediaFilter] = useState<"all" | "images" | "files">("all");
  const [mediaSearch, setMediaSearch] = useState("");
  const [copiedMediaUrl, setCopiedMediaUrl] = useState<string | null>(null);

  const showToast = (type: "success" | "error", msg: string) => {
    setFeedback({ type, msg });
    setTimeout(() => setFeedback(null), 4500);
  };

  // Helper to insert rich HTML/CSS snippets into blog post body
  const handleInsertPostSnippet = (
    field: "contentKm" | "contentEn",
    type: "btn" | "frame" | "video" | "badge" | "table"
  ) => {
    let snippet = "";
    if (type === "btn") {
      snippet = `\n\n<a href="https://t.me/broteach" target="_blank" style="display:inline-block;padding:12px 28px;background:linear-gradient(135deg,#06b6d4,#2563eb);color:#ffffff;font-weight:700;font-size:14px;border-radius:12px;text-decoration:none;box-shadow:0 4px 15px rgba(6,182,212,0.4);margin:12px 0;">🚀 ${field === "contentKm" ? "ទាក់ទងប្រឹក្សាឥឡូវនេះ" : "Contact Consultation"} &rarr;</a>\n\n`;
    } else if (type === "frame") {
      snippet = `\n\n<div style="background:rgba(15,23,42,0.85);border:1px solid rgba(6,182,212,0.4);border-left:5px solid #06b6d4;border-radius:14px;padding:20px 24px;margin:20px 0;box-shadow:0 10px 30px rgba(0,0,0,0.35);">\n  <h4 style="margin:0 0 10px 0;color:#38bdf8;font-size:16px;font-weight:bold;">💡 ${field === "contentKm" ? "គន្លឹះសំខាន់ • Key Point" : "Key Highlight"}</h4>\n  <p style="margin:0;color:#cbd5e1;font-size:14px;line-height:1.7;">${field === "contentKm" ? "សរសេរព័ត៌មានលម្អិត ឬគន្លឹះពិសេសនៅទីនេះ..." : "Insert callout details or key insight here..."}</p>\n</div>\n\n`;
    } else if (type === "video") {
      snippet = `\n\n<div style="position:relative;width:100%;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:16px;margin:20px 0;border:1px solid #334155;box-shadow:0 10px 30px rgba(0,0,0,0.5);">\n  <iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ" title="Video" style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;" allowfullscreen></iframe>\n</div>\n\n`;
    } else if (type === "badge") {
      snippet = ` <span style="display:inline-flex;align-items:center;padding:4px 14px;border-radius:9999px;background:#064e3b;color:#6ee7b7;border:1px solid #059669;font-size:12px;font-weight:700;margin:4px 4px 4px 0;">✨ ${field === "contentKm" ? "មុខងារថ្មី 2026" : "New Feature 2026"}</span> `;
    } else if (type === "table") {
      snippet = `\n\n<div style="overflow-x:auto;margin:20px 0;border-radius:14px;border:1px solid #334155;">\n  <table style="width:100%;border-collapse:collapse;font-size:13px;text-align:left;">\n    <thead>\n      <tr style="background:#0f172a;color:#38bdf8;border-bottom:1px solid #334155;">\n        <th style="padding:10px 14px;">#</th>\n        <th style="padding:10px 14px;">${field === "contentKm" ? "លក្ខណៈពិសេស" : "Feature"}</th>\n        <th style="padding:10px 14px;">${field === "contentKm" ? "ស្ថានភាព" : "Status"}</th>\n      </tr>\n    </thead>\n    <tbody style="background:rgba(15,23,42,0.6);color:#e2e8f0;">\n      <tr style="border-bottom:1px solid #1e293b;">\n        <td style="padding:10px 14px;">01</td>\n        <td style="padding:10px 14px;font-weight:600;">Ultra Fast Speed</td>\n        <td style="padding:10px 14px;color:#34d399;">✓ Available</td>\n      </tr>\n      <tr>\n        <td style="padding:10px 14px;">02</td>\n        <td style="padding:10px 14px;font-weight:600;">Enterprise Security</td>\n        <td style="padding:10px 14px;color:#34d399;">✓ Available</td>\n      </tr>\n    </tbody>\n  </table>\n</div>\n\n`;
    }

    setEditingPost((prev) => ({
      ...prev,
      [field]: (prev[field] || "") + snippet,
    }));
  };

  // Modern Pagination Controls Renderer
  const renderPagination = (
    currentPage: number,
    totalItems: number,
    pageSize: number,
    onPageChange: (newPage: number) => void
  ) => {
    const totalPages = Math.ceil(totalItems / pageSize);
    if (totalPages <= 1) return null;

    const pages = [];
    for (let i = 1; i <= totalPages; i++) {
      pages.push(i);
    }

    const startItem = (currentPage - 1) * pageSize + 1;
    const endItem = Math.min(currentPage * pageSize, totalItems);

    return (
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-800 text-xs text-slate-400">
        <div>
          {adminLang === "km" ? (
            <span>
              បង្ហាញ <strong className="text-white font-mono">{startItem} - {endItem}</strong> នៃសរុប{" "}
              <strong className="text-cyan-400 font-mono">{totalItems}</strong> ធាតុ
            </span>
          ) : (
            <span>
              Showing <strong className="text-white font-mono">{startItem} - {endItem}</strong> of{" "}
              <strong className="text-cyan-400 font-mono">{totalItems}</strong> items
            </span>
          )}
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            disabled={currentPage <= 1}
            onClick={() => onPageChange(currentPage - 1)}
            className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:text-white transition-colors cursor-pointer"
          >
            &larr; {adminLang === "km" ? "មុន" : "Prev"}
          </button>

          <div className="flex items-center gap-1">
            {pages.map((p) => {
              if (
                totalPages > 7 &&
                p !== 1 &&
                p !== totalPages &&
                Math.abs(p - currentPage) > 1
              ) {
                if (p === 2 || p === totalPages - 1) {
                  return (
                    <span key={p} className="px-1 text-slate-600">
                      ...
                    </span>
                  );
                }
                return null;
              }

              return (
                <button
                  key={p}
                  type="button"
                  onClick={() => onPageChange(p)}
                  className={`w-8 h-8 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
                    p === currentPage
                      ? "bg-cyan-500 text-black shadow-md shadow-cyan-500/30"
                      : "bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700"
                  }`}
                >
                  {p}
                </button>
              );
            })}
          </div>

          <button
            type="button"
            disabled={currentPage >= totalPages}
            onClick={() => onPageChange(currentPage + 1)}
            className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:text-white transition-colors cursor-pointer"
          >
            {adminLang === "km" ? "បន្ទាប់" : "Next"} &rarr;
          </button>
        </div>
      </div>
    );
  };

  const loadMediaFiles = useCallback(async () => {
    setLoadingMedia(true);
    try {
      const res = await fetch("/api/admin/upload");
      if (res.ok) {
        const data = await res.json();
        setMediaFiles(data.files || []);
      }
    } catch {
      // ignore
    } finally {
      setLoadingMedia(false);
    }
  }, []);

  const loadBackups = useCallback(async () => {
    setLoadingBackups(true);
    try {
      const res = await fetch("/api/admin/backup");
      if (res.ok) {
        const data = await res.json();
        setSnapshots(data.snapshots || []);
      }
    } catch {
      // ignore
    } finally {
      setLoadingBackups(false);
    }
  }, []);

  // 5-second countdown timer for Undo Toast
  useEffect(() => {
    if (!undoToast) return;
    const timer = setTimeout(() => {
      setUndoToast((prev) => {
        if (!prev) return null;
        if (prev.secondsRemaining <= 1) return null;
        return { ...prev, secondsRemaining: prev.secondsRemaining - 1 };
      });
    }, 1000);
    return () => clearTimeout(timer);
  }, [undoToast]);

  const loadTrashItems = useCallback(async () => {
    setLoadingTrash(true);
    try {
      const res = await fetch("/api/admin/trash");
      if (res.ok) {
        const data = await res.json();
        setTrashItems(data.items || []);
      }
    } catch {
      // ignore
    } finally {
      setLoadingTrash(false);
    }
  }, []);

  const handleEmptyTrash = () => {
    setDeleteConfirmModal({
      isOpen: true,
      title: adminLang === "km" ? "សម្អាតធុងសម្រាមទាំងអស់?" : "Empty All Trash?",
      itemTitle: adminLang === "km" ? `ទិន្នន័យសរុប ${trashItems.length} ធាតុ` : `All ${trashItems.length} Trash Items`,
      itemTypeLabel: adminLang === "km" ? "ធុងសម្រាម (Recycle Bin)" : "Recycle Bin",
      warningMessage: adminLang === "km" ? "ទិន្នន័យទាំងអស់ក្នុងធុងសម្រាមនឹងត្រូវលុបជាអចិន្ត្រៃយ៍ មិនអាចត្រឡប់វិញបានទេ!" : "All items will be permanently erased immediately! This cannot be undone.",
      isPermanent: true,
      onConfirm: async () => {
        try {
          const res = await fetch("/api/admin/trash", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "empty" }),
          });
          if (res.ok) {
            setTrashItems([]);
            showToast(
              "success",
              adminLang === "km" ? "ធុងសម្រាមត្រូវបានសម្អាតអស់ហើយ!" : "Trash emptied successfully!"
            );
          }
        } catch {
          showToast("error", "Failed to empty trash");
        }
      },
    });
  };

  const handleRestoreFromTrash = async (trashId: string) => {
    try {
      const res = await fetch("/api/admin/trash", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "restore", trashId }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        showToast("success", data.message || "Restored successfully!");
        loadTrashItems();
        loadAllData();
      } else {
        showToast("error", data.message || "Failed to restore");
      }
    } catch {
      showToast("error", "Error restoring item");
    }
  };

  const handleDeletePermanentTrash = (trashId: string) => {
    const item = trashItems.find((i) => i.id === trashId);
    const itemTitle = item ? item.title : trashId;

    setDeleteConfirmModal({
      isOpen: true,
      title: adminLang === "km" ? "លុបជាស្ថាពរចេញពីធុងសម្រាម?" : "Permanently Delete Trash Item?",
      itemTitle: itemTitle,
      itemTypeLabel: adminLang === "km" ? "ទិន្នន័យសម្រាម (Trash Item)" : "Trash Item",
      warningMessage: adminLang === "km" ? "សកម្មភាពនេះនឹងលុបទិន្នន័យជាអចិន្ត្រៃយ៍ មិនអាចត្រឡប់វិញបានទេ!" : "This item will be permanently erased and cannot be restored!",
      isPermanent: true,
      onConfirm: async () => {
        try {
          const res = await fetch("/api/admin/trash", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "delete", trashId }),
          });
          if (res.ok) {
            setTrashItems((prev) => prev.filter((i) => i.id !== trashId));
            showToast("success", adminLang === "km" ? "បានលុបជាស្ថាពរ!" : "Permanently deleted!");
          }
        } catch {
          showToast("error", "Failed to delete permanently");
        }
      },
    });
  };

  const loadAllData = useCallback(async () => {
    setLoadingData(true);
    try {
      // Content & Settings
      const resContent = await fetch("/api/admin/content");
      if (resContent.ok) {
        const data = await resContent.json();
        setSettings(data.settings);
        setPricing(data.pricing);
      }

      // Products
      const resProd = await fetch("/api/admin/products");
      if (resProd.ok) {
        const data = await resProd.json();
        setProducts(data.products || []);
      }

      // Content Sections
      const resSec = await fetch("/api/admin/sections");
      if (resSec.ok) {
        const data = await resSec.json();
        setSections(data.sections || []);
      }

      // Blog Posts
      const resPosts = await fetch("/api/admin/posts");
      if (resPosts.ok) {
        const data = await resPosts.json();
        setPosts(data.posts || []);
      }

      // Orders
      const resOrders = await fetch("/api/orders");
      if (resOrders.ok) {
        const data = await resOrders.json();
        setOrders(data.orders || []);
      }

      // Subscribers
      const resSubs = await fetch("/api/newsletter");
      if (resSubs.ok) {
        const data = await resSubs.json();
        setSubscribers(data.subscribers || []);
      }

      // Snapshots & Backups
      const resBackups = await fetch("/api/admin/backup");
      if (resBackups.ok) {
        const data = await resBackups.json();
        setSnapshots(data.snapshots || []);
      }

      // Uploaded Media & Storage
      const resMedia = await fetch("/api/admin/upload");
      if (resMedia.ok) {
        const data = await resMedia.json();
        setMediaFiles(data.files || []);
      }

      // Trash Items (7 days retention)
      loadTrashItems();
    } catch {
      showToast("error", adminLang === "km" ? "មានបញ្ហាក្នុងការទាញទិន្នន័យ" : "Error loading data");
    } finally {
      setLoadingData(false);
    }
  }, [adminLang, loadTrashItems]);

  // Check initial authentication
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const res = await fetch("/api/admin/content");
        if (res.ok) {
          setIsAuthenticated(true);
          loadAllData();
        }
      } catch {
        // Not authenticated
      }
    };
    checkAuth();
  }, [loadAllData]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError("");

    try {
      const res = await fetch("/api/admin/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: passwordInput }),
      });
      const data = await res.json();

      if (res.ok && data.success) {
        if (data.token) {
          localStorage.setItem("broteach_admin_token", data.token);
        }
        setIsAuthenticated(true);
        loadAllData();
      } else {
        setAuthError(
          data.message || (adminLang === "km" ? "ពាក្យសម្ងាត់មិនត្រឹមត្រូវទេ" : "Invalid password")
        );
      }
    } catch {
      setAuthError(adminLang === "km" ? "បញ្ហាក្នុងការតភ្ជាប់" : "Connection error");
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = async () => {
    await fetch("/api/admin/auth", { method: "DELETE" });
    localStorage.removeItem("broteach_admin_token");
    setIsAuthenticated(false);
    setPasswordInput("");
  };

  // Posts CMS Handlers
  const handleSavePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPost.slug || !editingPost.titleEn) {
      showToast("error", adminLang === "km" ? "សូមបញ្ចូលចំណងជើង និង Slug URL" : "Slug and Title (EN) are required");
      return;
    }

    try {
      const res = await fetch("/api/admin/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editingPost),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setPosts(data.posts || []);
        broadcastCmsUpdate("posts");
        setIsPostModalOpen(false);
        showToast(
          "success",
          adminLang === "km" ? "អត្ថបទត្រូវបានរក្សាទុកដោយជោគជ័យ!" : "Article saved successfully!"
        );
      } else {
        showToast("error", data.message || "Failed to save post");
      }
    } catch {
      showToast("error", adminLang === "km" ? "មានបញ្ហាក្នុងការរក្សាទុក" : "Network error");
    }
  };

  const handleDeletePost = (slug: string) => {
    const targetPost = posts.find((p) => p.slug === slug);
    const postTitle = targetPost ? (targetPost.titleKm || targetPost.titleEn) : slug;

    setDeleteConfirmModal({
      isOpen: true,
      title: adminLang === "km" ? "បញ្ជាក់ការលុបអត្ថបទ Blog" : "Confirm Delete Article",
      itemTitle: postTitle,
      itemTypeLabel: adminLang === "km" ? "អត្ថបទ (Article)" : "Blog Post",
      warningMessage: adminLang === "km" ? "រក្សាទុកក្នុងធុងសម្រាម 7 ថ្ងៃ អាចស្តារឡើងវិញបានគ្រប់ពេល" : "Kept in Trash for 7 days with instant 5-second undo and full restore capability.",
      isPermanent: false,
      onConfirm: async () => {
        try {
          let trashId = "";
          if (targetPost) {
            const trashRes = await fetch("/api/admin/trash", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                action: "move",
                itemType: "post",
                originalId: slug,
                title: postTitle,
                data: targetPost,
              }),
            });
            if (trashRes.ok) {
              const tData = await trashRes.json();
              trashId = tData.trashId;
              loadTrashItems();
            }
          }

          const res = await fetch(`/api/admin/posts?slug=${encodeURIComponent(slug)}`, {
            method: "DELETE",
          });
          const data = await res.json();
          if (res.ok && data.success) {
            setPosts(data.posts || []);
            broadcastCmsUpdate("posts");

            if (trashId) {
              setUndoToast({
                trashId,
                title: postTitle,
                itemType: "post",
                secondsRemaining: 5,
                restoreHandler: async () => {
                  await handleRestoreFromTrash(trashId);
                },
              });
            } else {
              showToast("success", adminLang === "km" ? "អត្ថបទត្រូវបានលុប!" : "Article deleted!");
            }
          } else {
            showToast("error", data.message || "Failed to delete post");
          }
        } catch {
          showToast("error", adminLang === "km" ? "មានបញ្ហាក្នុងការលុប" : "Network error");
        }
      },
    });
  };

  const handleDuplicatePost = async (post: BlogPostItem) => {
    const copySuffix = `${posts.length + 1}`;
    const newSlug = `${post.slug}-copy-${copySuffix}`;
    const duplicated: BlogPostItem = {
      ...post,
      slug: newSlug,
      titleKm: `${post.titleKm} (ចម្លង)`,
      titleEn: `${post.titleEn} (Copy)`,
      date: post.date,
    };

    try {
      const res = await fetch("/api/admin/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(duplicated),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setPosts(data.posts || []);
        broadcastCmsUpdate("posts");
        showToast("success", adminLang === "km" ? "អត្ថបទត្រូវបានចម្លងទ្វេដង!" : "Article duplicated successfully!");
      }
    } catch {
      showToast("error", adminLang === "km" ? "មានបញ្ហាក្នុងការចម្លង" : "Error duplicating post");
    }
  };

  // Save Settings
  const handleSaveSettings = async (e?: React.FormEvent) => {
    if (e && e.preventDefault) e.preventDefault();
    if (!settings) return;

    try {
      const res = await fetch("/api/admin/content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "settings", data: settings }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        broadcastCmsUpdate("settings");
        showToast("success", adminLang === "km" ? "ការកំណត់ត្រូវបានរក្សាទុក!" : "Settings saved successfully!");
      } else {
        showToast("error", data.message || "Failed to save settings");
      }
    } catch {
      showToast("error", "Failed to save settings");
    }
  };

  // Test Telegram Bot Notification
  const handleTestTelegram = async () => {
    if (!settings?.telegramBotToken || !settings?.telegramChatId) {
      showToast(
        "error",
        adminLang === "km"
          ? "សូមបញ្ចូល Bot Token និង Chat ID ជាមុនសិន!"
          : "Please enter Bot Token and Chat ID first!"
      );
      return;
    }
    setTelegramTesting(true);
    setTelegramTestStatus(null);
    try {
      const res = await fetch("/api/admin/telegram/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          botToken: settings.telegramBotToken,
          chatId: settings.telegramChatId,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setTelegramTestStatus({ success: true, message: data.message });
        showToast("success", data.message);
      } else {
        setTelegramTestStatus({ success: false, message: data.message || "Test failed" });
        showToast("error", data.message || "Failed to send test message");
      }
    } catch {
      setTelegramTestStatus({ success: false, message: "Network connection error" });
      showToast("error", "Network connection error");
    } finally {
      setTelegramTesting(false);
    }
  };

  // Save / Update Pricing Plan (Inline)
  const handleSavePlan = async (plan: PricingPlan) => {
    try {
      const res = await fetch("/api/admin/content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "pricing", data: plan }),
      });
      if (res.ok) {
        broadcastCmsUpdate("pricing");
        showToast("success", `${plan.nameKm} / ${plan.nameEn} updated!`);
      }
    } catch {
      showToast("error", "Failed to update pricing plan");
    }
  };

  // Save / Update Pricing Plan (Modal Add / Edit)
  const handleSavePricingPlan = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/admin/pricing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editingPlan),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        broadcastCmsUpdate("pricing");
        showToast(
          "success",
          adminLang === "km" ? "កញ្ចប់តម្លៃត្រូវបានរក្សាទុក!" : "Pricing plan saved successfully!"
        );
        setIsPricingModalOpen(false);
        loadAllData();
      } else {
        showToast("error", data.message || "Failed to save pricing plan");
      }
    } catch {
      showToast("error", "Failed to save pricing plan");
    }
  };

  // Delete Pricing Plan
  const handleDeletePricingPlan = (id: string) => {
    const targetPlan = pricing.find((p) => p.id === id);
    const planTitle = targetPlan ? (targetPlan.nameKm || targetPlan.nameEn) : id;

    setDeleteConfirmModal({
      isOpen: true,
      title: adminLang === "km" ? "បញ្ជាក់ការលុបកញ្ចប់តម្លៃ" : "Confirm Delete Pricing Plan",
      itemTitle: planTitle,
      itemTypeLabel: adminLang === "km" ? "កញ្ចប់តម្លៃ (Pricing Plan)" : "Pricing Plan",
      warningMessage: adminLang === "km" ? "រក្សាទុកក្នុងធុងសម្រាម 7 ថ្ងៃ អាចស្តារឡើងវិញបានគ្រប់ពេល" : "Kept in Trash for 7 days with instant 5-second undo.",
      isPermanent: false,
      onConfirm: async () => {
        try {
          let trashId = "";
          if (targetPlan) {
            const trashRes = await fetch("/api/admin/trash", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                action: "move",
                itemType: "plan",
                originalId: id,
                title: planTitle,
                data: targetPlan,
              }),
            });
            if (trashRes.ok) {
              const tData = await trashRes.json();
              trashId = tData.trashId;
              loadTrashItems();
            }
          }

          const res = await fetch(`/api/admin/pricing?id=${id}`, { method: "DELETE" });
          const data = await res.json();
          if (res.ok && data.success) {
            broadcastCmsUpdate("pricing");
            setPricing((prev) => prev.filter((p) => p.id !== id));

            if (trashId) {
              setUndoToast({
                trashId,
                title: planTitle,
                itemType: "plan",
                secondsRemaining: 5,
                restoreHandler: async () => {
                  await handleRestoreFromTrash(trashId);
                },
              });
            } else {
              showToast("success", adminLang === "km" ? "បានលុបកញ្ចប់តម្លៃជោគជ័យ!" : "Pricing plan deleted!");
            }
          } else {
            showToast("error", data.message || "Failed to delete pricing plan");
          }
        } catch {
          showToast("error", "Error deleting pricing plan");
        }
      },
    });
  };

  // Quick 1-click Toggle Section Active / Approved
  const handleToggleSectionActive = async (sec: ContentSection) => {
    const updated = { ...sec, isActive: !sec.isActive };
    try {
      const res = await fetch("/api/admin/sections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updated),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        broadcastCmsUpdate("sections");
        setSections((prev) => prev.map((s) => (s.id === sec.id ? updated : s)));
        showToast(
          "success",
          updated.isActive
            ? adminLang === "km"
              ? `បានអនុម័ត & បង្ហាញផ្នែក "${sec.titleKm}" លើគេហទំព័រ!`
              : `Section "${sec.titleEn}" approved & published!`
            : adminLang === "km"
              ? `បានបិទផ្នែក "${sec.titleKm}" (Draft / Hidden)!`
              : `Section "${sec.titleEn}" set to draft/hidden!`
        );
      } else {
        showToast("error", data.message || "Failed to update section");
      }
    } catch {
      showToast("error", "Failed to update section");
    }
  };

  // Delete Subscriber
  const handleDeleteSubscriber = (id: string) => {
    const targetSub = subscribers.find((s) => s.id === id);
    const subEmail = targetSub ? targetSub.email : id;

    setDeleteConfirmModal({
      isOpen: true,
      title: adminLang === "km" ? "បញ្ជាក់ការលុបអ៊ីមែលអ្នកជាវ" : "Confirm Delete Subscriber",
      itemTitle: subEmail,
      itemTypeLabel: adminLang === "km" ? "អ្នកជាវ (Subscriber)" : "Subscriber",
      warningMessage: adminLang === "km" ? "លុបអ៊ីមែលនេះចេញពីបញ្ជី Newsletter" : "Permanently remove this subscriber from the mailing list.",
      isPermanent: true,
      onConfirm: async () => {
        try {
          const res = await fetch(`/api/newsletter?id=${id}`, { method: "DELETE" });
          const data = await res.json();
          if (res.ok && data.success) {
            setSubscribers((prev) => prev.filter((s) => s.id !== id));
            showToast("success", adminLang === "km" ? "បានលុបអ៊ីមែលជោគជ័យ!" : "Subscriber deleted!");
          } else {
            showToast("error", data.message || "Failed to delete subscriber");
          }
        } catch {
          showToast("error", "Error deleting subscriber");
        }
      },
    });
  };

  // Copy all subscriber emails
  const handleCopySubscribers = () => {
    if (subscribers.length === 0) return;
    const emails = subscribers.map((s) => s.email).join(", ");
    navigator.clipboard.writeText(emails);
    setCopiedEmails(true);
    setTimeout(() => setCopiedEmails(false), 2500);
    showToast("success", adminLang === "km" ? "បានចម្លងបញ្ជីអ៊ីមែលទាំងអស់!" : "All emails copied to clipboard!");
  };

  // 1-Click Toggle Product Active/Disabled
  const handleToggleProductStatus = async (id: string, currentStatus: boolean) => {
    const target = products.find((p) => p.id === id);
    if (!target) return;
    const updated = { ...target, isActive: !currentStatus };
    setProducts((prev) => prev.map((p) => (p.id === id ? updated : p)));
    try {
      const res = await fetch("/api/admin/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updated),
      });
      if (res.ok) {
        broadcastCmsUpdate("products");
        showToast(
          "success",
          adminLang === "km"
            ? updated.isActive
              ? `បានបើកដំណើរការ «${updated.titleKm || updated.titleEn}»!`
              : `បានបិទដំណើរការ «${updated.titleKm || updated.titleEn}»!`
            : updated.isActive
              ? `Activated "${updated.titleEn || updated.titleKm}"!`
              : `Disabled "${updated.titleEn || updated.titleKm}"!`
        );
      } else {
        setProducts((prev) => prev.map((p) => (p.id === id ? target : p)));
        showToast("error", "Failed to update product status");
      }
    } catch {
      setProducts((prev) => prev.map((p) => (p.id === id ? target : p)));
      showToast("error", "Failed to update product status");
    }
  };

  // Home Layout Handlers (Reorder & Toggle)
  const handleMoveSection = (index: number, direction: "up" | "down") => {
    if (!settings) return;
    const currentSections = [
      ...(settings.homeSections && settings.homeSections.length > 0
        ? settings.homeSections
        : DEFAULT_HOME_SECTIONS),
    ].sort((a, b) => a.order - b.order);

    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= currentSections.length) return;

    const temp = currentSections[index];
    currentSections[index] = currentSections[targetIndex];
    currentSections[targetIndex] = temp;

    const updated = currentSections.map((item, idx) => ({ ...item, order: idx }));
    setSettings({ ...settings, homeSections: updated });
  };

  const handleToggleSectionEnabled = (id: string) => {
    if (!settings) return;
    const currentSections = [
      ...(settings.homeSections && settings.homeSections.length > 0
        ? settings.homeSections
        : DEFAULT_HOME_SECTIONS),
    ].sort((a, b) => a.order - b.order);

    const updated = currentSections.map((item) =>
      item.id === id ? { ...item, enabled: !item.enabled } : item
    );
    setSettings({ ...settings, homeSections: updated });
  };

  const handleResetHomeSections = () => {
    if (!settings) return;
    setSettings({ ...settings, homeSections: DEFAULT_HOME_SECTIONS });
    showToast(
      "success",
      adminLang === "km"
        ? "បានកំណត់លំដាប់លំនាំដើមឡើងវិញ!"
        : "Reset to default section layout!"
    );
  };

  const handleDragStart = (index: number) => {
    setDraggedSectionIndex(index);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (dropIndex: number) => {
    if (draggedSectionIndex === null || draggedSectionIndex === dropIndex || !settings) return;
    const currentSections = [
      ...(settings.homeSections && settings.homeSections.length > 0
        ? settings.homeSections
        : DEFAULT_HOME_SECTIONS),
    ].sort((a, b) => a.order - b.order);

    const itemToMove = currentSections.splice(draggedSectionIndex, 1)[0];
    currentSections.splice(dropIndex, 0, itemToMove);

    const updated = currentSections.map((item, idx) => ({ ...item, order: idx }));
    setSettings({ ...settings, homeSections: updated });
    setDraggedSectionIndex(null);
  };

  // Save / Update Product
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/admin/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editingProduct),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        broadcastCmsUpdate("products");
        showToast(
          "success",
          adminLang === "km" ? "ផលិតផលត្រូវបានរក្សាទុក!" : "Product saved successfully!"
        );
        setIsProductModalOpen(false);
        loadAllData();
      } else {
        showToast("error", data.message || "Failed to save product");
      }
    } catch {
      showToast("error", "Failed to save product");
    }
  };

  // Delete Product
  const handleDeleteProduct = (id: string) => {
    const targetProd = products.find((p) => p.id === id);
    const prodTitle = targetProd ? (targetProd.titleKm || targetProd.titleEn) : id;

    setDeleteConfirmModal({
      isOpen: true,
      title: adminLang === "km"
        ? `បញ្ជាក់ការលុបផលិតផល "${prodTitle}"? (រក្សាទុកក្នុងធុងសម្រាម 7 ថ្ងៃ)`
        : `Confirm delete product "${prodTitle}"? (Kept in Trash for 7 days)`,
      itemTitle: prodTitle,
      itemTypeLabel: adminLang === "km" ? "ផលិតផល (Product)" : "Product",
      warningMessage: adminLang === "km"
        ? "រក្សាទុកក្នុងធុងសម្រាម 7 ថ្ងៃ (Kept in Trash for 7 days) អាចស្តារឡើងវិញបានគ្រប់ពេល និងមានប៊ូតុង Undo 5 វិនាទីភ្លាមៗ។"
        : "Kept in Trash for 7 days with instant 5-second undo and full restore capability.",
      isPermanent: false,
      onConfirm: async () => {
        try {
          let trashId = "";
          if (targetProd) {
            const trashRes = await fetch("/api/admin/trash", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                action: "move",
                itemType: "product",
                originalId: id,
                title: prodTitle,
                data: targetProd,
              }),
            });
            if (trashRes.ok) {
              const tData = await trashRes.json();
              trashId = tData.trashId;
              loadTrashItems();
            }
          }

          const res = await fetch(`/api/admin/products?id=${id}`, { method: "DELETE" });
          if (res.ok) {
            broadcastCmsUpdate("products");
            setProducts((prev) => prev.filter((p) => p.id !== id));

            if (trashId) {
              setUndoToast({
                trashId,
                title: prodTitle,
                itemType: "product",
                secondsRemaining: 5,
                restoreHandler: async () => {
                  await handleRestoreFromTrash(trashId);
                },
              });
            } else {
              showToast("success", adminLang === "km" ? "បានលុបផលិតផលជោគជ័យ!" : "Product deleted!");
            }
          }
        } catch {
          showToast("error", "Error deleting product");
        }
      },
    });
  };

  // Duplicate / Copy Product
  const handleDuplicateProduct = async (prod: ProductItem) => {
    try {
      const duplicated: Omit<ProductItem, "id"> = {
        titleKm: `${prod.titleKm} (ចម្លង)`,
        titleEn: `${prod.titleEn} (Copy)`,
        category: prod.category,
        categoryLabelKm: prod.categoryLabelKm,
        categoryLabelEn: prod.categoryLabelEn,
        price: prod.price,
        badgeKm: prod.badgeKm,
        badgeEn: prod.badgeEn,
        descKm: prod.descKm,
        descEn: prod.descEn,
        featuresKm: [...(prod.featuresKm || [])],
        featuresEn: [...(prod.featuresEn || [])],
        icon: prod.icon,
        demoUrl: prod.demoUrl,
        isActive: prod.isActive,
        sortOrder: products.length + 1,
        salesCount: prod.salesCount,
        rating: prod.rating,
        ratingCount: prod.ratingCount,
        thumbnailUrl: prod.thumbnailUrl,
        author: prod.author,
        screenshots: prod.screenshots ? [...prod.screenshots] : [],
        techStack: prod.techStack ? [...prod.techStack] : [],
      };

      const res = await fetch("/api/admin/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(duplicated),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        broadcastCmsUpdate("products");
        showToast(
          "success",
          adminLang === "km"
            ? `បានចម្លងផលិតផល "${prod.titleKm}" ដោយជោគជ័យ!`
            : `Product "${prod.titleEn}" duplicated successfully!`
        );
        loadAllData();
      } else {
        showToast("error", data.message || "Failed to duplicate product");
      }
    } catch {
      showToast("error", "Error duplicating product");
    }
  };

  // Delete Order
  const handleDeleteOrder = (id: string) => {
    const targetOrder = orders.find((o) => o.id === id);
    const orderTitle = targetOrder ? `${targetOrder.clientName} (${targetOrder.planName})` : id;

    setDeleteConfirmModal({
      isOpen: true,
      title: adminLang === "km" ? "បញ្ជាក់ការលុបការកុម្ម៉ង់" : "Confirm Delete Order",
      itemTitle: orderTitle,
      itemTypeLabel: adminLang === "km" ? "ការកុម្ម៉ង់ទិញ (Order)" : "Customer Order",
      warningMessage: adminLang === "km" ? "លុបព័ត៌មានការកុម្ម៉ង់នេះចេញពីប្រព័ន្ធ" : "Delete this order record from the dashboard.",
      isPermanent: true,
      onConfirm: async () => {
        try {
          const res = await fetch(`/api/orders?id=${id}`, { method: "DELETE" });
          const data = await res.json();
          if (res.ok && data.success) {
            setOrders((prev) => prev.filter((o) => o.id !== id));
            showToast("success", adminLang === "km" ? "បានលុបការកុម្ម៉ង់ជោគជ័យ!" : "Order deleted successfully!");
          } else {
            showToast("error", data.message || "Failed to delete order");
          }
        } catch {
          showToast("error", "Error deleting order");
        }
      },
    });
  };

  // Save / Update Content Section
  const handleSaveSection = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/admin/sections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editingSection),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        broadcastCmsUpdate("sections");
        showToast(
          "success",
          adminLang === "km" ? "ផ្នែកមាតិកាត្រូវបានរក្សាទុក!" : "Content section saved successfully!"
        );
        setIsSectionModalOpen(false);
        loadAllData();
      } else {
        showToast("error", data.message || "Failed to save section");
      }
    } catch {
      showToast("error", "Failed to save section");
    }
  };

  // Delete Content Section
  const handleDeleteSection = (id: string) => {
    const targetSec = sections.find((s) => s.id === id);
    const secTitle = targetSec ? (targetSec.titleKm || targetSec.titleEn) : id;

    setDeleteConfirmModal({
      isOpen: true,
      title: adminLang === "km" ? "បញ្ជាក់ការលុបផ្នែកមាតិកា" : "Confirm Delete Section",
      itemTitle: secTitle,
      itemTypeLabel: adminLang === "km" ? "ផ្នែកមាតិកា (Section)" : "Content Section",
      warningMessage: adminLang === "km" ? "រក្សាទុកក្នុងធុងសម្រាម 7 ថ្ងៃ អាចស្តារឡើងវិញបានគ្រប់ពេល" : "Kept in Trash for 7 days with instant 5-second undo.",
      isPermanent: false,
      onConfirm: async () => {
        try {
          let trashId = "";
          if (targetSec) {
            const trashRes = await fetch("/api/admin/trash", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                action: "move",
                itemType: "section",
                originalId: id,
                title: secTitle,
                data: targetSec,
              }),
            });
            if (trashRes.ok) {
              const tData = await trashRes.json();
              trashId = tData.trashId;
              loadTrashItems();
            }
          }

          const res = await fetch(`/api/admin/sections?id=${id}`, { method: "DELETE" });
          if (res.ok) {
            broadcastCmsUpdate("sections");
            setSections((prev) => prev.filter((s) => s.id !== id));

            if (trashId) {
              setUndoToast({
                trashId,
                title: secTitle,
                itemType: "section",
                secondsRemaining: 5,
                restoreHandler: async () => {
                  await handleRestoreFromTrash(trashId);
                },
              });
            } else {
              showToast("success", adminLang === "km" ? "បានលុបផ្នែកមាតិកាជោគជ័យ!" : "Section deleted!");
            }
          }
        } catch {
          showToast("error", "Error deleting section");
        }
      },
    });
  };


  // Helper to add item into editingSection
  const handleAddSectionItem = () => {
    const newItem: SectionItem = {
      id: `item-${Date.now()}`,
      titleKm: "ចំណងជើងថ្មី",
      titleEn: "New Feature Item",
      descKm: "ការពិពណ៌នាអំពីមុខងារ ឬសេវាកម្ម",
      descEn: "Description of the feature or benefit",
      icon: "Sparkles",
      badgeKm: "ពិសេស",
      badgeEn: "Featured",
      metric: "",
    };
    setEditingSection((prev) => ({
      ...prev,
      items: [...(prev.items || []), newItem],
    }));
  };

  // Helper to remove item from editingSection
  const handleRemoveSectionItem = (index: number) => {
    setEditingSection((prev) => ({
      ...prev,
      items: (prev.items || []).filter((_, i) => i !== index),
    }));
  };

  // Helper to update item in editingSection
  const handleUpdateSectionItem = (index: number, fields: Partial<SectionItem>) => {
    setEditingSection((prev) => {
      const updated = [...(prev.items || [])];
      updated[index] = { ...updated[index], ...fields };
      return { ...prev, items: updated };
    });
  };

  // Backup & Recovery Handlers
  const handleCreateSnapshot = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCreatingSnapshot(true);
    try {
      const res = await fetch("/api/admin/backup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "create-snapshot",
          tag: snapshotTagInput.trim() || "manual-dashboard",
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setSnapshots(data.snapshots || []);
        setSnapshotTagInput("");
        showToast(
          "success",
          adminLang === "km"
            ? "បានបង្កើត Snapshot រក្សាទុកលើ Server ដោយជោគជ័យ!"
            : "Server snapshot created successfully!"
        );
      } else {
        showToast("error", data.message || "Failed to create snapshot");
      }
    } catch {
      showToast("error", adminLang === "km" ? "បញ្ហាក្នុងការបង្កើត Snapshot" : "Network error");
    } finally {
      setIsCreatingSnapshot(false);
    }
  };

  const handleDownloadSnapshot = (filename: string) => {
    window.open(`/api/admin/backup?action=download&file=${encodeURIComponent(filename)}`, "_blank");
  };

  const handleExportLiveBackup = () => {
    window.open("/api/admin/backup?action=export", "_blank");
    showToast(
      "success",
      adminLang === "km"
        ? "កំពុងទាញយកឯកសារបម្រុងទុក Live Backup JSON..."
        : "Downloading live backup JSON file..."
    );
  };

  const handleDeleteSnapshot = async (filename: string) => {
    if (
      !confirm(
        adminLang === "km"
          ? `តើអ្នកប្រាកដជាចង់លុប Snapshot "${filename}" នេះមែនទេ?`
          : `Are you sure you want to delete snapshot "${filename}"?`
      )
    )
      return;

    try {
      const res = await fetch("/api/admin/backup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "delete-snapshot",
          filename,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setSnapshots(data.snapshots || []);
        showToast(
          "success",
          adminLang === "km" ? "បានលុប Snapshot ដោយជោគជ័យ!" : "Snapshot deleted successfully!"
        );
      } else {
        showToast("error", data.message || "Failed to delete snapshot");
      }
    } catch {
      showToast("error", adminLang === "km" ? "បញ្ហាក្នុងការលុប Snapshot" : "Network error");
    }
  };

  // Media Upload & Storage Handlers
  const handleUploadMediaFile = async (file: File) => {
    if (!file) return;
    setUploadingMedia(true);
    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();

      if (res.ok && data.success) {
        showToast(
          "success",
          adminLang === "km"
            ? `បានផ្ទុកឡើងឯកសារ "${data.file.name}" ដោយជោគជ័យ!`
            : `Uploaded "${data.file.name}" successfully!`
        );
        await loadMediaFiles();
      } else {
        showToast("error", data.message || "Failed to upload file");
      }
    } catch {
      showToast("error", adminLang === "km" ? "បញ្ហាក្នុងការផ្ទុកឡើងឯកសារ" : "Network error during upload");
    } finally {
      setUploadingMedia(false);
    }
  };

  const handleDeleteMediaFile = (filename: string) => {
    const targetFile = mediaFiles.find((f) => f.name === filename);

    setDeleteConfirmModal({
      isOpen: true,
      title: adminLang === "km" ? "បញ្ជាក់ការលុបឯកសារមេឌៀ" : "Confirm Delete Media File",
      itemTitle: filename,
      itemTypeLabel: adminLang === "km" ? "ឯកសារមេឌៀ (Storage File)" : "Storage File",
      warningMessage: adminLang === "km" ? "រក្សាទុកក្នុងធុងសម្រាម 7 ថ្ងៃ អាចស្តារឡើងវិញបានគ្រប់ពេល" : "Kept in Trash for 7 days with instant 5-second undo.",
      isPermanent: false,
      onConfirm: async () => {
        try {
          let trashId = "";
          if (targetFile) {
            const trashRes = await fetch("/api/admin/trash", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                action: "move",
                itemType: "media",
                originalId: filename,
                title: filename,
                data: targetFile,
              }),
            });
            if (trashRes.ok) {
              const tData = await trashRes.json();
              trashId = tData.trashId;
              loadTrashItems();
            }
          }

          const res = await fetch(`/api/admin/upload?file=${encodeURIComponent(filename)}`, {
            method: "DELETE",
          });
          const data = await res.json();
          if (res.ok && data.success) {
            setMediaFiles((prev) => prev.filter((f) => f.name !== filename));

            if (trashId) {
              setUndoToast({
                trashId,
                title: filename,
                itemType: "media",
                secondsRemaining: 5,
                restoreHandler: async () => {
                  await handleRestoreFromTrash(trashId);
                },
              });
            } else {
              showToast(
                "success",
                adminLang === "km" ? "បានលុបឯកសារដោយជោគជ័យ!" : "File deleted successfully!"
              );
            }
          } else {
            showToast("error", data.message || "Failed to delete file");
          }
        } catch {
          showToast("error", "Error deleting file");
        }
      },
    });
  };

  const handleCopyMediaUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedMediaUrl(url);
    setTimeout(() => setCopiedMediaUrl(null), 3000);
    showToast(
      "success",
      adminLang === "km"
        ? `បានចម្លង URL: ${url}`
        : `Copied URL: ${url}`
    );
  };

  const [uploadingDirect, setUploadingDirect] = useState(false);
  const handleDirectUpload = async (e: React.ChangeEvent<HTMLInputElement>, target: "product" | "post" | "logo" | "icon") => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingDirect(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (res.ok && data.success && data.file) {
        const cleanUrl = data.file.url;
        if (target === "product") {
          setEditingProduct((prev) => ({ ...prev, thumbnailUrl: cleanUrl }));
        } else if (target === "post") {
          setEditingPost((prev) => ({ ...prev, image: cleanUrl }));
        } else if (target === "logo") {
          setSettings((prev) => (prev ? { ...prev, siteLogoUrl: cleanUrl } : null));
        } else if (target === "icon") {
          setSettings((prev) => (prev ? { ...prev, siteIconUrl: cleanUrl } : null));
        }
        await loadMediaFiles();
        showToast(
          "success",
          adminLang === "km" ? "បាន Upload រូបភាព និងបំពេញរួចរាល់! សូមចុចរក្សាទុក (Save)" : "Image uploaded! Remember to save settings."
        );
      } else {
        showToast("error", data.message || "Failed to upload file");
      }
    } catch {
      showToast("error", "Upload error");
    } finally {
      setUploadingDirect(false);
      e.target.value = "";
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith(".json")) {
      showToast("error", adminLang === "km" ? "សូមជ្រើសរើសឯកសារ .json" : "Please select a .json file");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (!parsed.data || typeof parsed.data !== "object") {
          showToast(
            "error",
            adminLang === "km"
              ? "ឯកសារ JSON មិនត្រឹមត្រូវតាមទម្រង់ Backup (Missing data structure)"
              : "Invalid backup JSON: Missing data structure"
          );
          return;
        }

        setUploadedBackupData(parsed);
        setUploadedFileName(file.name);
        setRestoreSource("upload");
        setSelectedSnapshotFile(null);
        setSelectiveRestore({
          settings: Boolean(parsed.data.settings),
          products: Boolean(Array.isArray(parsed.data.products) && parsed.data.products.length > 0),
          pricing: Boolean(Array.isArray(parsed.data.pricing) && parsed.data.pricing.length > 0),
          sections: Boolean(Array.isArray(parsed.data.sections) && parsed.data.sections.length > 0),
          posts: Boolean(Array.isArray(parsed.data.posts) && parsed.data.posts.length > 0),
          orders: Boolean(Array.isArray(parsed.data.orders) && parsed.data.orders.length > 0),
          subscribers: Boolean(Array.isArray(parsed.data.subscribers) && parsed.data.subscribers.length > 0),
        });
        setRestoreModalOpen(true);
      } catch {
        showToast(
          "error",
          adminLang === "km" ? "មិនអាចអានឯកសារ JSON បានទេ" : "Could not parse JSON file"
        );
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  const handleOpenRestoreSnapshotModal = async (snapshot: SnapshotItem) => {
    try {
      const res = await fetch(`/api/admin/backup?action=download&file=${encodeURIComponent(snapshot.filename)}`);
      if (res.ok) {
        const data = await res.json();
        setUploadedBackupData(data);
        setUploadedFileName(snapshot.filename);
        setSelectedSnapshotFile(snapshot);
        setRestoreSource("snapshot");
        setSelectiveRestore({
          settings: Boolean(data.data?.settings),
          products: Boolean(Array.isArray(data.data?.products) && data.data?.products.length > 0),
          pricing: Boolean(Array.isArray(data.data?.pricing) && data.data?.pricing.length > 0),
          sections: Boolean(Array.isArray(data.data?.sections) && data.data?.sections.length > 0),
          posts: Boolean(Array.isArray(data.data?.posts) && data.data?.posts.length > 0),
          orders: Boolean(Array.isArray(data.data?.orders) && data.data?.orders.length > 0),
          subscribers: Boolean(Array.isArray(data.data?.subscribers) && data.data?.subscribers.length > 0),
        });
        setRestoreModalOpen(true);
      } else {
        showToast("error", "Could not load snapshot details");
      }
    } catch {
      showToast("error", "Failed to load snapshot details");
    }
  };

  const handleToggleSelectAll = (select: boolean) => {
    setSelectiveRestore({
      settings: select,
      products: select,
      pricing: select,
      sections: select,
      posts: select,
      orders: select,
      subscribers: select,
    });
  };

  const handleExecuteRestore = async () => {
    if (!uploadedBackupData) return;

    const selectedKeys = Object.entries(selectiveRestore)
      .filter(([, v]) => v)
      .map(([k]) => k);

    if (selectedKeys.length === 0) {
      showToast(
        "error",
        adminLang === "km"
          ? "សូមជ្រើសរើសផ្នែកទិន្នន័យយ៉ាងហោចមួយដើម្បីស្តារ!"
          : "Please select at least one data category to restore!"
      );
      return;
    }

    setIsRestoring(true);
    try {
      const payload =
        restoreSource === "snapshot" && selectedSnapshotFile
          ? {
              action: "restore-snapshot",
              filename: selectedSnapshotFile.filename,
              selective: selectedKeys,
            }
          : {
              action: "restore-upload",
              backupData: uploadedBackupData,
              selective: selectedKeys,
            };

      const res = await fetch("/api/admin/backup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setRestoreModalOpen(false);
        setUploadedBackupData(null);
        setSelectedSnapshotFile(null);
        await loadAllData();
        await loadBackups();
        showToast(
          "success",
          adminLang === "km"
            ? "🎉 បានស្តារទិន្នន័យឡើងវិញដោយជោគជ័យ! (Pre-restore snapshot saved)"
            : "🎉 Data restored successfully! (Pre-restore safety snapshot created)"
        );
      } else {
        showToast("error", data.message || "Failed to restore backup");
      }
    } catch {
      showToast("error", adminLang === "km" ? "បញ្ហាក្នុងការស្តារទិន្នន័យ" : "Network error during restore");
    } finally {
      setIsRestoring(false);
    }
  };

  // Security Auth Gate View
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#030a16] text-white flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-[#081326] border border-cyan-500/30 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Language Flag Selector in Login Gate */}
          <div className="flex justify-end mb-4">
            <div className="flex items-center gap-1 bg-slate-900 border border-slate-700 p-1 rounded-full text-xs">
              <button
                type="button"
                onClick={() => setAdminLang("km")}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-full font-bold transition-all ${
                  adminLang === "km" ? "bg-red-600 text-white shadow-sm" : "text-slate-400"
                }`}
              >
                <CambodiaFlag className="w-4 h-3" />
                <span>KH</span>
              </button>
              <button
                type="button"
                onClick={() => setAdminLang("en")}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-full font-bold transition-all ${
                  adminLang === "en" ? "bg-cyan-600 text-white shadow-sm" : "text-slate-400"
                }`}
              >
                <UKFlag className="w-4 h-3" />
                <span>EN</span>
              </button>
            </div>
          </div>

          <div className="text-center space-y-3 mb-8">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-red-600 via-rose-500 to-amber-500 flex items-center justify-center mx-auto shadow-lg">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-black text-white tracking-tight">
              Broteach CMS Security
            </h2>
            <p className="text-xs text-slate-400">
              {adminLang === "km"
                ? "ផ្ទាំងគ្រប់គ្រងមាតិកា និងប្រព័ន្ធសុវត្ថិភាព Admin"
                : "Restricted Admin Authentication Gate"}
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                {adminLang === "km" ? "ពាក្យសម្ងាត់ Admin (Password)" : "Admin Security Password"}
              </label>
              <input
                type="password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="••••••••••••"
                required
                className="w-full px-4 py-3 rounded-xl bg-slate-900/90 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-400"
              />
            </div>

            {authError && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{authError}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={authLoading}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-black text-sm shadow-lg shadow-cyan-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {authLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <Unlock className="w-4 h-4" />
                  <span>{adminLang === "km" ? "ចូលទៅកាន់ផ្ទាំងគ្រប់គ្រង" : "Unlock Admin Dashboard"}</span>
                </>
              )}
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-slate-800 flex justify-between items-center text-xs text-slate-500">
            <Link href="/" className="hover:text-cyan-400 transition-colors flex items-center gap-1">
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{adminLang === "km" ? "ត្រឡប់ទៅទំព័រមុខ" : "Back to Website"}</span>
            </Link>
            <span>v2.5 Full-Stack</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#030a16] text-white flex flex-col selection:bg-cyan-500 selection:text-white">
      {/* Toast Notification */}
      {feedback && (
        <div
          className={`fixed top-4 right-4 z-50 flex items-center gap-2.5 px-5 py-3 rounded-2xl shadow-2xl text-xs font-bold transition-all animate-in slide-in-from-top-4 ${
            feedback.type === "success"
              ? "bg-emerald-950 border border-emerald-500 text-emerald-200"
              : "bg-red-950 border border-red-500 text-red-200"
          }`}
        >
          {feedback.type === "success" ? (
            <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
          )}
          <span>{feedback.msg}</span>
        </div>
      )}

      {/* Admin Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-[#061427]/95 backdrop-blur-xl border-b border-cyan-500/20 px-4 sm:px-8 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/" className="flex items-center gap-2 group">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-red-600 to-amber-500 flex items-center justify-center shadow-md">
                <span className="text-white font-black text-lg">B</span>
              </div>
              <div className="hidden sm:flex flex-col">
                <span className="font-bold text-base text-white tracking-tight leading-none">
                  Broteach CMS
                </span>
                <span className="text-[10px] text-cyan-400 font-semibold tracking-wider uppercase mt-0.5">
                  Control Dashboard
                </span>
              </div>
            </Link>
          </div>

          <div className="flex items-center gap-2 sm:gap-4">
            {/* Language Switcher KH / EN with Real Flags */}
            <div className="flex items-center p-1 rounded-full bg-slate-900 border border-slate-700">
              <button
                type="button"
                onClick={() => setAdminLang("km")}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all ${
                  adminLang === "km"
                    ? "bg-red-600 text-white shadow-sm"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <CambodiaFlag className="w-4 h-3" />
                <span>KH</span>
              </button>
              <button
                type="button"
                onClick={() => setAdminLang("en")}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all ${
                  adminLang === "en"
                    ? "bg-cyan-600 text-white shadow-sm"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <UKFlag className="w-4 h-3" />
                <span>EN</span>
              </button>
            </div>

            <Link
              href="/"
              target="_blank"
              className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700 text-xs font-semibold text-slate-300 hover:text-white hover:border-cyan-500/40 transition-colors"
            >
              <Eye className="w-3.5 h-3.5 text-cyan-400" />
              <span>{adminLang === "km" ? "មើលគេហទំព័រ" : "Live View"}</span>
            </Link>

            {/* Quick Header Short-cut: Backups */}
            <button
              type="button"
              onClick={() => {
                setActiveTab("backup");
                loadBackups();
              }}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-900/60 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm"
              title="Quick Jump to Backups"
            >
              <Database className="w-3.5 h-3.5 text-cyan-400" />
              <span>{adminLang === "km" ? "បម្រុងទុក" : "Backups"}</span>
              {snapshots.length > 0 && (
                <span className="px-1.5 py-0.5 rounded-full bg-cyan-900 text-[10px] text-cyan-200 font-mono">
                  {snapshots.length}
                </span>
              )}
            </button>

            {/* Quick Header Short-cut: Storage */}
            <button
              type="button"
              onClick={() => {
                setActiveTab("storage");
                loadMediaFiles();
              }}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-950/60 border border-purple-500/40 text-purple-300 hover:bg-purple-900/60 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm"
              title="Quick Jump to Storage"
            >
              <FolderOpen className="w-3.5 h-3.5 text-purple-400" />
              <span>{adminLang === "km" ? "ផ្ទុកឯកសារ" : "Storage"}</span>
              {mediaFiles.length > 0 && (
                <span className="px-1.5 py-0.5 rounded-full bg-purple-900 text-[10px] text-purple-200 font-mono">
                  {mediaFiles.length}
                </span>
              )}
            </button>

            <button
              onClick={loadAllData}
              disabled={loadingData}
              className="p-2 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-white transition-colors"
              title="Refresh Data"
            >
              <RefreshCw className={`w-4 h-4 ${loadingData ? "animate-spin text-cyan-400" : ""}`} />
            </button>

            <button
              onClick={handleLogout}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-950/40 border border-red-500/40 text-red-300 hover:bg-red-900/50 hover:text-white text-xs font-bold transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{adminLang === "km" ? "ចាកចេញ" : "Logout"}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container with Vertical Sidebar "ជាជួរឈ" */}
      <div className="flex-1 flex flex-col md:flex-row min-h-[calc(100vh-64px)]">
        {/* Mobile Subheader Toggle */}
        <div className="md:hidden flex items-center justify-between px-4 py-3 bg-[#040e1d] border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">{adminLang === "km" ? "ម៉ឺនុយ:" : "Menu:"}</span>
            <span className="text-xs font-bold text-cyan-400 capitalize">{activeTab}</span>
          </div>
          <button
            type="button"
            onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700 transition-colors"
          >
            <Menu className="w-4 h-4 text-cyan-400" />
            <span>{adminLang === "km" ? "មើលម៉ឺនុយទាំងអស់" : "Toggle Menu"}</span>
          </button>
        </div>

        {/* Vertical Column Sidebar ("ជាជួរឈ") */}
        <aside
          className={`${
            mobileSidebarOpen ? "block" : "hidden"
          } md:block w-full md:w-64 shrink-0 bg-[#040e1d] border-r border-slate-800/80 p-3 sm:p-4 space-y-6 md:sticky md:top-16 md:h-[calc(100vh-64px)] md:overflow-y-auto`}
        >
          {/* GROUP 1: OVERVIEW & METRICS */}
          <div>
            <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 px-3 mb-2">
              {adminLang === "km" ? "ផ្ទាំងសង្ខេប & ការវិភាគ" : "Overview & Metrics"}
            </div>
            <div className="space-y-1">
              <button
                type="button"
                onClick={() => {
                  setActiveTab("overview");
                  setMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === "overview"
                    ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30 font-black"
                    : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <LayoutGrid className="w-4 h-4 text-cyan-400" />
                  <span>{adminLang === "km" ? "ផ្ទាំងសង្ខេប" : "Overview"}</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab("orders");
                  setMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === "orders"
                    ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30 font-black"
                    : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <ShoppingCart className="w-4 h-4 text-emerald-400" />
                  <span>{adminLang === "km" ? "ការកុម្ម៉ង់" : "Orders"}</span>
                </div>
                {orders.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold">
                    {orders.length}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab("subscribers");
                  setMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === "subscribers"
                    ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30 font-black"
                    : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Users className="w-4 h-4 text-cyan-400" />
                  <span>{adminLang === "km" ? "អ្នកជាវព័ត៌មាន" : "Subscribers"}</span>
                </div>
                {subscribers.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-slate-800 text-cyan-300 text-[10px] font-mono">
                    {subscribers.length}
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* GROUP 2: CONTENT & STORE */}
          <div>
            <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 px-3 mb-2">
              {adminLang === "km" ? "គ្រប់គ្រងមាតិកា & ផលិតផល" : "Content & Catalog"}
            </div>
            <div className="space-y-1">
              <button
                type="button"
                onClick={() => {
                  setActiveTab("posts");
                  setMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === "posts"
                    ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30 font-black"
                    : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <BookOpen className="w-4 h-4 text-cyan-400" />
                  <span>{adminLang === "km" ? "អត្ថបទ & Blog" : "Blog & Articles"}</span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-slate-800 text-cyan-300 text-[10px] font-mono">
                  {posts.length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab("products");
                  setMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === "products"
                    ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30 font-black"
                    : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Package className="w-4 h-4 text-blue-400" />
                  <span>{adminLang === "km" ? "ផលិតផលគេហទំព័រ" : "Products"}</span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-slate-800 text-cyan-300 text-[10px] font-mono">
                  {products.length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab("homelayout");
                  setMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === "homelayout"
                    ? "bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-600/30 font-black"
                    : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <LayoutGrid className="w-4 h-4 text-emerald-400" />
                  <span>{adminLang === "km" ? "ទម្រង់ទំព័រដើម (Layout)" : "Home Layout"}</span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 text-[10px] font-mono border border-emerald-500/30">
                  Reorder
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab("sections");
                  setMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === "sections"
                    ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30 font-black"
                    : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Layers className="w-4 h-4 text-amber-400" />
                  <span>{adminLang === "km" ? "ផ្នែកទំព័រដើម" : "Home Sections"}</span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-slate-800 text-cyan-300 text-[10px] font-mono">
                  {sections.length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab("pricing");
                  setMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === "pricing"
                    ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30 font-black"
                    : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Sparkles className="w-4 h-4 text-yellow-400" />
                  <span>{adminLang === "km" ? "កញ្ចប់តម្លៃ" : "Pricing Plans"}</span>
                </div>
              </button>
            </div>
          </div>

          {/* GROUP 3: ADS & EVENTS (NEW!) */}
          <div>
            <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 px-3 mb-2">
              {adminLang === "km" ? "ការផ្សាយ & ព្រឹត្តិការណ៍" : "Marketing & Ads"}
            </div>
            <div className="space-y-1">
              <button
                type="button"
                onClick={() => {
                  setActiveTab("ads");
                  setMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === "ads"
                    ? "bg-gradient-to-r from-red-600 to-rose-600 text-white shadow-md shadow-red-600/30 font-black"
                    : "text-rose-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Megaphone className="w-4 h-4 text-rose-400" />
                  <span>{adminLang === "km" ? "ផ្សាយពាណិជ្ជកម្ម & Popup" : "Header Ads & Popup"}</span>
                </div>
                <span className="w-2 h-2 rounded-full bg-rose-400 animate-ping" />
              </button>
            </div>
          </div>

          {/* GROUP 4: STORAGE & SAFETY */}
          <div>
            <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 px-3 mb-2">
              {adminLang === "km" ? "ទិន្នន័យ & កន្លែងផ្ទុក" : "Storage & Retention"}
            </div>
            <div className="space-y-1">
              <button
                type="button"
                onClick={() => {
                  setActiveTab("storage");
                  loadMediaFiles();
                  setMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === "storage"
                    ? "bg-purple-600 text-white shadow-md shadow-purple-600/30 font-black"
                    : "text-purple-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <FolderOpen className="w-4 h-4 text-purple-400" />
                  <span>{adminLang === "km" ? "កន្លែងផ្ទុកឯកសារ" : "Media Storage"}</span>
                </div>
                {mediaFiles.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-slate-800 text-purple-300 text-[10px] font-mono">
                    {mediaFiles.length}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab("backup");
                  loadBackups();
                  setMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === "backup"
                    ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30 font-black"
                    : "text-cyan-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Database className="w-4 h-4 text-cyan-400" />
                  <span>{adminLang === "km" ? "បម្រុងទុក & ស្តារ" : "Backup & Restore"}</span>
                </div>
                {snapshots.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-slate-800 text-cyan-300 text-[10px] font-mono">
                    {snapshots.length}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab("trash");
                  loadTrashItems();
                  setMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === "trash"
                    ? "bg-amber-600 text-white shadow-md shadow-amber-600/30 font-black"
                    : "text-amber-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Trash className="w-4 h-4 text-amber-400" />
                  <span>{adminLang === "km" ? "ធុងសម្រាម (៧ ថ្ងៃ)" : "Trash (7-Day)"}</span>
                </div>
                {trashItems.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-mono font-bold">
                    {trashItems.length}
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* GROUP 5: SYSTEM & SETTINGS */}
          <div>
            <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 px-3 mb-2">
              {adminLang === "km" ? "ប្រព័ន្ធ & ការកំណត់" : "Settings & Integrations"}
            </div>
            <div className="space-y-1">
              <button
                type="button"
                onClick={() => {
                  setActiveTab("telegram");
                  setMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === "telegram"
                    ? "bg-sky-600 text-white shadow-md shadow-sky-600/30 font-black"
                    : "text-sky-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Send className="w-4 h-4 text-sky-400" />
                  <span>{adminLang === "km" ? "កំណត់ Telegram Bot" : "Telegram Bot"}</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab("seo");
                  setMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === "seo"
                    ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30 font-black"
                    : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <SearchCheck className="w-4 h-4 text-emerald-400" />
                  <span>{adminLang === "km" ? "SEO & Google Search" : "SEO & Google"}</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab("settings");
                  setMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === "settings"
                    ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30 font-black"
                    : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Settings className="w-4 h-4 text-slate-400" />
                  <span>{adminLang === "km" ? "ការកំណត់គេហទំព័រ" : "Site Settings"}</span>
                </div>
              </button>
            </div>
          </div>
        </aside>

        {/* Main Content Body */}
        <main className="flex-1 min-w-0 p-4 sm:p-8 overflow-y-auto">
        {/* TAB 1: OVERVIEW */}
        {activeTab === "overview" && (
          <div className="space-y-8">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-black text-white">
                  {adminLang === "km" ? "ផ្ទាំងសង្ខេបប្រព័ន្ធ CMS" : "CMS Overview & Metrics"}
                </h1>
                <p className="text-xs sm:text-sm text-slate-400 mt-1">
                  {adminLang === "km"
                    ? "គ្រប់គ្រងផលិតផល ផ្នែកមាតិកាថ្មីៗ និងការបញ្ជាទិញនៅលើ Broteach"
                    : "Manage productions, dynamic content sections, orders, and site parameters."}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  onClick={() => {
                    setEditingPost({
                      slug: "",
                      titleKm: "",
                      titleEn: "",
                      category: "Web Development",
                      categoryKm: "ការអភិវឌ្ឍគេហទំព័រ",
                      categoryEn: "Web Development",
                      author: "Broteach Team",
                      date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
                      readTime: "5 min",
                      image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1200&q=80",
                      excerptKm: "",
                      excerptEn: "",
                      contentKm: "",
                      contentEn: "",
                      featured: false,
                    });
                    setIsPostModalOpen(true);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-400 hover:to-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
                >
                  <PenSquare className="w-4 h-4" />
                  <span>{adminLang === "km" ? "សរសេរអត្ថបទថ្មី" : "New Article"}</span>
                </button>

                <button
                  onClick={() => {
                    setEditingProduct({
                      titleKm: "",
                      titleEn: "",
                      category: "webapp",
                      categoryLabelKm: "គេហទំព័រអាជីវកម្ម",
                      categoryLabelEn: "Web App",
                      price: 350,
                      badgeKm: "ថ្មី",
                      badgeEn: "New",
                      descKm: "",
                      descEn: "",
                      featuresKm: ["រចនាបទ Responsive លើគ្រប់ឧបករណ៍", "ល្បឿនផ្ទុកលឿន", "Free Domain & Hosting 1 ឆ្នាំ"],
                      featuresEn: ["Fully Responsive on all devices", "Fast page loading", "Free Domain & Hosting 1 Year"],
                      icon: "Briefcase",
                      demoUrl: "",
                      isActive: true,
                    });
                    setIsProductModalOpen(true);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-cyan-600/30 transition-all cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>{adminLang === "km" ? "បន្ថែមផលិតផលថ្មី" : "Add Production"}</span>
                </button>

                <button
                  onClick={() => {
                    setEditingSection({
                      titleKm: "",
                      titleEn: "",
                      subtitleKm: "",
                      subtitleEn: "",
                      badgeKm: "",
                      badgeEn: "",
                      layoutType: "cards",
                      items: [],
                      isActive: true,
                      sortOrder: sections.length + 1,
                      anchorId: "",
                    });
                    setIsSectionModalOpen(true);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>{adminLang === "km" ? "បន្ថែមផ្នែកមាតិកាថ្មី" : "Add Content Section"}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveTab("backup");
                    loadBackups();
                  }}
                  className="px-4 py-2.5 rounded-xl bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-300 hover:text-white font-bold text-xs flex items-center gap-1.5 shadow-lg transition-all cursor-pointer"
                >
                  <Database className="w-4 h-4 text-cyan-400" />
                  <span>{adminLang === "km" ? "បម្រុងទុក & ស្តារ" : "Backups & Restore"}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveTab("storage");
                    loadMediaFiles();
                  }}
                  className="px-4 py-2.5 rounded-xl bg-purple-950/80 hover:bg-purple-900 border border-purple-500/40 text-purple-300 hover:text-white font-bold text-xs flex items-center gap-1.5 shadow-lg transition-all cursor-pointer"
                >
                  <FolderOpen className="w-4 h-4 text-purple-400" />
                  <span>{adminLang === "km" ? "ផ្ទុកឯកសារ / Media" : "Storage & Media"}</span>
                </button>
              </div>
            </div>

            {/* Quick Stat Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3.5 sm:gap-4">
              {/* Stat 1: Articles */}
              <div 
                onClick={() => setActiveTab("posts")}
                className="p-4 sm:p-5 rounded-2xl bg-[#061528] border border-slate-800 hover:border-emerald-500/50 hover:bg-[#081a32] transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    {adminLang === "km" ? "អត្ថបទ & មាតិកា" : "Articles / Posts"}
                  </span>
                  <div className="w-8 h-8 rounded-lg bg-emerald-950/80 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <BookOpen className="w-4 h-4" />
                  </div>
                </div>
                <p className="text-2xl sm:text-3xl font-black text-emerald-400">{posts.length}</p>
                <p className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
                  <span>{posts.filter(p => p.featured).length} {adminLang === "km" ? "ពិសេស" : "Featured"}</span>
                  <span className="text-emerald-400 group-hover:translate-x-1 transition-transform">&rarr;</span>
                </p>
              </div>

              {/* Stat 2: Productions */}
              <div 
                onClick={() => setActiveTab("products")}
                className="p-4 sm:p-5 rounded-2xl bg-[#061528] border border-slate-800 hover:border-cyan-500/50 hover:bg-[#081a32] transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    {adminLang === "km" ? "ផលិតផលសរុប" : "Total Productions"}
                  </span>
                  <div className="w-8 h-8 rounded-lg bg-cyan-950/80 text-cyan-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Package className="w-4 h-4" />
                  </div>
                </div>
                <p className="text-2xl sm:text-3xl font-black text-cyan-400">{products.length}</p>
                <p className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
                  <span>{products.filter((p) => p.isActive).length} {adminLang === "km" ? "កំពុងដំណើរការ" : "Active"}</span>
                  <span className="text-cyan-400 group-hover:translate-x-1 transition-transform">&rarr;</span>
                </p>
              </div>

              {/* Stat 3: Sections */}
              <div 
                onClick={() => setActiveTab("sections")}
                className="p-4 sm:p-5 rounded-2xl bg-[#061528] border border-slate-800 hover:border-indigo-500/50 hover:bg-[#081a32] transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    {adminLang === "km" ? "ផ្នែកមាតិកាសរុប" : "Content Sections"}
                  </span>
                  <div className="w-8 h-8 rounded-lg bg-indigo-950/80 text-indigo-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Layers className="w-4 h-4" />
                  </div>
                </div>
                <p className="text-2xl sm:text-3xl font-black text-indigo-400">{sections.length}</p>
                <p className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
                  <span>{sections.filter((s) => s.isActive).length} {adminLang === "km" ? "បង្ហាញលើទំព័រមុខ" : "Visible"}</span>
                  <span className="text-indigo-400 group-hover:translate-x-1 transition-transform">&rarr;</span>
                </p>
              </div>

              {/* Stat 4: Orders */}
              <div 
                onClick={() => setActiveTab("orders")}
                className="p-4 sm:p-5 rounded-2xl bg-[#061528] border border-slate-800 hover:border-rose-500/50 hover:bg-[#081a32] transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    {adminLang === "km" ? "ការកុម្ម៉ង់ទិញ" : "Customer Orders"}
                  </span>
                  <div className="w-8 h-8 rounded-lg bg-rose-950/80 text-rose-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <ShoppingCart className="w-4 h-4" />
                  </div>
                </div>
                <p className="text-2xl sm:text-3xl font-black text-rose-400">{orders.length}</p>
                <p className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
                  <span>{orders.filter((o) => o.status === "pending").length} {adminLang === "km" ? "រង់ចាំពិនិត្យ" : "Pending"}</span>
                  <span className="text-rose-400 group-hover:translate-x-1 transition-transform">&rarr;</span>
                </p>
              </div>

              {/* Stat 5: Subscribers */}
              <div 
                onClick={() => setActiveTab("subscribers")}
                className="p-4 sm:p-5 rounded-2xl bg-[#061528] border border-slate-800 hover:border-amber-500/50 hover:bg-[#081a32] transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    {adminLang === "km" ? "អ្នកជាវ Newsletter" : "Subscribers"}
                  </span>
                  <div className="w-8 h-8 rounded-lg bg-amber-950/80 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Users className="w-4 h-4" />
                  </div>
                </div>
                <p className="text-2xl sm:text-3xl font-black text-amber-400">{subscribers.length}</p>
                <p className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
                  <span>{adminLang === "km" ? "អតិថិជនបានចុះឈ្មោះ" : "Registered leads"}</span>
                  <span className="text-amber-400 group-hover:translate-x-1 transition-transform">&rarr;</span>
                </p>
              </div>

              {/* Stat 6: Backup & Recovery */}
              <div 
                onClick={() => {
                  setActiveTab("backup");
                  loadBackups();
                }}
                className="p-4 sm:p-5 rounded-2xl bg-[#061528] border border-slate-800 hover:border-cyan-500/50 hover:bg-[#081a32] transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    {adminLang === "km" ? "បម្រុងទុកទិន្នន័យ" : "Backups"}
                  </span>
                  <div className="w-8 h-8 rounded-lg bg-cyan-950/80 text-cyan-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Database className="w-4 h-4" />
                  </div>
                </div>
                <p className="text-2xl sm:text-3xl font-black text-cyan-400">{snapshots.length}</p>
                <p className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
                  <span>{adminLang === "km" ? "Server Snapshots" : "Snapshots"}</span>
                  <span className="text-cyan-400 group-hover:translate-x-1 transition-transform">&rarr;</span>
                </p>
              </div>

              {/* Stat 7: Storage & Media */}
              <div 
                onClick={() => {
                  setActiveTab("storage");
                  loadMediaFiles();
                }}
                className="p-4 sm:p-5 rounded-2xl bg-[#061528] border border-slate-800 hover:border-purple-500/50 hover:bg-[#081a32] transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    {adminLang === "km" ? "ផ្ទុកឯកសារ" : "Storage"}
                  </span>
                  <div className="w-8 h-8 rounded-lg bg-purple-950/80 text-purple-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <FolderOpen className="w-4 h-4" />
                  </div>
                </div>
                <p className="text-2xl sm:text-3xl font-black text-purple-400">{mediaFiles.length}</p>
                <p className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
                  <span>{adminLang === "km" ? "Files & Media" : "Uploaded"}</span>
                  <span className="text-purple-400 group-hover:translate-x-1 transition-transform">&rarr;</span>
                </p>
              </div>
            </div>

            {/* SEO & Search Indexing Health Bar */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-[#061830] via-[#041426] to-[#020b17] border border-cyan-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
              <div className="flex items-center gap-3.5">
                <div className="w-11 h-11 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shrink-0 shadow-md">
                  <SearchCheck className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-white">
                      {adminLang === "km" ? "ស្ថានភាព SEO & Google Indexing Readiness" : "SEO Health & Search Engine Readiness"}
                    </h3>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                      settings?.googleConsoleVerification ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40" : "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                    }`}>
                      {settings?.googleConsoleVerification ? "Connected" : "Action Needed"}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    {adminLang === "km"
                      ? "Meta Tags, Google Search Console Token, Canonical URLs, និង Sitemap.xml បានត្រៀមរួចរាល់"
                      : "Meta titles, Google Search Console token, and sitemap.xml canonical endpoints."}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2.5 shrink-0 self-end md:self-auto">
                <a
                  href="/sitemap.xml"
                  target="_blank"
                  className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-[11px] font-bold text-slate-300 hover:text-white transition-colors flex items-center gap-1"
                >
                  <span>sitemap.xml</span>
                  <ExternalLink className="w-3 h-3 text-cyan-400" />
                </a>
                <button
                  onClick={() => setActiveTab("seo")}
                  className="px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
                >
                  <span>{adminLang === "km" ? "ពិនិត្យមើល SEO" : "Open SEO Hub"}</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Quick Actions & Recent Content (3-column layout) */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Recent Articles */}
              <div className="p-6 rounded-2xl bg-[#061528] border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-emerald-400" />
                    <span>{adminLang === "km" ? "អត្ថបទថ្មីៗ" : "Recent Articles"}</span>
                  </h3>
                  <button
                    onClick={() => setActiveTab("posts")}
                    className="text-xs text-emerald-400 hover:underline"
                  >
                    {adminLang === "km" ? "គ្រប់គ្រង" : "Manage"} &rarr;
                  </button>
                </div>

                <div className="space-y-2.5">
                  {posts.slice(0, 4).map((p) => (
                    <div
                      key={p.slug}
                      className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        {p.image ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={p.image}
                            alt=""
                            className="w-9 h-9 rounded-lg object-cover shrink-0 border border-slate-700"
                          />
                        ) : (
                          <div className="w-9 h-9 rounded-lg bg-emerald-950 flex items-center justify-center text-emerald-400 shrink-0">
                            <BookOpen className="w-4 h-4" />
                          </div>
                        )}
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-white truncate">{p.titleKm || p.titleEn}</p>
                          <p className="text-[10px] text-slate-400">{p.date}</p>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 font-semibold">
                          {p.category}
                        </span>
                      </div>
                    </div>
                  ))}
                  {posts.length === 0 && (
                    <p className="text-xs text-slate-500 py-3 text-center">
                      {adminLang === "km" ? "មិនទាន់មានអត្ថបទទេ" : "No articles yet."}
                    </p>
                  )}
                </div>
              </div>

              {/* Recent Productions */}
              <div className="p-6 rounded-2xl bg-[#061528] border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Package className="w-4 h-4 text-cyan-400" />
                    <span>{adminLang === "km" ? "ផលិតផលថ្មីៗ" : "Recent Productions"}</span>
                  </h3>
                  <button
                    onClick={() => setActiveTab("products")}
                    className="text-xs text-cyan-400 hover:underline"
                  >
                    {adminLang === "km" ? "មើលទាំងអស់" : "View All"} &rarr;
                  </button>
                </div>

                <div className="space-y-2.5">
                  {products.slice(0, 4).map((p) => (
                    <div
                      key={p.id}
                      className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-cyan-400 shrink-0">
                          <Package className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-white truncate">{p.titleKm}</p>
                          <p className="text-[11px] text-slate-400 truncate">{p.titleEn}</p>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-sm font-black text-cyan-400">${p.price}</span>
                        <p className="text-[10px] text-emerald-400">{p.category}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Dynamic Content Sections Preview */}
              <div className="p-6 rounded-2xl bg-[#061528] border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Layers className="w-4 h-4 text-indigo-400" />
                    <span>{adminLang === "km" ? "ផ្នែកមាតិកាសកម្ម" : "Active Dynamic Sections"}</span>
                  </h3>
                  <button
                    onClick={() => setActiveTab("sections")}
                    className="text-xs text-indigo-400 hover:underline"
                  >
                    {adminLang === "km" ? "គ្រប់គ្រងផ្នែក" : "Manage Sections"} &rarr;
                  </button>
                </div>

                <div className="space-y-2.5">
                  {sections.slice(0, 4).map((s) => (
                    <div
                      key={s.id}
                      className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-xs font-bold text-white truncate">{s.titleKm}</p>
                          <span className="px-2 py-0.5 rounded-full text-[10px] bg-indigo-950 text-indigo-300 font-semibold uppercase shrink-0">
                            {s.layoutType}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 truncate">{s.titleEn}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-xs font-bold text-cyan-400">
                          {s.items?.length || 0} {adminLang === "km" ? "ធាតុ" : "items"}
                        </span>
                        <p className="text-[10px] text-slate-500">#{s.anchorId || s.id}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 1.5: BLOG POSTS & ARTICLES CMS */}
        {activeTab === "posts" && (
          <div className="space-y-6">
            {/* Posts Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl sm:text-2xl font-black text-white">
                    {adminLang === "km" ? "គ្រប់គ្រងអត្ថបទ & មាតិកា" : "Articles & Blog Posts CMS"}
                  </h2>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-xs font-bold">
                    {posts.length} {adminLang === "km" ? "អត្ថបទ" : "Articles"}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  {adminLang === "km"
                    ? "សរសេរ បង្ហោះ និងកែសម្រួលអត្ថបទបច្ចេកវិទ្យាដែលបង្ហាញលើទំព័រ /blog និង Google Search"
                    : "Publish, edit, and optimize tech articles displayed at /blog with SEO meta tags."}
                </p>
              </div>

              <div className="flex items-center gap-2.5">
                <Link
                  href="/blog"
                  target="_blank"
                  className="px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white hover:border-cyan-500/40 text-xs font-bold transition-all flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{adminLang === "km" ? "មើលទំព័រ Blog" : "Live Blog"}</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </Link>

                <button
                  onClick={() => {
                    setEditingPost({
                      slug: "",
                      titleKm: "",
                      titleEn: "",
                      category: "Web Development",
                      categoryKm: "ការអភិវឌ្ឍគេហទំព័រ",
                      categoryEn: "Web Development",
                      author: "Broteach Team",
                      date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
                      readTime: "5 min",
                      image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1200&q=80",
                      excerptKm: "",
                      excerptEn: "",
                      contentKm: "",
                      contentEn: "",
                      featured: false,
                    });
                    setIsPostModalOpen(true);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-400 hover:to-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>{adminLang === "km" ? "សរសេរអត្ថបទថ្មី" : "New Article"}</span>
                </button>
              </div>
            </div>

            {/* Filter & Search Toolbar */}
            <div className="p-4 rounded-2xl bg-[#061528] border border-slate-800 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder={adminLang === "km" ? "ស្វែងរកអត្ថបទតាមចំណងជើង, slug, ប្រភេទ..." : "Search articles by title, slug, category..."}
                  value={postSearch}
                  onChange={(e) => setPostSearch(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
                />
                {postSearch && (
                  <button
                    onClick={() => setPostSearch("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Category Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
                {["all", "Web Development", "Cloud & Hosting", "Tech & AI", "Cybersecurity", "Guides"].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setPostCategoryFilter(cat)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                      postCategoryFilter === cat
                        ? "bg-emerald-600 text-white shadow-sm"
                        : "bg-slate-900/80 border border-slate-700/60 text-slate-400 hover:text-white hover:border-slate-600"
                    }`}
                  >
                    {cat === "all" ? (adminLang === "km" ? "ទាំងអស់" : "All") : cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Posts Grid / Table */}
            {(() => {
              const filteredPosts = posts.filter((p) => {
                const matchSearch =
                  !postSearch ||
                  (p.titleKm || "").toLowerCase().includes(postSearch.toLowerCase()) ||
                  (p.titleEn || "").toLowerCase().includes(postSearch.toLowerCase()) ||
                  (p.slug || "").toLowerCase().includes(postSearch.toLowerCase()) ||
                  (p.category || "").toLowerCase().includes(postSearch.toLowerCase());
                const matchCat =
                  postCategoryFilter === "all" ||
                  (p.category || "").toLowerCase() === postCategoryFilter.toLowerCase();
                return matchSearch && matchCat;
              });
              const pagedPosts = filteredPosts.slice((postsPage - 1) * 6, postsPage * 6);

              return (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                    {pagedPosts.map((post) => (
                      <div
                        key={post.slug}
                        className="p-5 rounded-2xl bg-[#061528] border border-slate-800 hover:border-emerald-500/40 hover:bg-[#07192f] transition-all flex flex-col justify-between group shadow-lg"
                      >
                        <div className="space-y-3">
                          {/* Image Thumbnail & Badges */}
                          <div className="relative w-full h-40 rounded-xl overflow-hidden bg-slate-900 border border-slate-800">
                            {post.image ? (
                              // eslint-disable-next-line @next/next/no-img-element
                              <img
                                src={post.image}
                                alt=""
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center bg-slate-900 text-slate-600">
                                <ImageIcon className="w-8 h-8" />
                              </div>
                            )}
                            <div className="absolute top-2 left-2 flex items-center gap-1.5">
                              <span className="px-2 py-0.5 rounded-md bg-black/75 backdrop-blur-md text-[10px] font-bold text-emerald-300 border border-emerald-500/30 uppercase">
                                {post.category}
                              </span>
                              {post.featured && (
                                <span className="px-2 py-0.5 rounded-md bg-amber-500/90 text-white text-[10px] font-black uppercase shadow-sm">
                                  Featured
                                </span>
                              )}
                            </div>
                            <div className="absolute bottom-2 right-2">
                              <span className="px-2 py-0.5 rounded-md bg-black/75 backdrop-blur-md text-[10px] text-slate-300">
                                {post.readTime}
                              </span>
                            </div>
                          </div>

                          {/* Title & Slug */}
                          <div>
                            <h3 className="text-sm font-bold text-white line-clamp-1 group-hover:text-emerald-300 transition-colors">
                              {adminLang === "km" ? post.titleKm || post.titleEn : post.titleEn || post.titleKm}
                            </h3>
                            <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                              {adminLang === "km" ? post.titleEn : post.titleKm}
                            </p>
                            <p className="text-[10px] text-cyan-400/80 font-mono mt-1 truncate">
                              /blog/{post.slug}
                            </p>
                          </div>

                          {/* Excerpt */}
                          <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                            {adminLang === "km" ? post.excerptKm || post.excerptEn : post.excerptEn || post.excerptKm}
                          </p>

                          {/* Meta Info */}
                          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
                            <span>{post.author || "Broteach"}</span>
                            <span>{post.date}</span>
                          </div>
                        </div>

                        {/* Actions Toolbar */}
                        <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between gap-1.5">
                          <Link
                            href={`/blog/${post.slug}`}
                            target="_blank"
                            className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700/80 hover:border-cyan-500/40 text-slate-300 hover:text-white text-xs flex items-center gap-1 transition-colors"
                            title={adminLang === "km" ? "មើលផ្ទាល់" : "View Live"}
                          >
                            <ExternalLink className="w-3 h-3 text-cyan-400" />
                            <span className="text-[10px] font-semibold">{adminLang === "km" ? "មើល" : "View"}</span>
                          </Link>

                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleDuplicatePost(post)}
                              className="p-1.5 rounded-lg bg-slate-900 border border-slate-700/80 hover:border-slate-500 text-slate-300 hover:text-white transition-colors cursor-pointer"
                              title={adminLang === "km" ? "ចម្លងអត្ថបទ" : "Duplicate"}
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                setEditingPost(post);
                                setIsPostModalOpen(true);
                              }}
                              className="px-2.5 py-1.5 rounded-lg bg-cyan-600/20 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-600 hover:text-white text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                            >
                              <Edit className="w-3 h-3" />
                              <span className="text-[10px]">{adminLang === "km" ? "កែសម្រួល" : "Edit"}</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => handleDeletePost(post.slug)}
                              className="p-1.5 rounded-lg bg-red-950/40 border border-red-500/40 text-red-300 hover:bg-red-900/60 hover:text-white transition-colors cursor-pointer"
                              title={adminLang === "km" ? "លុប" : "Delete"}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  {renderPagination(postsPage, filteredPosts.length, 6, setPostsPage)}
                </div>
              );
            })()}

            {/* Empty state */}
            {posts.length === 0 && (
              <div className="p-12 text-center rounded-2xl bg-[#061528] border border-slate-800 space-y-3">
                <BookOpen className="w-10 h-10 text-slate-600 mx-auto" />
                <h3 className="text-base font-bold text-white">
                  {adminLang === "km" ? "មិនទាន់មានអត្ថបទនៅឡើយទេ" : "No articles published yet"}
                </h3>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  {adminLang === "km"
                    ? "ចុចប៊ូតុងខាងក្រោមដើម្បីចាប់ផ្តើមសរសេរអត្ថបទទី ១ របស់អ្នកនៅលើ Broteach Blog"
                    : "Create your first knowledge base article or company update to share with your audience."}
                </p>
                <button
                  onClick={() => {
                    setEditingPost({
                      slug: "",
                      titleKm: "",
                      titleEn: "",
                      category: "Web Development",
                      categoryKm: "ការអភិវឌ្ឍគេហទំព័រ",
                      categoryEn: "Web Development",
                      author: "Broteach Team",
                      date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
                      readTime: "5 min",
                      image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1200&q=80",
                      excerptKm: "",
                      excerptEn: "",
                      contentKm: "",
                      contentEn: "",
                      featured: false,
                    });
                    setIsPostModalOpen(true);
                  }}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold inline-flex items-center gap-1.5 shadow-md cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>{adminLang === "km" ? "សរសេរអត្ថបទដំបូង" : "Write First Article"}</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: PRODUCTS / PRODUCTIONS CMS */}
        {activeTab === "products" && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-white">
                  {adminLang === "km" ? "គ្រប់គ្រងផលិតផល & ដំណោះស្រាយ" : "Productions & Solutions CMS"}
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  {adminLang === "km"
                    ? "បន្ថែម កែប្រែ ឬលុបផលិតផលដែលបង្ហាញលើទំព័រដើម និងទំព័រ /products"
                    : "Add, edit, or delete productions displayed on the home page and /products catalog."}
                </p>
              </div>

              <button
                onClick={() => {
                  setEditingProduct({
                    titleKm: "",
                    titleEn: "",
                    category: "webapp",
                    categoryLabelKm: "គេហទំព័រអាជីវកម្ម",
                    categoryLabelEn: "Web App",
                    price: 350,
                    badgeKm: "ថ្មី",
                    badgeEn: "New",
                    descKm: "",
                    descEn: "",
                    featuresKm: ["រចនាបទ Responsive លើគ្រប់ឧបករណ៍", "ល្បឿនផ្ទុកលឿន", "Free Domain & Hosting 1 ឆ្នាំ"],
                    featuresEn: ["Fully Responsive on all devices", "Fast page loading", "Free Domain & Hosting 1 Year"],
                    icon: "Briefcase",
                    demoUrl: "",
                    isActive: true,
                  });
                  setIsProductModalOpen(true);
                }}
                className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-cyan-600/30 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{adminLang === "km" ? "បន្ថែមផលិតផលថ្មី" : "Add Production"}</span>
              </button>
            </div>

            {/* Products Table */}
            <div className="rounded-2xl bg-[#061528] border border-slate-800 overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900/90 text-slate-400 font-semibold border-b border-slate-800">
                    <tr>
                      <th className="p-4">Icon / Title</th>
                      <th className="p-4">Category</th>
                      <th className="p-4">Price</th>
                      <th className="p-4">Badge</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {products
                      .slice((productsPage - 1) * 6, productsPage * 6)
                      .map((prod) => (
                      <tr key={prod.id} className="hover:bg-slate-900/40 transition-colors">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            {prod.thumbnailUrl ? (
                              // eslint-disable-next-line @next/next/no-img-element
                              <img
                                src={prod.thumbnailUrl}
                                alt=""
                                className="w-12 h-9 rounded-lg object-cover border border-slate-700 shrink-0"
                              />
                            ) : (
                              <div className="w-9 h-9 rounded-xl bg-slate-800 flex items-center justify-center text-cyan-400 shrink-0">
                                <Package className="w-4 h-4" />
                              </div>
                            )}
                            <div>
                              <p className="font-bold text-white text-sm">{prod.titleKm}</p>
                              <p className="text-slate-400 text-xs">{prod.titleEn}</p>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-medium">
                            {prod.category}
                          </span>
                        </td>
                        <td className="p-4 font-black text-cyan-400 text-base">
                          ${prod.price}
                        </td>
                        <td className="p-4">
                          {prod.badgeKm ? (
                            <span className="px-2.5 py-0.5 rounded-full bg-red-950 text-red-300 border border-red-500/40 text-[10px] font-bold">
                              {prod.badgeKm}
                            </span>
                          ) : (
                            <span className="text-slate-600">-</span>
                          )}
                        </td>
                        <td className="p-4">
                          <button
                            type="button"
                            onClick={() => handleToggleProductStatus(prod.id, prod.isActive)}
                            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold transition-all cursor-pointer shadow-sm ${
                              prod.isActive
                                ? "bg-emerald-950/90 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-900/60"
                                : "bg-slate-800 text-slate-400 border border-slate-700 hover:bg-slate-700 hover:text-white"
                            }`}
                            title={
                              prod.isActive
                                ? adminLang === "km"
                                  ? "ចុចដើម្បីបិទផលិតផលនេះ"
                                  : "Click to disable product"
                                : adminLang === "km"
                                ? "ចុចដើម្បីបើកផលិតផលនេះ"
                                : "Click to enable product"
                            }
                          >
                            <span
                              className={`w-2 h-2 rounded-full ${
                                prod.isActive ? "bg-emerald-400 animate-pulse" : "bg-slate-500"
                              }`}
                            />
                            <span>
                              {prod.isActive
                                ? adminLang === "km"
                                  ? "បើក (Active)"
                                  : "Active"
                                : adminLang === "km"
                                ? "បិទ (Disabled)"
                                : "Disabled"}
                            </span>
                          </button>
                        </td>
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => handleDuplicateProduct(prod)}
                              className="p-2 rounded-lg bg-cyan-950/40 hover:bg-cyan-900/60 text-cyan-300 hover:text-white transition-colors cursor-pointer"
                              title={adminLang === "km" ? "ចម្លងផលិតផល (Duplicate)" : "Duplicate Product"}
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setEditingProduct({ ...prod });
                                setIsProductModalOpen(true);
                              }}
                              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition-colors cursor-pointer"
                              title="Edit"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteProduct(prod.id)}
                              className="p-2 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-300 hover:text-white transition-colors cursor-pointer"
                              title="Delete"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="p-4 border-t border-slate-800">
                {renderPagination(productsPage, products.length, 6, setProductsPage)}
              </div>
            </div>
          </div>
        )}

        {/* TAB: HOME PAGE LAYOUT & SECTIONS REORDERING (DRAG & DROP / UP & DOWN / HIDE & SHOW) */}
        {activeTab === "homelayout" && settings && (
          <div className="space-y-6 max-w-5xl">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2.5">
                  <LayoutGrid className="w-6 h-6 text-emerald-400" />
                  <span>
                    {adminLang === "km"
                      ? "គ្រប់គ្រងទម្រង់ និងលំដាប់ទំព័រដើម (Home Page Layout)"
                      : "Home Page Layout & Section Ordering"}
                  </span>
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  {adminLang === "km"
                    ? "បើក/បិទ (Hide/Show) ផ្នែកនីមួយៗ និងអូសទម្លាក់ (Drag & Drop) ឬចុចព្រួញឡើងលើ/ចុះក្រោម (Up/Down) ដើម្បីរៀបចំលំដាប់លើទំព័រដើម"
                    : "Enable or disable any section, and drag & drop or use Up/Down arrows to reorder homepage content."}
                </p>
              </div>

              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={handleResetHomeSections}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
                  <span>{adminLang === "km" ? "កំណត់ឡើងវិញ" : "Reset Order"}</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSaveSettings()}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{adminLang === "km" ? "រក្សាទុកទម្រង់ទំព័រដើម" : "Save Home Layout"}</span>
                </button>
              </div>
            </div>

            {/* Layout Cards */}
            <div className="rounded-2xl bg-[#061528] border border-slate-800 p-6 space-y-4 shadow-xl">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  {adminLang === "km" ? "បញ្ជីផ្នែកលើទំព័រដើម (អូសទម្លាក់ ឬចុចព្រួញ)" : "Homepage Sections (Drag to reorder)"}
                </span>
                <span className="text-[11px] text-slate-400">
                  {adminLang === "km"
                    ? `${(settings.homeSections || DEFAULT_HOME_SECTIONS).filter((s) => s.enabled).length} ផ្នែកកំពុងបង្ហាញលើទំព័រដើម`
                    : `${(settings.homeSections || DEFAULT_HOME_SECTIONS).filter((s) => s.enabled).length} sections currently visible`}
                </span>
              </div>

              <div className="space-y-3">
                {[...(settings.homeSections || DEFAULT_HOME_SECTIONS)]
                  .sort((a, b) => a.order - b.order)
                  .map((sec, index, arr) => {
                    const isFirst = index === 0;
                    const isLast = index === arr.length - 1;

                    // Section meta icons and descriptions
                    const metaMap: Record<
                      string,
                      { icon: React.ReactNode; descKm: string; descEn: string; tabTarget: Parameters<typeof setActiveTab>[0] }
                    > = {
                      hero: {
                        icon: <Sparkles className="w-5 h-5 text-amber-400" />,
                        descKm: "ផ្ទាំង Hero ធំ មាន Typing title, server 3D graphic, ប៊ូតុង Telegram CTA និង Stats",
                        descEn: "Hero banner with animated typing title, 3D server graphic, Telegram CTA, and stats",
                        tabTarget: "settings",
                      },
                      products: {
                        icon: <Package className="w-5 h-5 text-cyan-400" />,
                        descKm: "ផលិតផលគុណភាពខ្ពស់ Premium Products (E-Commerce, Web App, VPS, LMS...)",
                        descEn: "Premium Products catalog grid (E-Commerce, Web App, VPS, LMS...)",
                        tabTarget: "products",
                      },
                      pricing: {
                        icon: <ShoppingCart className="w-5 h-5 text-yellow-400" />,
                        descKm: "កញ្ចប់តម្លៃ និងសេវាកម្ម (Starter, Standard, Enterprise)",
                        descEn: "Pricing plans & packages with direct demo and order flow",
                        tabTarget: "pricing",
                      },
                      blog: {
                        icon: <BookOpen className="w-5 h-5 text-indigo-400" />,
                        descKm: "អត្ថបទ និងបច្ចេកវិទ្យាថ្មីៗ (Latest published blog articles & news)",
                        descEn: "Latest published articles and tech updates grid on homepage",
                        tabTarget: "posts",
                      },
                      dynamic_sections: {
                        icon: <Layers className="w-5 h-5 text-purple-400" />,
                        descKm: "ផ្នែកមាតិកា CMS បន្ថែម ដូចជា ហេតុអ្វីជ្រើសរើសយើង (Why Us) និង សំណួរញឹកញាប់ (FAQ)",
                        descEn: "Custom CMS content sections like Why Choose Us, FAQs, and Stats",
                        tabTarget: "sections",
                      },
                      newsletter: {
                        icon: <Send className="w-5 h-5 text-rose-400" />,
                        descKm: "ផ្ទាំងចុះឈ្មោះអ៊ីមែល Newsletter Subscription",
                        descEn: "Newsletter email capture banner",
                        tabTarget: "subscribers",
                      },
                    };

                    const meta = metaMap[sec.id] || {
                      icon: <Layers className="w-5 h-5 text-slate-400" />,
                      descKm: "ផ្នែកមាតិកាគេហទំព័រ",
                      descEn: "Content section",
                      tabTarget: "sections",
                    };

                    return (
                      <div
                        key={sec.id}
                        draggable
                        onDragStart={() => handleDragStart(index)}
                        onDragOver={handleDragOver}
                        onDrop={() => handleDrop(index)}
                        className={`group flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl border transition-all duration-200 cursor-move ${
                          draggedSectionIndex === index
                            ? "opacity-50 border-cyan-400 bg-cyan-950/40"
                            : sec.enabled
                            ? "bg-slate-900/90 border-slate-700/80 hover:border-cyan-500/50 hover:bg-slate-900 shadow-md"
                            : "bg-slate-950/60 border-slate-800/60 opacity-60 hover:opacity-90"
                        }`}
                      >
                        {/* Left: Drag Handle, Order, Icon & Title */}
                        <div className="flex items-center gap-3.5">
                          <div
                            className="p-1.5 rounded-lg text-slate-500 group-hover:text-slate-300 hover:bg-slate-800 cursor-grab active:cursor-grabbing shrink-0"
                            title={adminLang === "km" ? "អូសទម្លាក់ដើម្បីផ្លាស់ប្តូរលំដាប់" : "Drag to reorder"}
                          >
                            <GripVertical className="w-4 h-4" />
                          </div>

                          <div className="w-7 h-7 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-mono font-bold text-slate-300 shrink-0">
                            #{index + 1}
                          </div>

                          <div className="w-10 h-10 rounded-xl bg-slate-800/80 border border-slate-700 flex items-center justify-center shrink-0">
                            {meta.icon}
                          </div>

                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-sm font-bold text-white">
                                {adminLang === "km" ? sec.labelKm : sec.labelEn}
                              </h4>
                              <span
                                className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                                  sec.enabled
                                    ? "bg-emerald-950 text-emerald-300 border border-emerald-500/40"
                                    : "bg-slate-800 text-slate-400 border border-slate-700"
                                }`}
                              >
                                {sec.enabled
                                  ? adminLang === "km"
                                    ? "បង្ហាញលើទំព័រដើម"
                                    : "Active on Home"
                                  : adminLang === "km"
                                  ? "លាក់ (Hidden)"
                                  : "Hidden"}
                              </span>
                            </div>
                            <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">
                              {adminLang === "km" ? meta.descKm : meta.descEn}
                            </p>
                          </div>
                        </div>

                        {/* Right: Controls (Move Up/Down, Enable/Disable Toggle, Configure) */}
                        <div className="flex items-center justify-end gap-2.5 shrink-0 pl-10 sm:pl-0">
                          {/* Up & Down Reorder Buttons */}
                          <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700">
                            <button
                              type="button"
                              disabled={isFirst}
                              onClick={() => handleMoveSection(index, "up")}
                              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                                isFirst
                                  ? "text-slate-600 cursor-not-allowed"
                                  : "text-slate-300 hover:text-white hover:bg-slate-700"
                              }`}
                              title={adminLang === "km" ? "រំកិលឡើងលើ (Move Up)" : "Move Up"}
                            >
                              <ArrowUp className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              disabled={isLast}
                              onClick={() => handleMoveSection(index, "down")}
                              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                                isLast
                                  ? "text-slate-600 cursor-not-allowed"
                                  : "text-slate-300 hover:text-white hover:bg-slate-700"
                              }`}
                              title={adminLang === "km" ? "រំកិលចុះក្រោម (Move Down)" : "Move Down"}
                            >
                              <ArrowDown className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {/* Quick Edit Target */}
                          <button
                            type="button"
                            onClick={() => {
                              setActiveTab(meta.tabTarget);
                              setMobileSidebarOpen(false);
                            }}
                            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1 border border-slate-700 transition-colors cursor-pointer"
                            title="Edit Section Content"
                          >
                            <Edit className="w-3 h-3 text-cyan-400" />
                            <span className="hidden sm:inline">
                              {adminLang === "km" ? "កែប្រែ" : "Manage"}
                            </span>
                          </button>

                          {/* Hide / Show Toggle Button */}
                          <button
                            type="button"
                            onClick={() => handleToggleSectionEnabled(sec.id)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                              sec.enabled
                                ? "bg-emerald-600/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600/30"
                                : "bg-slate-800 text-slate-400 border border-slate-700 hover:bg-slate-700 hover:text-white"
                            }`}
                          >
                            <span
                              className={`w-2 h-2 rounded-full ${
                                sec.enabled ? "bg-emerald-400 animate-pulse" : "bg-slate-500"
                              }`}
                            />
                            <span>
                              {sec.enabled
                                ? adminLang === "km"
                                  ? "បើក (Enabled)"
                                  : "Enabled"
                                : adminLang === "km"
                                ? "បិទ (Disabled)"
                                : "Disabled"}
                            </span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
              </div>

              {/* Bottom Quick Save Bar */}
              <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                <p className="text-xs text-slate-400">
                  {adminLang === "km"
                    ? "💡 គន្លឹះ៖ បន្ទាប់ពីរៀបចំលំដាប់រួចរាល់ សូមចុច «រក្សាទុកទម្រង់ទំព័រដើម» ដើម្បីឱ្យទំព័រដើមធ្វើបច្ចុប្បន្នភាពភ្លាមៗ"
                    : "💡 Tip: After reordering, click 'Save Home Layout' to immediately apply changes to your live homepage."}
                </p>
                <button
                  type="button"
                  onClick={() => handleSaveSettings()}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer shrink-0"
                >
                  <Save className="w-4 h-4" />
                  <span>{adminLang === "km" ? "រក្សាទុកទម្រង់ទំព័រដើម" : "Save Home Layout"}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: DYNAMIC CONTENT SECTIONS CMS (NEW!) */}
        {activeTab === "sections" && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-white">
                  {adminLang === "km" ? "គ្រប់គ្រងផ្នែកមាតិកាគេហទំព័រ (Sections)" : "Content Sections CMS"}
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  {adminLang === "km"
                    ? "បង្កើត ឬកែប្រែផ្នែកមាតិកាណាមួយ (Why Us, FAQ, Stats, Features) ដោយសេរី"
                    : "Add any content section dynamically with custom cards, FAQs, stats, or banners."}
                </p>
              </div>

              <button
                onClick={() => {
                  setEditingSection({
                    titleKm: "",
                    titleEn: "",
                    subtitleKm: "",
                    subtitleEn: "",
                    badgeKm: "",
                    badgeEn: "",
                    layoutType: "cards",
                    items: [],
                    isActive: true,
                    sortOrder: sections.length + 1,
                    anchorId: "",
                  });
                  setIsSectionModalOpen(true);
                }}
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{adminLang === "km" ? "បង្កើតផ្នែកថ្មី (Add Section)" : "Add Section"}</span>
              </button>
            </div>

            {/* Sections Grid */}
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {sections
                  .slice((sectionsPage - 1) * 6, sectionsPage * 6)
                  .map((sec) => (
                  <div
                    key={sec.id}
                    className="rounded-2xl bg-[#061528] border border-slate-800 p-6 space-y-4 hover:border-indigo-500/50 transition-colors shadow-lg relative"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="px-2 py-0.5 rounded-md bg-indigo-950 text-indigo-300 text-[10px] font-bold uppercase tracking-wider">
                            {sec.layoutType}
                          </span>
                          {sec.anchorId && (
                            <span className="text-[10px] text-slate-500">#{sec.anchorId}</span>
                          )}
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                              sec.isActive
                                ? "bg-emerald-950 text-emerald-300"
                                : "bg-slate-800 text-slate-500"
                            }`}
                          >
                            {sec.isActive ? "Active" : "Hidden"}
                          </span>
                        </div>
                        <h3 className="text-base font-bold text-white">{sec.titleKm}</h3>
                        <p className="text-xs text-slate-400">{sec.titleEn}</p>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => {
                            setEditingSection({ ...sec });
                            setIsSectionModalOpen(true);
                          }}
                          className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition-colors cursor-pointer"
                          title="Edit Section"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteSection(sec.id)}
                          className="p-2 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-300 hover:text-white transition-colors cursor-pointer"
                          title="Delete Section"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {sec.subtitleKm && (
                      <p className="text-xs text-slate-400 leading-relaxed border-t border-slate-800/80 pt-3">
                        {sec.subtitleKm}
                      </p>
                    )}

                    {/* 1-Click Approve / Publish Toggle */}
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                      <div className="flex items-center gap-2">
                        {sec.isActive ? (
                          <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-bold">
                            <CheckCircle className="w-4 h-4 text-emerald-400" />
                            <span>{adminLang === "km" ? "បានអនុម័ត (ផ្សាយផ្ទាល់)" : "Approved & Live"}</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1.5 text-xs text-amber-400 font-bold">
                            <AlertCircle className="w-4 h-4 text-amber-400" />
                            <span>{adminLang === "km" ? "រង់ចាំអនុម័ត (ព្រាង)" : "Draft / Hidden"}</span>
                          </div>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={() => handleToggleSectionActive(sec)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                          sec.isActive
                            ? "bg-slate-800 hover:bg-red-950 text-slate-300 hover:text-red-300 border border-slate-700"
                            : "bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/30"
                        }`}
                      >
                        {sec.isActive ? (
                          <>
                            <X className="w-3.5 h-3.5" />
                            <span>{adminLang === "km" ? "ផ្អាកការផ្សាយ" : "Unpublish"}</span>
                          </>
                        ) : (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>{adminLang === "km" ? "អនុម័ត & ផ្សាយ" : "Approve & Publish"}</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Items Preview */}
                    <div className="space-y-1.5 pt-2">
                      <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                        {sec.items?.length || 0} {adminLang === "km" ? "ធាតុខាងក្នុង (Items)" : "Items included"}:
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {sec.items?.map((it, idx) => (
                          <span
                            key={it.id || idx}
                            className="px-2 py-1 rounded-lg bg-slate-900 text-slate-300 text-[11px] border border-slate-800"
                          >
                            {it.titleKm || it.titleEn}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              {renderPagination(sectionsPage, sections.length, 6, setSectionsPage)}
            </div>
          </div>
        )}

        {/* TAB 4: PRICING PLANS */}
        {activeTab === "pricing" && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-white">
                  {adminLang === "km" ? "គ្រប់គ្រងកញ្ចប់តម្លៃសេវាកម្ម" : "Pricing Plans Management"}
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  {adminLang === "km"
                    ? "បន្ថែម កែប្រែ ឬលុបកញ្ចប់តម្លៃ និងកំណត់ Live Demo & Order Telegram URL"
                    : "Add, edit, or delete pricing tiers, customize demo URLs, and telegram ordering links."}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  setEditingPlan({
                    nameKm: "",
                    nameEn: "",
                    badgeKm: "ពេញនិយម",
                    badgeEn: "Popular",
                    price: 49,
                    periodKm: "/ខែ",
                    periodEn: "/month",
                    colorScheme: "red",
                    featuresKm: [
                      "NVMe SSD Storage 20GB",
                      "Free .COM Domain 1 ឆ្នាំ",
                      "SSL Certificate មិនគិតថ្លៃ",
                      "Backup ប្រចាំថ្ងៃស្វ័យប្រវត្តិ",
                      "ជំនួយបច្ចេកទេស 24/7",
                    ],
                    featuresEn: [
                      "20GB NVMe SSD Fast Storage",
                      "Free .COM Domain 1 Year",
                      "Free SSL Certificate",
                      "Automated Daily Backups",
                      "24/7 Technical Support",
                    ],
                    recommended: false,
                    demoUrl: "https://t.me/broteach_support",
                    orderUrl: "https://t.me/broteach_support",
                  });
                  setIsPricingModalOpen(true);
                }}
                className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-cyan-600/30 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{adminLang === "km" ? "បន្ថែមគម្រោងតម្លៃថ្មី" : "Add Pricing Plan"}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {pricing.map((plan) => (
                <div
                  key={plan.id}
                  className="rounded-2xl bg-[#061528] border border-slate-800 p-6 space-y-4 shadow-xl hover:border-cyan-500/40 transition-colors relative flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-1.5 mb-1">
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                              plan.colorScheme === "red"
                                ? "bg-red-950 text-red-300 border border-red-500/40"
                                : "bg-slate-800 text-cyan-300 border border-slate-700"
                            }`}
                          >
                            {plan.colorScheme === "red" ? "Premium Red" : "Silver Plan"}
                          </span>
                          {plan.recommended && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-amber-950 text-amber-300 border border-amber-500/40">
                              ★ Recommended
                            </span>
                          )}
                        </div>
                        <h3 className="font-black text-white text-lg">{plan.nameKm}</h3>
                        <p className="text-xs font-semibold text-cyan-400">{plan.nameEn}</p>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingPlan({ ...plan });
                            setIsPricingModalOpen(true);
                          }}
                          className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition-colors cursor-pointer"
                          title="Edit Full Plan"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeletePricingPlan(plan.id)}
                          className="p-2 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-300 hover:text-white transition-colors cursor-pointer"
                          title="Delete Plan"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-2">
                      <div>
                        <label className="text-[10px] text-slate-400 font-bold uppercase">Price ($)</label>
                        <input
                          type="number"
                          value={plan.price}
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            setPricing((prev) =>
                              prev.map((p) => (p.id === plan.id ? { ...p, price: val } : p))
                            );
                          }}
                          className="w-full mt-1 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-black text-base focus:outline-none focus:border-cyan-400"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 font-bold uppercase">Period (EN)</label>
                        <input
                          type="text"
                          value={plan.periodEn || "/month"}
                          onChange={(e) => {
                            const val = e.target.value;
                            setPricing((prev) =>
                              prev.map((p) => (p.id === plan.id ? { ...p, periodEn: val } : p))
                            );
                          }}
                          className="w-full mt-1 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] text-slate-400 font-bold uppercase">Badge (KM)</label>
                        <input
                          type="text"
                          value={plan.badgeKm || ""}
                          onChange={(e) => {
                            const val = e.target.value;
                            setPricing((prev) =>
                              prev.map((p) => (p.id === plan.id ? { ...p, badgeKm: val } : p))
                            );
                          }}
                          className="w-full mt-1 px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 font-bold uppercase">Badge (EN)</label>
                        <input
                          type="text"
                          value={plan.badgeEn || ""}
                          onChange={(e) => {
                            const val = e.target.value;
                            setPricing((prev) =>
                              prev.map((p) => (p.id === plan.id ? { ...p, badgeEn: val } : p))
                            );
                          }}
                          className="w-full mt-1 px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                        />
                      </div>
                    </div>

                    {/* Features summary */}
                    <div className="pt-2 border-t border-slate-800">
                      <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Features Included ({plan.featuresKm?.length || 0}):
                      </p>
                      <ul className="space-y-1 text-xs text-slate-300">
                        {plan.featuresKm?.slice(0, 3).map((f, idx) => (
                          <li key={idx} className="flex items-center gap-1.5 truncate text-[11px]">
                            <span className="text-emerald-400">✓</span>
                            <span className="truncate">{f}</span>
                          </li>
                        ))}
                        {(plan.featuresKm?.length || 0) > 3 && (
                          <li className="text-[10px] text-cyan-400 font-semibold">
                            + {(plan.featuresKm?.length || 0) - 3} more features...
                          </li>
                        )}
                      </ul>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-800 flex gap-2">
                    <button
                      type="button"
                      onClick={() => handleSavePlan(plan)}
                      className="flex-1 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center justify-center gap-1 shadow-md transition-colors cursor-pointer"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{adminLang === "km" ? "រក្សាទុក" : "Save"}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEditingPlan({ ...plan });
                        setIsPricingModalOpen(true);
                      }}
                      className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
                    >
                      {adminLang === "km" ? "កែប្រែពេញលេញ" : "Full Edit"}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: SEO & GOOGLE SEARCH CONSOLE */}
        {activeTab === "seo" && settings && (
          <form onSubmit={handleSaveSettings} className="space-y-6 max-w-4xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2.5">
                  <SearchCheck className="w-6 h-6 text-cyan-400" />
                  <span>{adminLang === "km" ? "ការកំណត់ SEO & Google Search Console" : "SEO & Google Search Console Hub"}</span>
                </h2>
                <p className="text-xs sm:text-sm text-slate-400 mt-1">
                  {adminLang === "km"
                    ? "គ្រប់គ្រងទិន្នន័យ Meta Tags, Google Search Console Token, និងពិនិត្យមើលរូបរាងលើ Google"
                    : "Optimize meta tags, Google Search Console verification token, and preview live SERP snippets."}
                </p>
              </div>

              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-black text-xs shadow-lg shadow-cyan-600/30 flex items-center gap-2 cursor-pointer self-start sm:self-auto"
              >
                <Save className="w-4 h-4" />
                <span>{adminLang === "km" ? "រក្សាទុកការកំណត់ SEO" : "Save SEO Settings"}</span>
              </button>
            </div>

            {/* Google SERP Live Interactive Mockup Card */}
            <div className="rounded-3xl bg-[#061528] border border-cyan-500/30 p-6 space-y-4 shadow-xl relative overflow-hidden">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center">
                    <Globe className="w-3.5 h-3.5 text-cyan-400" />
                  </div>
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    Google Search Result Live Mockup
                  </span>
                </div>

                {/* Switch preview language: KH vs EN */}
                <div className="flex items-center gap-1 bg-slate-900 border border-slate-700 p-1 rounded-full text-xs">
                  <span className="text-[10px] text-slate-400 px-2">Preview:</span>
                  <button
                    type="button"
                    onClick={() => setSeoPreviewLang("km")}
                    className={`px-2.5 py-0.5 rounded-full font-bold transition-all text-xs cursor-pointer ${
                      seoPreviewLang === "km" ? "bg-red-600 text-white shadow-sm" : "text-slate-400 hover:text-white"
                    }`}
                  >
                    KH
                  </button>
                  <button
                    type="button"
                    onClick={() => setSeoPreviewLang("en")}
                    className={`px-2.5 py-0.5 rounded-full font-bold transition-all text-xs cursor-pointer ${
                      seoPreviewLang === "en" ? "bg-cyan-600 text-white shadow-sm" : "text-slate-400 hover:text-white"
                    }`}
                  >
                    EN
                  </button>
                </div>
              </div>

              {/* SERP Card Box */}
              <div className="p-5 rounded-2xl bg-[#030a16] border border-slate-800/80 space-y-1.5 shadow-inner">
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <div className="w-4 h-4 rounded-full bg-cyan-600/30 flex items-center justify-center text-[10px] text-cyan-300 font-black">
                    B
                  </div>
                  <span className="text-xs text-slate-300 font-medium">Broteach Digital</span>
                  <span className="text-slate-500">•</span>
                  <span className="text-xs text-slate-400 font-mono">https://broteach.com</span>
                </div>

                <h4 className="text-base sm:text-lg font-medium text-[#8ab4f8] hover:underline cursor-pointer leading-snug pt-0.5">
                  {seoPreviewLang === "km"
                    ? settings.seoTitleKm || "Broteach | គេហទំព័រអាជីវកម្មតាមបែបស្តង់ដារ & Cloud Hosting"
                    : settings.seoTitleEn || "Broteach | Enterprise Web Development & Cloud Hosting Solutions"}
                </h4>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed line-clamp-2 pt-0.5">
                  {seoPreviewLang === "km"
                    ? settings.seoDescKm || "សេវាកម្មបង្កើតគេហទំព័រអាជីវកម្មតាមបែបស្តង់ដារ ហាងទំនិញ E-Commerce..."
                    : settings.seoDescEn || "Premium web development services and digital solutions designed to accelerate..."}
                </p>
              </div>

              {/* Real-time Character Counters & Recommendation Badges */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {(() => {
                  const currentTitle = seoPreviewLang === "km" ? settings.seoTitleKm || "" : settings.seoTitleEn || "";
                  const titleLen = currentTitle.length;
                  const isTitleOptimal = titleLen >= 40 && titleLen <= 65;
                  const currentDesc = seoPreviewLang === "km" ? settings.seoDescKm || "" : settings.seoDescEn || "";
                  const descLen = currentDesc.length;
                  const isDescOptimal = descLen >= 120 && descLen <= 165;

                  return (
                    <>
                      <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/90 border border-slate-800">
                        <span className="text-xs text-slate-400 font-medium">Title Length:</span>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-bold text-white">{titleLen} / 60 chars</span>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                            isTitleOptimal
                              ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                              : titleLen > 65
                              ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                              : "bg-slate-800 text-slate-400"
                          }`}>
                            {isTitleOptimal ? "Optimal" : titleLen > 65 ? "Too Long" : "Short"}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/90 border border-slate-800">
                        <span className="text-xs text-slate-400 font-medium">Description Length:</span>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-bold text-white">{descLen} / 160 chars</span>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                            isDescOptimal
                              ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                              : descLen > 165
                              ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                              : "bg-slate-800 text-slate-400"
                          }`}>
                            {isDescOptimal ? "Optimal" : descLen > 165 ? "Too Long" : "Short"}
                          </span>
                        </div>
                      </div>
                    </>
                  );
                })()}
              </div>
            </div>

            {/* Meta Title & Meta Description Inputs */}
            <div className="rounded-2xl bg-[#061528] border border-slate-800 p-6 space-y-4">
              <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                <FileText className="w-4 h-4" />
                <span>Page Meta Titles & Descriptions</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-semibold text-slate-300">Meta SEO Title (Khmer)</label>
                    <span className="text-[11px] text-slate-500 font-mono">{(settings.seoTitleKm || "").length} chars</span>
                  </div>
                  <input
                    type="text"
                    value={settings.seoTitleKm || ""}
                    onChange={(e) => setSettings({ ...settings, seoTitleKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-semibold text-slate-300">Meta SEO Title (English)</label>
                    <span className="text-[11px] text-slate-500 font-mono">{(settings.seoTitleEn || "").length} chars</span>
                  </div>
                  <input
                    type="text"
                    value={settings.seoTitleEn || ""}
                    onChange={(e) => setSettings({ ...settings, seoTitleEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div>
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-semibold text-slate-300">Meta Description (Khmer)</label>
                    <span className="text-[11px] text-slate-500 font-mono">{(settings.seoDescKm || "").length} chars</span>
                  </div>
                  <textarea
                    rows={3}
                    value={settings.seoDescKm || ""}
                    onChange={(e) => setSettings({ ...settings, seoDescKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-semibold text-slate-300">Meta Description (English)</label>
                    <span className="text-[11px] text-slate-500 font-mono">{(settings.seoDescEn || "").length} chars</span>
                  </div>
                  <textarea
                    rows={3}
                    value={settings.seoDescEn || ""}
                    onChange={(e) => setSettings({ ...settings, seoDescEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300">Target SEO Keywords (Comma-separated)</label>
                <input
                  type="text"
                  placeholder="broteach, web design cambodia, cloud hosting cambodia, ABA KHQR..."
                  value={settings.seoKeywords || ""}
                  onChange={(e) => setSettings({ ...settings, seoKeywords: e.target.value })}
                  className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="pt-2 border-t border-slate-800">
                <label className="text-xs font-semibold text-slate-300">
                  SEO Social Share Image URL (OpenGraph & Twitter Image)
                </label>
                <input
                  type="url"
                  placeholder="https://... or /og-preview.jpg"
                  value={settings.seoImageUrl || ""}
                  onChange={(e) => setSettings({ ...settings, seoImageUrl: e.target.value })}
                  className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-cyan-300 font-mono focus:outline-none focus:border-cyan-400"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Image displayed when links are shared on Facebook, Telegram, Twitter, LinkedIn (Recommended 1200 x 630 px).
                </span>
                {settings.seoImageUrl && (
                  <div className="mt-2.5 p-2 rounded-xl bg-slate-900 border border-slate-800 inline-block">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={settings.seoImageUrl}
                      alt="SEO Social Card Preview"
                      className="h-28 max-w-full rounded-lg object-cover"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Google Search Console & Analytics */}
            <div className="rounded-2xl bg-[#061528] border border-slate-800 p-6 space-y-4">
              <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                <ShieldCheck className="w-4 h-4" />
                <span>Google Search Console & Analytics Verification</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Google Console Verification Token</label>
                  <input
                    type="text"
                    placeholder="e.g. 7q8XyZ9AbC1234567890"
                    value={settings.googleConsoleVerification || ""}
                    onChange={(e) => setSettings({ ...settings, googleConsoleVerification: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-amber-300 font-mono focus:outline-none focus:border-amber-400"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Injected into HTML head as &lt;meta name=&quot;google-site-verification&quot; /&gt;
                  </span>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300">Google Analytics GA4 ID</label>
                  <input
                    type="text"
                    placeholder="e.g. G-XXXXXXXXXX"
                    value={settings.googleAnalyticsId || ""}
                    onChange={(e) => setSettings({ ...settings, googleAnalyticsId: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-cyan-300 font-mono focus:outline-none focus:border-cyan-400"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Tracks live visitor traffic and Google conversions
                  </span>
                </div>
              </div>
            </div>

            {/* Technical SEO Status Hub */}
            <div className="rounded-2xl bg-[#061528] border border-slate-800 p-6 space-y-4">
              <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                <span>Technical SEO & Crawler Endpoints</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <a
                  href="/sitemap.xml"
                  target="_blank"
                  className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 transition-colors group flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white group-hover:text-cyan-300">sitemap.xml</span>
                    <ExternalLink className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400" />
                  </div>
                  <p className="text-[10px] text-emerald-400 font-medium mt-2 flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    <span>Canonical Clean URLs</span>
                  </p>
                </a>

                <a
                  href="/robots.txt"
                  target="_blank"
                  className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 transition-colors group flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white group-hover:text-cyan-300">robots.txt</span>
                    <ExternalLink className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400" />
                  </div>
                  <p className="text-[10px] text-emerald-400 font-medium mt-2 flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    <span>Crawler Rules Active</span>
                  </p>
                </a>

                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between">
                  <span className="text-xs font-bold text-white">Structured Data</span>
                  <p className="text-[10px] text-emerald-400 font-medium mt-2 flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    <span>JSON-LD Schemas Live</span>
                  </p>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-black text-sm shadow-lg shadow-cyan-600/30 flex items-center gap-2 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>{adminLang === "km" ? "រក្សាទុកការកំណត់ SEO" : "Save SEO Settings"}</span>
              </button>
            </div>
          </form>
        )}

        {/* TAB 6: SITE SETTINGS */}
        {activeTab === "settings" && settings && (
          <form onSubmit={handleSaveSettings} className="space-y-6 max-w-4xl">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                {adminLang === "km" ? "ការកំណត់គេហទំព័រ & Hero Banner" : "Site Settings & Branding"}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                {adminLang === "km"
                  ? "គ្រប់គ្រងចំណងជើង Hero, ការប្រកាស Ticker, និងព័ត៌មានទំនាក់ទំនង Telegram/ទូរស័ព្ទ"
                  : "Control hero titles, announcement ticker, and contact channels."}
              </p>
            </div>

            {/* HERO SECTION CUSTOMIZATION */}
            <div className="rounded-2xl bg-[#061528] border border-slate-800 p-6 space-y-6 shadow-xl">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2.5">
                  <Sparkles className="w-5 h-5 text-amber-400" />
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                    {adminLang === "km" ? "គ្រប់គ្រងផ្នែកក្បាលទំព័រ Hero" : "Hero Section Customization"}
                  </h3>
                </div>
                <span className="text-[10px] px-2.5 py-1 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/30 font-bold">
                  Live Customizable
                </span>
              </div>

              {/* 1. Hero Pill Badge */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">
                    {adminLang === "km" ? "ស្លាកខាងលើចំណងជើង Badge (Khmer)" : "Top Badge Text (Khmer)"}
                  </label>
                  <input
                    type="text"
                    placeholder="សេវាកម្មកម្រិតស្តង់ដារអន្តរជាតិ"
                    value={settings.heroBadgeKm || ""}
                    onChange={(e) => setSettings({ ...settings, heroBadgeKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-cyan-300"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">
                    {adminLang === "km" ? "ស្លាកខាងលើចំណងជើង Badge (English)" : "Top Badge Text (English)"}
                  </label>
                  <input
                    type="text"
                    placeholder="Enterprise Standard Solutions"
                    value={settings.heroBadgeEn || ""}
                    onChange={(e) => setSettings({ ...settings, heroBadgeEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-cyan-300"
                  />
                </div>
              </div>

              {/* 2. Main Title */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">
                    {adminLang === "km" ? "ចំណងជើងធំ Hero Title (Khmer)" : "Main Hero Title (Khmer)"}
                  </label>
                  <input
                    type="text"
                    value={settings.heroTitleKm || ""}
                    onChange={(e) => setSettings({ ...settings, heroTitleKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white font-bold"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    {adminLang === "km" ? "បង្ហាញជាមួយ Typing animation ដ៏ស្រស់ស្អាត" : "Rendered with smooth typing animation"}
                  </span>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">
                    {adminLang === "km" ? "ចំណងជើងធំ Hero Title (English)" : "Main Hero Title (English)"}
                  </label>
                  <input
                    type="text"
                    value={settings.heroTitleEn || ""}
                    onChange={(e) => setSettings({ ...settings, heroTitleEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white font-bold"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    {adminLang === "km" ? "បង្ហាញជាមួយ Typing animation ដ៏ស្រស់ស្អាត" : "Rendered with smooth typing animation"}
                  </span>
                </div>
              </div>

              {/* 3. Subtitle */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">
                    {adminLang === "km" ? "បរិយាយសង្ខេប Hero Subtitle (Khmer)" : "Hero Subtitle (Khmer)"}
                  </label>
                  <textarea
                    rows={3}
                    value={settings.heroSubtitleKm || ""}
                    onChange={(e) => setSettings({ ...settings, heroSubtitleKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white leading-relaxed"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">
                    {adminLang === "km" ? "បរិយាយសង្ខេប Hero Subtitle (English)" : "Hero Subtitle (English)"}
                  </label>
                  <textarea
                    rows={3}
                    value={settings.heroSubtitleEn || ""}
                    onChange={(e) => setSettings({ ...settings, heroSubtitleEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white leading-relaxed"
                  />
                </div>
              </div>

              {/* 4. Primary CTA Button (Get Started -> Telegram) */}
              <div className="p-4 rounded-xl bg-slate-900/90 border border-amber-500/20 space-y-3">
                <div className="flex items-center gap-2">
                  <Play className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                    {adminLang === "km"
                      ? "ប៊ូតុងចម្បង «Get Started» (ភ្ជាប់ទៅ Telegram ផ្ទាល់)"
                      : "Primary CTA Button «Get Started» (Direct Telegram Action)"}
                  </h4>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-300">
                      {adminLang === "km" ? "ឈ្មោះប៊ូតុង (Khmer)" : "Button Label (Khmer)"}
                    </label>
                    <input
                      type="text"
                      placeholder="ចាប់ផ្តើមឥឡូវនេះ"
                      value={settings.heroCtaTextKm || ""}
                      onChange={(e) => setSettings({ ...settings, heroCtaTextKm: e.target.value })}
                      className="w-full mt-1 px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-xs text-amber-300 font-semibold"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-300">
                      {adminLang === "km" ? "ឈ្មោះប៊ូតុង (English)" : "Button Label (English)"}
                    </label>
                    <input
                      type="text"
                      placeholder="Get Started"
                      value={settings.heroCtaTextEn || ""}
                      onChange={(e) => setSettings({ ...settings, heroCtaTextEn: e.target.value })}
                      className="w-full mt-1 px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-xs text-amber-300 font-semibold"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-300">
                      {adminLang === "km" ? "តំណ Telegram CTA Link / Username" : "Telegram CTA Link / Username"}
                    </label>
                    <input
                      type="text"
                      placeholder={settings.telegramUsername || "broteach_support"}
                      value={settings.heroCtaTelegramUrl || ""}
                      onChange={(e) => setSettings({ ...settings, heroCtaTelegramUrl: e.target.value })}
                      className="w-full mt-1 px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-xs text-cyan-300 font-mono"
                    />
                    <span className="text-[10px] text-slate-500 mt-0.5 block">
                      {adminLang === "km" ? "បញ្ចូល username ឬ link ពេញលេញ https://t.me/..." : "Enter @username or full https://t.me/... link"}
                    </span>
                  </div>
                </div>
              </div>

              {/* 5. Secondary Button (Explore Products) */}
              <div className="p-4 rounded-xl bg-slate-900/90 border border-cyan-500/20 space-y-3">
                <div className="flex items-center gap-2">
                  <Package className="w-4 h-4 text-cyan-400" />
                  <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                    {adminLang === "km" ? "ប៊ូតុងបន្ទាប់ (Secondary Button)" : "Secondary Button"}
                  </h4>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-300">
                      {adminLang === "km" ? "ឈ្មោះប៊ូតុង (Khmer)" : "Button Label (Khmer)"}
                    </label>
                    <input
                      type="text"
                      placeholder="មើលផលិតផល & សេវា"
                      value={settings.heroSecondaryBtnTextKm || ""}
                      onChange={(e) => setSettings({ ...settings, heroSecondaryBtnTextKm: e.target.value })}
                      className="w-full mt-1 px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-300">
                      {adminLang === "km" ? "ឈ្មោះប៊ូតុង (English)" : "Button Label (English)"}
                    </label>
                    <input
                      type="text"
                      placeholder="Explore Products"
                      value={settings.heroSecondaryBtnTextEn || ""}
                      onChange={(e) => setSettings({ ...settings, heroSecondaryBtnTextEn: e.target.value })}
                      className="w-full mt-1 px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-300">
                      {adminLang === "km" ? "តំណភ្ជាប់ (URL)" : "Link URL"}
                    </label>
                    <input
                      type="text"
                      placeholder="/products"
                      value={settings.heroSecondaryBtnUrl || ""}
                      onChange={(e) => setSettings({ ...settings, heroSecondaryBtnUrl: e.target.value })}
                      className="w-full mt-1 px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-xs text-cyan-300 font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* 6. Quick Stats Metrics (Uptime, Clients, Support) */}
              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  {adminLang === "km" ? "ទិន្នន័យស្ថិតិ Hero Stats (Uptime / Clients / Support)" : "Hero Quick Stats Bar"}
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {/* Stat 1 */}
                  <div className="space-y-1.5 p-3 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="text-[10px] font-bold text-cyan-400">Stat #1</span>
                    <input
                      type="text"
                      placeholder="99.9%"
                      value={settings.heroStat1Number || ""}
                      onChange={(e) => setSettings({ ...settings, heroStat1Number: e.target.value })}
                      className="w-full px-2.5 py-1.5 rounded bg-slate-900 border border-slate-700 text-xs font-bold text-cyan-400"
                    />
                    <input
                      type="text"
                      placeholder="Uptime ធានា"
                      value={settings.heroStat1LabelKm || ""}
                      onChange={(e) => setSettings({ ...settings, heroStat1LabelKm: e.target.value })}
                      className="w-full px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-[11px] text-slate-300"
                    />
                    <input
                      type="text"
                      placeholder="Guaranteed Uptime"
                      value={settings.heroStat1LabelEn || ""}
                      onChange={(e) => setSettings({ ...settings, heroStat1LabelEn: e.target.value })}
                      className="w-full px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-[11px] text-slate-400"
                    />
                  </div>

                  {/* Stat 2 */}
                  <div className="space-y-1.5 p-3 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="text-[10px] font-bold text-white">Stat #2</span>
                    <input
                      type="text"
                      placeholder="500+"
                      value={settings.heroStat2Number || ""}
                      onChange={(e) => setSettings({ ...settings, heroStat2Number: e.target.value })}
                      className="w-full px-2.5 py-1.5 rounded bg-slate-900 border border-slate-700 text-xs font-bold text-white"
                    />
                    <input
                      type="text"
                      placeholder="អតិថិជនពេញចិត្ត"
                      value={settings.heroStat2LabelKm || ""}
                      onChange={(e) => setSettings({ ...settings, heroStat2LabelKm: e.target.value })}
                      className="w-full px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-[11px] text-slate-300"
                    />
                    <input
                      type="text"
                      placeholder="Happy Clients"
                      value={settings.heroStat2LabelEn || ""}
                      onChange={(e) => setSettings({ ...settings, heroStat2LabelEn: e.target.value })}
                      className="w-full px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-[11px] text-slate-400"
                    />
                  </div>

                  {/* Stat 3 */}
                  <div className="space-y-1.5 p-3 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="text-[10px] font-bold text-amber-400">Stat #3</span>
                    <input
                      type="text"
                      placeholder="24/7"
                      value={settings.heroStat3Number || ""}
                      onChange={(e) => setSettings({ ...settings, heroStat3Number: e.target.value })}
                      className="w-full px-2.5 py-1.5 rounded bg-slate-900 border border-slate-700 text-xs font-bold text-amber-400"
                    />
                    <input
                      type="text"
                      placeholder="ជំនួយបច្ចេកទេស"
                      value={settings.heroStat3LabelKm || ""}
                      onChange={(e) => setSettings({ ...settings, heroStat3LabelKm: e.target.value })}
                      className="w-full px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-[11px] text-slate-300"
                    />
                    <input
                      type="text"
                      placeholder="Live Support"
                      value={settings.heroStat3LabelEn || ""}
                      onChange={(e) => setSettings({ ...settings, heroStat3LabelEn: e.target.value })}
                      className="w-full px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-[11px] text-slate-400"
                    />
                  </div>
                </div>
              </div>

              {/* 7. Live Preview Card */}
              <div className="p-5 rounded-2xl bg-[#030d1a] border border-cyan-500/30 space-y-3 shadow-inner">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-cyan-400 flex items-center gap-1.5">
                    <Eye className="w-3.5 h-3.5" />
                    <span>{adminLang === "km" ? "គំរូផ្សាយផ្ទាល់ (Live Hero Preview)" : "Live Hero Preview"}</span>
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {adminLang === "km" ? "ភាសា៖ ខ្មែរ" : "Language: English"}
                  </span>
                </div>

                <div className="space-y-3 pt-2">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-300 text-[11px] font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                    <span>
                      {(adminLang === "km" ? settings.heroBadgeKm : settings.heroBadgeEn) ||
                        (adminLang === "km" ? "សេវាកម្មកម្រិតស្តង់ដារអន្តរជាតិ" : "Enterprise Standard Solutions")}
                    </span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-black text-white">
                    {(adminLang === "km" ? settings.heroTitleKm : settings.heroTitleEn) ||
                      (adminLang === "km" ? "គេហទំព័រអាជីវកម្មតាមបែបស្តង់ដារ" : "Standard Professional Business Website")}
                  </h3>

                  <p className="text-xs text-slate-300 line-clamp-2 max-w-xl">
                    {(adminLang === "km" ? settings.heroSubtitleKm : settings.heroSubtitleEn) ||
                      "សេវាកម្មបង្កើតគេហទំព័រនិងដំណោះស្រាយឌីជីថលកម្រិតខ្ពស់..."}
                  </p>

                  <div className="flex items-center gap-2 pt-2">
                    <span className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 font-bold text-xs shadow-md">
                      <Play className="w-3 h-3 fill-slate-950" />
                      <span>
                        {(adminLang === "km" ? settings.heroCtaTextKm : settings.heroCtaTextEn) ||
                          (adminLang === "km" ? "ចាប់ផ្តើមឥឡូវនេះ" : "Get Started")}
                      </span>
                    </span>

                    <span className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full border border-cyan-500/40 text-cyan-300 text-xs font-semibold bg-cyan-950/30">
                      <span>
                        {(adminLang === "km" ? settings.heroSecondaryBtnTextKm : settings.heroSecondaryBtnTextEn) ||
                          (adminLang === "km" ? "មើលផលិតផល & សេវា" : "Explore Products")}
                      </span>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Announcement & Contacts */}
            <div className="rounded-2xl bg-[#061528] border border-slate-800 p-6 space-y-4">
              <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-wider">
                Announcement Ticker & Contact Info
              </h3>

              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="showAnnounce"
                  checked={settings.showAnnouncement}
                  onChange={(e) => setSettings({ ...settings, showAnnouncement: e.target.checked })}
                  className="w-4 h-4 rounded text-cyan-500"
                />
                <label htmlFor="showAnnounce" className="text-xs font-semibold text-white">
                  {adminLang === "km" ? "បង្ហាញផ្ទាំងប្រកាស (Show Announcement Ticker)" : "Show Announcement Ticker"}
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Announcement (Khmer)</label>
                  <input
                    type="text"
                    value={settings.announcementTextKm}
                    onChange={(e) => setSettings({ ...settings, announcementTextKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Announcement (English)</label>
                  <input
                    type="text"
                    value={settings.announcementTextEn}
                    onChange={(e) => setSettings({ ...settings, announcementTextEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Telegram Username</label>
                  <input
                    type="text"
                    value={settings.telegramUsername}
                    onChange={(e) => setSettings({ ...settings, telegramUsername: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-cyan-300 font-semibold"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Phone 1</label>
                  <input
                    type="text"
                    value={settings.phone1}
                    onChange={(e) => setSettings({ ...settings, phone1: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Phone 2</label>
                  <input
                    type="text"
                    value={settings.phone2}
                    onChange={(e) => setSettings({ ...settings, phone2: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>
            </div>

            {/* Brand Identity & Media (Logo & Favicon) */}
            <div className="rounded-2xl bg-[#061528] border border-slate-800 p-6 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-800/80 pb-4">
                <div>
                  <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                    <ImageIcon className="w-4 h-4" />
                    <span>Brand Identity: Logo, Icon & Text Styling</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    {adminLang === "km"
                      ? "កំណត់ Brand Name, Subtitle, ពណ៌ Dot, រចនាប័ទ្ម Border និងរូបភាព Logo / Favicon"
                      : "Customize Brand Name, Subtitle, Dot Color, Border/Frame Style, and Logo/Favicon."}
                  </p>
                </div>
                <span className="text-[11px] px-2.5 py-1 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 w-fit">
                  Live Preview Active
                </span>
              </div>

              {/* Interactive Live Brand Preview on Dark Header */}
              <div className="p-4 rounded-xl bg-[#030d1a] border border-cyan-950 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-inner">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                    Navbar & Header Live Preview:
                  </span>
                  <BroteachBrand
                    logoUrl={settings.siteLogoUrl || ""}
                    brandName={settings.siteBrandName || "broteach"}
                    brandSubtitle={settings.siteBrandSubtitle || "Digital & Cloud"}
                    brandDotColor={settings.siteBrandDotColor || "#ef4444"}
                    borderStyle={settings.siteBrandBorderStyle || "none"}
                    size="md"
                  />
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-900/80 px-3 py-2 rounded-lg border border-slate-800">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                  <span>Silky-smooth retina vector SVG enabled</span>
                </div>
              </div>

              {/* Brand Text Customization */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Brand Name</label>
                  <input
                    type="text"
                    placeholder="broteach"
                    value={settings.siteBrandName || ""}
                    onChange={(e) => setSettings({ ...settings, siteBrandName: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white font-medium focus:border-cyan-400 focus:outline-hidden"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">Default: broteach</span>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300">Brand Subtitle</label>
                  <input
                    type="text"
                    placeholder="Digital & Cloud"
                    value={settings.siteBrandSubtitle || ""}
                    onChange={(e) => setSettings({ ...settings, siteBrandSubtitle: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-cyan-300 font-medium focus:border-cyan-400 focus:outline-hidden"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">Default: Digital & Cloud</span>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300">Accent Dot Color</label>
                  <div className="flex items-center gap-2 mt-1.5">
                    <input
                      type="color"
                      value={settings.siteBrandDotColor || "#ef4444"}
                      onChange={(e) => setSettings({ ...settings, siteBrandDotColor: e.target.value })}
                      className="w-9 h-9 rounded-lg bg-transparent cursor-pointer border border-slate-700"
                    />
                    <input
                      type="text"
                      value={settings.siteBrandDotColor || "#ef4444"}
                      onChange={(e) => setSettings({ ...settings, siteBrandDotColor: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs font-mono text-white"
                      placeholder="#ef4444"
                    />
                  </div>
                  {/* Preset Dot Colors */}
                  <div className="flex items-center gap-1.5 mt-2">
                    {[
                      { name: "Red", hex: "#ef4444" },
                      { name: "Cyan", hex: "#00f0ff" },
                      { name: "Blue", hex: "#3b82f6" },
                      { name: "Green", hex: "#10b981" },
                      { name: "Amber", hex: "#f59e0b" },
                      { name: "Pink", hex: "#ec4899" },
                    ].map((col) => (
                      <button
                        key={col.hex}
                        type="button"
                        onClick={() => setSettings({ ...settings, siteBrandDotColor: col.hex })}
                        className="w-4 h-4 rounded-full border border-slate-700 hover:scale-125 transition-transform"
                        style={{ backgroundColor: col.hex }}
                        title={col.name}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Brand Frame / Border Customization */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Brand Border & Frame Style (Customize border around brand text)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                  {[
                    { id: "none", label: "Clean / None", desc: "Borderless modern" },
                    { id: "blue", label: "Blue Border", desc: "Solid 2px blue box" },
                    { id: "cyan-glow", label: "Cyan Glow", desc: "Glowing tech frame" },
                    { id: "glass", label: "Glassmorphism", desc: "Frosted glass box" },
                    { id: "pill", label: "Modern Pill", desc: "Cyan rounded pill" },
                  ].map((styleOpt) => {
                    const isSelected = (settings.siteBrandBorderStyle || "none") === styleOpt.id;
                    return (
                      <button
                        key={styleOpt.id}
                        type="button"
                        onClick={() => setSettings({ ...settings, siteBrandBorderStyle: styleOpt.id })}
                        className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                          isSelected
                            ? "bg-cyan-950/40 border-cyan-400 text-white shadow-[0_0_12px_rgba(6,182,212,0.3)] scale-[1.02]"
                            : "bg-slate-900 border-slate-700 text-slate-400 hover:border-slate-500 hover:text-white"
                        }`}
                      >
                        <div className="text-xs font-bold">{styleOpt.label}</div>
                        <div className="text-[10px] text-slate-400 mt-0.5">{styleOpt.desc}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* URLs & Direct Uploads for Custom Overrides (Logo Image & Favicon) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-800/80">
                <div>
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-300">Custom Logo Image</label>
                    <label className="px-2.5 py-1 rounded-lg bg-cyan-600/90 hover:bg-cyan-500 text-white text-[11px] font-semibold cursor-pointer flex items-center gap-1.5 transition-colors">
                      <Upload className="w-3 h-3" />
                      <span>{uploadingDirect ? "Uploading..." : "Upload Logo"}</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        disabled={uploadingDirect}
                        onChange={(e) => handleDirectUpload(e, "logo")}
                      />
                    </label>
                  </div>
                  <input
                    type="text"
                    placeholder="/uploads/... or https://..."
                    value={settings.siteLogoUrl || ""}
                    onChange={(e) => setSettings({ ...settings, siteLogoUrl: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-cyan-300 font-mono"
                  />
                  <div className="mt-2 flex items-center justify-between">
                    {settings.siteLogoUrl ? (
                      <div className="p-2 bg-slate-900 border border-slate-800 rounded-xl inline-flex items-center gap-2">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={settings.siteLogoUrl} alt="Logo Preview" className="h-8 max-w-[120px] object-contain rounded" />
                        <button
                          type="button"
                          onClick={() => setSettings({ ...settings, siteLogoUrl: "" })}
                          className="text-[10px] text-rose-400 hover:text-rose-300 ml-1 underline cursor-pointer"
                        >
                          Clear (Use Vector)
                        </button>
                      </div>
                    ) : (
                      <span className="text-[10px] text-cyan-400/90">
                        ✓ Using native ultra-smooth vector logo
                      </span>
                    )}
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-300">Favicon / Browser Tab Icon</label>
                    <label className="px-2.5 py-1 rounded-lg bg-cyan-600/90 hover:bg-cyan-500 text-white text-[11px] font-semibold cursor-pointer flex items-center gap-1.5 transition-colors">
                      <Upload className="w-3 h-3" />
                      <span>{uploadingDirect ? "Uploading..." : "Upload Favicon"}</span>
                      <input
                        type="file"
                        accept="image/*,.ico,.svg"
                        className="hidden"
                        disabled={uploadingDirect}
                        onChange={(e) => handleDirectUpload(e, "icon")}
                      />
                    </label>
                  </div>
                  <input
                    type="text"
                    placeholder="/icon.svg, /favicon.ico or /uploads/..."
                    value={settings.siteIconUrl || ""}
                    onChange={(e) => setSettings({ ...settings, siteIconUrl: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-cyan-300 font-mono"
                  />
                  <div className="mt-2 flex items-center justify-between">
                    {settings.siteIconUrl ? (
                      <div className="p-2 bg-slate-900 border border-slate-800 rounded-xl inline-flex items-center gap-2">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={settings.siteIconUrl} alt="Icon Preview" className="w-6 h-6 object-contain rounded" />
                        <button
                          type="button"
                          onClick={() => setSettings({ ...settings, siteIconUrl: "" })}
                          className="text-[10px] text-rose-400 hover:text-rose-300 ml-1 underline cursor-pointer"
                        >
                          Clear (Use Default)
                        </button>
                      </div>
                    ) : (
                      <span className="text-[10px] text-cyan-400/90">
                        ✓ Using official /icon.svg & /favicon.ico
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Instant Brand Save Button */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  {adminLang === "km"
                    ? "ការផ្លាស់ប្តូរនឹងបង្ហាញលើ Navbar, Footer និង Browser Tab ភ្លាមៗ"
                    : "Changes sync in real-time across Navbar, Footer, and Browser tabs"}
                </span>
                <button
                  type="button"
                  onClick={() => handleSaveSettings()}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-xs shadow-md shadow-cyan-600/20 hover:scale-105 transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{adminLang === "km" ? "រក្សាទុក Brand & Logo" : "Save Brand & Logo Settings"}</span>
                </button>
              </div>
            </div>

            {/* Footer & Social Media CMS */}
            <div className="rounded-2xl bg-[#061528] border border-slate-800 p-6 space-y-4">
              <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                <Globe className="w-4 h-4" />
                <span>Footer Content & Social Media Links</span>
              </h3>
              <p className="text-xs text-slate-400">
                {adminLang === "km"
                  ? "គ្រប់គ្រងអត្ថបទពិពណ៌នានៅ Footer ការរក្សាសិទ្ធិ (Copyright) និងតំណភ្ជាប់ Facebook / YouTube"
                  : "Customize footer description, copyright notices, and official Facebook/YouTube channel links."}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Footer Description (Khmer)</label>
                  <textarea
                    rows={2}
                    value={settings.footerDescKm || ""}
                    onChange={(e) => setSettings({ ...settings, footerDescKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Footer Description (English)</label>
                  <textarea
                    rows={2}
                    value={settings.footerDescEn || ""}
                    onChange={(e) => setSettings({ ...settings, footerDescEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Footer Copyright (Khmer)</label>
                  <input
                    type="text"
                    value={settings.footerCopyrightKm || ""}
                    onChange={(e) => setSettings({ ...settings, footerCopyrightKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Footer Copyright (English)</label>
                  <input
                    type="text"
                    value={settings.footerCopyrightEn || ""}
                    onChange={(e) => setSettings({ ...settings, footerCopyrightEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Facebook Page URL</label>
                  <input
                    type="url"
                    value={settings.facebookUrl || ""}
                    onChange={(e) => setSettings({ ...settings, facebookUrl: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-cyan-300"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">YouTube Channel URL</label>
                  <input
                    type="url"
                    value={settings.youtubeUrl || ""}
                    onChange={(e) => setSettings({ ...settings, youtubeUrl: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-rose-300"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Telegram Channel / Support URL</label>
                  <input
                    type="url"
                    value={settings.telegramChannelUrl || ""}
                    onChange={(e) => setSettings({ ...settings, telegramChannelUrl: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-cyan-300"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">TikTok URL</label>
                  <input
                    type="url"
                    value={settings.tiktokUrl || ""}
                    onChange={(e) => setSettings({ ...settings, tiktokUrl: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              {/* Contact Heading */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Contact Heading (Khmer)</label>
                  <input
                    type="text"
                    value={settings.footerContactHeadingKm || ""}
                    onChange={(e) => setSettings({ ...settings, footerContactHeadingKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Contact Heading (English)</label>
                  <input
                    type="text"
                    value={settings.footerContactHeadingEn || ""}
                    onChange={(e) => setSettings({ ...settings, footerContactHeadingEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              {/* Email & Physical Address */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Footer Email</label>
                  <input
                    type="email"
                    value={settings.email || ""}
                    onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Address (Khmer)</label>
                  <input
                    type="text"
                    value={settings.addressKm || ""}
                    onChange={(e) => setSettings({ ...settings, addressKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Address (English)</label>
                  <input
                    type="text"
                    value={settings.addressEn || ""}
                    onChange={(e) => setSettings({ ...settings, addressEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              {/* Column 2: Services Column Customizer */}
              <div className="pt-4 border-t border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                  Footer Column 2: Services
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-300">Column Title (Khmer)</label>
                    <input
                      type="text"
                      value={settings.footerServicesTitleKm || ""}
                      onChange={(e) => setSettings({ ...settings, footerServicesTitleKm: e.target.value })}
                      className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-300">Column Title (English)</label>
                    <input
                      type="text"
                      value={settings.footerServicesTitleEn || ""}
                      onChange={(e) => setSettings({ ...settings, footerServicesTitleEn: e.target.value })}
                      className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                    />
                  </div>
                </div>

                {/* 4 Service links */}
                {[1, 2, 3, 4].map((num) => {
                  const keyKm = `footerService${num}Km` as keyof SiteSettings;
                  const keyEn = `footerService${num}En` as keyof SiteSettings;
                  const keyUrl = `footerService${num}Url` as keyof SiteSettings;
                  return (
                    <div key={num} className="grid grid-cols-1 sm:grid-cols-3 gap-2 p-2 bg-slate-900/60 rounded-xl border border-slate-800">
                      <div>
                        <label className="text-[10px] text-slate-400">Service {num} Label (Khmer)</label>
                        <input
                          type="text"
                          value={(settings[keyKm] as string) || ""}
                          onChange={(e) => setSettings({ ...settings, [keyKm]: e.target.value })}
                          className="w-full mt-1 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400">Service {num} Label (English)</label>
                        <input
                          type="text"
                          value={(settings[keyEn] as string) || ""}
                          onChange={(e) => setSettings({ ...settings, [keyEn]: e.target.value })}
                          className="w-full mt-1 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400">Service {num} Link URL</label>
                        <input
                          type="text"
                          placeholder="/products or /#pricing"
                          value={(settings[keyUrl] as string) || ""}
                          onChange={(e) => setSettings({ ...settings, [keyUrl]: e.target.value })}
                          className="w-full mt-1 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-cyan-300 font-mono"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Column 3: Quick Links Column Customizer */}
              <div className="pt-4 border-t border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                  Footer Column 3: Quick Links
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-300">Column Title (Khmer)</label>
                    <input
                      type="text"
                      value={settings.footerQuickLinksTitleKm || ""}
                      onChange={(e) => setSettings({ ...settings, footerQuickLinksTitleKm: e.target.value })}
                      className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-300">Column Title (English)</label>
                    <input
                      type="text"
                      value={settings.footerQuickLinksTitleEn || ""}
                      onChange={(e) => setSettings({ ...settings, footerQuickLinksTitleEn: e.target.value })}
                      className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                    />
                  </div>
                </div>

                {/* 4 Quick links */}
                {[1, 2, 3, 4].map((num) => {
                  const keyKm = `footerQuickLink${num}Km` as keyof SiteSettings;
                  const keyEn = `footerQuickLink${num}En` as keyof SiteSettings;
                  const keyUrl = `footerQuickLink${num}Url` as keyof SiteSettings;
                  return (
                    <div key={num} className="grid grid-cols-1 sm:grid-cols-3 gap-2 p-2 bg-slate-900/60 rounded-xl border border-slate-800">
                      <div>
                        <label className="text-[10px] text-slate-400">Link {num} Label (Khmer)</label>
                        <input
                          type="text"
                          value={(settings[keyKm] as string) || ""}
                          onChange={(e) => setSettings({ ...settings, [keyKm]: e.target.value })}
                          className="w-full mt-1 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400">Link {num} Label (English)</label>
                        <input
                          type="text"
                          value={(settings[keyEn] as string) || ""}
                          onChange={(e) => setSettings({ ...settings, [keyEn]: e.target.value })}
                          className="w-full mt-1 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400">Link {num} URL</label>
                        <input
                          type="text"
                          placeholder="/about or /blog"
                          value={(settings[keyUrl] as string) || ""}
                          onChange={(e) => setSettings({ ...settings, [keyUrl]: e.target.value })}
                          className="w-full mt-1 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-cyan-300 font-mono"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* SEO & Google Search Console Quick Jump */}
            <div className="rounded-2xl bg-gradient-to-r from-[#061528] to-[#041223] border border-cyan-500/30 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg">
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                  <SearchCheck className="w-4 h-4" />
                  <span>SEO & Google Search Console Hub</span>
                </h3>
                <p className="text-xs text-slate-300">
                  {adminLang === "km"
                    ? "ទិន្នន័យ Meta Tags, Google Search Console Token, និង Google SERP Live Mockup ត្រូវបានរៀបចំនៅក្នុងផ្ទាំង SEO ផ្តាច់មុខ"
                    : "Meta tags, Google Search Console tokens, and live SERP preview are now managed in the dedicated SEO tab."}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab("seo")}
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer self-start sm:self-auto shrink-0 shadow-md shadow-cyan-600/30"
              >
                <span>{adminLang === "km" ? "បើកផ្ទាំង SEO" : "Open SEO Hub"}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* About Us Page CMS Content */}
            <div className="rounded-2xl bg-[#061528] border border-slate-800 p-6 space-y-4">
              <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                <FileText className="w-4 h-4" />
                <span>About Us Page CMS Content</span>
              </h3>
              <p className="text-xs text-slate-400">
                {adminLang === "km"
                  ? "គ្រប់គ្រងអត្ថបទ និងខ្លឹមសារដែលត្រូវបង្ហាញលើទំព័រ អំពីយើងខ្ញុំ (/about)"
                  : "Customize titles, story, and mission displayed on the dedicated /about page."}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">About Page Title (Khmer)</label>
                  <input
                    type="text"
                    value={settings.aboutTitleKm || ""}
                    onChange={(e) => setSettings({ ...settings, aboutTitleKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">About Page Title (English)</label>
                  <input
                    type="text"
                    value={settings.aboutTitleEn || ""}
                    onChange={(e) => setSettings({ ...settings, aboutTitleEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">About Subtitle (Khmer)</label>
                  <textarea
                    rows={2}
                    value={settings.aboutSubtitleKm || ""}
                    onChange={(e) => setSettings({ ...settings, aboutSubtitleKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">About Subtitle (English)</label>
                  <textarea
                    rows={2}
                    value={settings.aboutSubtitleEn || ""}
                    onChange={(e) => setSettings({ ...settings, aboutSubtitleEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Our Story (Khmer)</label>
                  <textarea
                    rows={4}
                    value={settings.aboutStoryKm || ""}
                    onChange={(e) => setSettings({ ...settings, aboutStoryKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Our Story (English)</label>
                  <textarea
                    rows={4}
                    value={settings.aboutStoryEn || ""}
                    onChange={(e) => setSettings({ ...settings, aboutStoryEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Mission & Vision (Khmer)</label>
                  <textarea
                    rows={3}
                    value={settings.aboutMissionKm || ""}
                    onChange={(e) => setSettings({ ...settings, aboutMissionKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Mission & Vision (English)</label>
                  <textarea
                    rows={3}
                    value={settings.aboutMissionEn || ""}
                    onChange={(e) => setSettings({ ...settings, aboutMissionEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-sm shadow-lg shadow-cyan-600/30 hover:scale-105 transition-all cursor-pointer flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>{adminLang === "km" ? "រក្សាទុកការកំណត់" : "Save All Settings"}</span>
            </button>
          </form>
        )}

        {/* TAB 6: ORDERS */}
        {activeTab === "orders" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                {adminLang === "km" ? "បញ្ជីការកុម្ម៉ង់ទិញរបស់អតិថិជន" : "Customer Orders"}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                {adminLang === "km"
                  ? "ព័ត៌មានអតិថិជនដែលបានដាក់ស្នើកុម្ម៉ង់តាមគេហទំព័រ"
                  : "Review client submissions, contacts, and status."}
              </p>
            </div>

            <div className="rounded-2xl bg-[#061528] border border-slate-800 overflow-hidden shadow-xl p-4 sm:p-5">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900/90 text-slate-400 font-semibold border-b border-slate-800">
                    <tr>
                      <th className="p-4">Customer</th>
                      <th className="p-4">Plan / Service</th>
                      <th className="p-4">Phone / Telegram</th>
                      <th className="p-4">Status</th>
                      <th className="p-4">Date</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {orders.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="p-8 text-center text-slate-500">
                          {adminLang === "km" ? "មិនទាន់មានការកុម្ម៉ង់នៅឡើយទេ" : "No orders received yet."}
                        </td>
                      </tr>
                    ) : (
                      orders
                        .slice((ordersPage - 1) * 8, ordersPage * 8)
                        .map((o) => (
                          <tr key={o.id} className="hover:bg-slate-900/40 transition-colors">
                            <td className="p-4 font-bold text-white">{o.clientName}</td>
                            <td className="p-4 font-semibold text-cyan-300">{o.planName}</td>
                            <td className="p-4 text-slate-300">
                              <div>{o.phone}</div>
                              {o.telegram && <div className="text-[10px] text-cyan-400">{o.telegram}</div>}
                            </td>
                            <td className="p-4">
                              <span
                                className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                                  o.status === "completed"
                                    ? "bg-emerald-950 text-emerald-300 border border-emerald-500/40"
                                    : "bg-amber-950 text-amber-300 border border-amber-500/40"
                                }`}
                              >
                                {o.status}
                              </span>
                            </td>
                            <td className="p-4 text-slate-500 text-[11px]">
                              {new Date(o.createdAt).toLocaleDateString()}
                            </td>
                            <td className="p-4 text-right">
                              <button
                                type="button"
                                onClick={() => handleDeleteOrder(o.id)}
                                className="p-2 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-300 hover:text-white transition-colors cursor-pointer"
                                title={adminLang === "km" ? "លុបការកុម្ម៉ង់" : "Delete Order"}
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))
                    )}
                  </tbody>
                </table>
              </div>
              {renderPagination(ordersPage, orders.length, 8, setOrdersPage)}
            </div>
          </div>
        )}

        {/* TAB 7: SUBSCRIBERS */}
        {activeTab === "subscribers" && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-white">
                  {adminLang === "km" ? "បញ្ជីអ៊ីមែលអ្នកជាវ Newsletter" : "Newsletter Subscribers"}
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  {adminLang === "km"
                    ? "បញ្ជីអ៊ីមែលអតិថិជនសរុប និងឧបករណ៍ចម្លងបញ្ជីអ៊ីមែលសម្រាប់ Email Marketing"
                    : "List of subscriber emails collected with one-click export & management."}
                </p>
              </div>

              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={handleCopySubscribers}
                  disabled={subscribers.length === 0}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold text-xs flex items-center gap-1.5 border border-cyan-500/30 transition-all cursor-pointer disabled:opacity-50"
                >
                  <Copy className="w-4 h-4" />
                  <span>
                    {copiedEmails
                      ? adminLang === "km" ? "បានចម្លងរួចរាល់!" : "Copied to Clipboard!"
                      : adminLang === "km" ? `ចម្លងអ៊ីមែលទាំងអស់ (${subscribers.length})` : `Copy All Emails (${subscribers.length})`}
                  </span>
                </button>
              </div>
            </div>

            {/* Search filter */}
            <div className="relative max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                placeholder={adminLang === "km" ? "ស្វែងរកអ៊ីមែល..." : "Search subscriber emails..."}
                value={subscriberSearch}
                onChange={(e) => {
                  setSubscriberSearch(e.target.value);
                  setSubscribersPage(1);
                }}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#061528] border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>

            {(() => {
              const filteredSubs = subscribers.filter((s) =>
                s.email.toLowerCase().includes(subscriberSearch.toLowerCase())
              );
              const pagedSubs = filteredSubs.slice((subscribersPage - 1) * 10, subscribersPage * 10);

              return (
                <div className="rounded-2xl bg-[#061528] border border-slate-800 overflow-hidden shadow-xl max-w-3xl p-4 sm:p-5">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-900/90 text-slate-400 font-semibold border-b border-slate-800">
                        <tr>
                          <th className="p-4">Subscriber Email</th>
                          <th className="p-4">Date Subscribed</th>
                          <th className="p-4 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60">
                        {filteredSubs.length === 0 ? (
                          <tr>
                            <td colSpan={3} className="p-8 text-center text-slate-500">
                              {adminLang === "km" ? "មិនមានទិន្នន័យអ៊ីមែលឡើយ" : "No subscriber emails found."}
                            </td>
                          </tr>
                        ) : (
                          pagedSubs.map((s) => (
                            <tr key={s.id} className="hover:bg-slate-900/40 transition-colors">
                              <td className="p-4 font-semibold text-white">{s.email}</td>
                              <td className="p-4 text-slate-400 text-[11px]">
                                {new Date(s.subscribedAt).toLocaleString()}
                              </td>
                              <td className="p-4 text-right">
                                <button
                                  type="button"
                                  onClick={() => handleDeleteSubscriber(s.id)}
                                  className="p-2 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-300 hover:text-white transition-colors cursor-pointer"
                                  title="Delete Subscriber"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                  {renderPagination(subscribersPage, filteredSubs.length, 10, setSubscribersPage)}
                </div>
              );
            })()}
          </div>
        )}

        {/* TAB 8: BACKUP & RESTORE */}
        {activeTab === "backup" && (
          <div className="space-y-8">
            {/* Header & Main Actions */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-black text-white flex items-center gap-2.5">
                  <Database className="w-7 h-7 text-cyan-400" />
                  <span>
                    {adminLang === "km"
                      ? "ប្រព័ន្ធបម្រុងទុក និងស្តារទិន្នន័យ (Backups & Disaster Recovery)"
                      : "Backups & Disaster Recovery"}
                  </span>
                </h1>
                <p className="text-xs sm:text-sm text-slate-400 mt-1">
                  {adminLang === "km"
                    ? "ទាញយកឯកសារបម្រុងទុក (JSON Export) បង្កើត Server Snapshot ឬស្តារទិន្នន័យឡើងវិញដោយសុវត្ថិភាពខ្ពស់"
                    : "Export instant JSON backups, persist on-server snapshots, and perform selective disaster recovery."}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={handleExportLiveBackup}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-600/30 transition-all cursor-pointer hover:scale-105"
                >
                  <Download className="w-4 h-4" />
                  <span>{adminLang === "km" ? "ទាញយក Backup ភ្លាមៗ (JSON)" : "Export Live Backup (JSON)"}</span>
                </button>

                <button
                  type="button"
                  onClick={loadBackups}
                  disabled={loadingBackups}
                  className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title="Refresh Snapshots"
                >
                  <RefreshCw className={`w-4 h-4 ${loadingBackups ? "animate-spin text-cyan-400" : ""}`} />
                </button>
              </div>
            </div>

            {/* Zero-Loss Guarantee & Live Data Breakdown */}
            <div className="rounded-2xl bg-[#061528] border border-cyan-500/30 p-5 shadow-xl relative overflow-hidden">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 flex-shrink-0 mt-0.5">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <span>{adminLang === "km" ? "ការការពារសុវត្ថិភាពទិន្នន័យស្វ័យប្រវត្តិ 100%" : "Automated Zero-Loss Safety Guard"}</span>
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                        Active & Protected
                      </span>
                    </h3>
                    <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                      {adminLang === "km"
                        ? "រាល់ពេលលោកអ្នកដំណើរការស្តារទិន្នន័យ (Restore) ណាមួយ ប្រព័ន្ធនឹងបង្កើត Pre-restore Safety Snapshot មួយដោយស្វ័យប្រវត្តមុនពេលកែប្រែ ដូច្នេះទិន្នន័យមិនអាចបាត់បង់ឡើយ។"
                        : "Before performing any restore operation, the system automatically creates an on-server safety snapshot so you can roll back at any time."}
                    </p>
                  </div>
                </div>

                {/* Storage Info Badge */}
                <div className="flex items-center gap-2 text-xs bg-slate-900/90 border border-slate-800 px-3.5 py-2 rounded-xl text-slate-300 self-start lg:self-auto font-mono">
                  <HardDrive className="w-4 h-4 text-cyan-400" />
                  <span>Volume: .data/backups/</span>
                </div>
              </div>

              {/* Entity Counters */}
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5 pt-4 mt-4 border-t border-slate-800 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">{adminLang === "km" ? "ការកំណត់" : "Settings"}</span>
                  <span className="font-bold text-white mt-0.5 block">{settings ? "✓ Active" : "Default"}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">{adminLang === "km" ? "ផលិតផល" : "Products"}</span>
                  <span className="font-bold text-cyan-400 mt-0.5 block">{products.length} Items</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">{adminLang === "km" ? "កញ្ចប់តម្លៃ" : "Pricing"}</span>
                  <span className="font-bold text-cyan-400 mt-0.5 block">{pricing.length} Plans</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">{adminLang === "km" ? "ផ្នែកមាតិកា" : "Sections"}</span>
                  <span className="font-bold text-indigo-400 mt-0.5 block">{sections.length} Sections</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">{adminLang === "km" ? "អត្ថបទ Blog" : "Blog Posts"}</span>
                  <span className="font-bold text-emerald-400 mt-0.5 block">{posts.length} Posts</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">{adminLang === "km" ? "ការកុម្ម៉ង់" : "Orders"}</span>
                  <span className="font-bold text-rose-400 mt-0.5 block">{orders.length} Orders</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">{adminLang === "km" ? "អ្នកជាវ" : "Subscribers"}</span>
                  <span className="font-bold text-amber-400 mt-0.5 block">{subscribers.length} Leads</span>
                </div>
              </div>
            </div>

            {/* Two Action Panels: 1) Restore Upload & 2) Create Snapshot */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* PANEL A: Restore from Uploaded JSON */}
              <div className="rounded-2xl bg-[#061528] border border-slate-800 p-6 flex flex-col justify-between space-y-5 shadow-xl">
                <div>
                  <div className="flex items-center gap-2.5 mb-2">
                    <div className="w-8 h-8 rounded-lg bg-emerald-950/80 text-emerald-400 flex items-center justify-center">
                      <Upload className="w-4 h-4" />
                    </div>
                    <h2 className="text-base font-bold text-white">
                      {adminLang === "km" ? "ស្តារទិន្នន័យពីឯកសារ JSON (File Restore)" : "Restore from Backup File"}
                    </h2>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {adminLang === "km"
                      ? "ផ្ទុកឡើងឯកសារ .json ដែលបានទាញយកពីមុន។ លោកអ្នកនឹងអាចមើលព័ត៌មានលម្អិត និងជ្រើសរើសផ្នែកដែលត្រូវស្តារ (Selective Restore) មុននឹងសម្រេចចិត្ត។"
                      : "Upload a previously exported .json backup file. You can preview file contents and selectively choose which collections to restore."}
                  </p>
                </div>

                <div className="border-2 border-dashed border-cyan-500/40 hover:border-cyan-400 rounded-2xl p-6 text-center bg-slate-900/40 hover:bg-slate-900/80 transition-all cursor-pointer relative group">
                  <input
                    type="file"
                    accept=".json,application/json"
                    onChange={handleFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  <div className="flex flex-col items-center gap-2.5 pointer-events-none">
                    <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
                      <FileArchive className="w-6 h-6" />
                    </div>
                    <div className="text-xs font-bold text-white">
                      {adminLang === "km" ? "ចុចដើម្បីជ្រើសរើសឯកសារ Backup .JSON" : "Click to select a .JSON backup file"}
                    </div>
                    <span className="text-[11px] text-slate-400">
                      {adminLang === "km" ? "ឬទាញឯកសារទម្លាក់នៅទីនេះ (Supports .json format)" : "or drag & drop your file here"}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-[11px] text-slate-400">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>{adminLang === "km" ? "គាំទ្រការស្តារទិន្នន័យដោយជ្រើសរើស (Selective Restore Supported)" : "Selective restore support included"}</span>
                </div>
              </div>

              {/* PANEL B: Create Server Snapshot */}
              <div className="rounded-2xl bg-[#061528] border border-slate-800 p-6 flex flex-col justify-between space-y-5 shadow-xl">
                <div>
                  <div className="flex items-center gap-2.5 mb-2">
                    <div className="w-8 h-8 rounded-lg bg-cyan-950/80 text-cyan-400 flex items-center justify-center">
                      <Save className="w-4 h-4" />
                    </div>
                    <h2 className="text-base font-bold text-white">
                      {adminLang === "km" ? "បង្កើត Snapshot ថ្មីលើ Server" : "Create On-Server Snapshot"}
                    </h2>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {adminLang === "km"
                      ? "បង្កើត Snapshot រក្សាទុកក្នុងថត .data/backups/ លើ Server ភ្លាមៗ។ មិនបាត់បង់ពេល Restart កុងតឺន័រ Docker ឡើយ។"
                      : "Create an instant snapshot saved directly on the host server volume (.data/backups/). Persists across container restarts."}
                  </p>
                </div>

                <form onSubmit={handleCreateSnapshot} className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                      {adminLang === "km" ? "ស្លាកសម្គាល់ / ចំណាំ Snapshot (Optional Tag)" : "Snapshot Label / Note (Optional)"}
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. before-update, deploy-v1, clean-install"
                      value={snapshotTagInput}
                      onChange={(e) => setSnapshotTagInput(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isCreatingSnapshot}
                    className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-bold text-xs shadow-lg shadow-cyan-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all"
                  >
                    {isCreatingSnapshot ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>{adminLang === "km" ? "កំពុងបង្កើត Snapshot..." : "Creating Snapshot..."}</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-4 h-4" />
                        <span>{adminLang === "km" ? "បង្កើត Snapshot ឥឡូវនេះ" : "Create Snapshot Now"}</span>
                      </>
                    )}
                  </button>
                </form>

                <div className="flex items-center gap-2 text-[11px] text-slate-400">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>{adminLang === "km" ? "រក្សាទុកជាអចិន្ត្រៃយ៍លើ Host Storage" : "Persisted permanently on host volume"}</span>
                </div>
              </div>
            </div>

            {/* Server Snapshots History List */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-white flex items-center gap-2">
                    <span>{adminLang === "km" ? "បញ្ជី Snapshot រក្សាទុកលើ Server" : "Server Snapshot Archives"}</span>
                    <span className="px-2 py-0.5 rounded-full bg-slate-800 text-[10px] text-cyan-300 font-mono">
                      {snapshots.length}
                    </span>
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {adminLang === "km"
                      ? "គ្រប់គ្រង ទាញយក ឬស្តារប្រព័ន្ធត្រឡប់ទៅ Snapshot ណាមួយដោយចុចតែម្តង"
                      : "Download, restore, or manage on-server snapshot archives."}
                  </p>
                </div>
              </div>

              <div className="rounded-2xl bg-[#061528] border border-slate-800 overflow-hidden shadow-xl">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900/90 text-slate-400 font-semibold border-b border-slate-800">
                      <tr>
                        <th className="p-4">{adminLang === "km" ? "ឈ្មោះឯកសារ Snapshot" : "Snapshot File & Tag"}</th>
                        <th className="p-4">{adminLang === "km" ? "កាលបរិច្ឆេទ" : "Created Date"}</th>
                        <th className="p-4">{adminLang === "km" ? "ទំហំ" : "Size"}</th>
                        <th className="p-4">{adminLang === "km" ? "ទិន្នន័យរួមបញ្ចូល" : "Contents Breakdown"}</th>
                        <th className="p-4 text-right">{adminLang === "km" ? "សកម្មភាព" : "Actions"}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {snapshots.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="p-12 text-center text-slate-500">
                            <Database className="w-8 h-8 text-slate-600 mx-auto mb-2 opacity-50" />
                            <p className="text-xs font-semibold text-slate-400">
                              {adminLang === "km"
                                ? "មិនទាន់មាន Server Snapshot នៅឡើយទេ។"
                                : "No server snapshots available yet."}
                            </p>
                            <p className="text-[11px] text-slate-500 mt-1">
                              {adminLang === "km"
                                ? "សូមចុចប៊ូតុង 'បង្កើត Snapshot' ខាងលើដើម្បីរក្សាទុកស្ថានភាពដំបូង"
                                : "Click 'Create Snapshot Now' above to save the current state."}
                            </p>
                          </td>
                        </tr>
                      ) : (
                        snapshots.map((snap) => (
                          <tr key={snap.filename} className="hover:bg-slate-900/40 transition-colors">
                            <td className="p-4">
                              <div className="font-mono text-cyan-300 font-semibold text-xs truncate max-w-xs">
                                {snap.filename}
                              </div>
                              {snap.tag && (
                                <span className="inline-block mt-1 px-2 py-0.5 rounded-md bg-cyan-950 border border-cyan-800 text-[10px] text-cyan-300 font-semibold">
                                  #{snap.tag}
                                </span>
                              )}
                            </td>
                            <td className="p-4 text-slate-300 text-[11px] whitespace-nowrap">
                              {new Date(snap.createdAt).toLocaleString()}
                            </td>
                            <td className="p-4 text-slate-400 font-mono text-[11px]">
                              {(snap.sizeBytes / 1024).toFixed(1)} KB
                            </td>
                            <td className="p-4">
                              {snap.stats ? (
                                <div className="flex flex-wrap gap-1 text-[10px]">
                                  <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                                    {snap.stats.productsCount} products
                                  </span>
                                  <span className="px-1.5 py-0.5 rounded bg-slate-800 text-emerald-300">
                                    {snap.stats.postsCount} posts
                                  </span>
                                  <span className="px-1.5 py-0.5 rounded bg-slate-800 text-rose-300">
                                    {snap.stats.ordersCount} orders
                                  </span>
                                  <span className="px-1.5 py-0.5 rounded bg-slate-800 text-amber-300">
                                    {snap.stats.subscribersCount} subs
                                  </span>
                                </div>
                              ) : (
                                <span className="text-slate-500 text-[11px]">Verified Archive</span>
                              )}
                            </td>
                            <td className="p-4 text-right whitespace-nowrap">
                              <div className="inline-flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => handleDownloadSnapshot(snap.filename)}
                                  className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer text-[11px] font-bold inline-flex items-center gap-1"
                                  title="Download File"
                                >
                                  <Download className="w-3.5 h-3.5 text-cyan-400" />
                                  <span className="hidden sm:inline">Download</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleOpenRestoreSnapshotModal(snap)}
                                  className="px-2.5 py-1.5 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/40 text-emerald-300 hover:text-white transition-colors cursor-pointer text-[11px] font-bold inline-flex items-center gap-1"
                                  title="Restore snapshot"
                                >
                                  <RotateCcw className="w-3.5 h-3.5" />
                                  <span>{adminLang === "km" ? "ស្តារ" : "Restore"}</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleDeleteSnapshot(snap.filename)}
                                  className="p-1.5 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-300 hover:text-white transition-colors cursor-pointer"
                                  title="Delete snapshot"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB: STORAGE & MEDIA LIBRARY */}
        {activeTab === "storage" && (
          <div className="space-y-8">
            {/* Header & Quick Action */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-black text-white flex items-center gap-2.5">
                  <FolderOpen className="w-7 h-7 text-purple-400" />
                  <span>
                    {adminLang === "km"
                      ? "ប្រព័ន្ធផ្ទុកឯកសារ & រូបភាព (Storage & Media Library)"
                      : "Storage & Media Library"}
                  </span>
                </h1>
                <p className="text-xs sm:text-sm text-slate-400 mt-1">
                  {adminLang === "km"
                    ? "ផ្ទុកឡើងរូបភាព (JPG, PNG, WebP, SVG, GIF) ឬឯកសារ (PDF, ZIP, JSON) រក្សាទុកជាអចិន្ត្រៃយ៍លើ Server Host (.data/uploads/)"
                    : "Upload images and files directly to host storage (.data/uploads/). Instant live URLs accessible at /uploads/<filename>."}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <label className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-purple-600/30 transition-all cursor-pointer hover:scale-105">
                  <UploadCloud className="w-4 h-4" />
                  <span>{uploadingMedia ? (adminLang === "km" ? "កំពុង Upload..." : "Uploading...") : (adminLang === "km" ? "Upload ឯកសារថ្មី" : "Upload New File")}</span>
                  <input
                    type="file"
                    multiple
                    disabled={uploadingMedia}
                    className="hidden"
                    onChange={(e) => {
                      const files = e.target.files;
                      if (!files || files.length === 0) return;
                      Array.from(files).forEach((f) => handleUploadMediaFile(f));
                      e.target.value = "";
                    }}
                  />
                </label>

                <button
                  type="button"
                  onClick={loadMediaFiles}
                  disabled={loadingMedia}
                  className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title="Refresh Files"
                >
                  <RefreshCw className={`w-4 h-4 ${loadingMedia ? "animate-spin text-purple-400" : ""}`} />
                </button>
              </div>
            </div>

            {/* Drag & Drop Upload Zone */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                e.stopPropagation();
              }}
              onDrop={(e) => {
                e.preventDefault();
                e.stopPropagation();
                const files = e.dataTransfer.files;
                if (!files || files.length === 0) return;
                Array.from(files).forEach((f) => handleUploadMediaFile(f));
              }}
              className="relative border-2 border-dashed border-purple-500/40 hover:border-purple-400 rounded-3xl p-8 text-center bg-gradient-to-b from-[#0a1426] to-[#040c1a] transition-all group overflow-hidden shadow-xl"
            >
              <input
                type="file"
                multiple
                disabled={uploadingMedia}
                onChange={(e) => {
                  const files = e.target.files;
                  if (!files || files.length === 0) return;
                  Array.from(files).forEach((f) => handleUploadMediaFile(f));
                  e.target.value = "";
                }}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              />

              <div className="flex flex-col items-center gap-3 pointer-events-none">
                <div className="w-16 h-16 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform shadow-lg">
                  {uploadingMedia ? (
                    <Loader2 className="w-8 h-8 animate-spin" />
                  ) : (
                    <UploadCloud className="w-8 h-8" />
                  )}
                </div>

                <div className="space-y-1">
                  <h3 className="text-base font-bold text-white">
                    {uploadingMedia
                      ? adminLang === "km"
                        ? "កំពុងរក្សាទុកឯកសារលើ Server Storage..."
                        : "Uploading & securing file on host volume..."
                      : adminLang === "km"
                      ? "ទាញទម្លាក់ឯកសារនៅទីនេះ ឬចុចដើម្បីជ្រើសរើស"
                      : "Drag & drop files here, or click to browse"}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {adminLang === "km"
                      ? "គាំទ្ររូបភាព WebP, PNG, JPG, SVG, GIF និងឯកសារ PDF, ZIP, JSON, TXT (រហូតដល់ 15MB ក្នុងមួយឯកសារ)"
                      : "Supports images (WebP, PNG, JPG, SVG, GIF) and documents (PDF, ZIP, JSON, TXT) up to 15MB"}
                  </p>
                </div>

                {/* Storage Tags */}
                <div className="flex flex-wrap items-center justify-center gap-2 pt-2 text-[10px]">
                  <span className="px-2.5 py-1 rounded-full bg-slate-900 border border-slate-700 text-slate-300 font-mono">
                    Max: 15MB
                  </span>
                  <span className="px-2.5 py-1 rounded-full bg-slate-900 border border-slate-700 text-purple-300 font-mono">
                    Auto-Rename Safe Slugs
                  </span>
                  <span className="px-2.5 py-1 rounded-full bg-slate-900 border border-slate-700 text-cyan-300 font-mono">
                    Host Volume: .data/uploads/
                  </span>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 font-semibold">
                    ✓ Cache-Optimized
                  </span>
                </div>
              </div>
            </div>

            {/* Storage Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 sm:gap-4">
              <div className="p-4 sm:p-5 rounded-2xl bg-[#061528] border border-slate-800">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                  {adminLang === "km" ? "ឯកសារសរុប" : "Total Files"}
                </span>
                <p className="text-2xl sm:text-3xl font-black text-white mt-1">
                  {mediaFiles.length}
                </p>
                <span className="text-[10px] text-slate-500 mt-1 block">In .data/uploads/</span>
              </div>

              <div className="p-4 sm:p-5 rounded-2xl bg-[#061528] border border-slate-800">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                  {adminLang === "km" ? "រូបភាព" : "Images"}
                </span>
                <p className="text-2xl sm:text-3xl font-black text-purple-400 mt-1">
                  {mediaFiles.filter((f) => f.isImage).length}
                </p>
                <span className="text-[10px] text-purple-300/80 mt-1 block">JPG, PNG, WebP, SVG</span>
              </div>

              <div className="p-4 sm:p-5 rounded-2xl bg-[#061528] border border-slate-800">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                  {adminLang === "km" ? "ឯកសារផ្សេងៗ" : "Documents & Archives"}
                </span>
                <p className="text-2xl sm:text-3xl font-black text-cyan-400 mt-1">
                  {mediaFiles.filter((f) => !f.isImage).length}
                </p>
                <span className="text-[10px] text-cyan-300/80 mt-1 block">PDF, ZIP, JSON, TXT</span>
              </div>

              <div className="p-4 sm:p-5 rounded-2xl bg-[#061528] border border-slate-800">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                  {adminLang === "km" ? "ទំហំផ្ទុកសរុប" : "Storage Used"}
                </span>
                <p className="text-2xl sm:text-3xl font-black text-emerald-400 mt-1 font-mono">
                  {(() => {
                    const totalBytes = mediaFiles.reduce((acc, f) => acc + f.sizeBytes, 0);
                    if (totalBytes < 1024 * 1024) {
                      return `${(totalBytes / 1024).toFixed(1)} KB`;
                    }
                    return `${(totalBytes / (1024 * 1024)).toFixed(2)} MB`;
                  })()}
                </p>
                <span className="text-[10px] text-emerald-300/80 mt-1 block">Host Persistent Disk</span>
              </div>
            </div>

            {/* Filter and Search Bar */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
              <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900 border border-slate-800">
                <button
                  type="button"
                  onClick={() => setMediaFilter("all")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    mediaFilter === "all"
                      ? "bg-purple-600 text-white shadow-sm"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {adminLang === "km" ? "ទាំងអស់" : "All"} ({mediaFiles.length})
                </button>
                <button
                  type="button"
                  onClick={() => setMediaFilter("images")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    mediaFilter === "images"
                      ? "bg-purple-600 text-white shadow-sm"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {adminLang === "km" ? "រូបភាព" : "Images"} ({mediaFiles.filter((f) => f.isImage).length})
                </button>
                <button
                  type="button"
                  onClick={() => setMediaFilter("files")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    mediaFilter === "files"
                      ? "bg-purple-600 text-white shadow-sm"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {adminLang === "km" ? "ឯកសារ" : "Files"} ({mediaFiles.filter((f) => !f.isImage).length})
                </button>
              </div>

              <div className="relative max-w-sm w-full">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  placeholder={adminLang === "km" ? "ស្វែងរកឈ្មោះឯកសារ..." : "Search files by name..."}
                  value={mediaSearch}
                  onChange={(e) => {
                    setMediaSearch(e.target.value);
                    setMediaPage(1);
                  }}
                  className="w-full pl-10 pr-4 py-2 rounded-xl bg-[#061528] border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>
            </div>

            {/* Media Grid */}
            {(() => {
              const filtered = mediaFiles.filter((f) => {
                if (mediaFilter === "images" && !f.isImage) return false;
                if (mediaFilter === "files" && f.isImage) return false;
                if (mediaSearch.trim() && !f.name.toLowerCase().includes(mediaSearch.toLowerCase())) {
                  return false;
                }
                return true;
              });

              if (filtered.length === 0) {
                return (
                  <div className="rounded-3xl bg-[#061528] border border-slate-800 p-12 text-center text-slate-500">
                    <FolderOpen className="w-12 h-12 text-slate-600 mx-auto mb-3 opacity-50" />
                    <p className="text-sm font-bold text-slate-300">
                      {adminLang === "km"
                        ? "មិនមានឯកសារដែលត្រូវនឹងការស្វែងរកឡើយ"
                        : "No files found matching your filter."}
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      {adminLang === "km"
                        ? "សូមផ្ទុកឡើងឯកសារថ្មីដោយទាញទម្លាក់ក្នុងប្រអប់ខាងលើ"
                        : "Upload a file using the dropzone above to get started."}
                    </p>
                  </div>
                );
              }

              const pagedMedia = filtered.slice((mediaPage - 1) * 12, mediaPage * 12);

              return (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                    {pagedMedia.map((file) => (
                      <div
                        key={file.name}
                        className="group rounded-2xl bg-[#061528] border border-slate-800 hover:border-purple-500/50 hover:bg-[#081a32] overflow-hidden transition-all flex flex-col justify-between shadow-lg"
                      >
                        {/* Thumbnail Container */}
                        <div className="relative aspect-square w-full bg-slate-950 overflow-hidden flex items-center justify-center">
                          {file.isImage ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img
                              src={file.url}
                              alt={file.name}
                              loading="lazy"
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                          ) : (
                            <div className="flex flex-col items-center gap-2 p-4 text-center">
                              <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                                {file.name.endsWith(".pdf") ? (
                                  <FileText className="w-6 h-6 text-red-400" />
                                ) : file.name.endsWith(".zip") ? (
                                  <FileArchive className="w-6 h-6 text-amber-400" />
                                ) : (
                                  <FileIcon className="w-6 h-6 text-cyan-400" />
                                )}
                              </div>
                              <span className="text-[10px] font-mono uppercase font-bold text-slate-400">
                                {file.name.split(".").pop()}
                              </span>
                            </div>
                          )}

                          {/* Top Badge: Extension */}
                          <div className="absolute top-2 left-2 px-1.5 py-0.5 rounded-md bg-black/70 backdrop-blur text-[10px] font-mono text-purple-300 uppercase font-bold">
                            {file.name.split(".").pop()}
                          </div>

                          {/* Hover Overlay: Quick Actions */}
                          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 p-2">
                            <button
                              type="button"
                              onClick={() => handleCopyMediaUrl(file.url)}
                              className="p-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white shadow-lg cursor-pointer transition-transform hover:scale-110"
                              title="Copy URL"
                            >
                              {copiedMediaUrl === file.url ? (
                                <Check className="w-4 h-4 text-emerald-300" />
                              ) : (
                                <Copy className="w-4 h-4" />
                              )}
                            </button>
                            <Link
                              href={file.url}
                              target="_blank"
                              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white shadow-lg transition-transform hover:scale-110"
                              title="Open in new tab"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </Link>
                            <button
                              type="button"
                              onClick={() => handleDeleteMediaFile(file.name)}
                              className="p-2 rounded-xl bg-red-600/80 hover:bg-red-600 text-white shadow-lg cursor-pointer transition-transform hover:scale-110"
                              title="Delete file"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        {/* File Details */}
                        <div className="p-3 space-y-1.5">
                          <p
                            className="text-xs font-bold text-white truncate"
                            title={file.name}
                          >
                            {file.name}
                          </p>
                          <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                            <span>
                              {file.sizeBytes < 1024 * 1024
                                ? `${(file.sizeBytes / 1024).toFixed(0)} KB`
                                : `${(file.sizeBytes / (1024 * 1024)).toFixed(1)} MB`}
                            </span>
                            <span>{new Date(file.createdAt).toLocaleDateString()}</span>
                          </div>

                          {/* Copy URL Pill Button */}
                          <button
                            type="button"
                            onClick={() => handleCopyMediaUrl(file.url)}
                            className="w-full mt-1 py-1.5 px-2 rounded-lg bg-slate-900 hover:bg-purple-950/60 border border-slate-800 hover:border-purple-500/40 text-[10px] text-purple-300 hover:text-white font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                          >
                            {copiedMediaUrl === file.url ? (
                              <>
                                <Check className="w-3 h-3 text-emerald-400" />
                                <span className="text-emerald-400">Copied URL!</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                <span>Copy URL</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                  {renderPagination(mediaPage, filtered.length, 12, setMediaPage)}
                </div>
              );
            })()}
          </div>
        )}

        {/* TAB: ADS & EVENTS POPUP */}
        {activeTab === "ads" && settings && (
          <form onSubmit={handleSaveSettings} className="space-y-8 max-w-5xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-black text-white flex items-center gap-2.5">
                  <Megaphone className="w-7 h-7 text-rose-500" />
                  <span>{adminLang === "km" ? "ផ្ទាំងផ្សាយពាណិជ្ជកម្ម & Popup" : "Ads & Event Popups"}</span>
                </h1>
                <p className="text-xs sm:text-sm text-slate-400 mt-1">
                  {adminLang === "km"
                    ? "កំណត់ការប្រកាសព្រឹត្តិការណ៍ពិសេសនៅលើ Header (ដូចជា ចូលឆ្នាំខ្មែរ) និងផ្ទាំង Ads Popup នៅលើអេក្រង់"
                    : "Configure festive announcement banners on the header and promotional popups on screen."}
                </p>
              </div>

              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-cyan-600/30 flex items-center gap-2 cursor-pointer self-start sm:self-auto"
              >
                <Save className="w-4 h-4" />
                <span>{adminLang === "km" ? "រក្សាទុកការផ្លាស់ប្តូរ" : "Save Changes"}</span>
              </button>
            </div>

            {/* SECTION 1: HEADER ANNOUNCEMENT BANNER */}
            <div className="rounded-2xl bg-[#061528] border border-slate-800 p-6 space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div>
                  <h3 className="text-sm font-bold text-rose-400 uppercase tracking-wider flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    <span>Header Event Announcement Bar</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {adminLang === "km"
                      ? "របារប្រកាសព្រឹត្តិការណ៍ពិសេសនៅផ្នែកខាងលើគេហទំព័រ (Header Bar)"
                      : "Top announcement bar displayed above the navigation bar"}
                  </p>
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <span className="text-xs text-slate-300 font-semibold">
                    {settings.headerBannerActive ? (adminLang === "km" ? "បើកដំណើរការ" : "Active") : (adminLang === "km" ? "បិទ" : "Disabled")}
                  </span>
                  <input
                    type="checkbox"
                    checked={settings.headerBannerActive ?? true}
                    onChange={(e) => setSettings({ ...settings, headerBannerActive: e.target.checked })}
                    className="w-5 h-5 rounded text-rose-600 bg-slate-900 border-slate-700 focus:ring-0 cursor-pointer"
                  />
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Badge Label (Khmer)</label>
                  <input
                    type="text"
                    placeholder="ឧ. 🎉 ព្រឹត្តិការណ៍ពិសេស"
                    value={settings.headerBannerBadgeKm || ""}
                    onChange={(e) => setSettings({ ...settings, headerBannerBadgeKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Badge Label (English)</label>
                  <input
                    type="text"
                    placeholder="e.g. 🎉 SPECIAL EVENT"
                    value={settings.headerBannerBadgeEn || ""}
                    onChange={(e) => setSettings({ ...settings, headerBannerBadgeEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Banner Announcement Text (Khmer) *</label>
                  <input
                    type="text"
                    placeholder="ឧ. អបអរសាទរពិធីបុណ្យចូលឆ្នាំថ្មីប្រពៃណីជាតិខ្មែរ! បញ្ចុះតម្លៃ 20%..."
                    value={settings.headerBannerTextKm || ""}
                    onChange={(e) => setSettings({ ...settings, headerBannerTextKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Banner Announcement Text (English) *</label>
                  <input
                    type="text"
                    placeholder="e.g. Happy Khmer New Year! Enjoy 20% OFF all Web Development & Cloud Hosting..."
                    value={settings.headerBannerTextEn || ""}
                    onChange={(e) => setSettings({ ...settings, headerBannerTextEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300">Target Link URL (When clicked)</label>
                <input
                  type="text"
                  placeholder="/pricing"
                  value={settings.headerBannerLink || ""}
                  onChange={(e) => setSettings({ ...settings, headerBannerLink: e.target.value })}
                  className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                />
              </div>

              {/* Preview */}
              <div className="mt-4 pt-4 border-t border-slate-800">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Live Header Banner Preview:</span>
                <div className="mt-2 rounded-xl bg-gradient-to-r from-red-600 via-amber-600 to-rose-600 text-white text-xs font-bold py-2.5 px-4 flex items-center justify-between shadow-lg">
                  <div className="flex items-center gap-2 truncate">
                    <span className="px-2 py-0.5 rounded-full text-[10px] uppercase bg-black/30 border border-white/20 text-yellow-300 font-black">
                      {settings.headerBannerBadgeKm || "🎉 ព្រឹត្តិការណ៍"}
                    </span>
                    <span className="truncate">
                      {settings.headerBannerTextKm || "អបអរសាទរពិធីបុណ្យចូលឆ្នាំថ្មីប្រពៃណីជាតិខ្មែរ!"}
                    </span>
                  </div>
                  <ExternalLink className="w-3.5 h-3.5 text-yellow-200 shrink-0" />
                </div>
              </div>
            </div>

            {/* SECTION 2: SCREEN PROMOTIONAL POPUP */}
            <div className="rounded-2xl bg-[#061528] border border-slate-800 p-6 space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div>
                  <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                    <Megaphone className="w-4 h-4" />
                    <span>Screen Promotional Ads Popup</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {adminLang === "km"
                      ? "ផ្ទាំង Ads Popup លោតលើអេក្រង់ពេលភ្ញៀវចូលមកកាន់គេហទំព័រ"
                      : "Promotional modal popup shown to visitors on screen"}
                  </p>
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <span className="text-xs text-slate-300 font-semibold">
                    {settings.popupActive ? (adminLang === "km" ? "បើកដំណើរការ" : "Active") : (adminLang === "km" ? "បិទ" : "Disabled")}
                  </span>
                  <input
                    type="checkbox"
                    checked={settings.popupActive ?? false}
                    onChange={(e) => setSettings({ ...settings, popupActive: e.target.checked })}
                    className="w-5 h-5 rounded text-cyan-600 bg-slate-900 border-slate-700 focus:ring-0 cursor-pointer"
                  />
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Popup Badge Label (Khmer)</label>
                  <input
                    type="text"
                    placeholder="🎁 កាដូពិសេស"
                    value={settings.popupBadgeKm || ""}
                    onChange={(e) => setSettings({ ...settings, popupBadgeKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Popup Badge Label (English)</label>
                  <input
                    type="text"
                    placeholder="🎁 SPECIAL OFFER"
                    value={settings.popupBadgeEn || ""}
                    onChange={(e) => setSettings({ ...settings, popupBadgeEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Popup Title (Khmer)</label>
                  <input
                    type="text"
                    placeholder="ទទួលកាដូពិសេសពី Broteach!"
                    value={settings.popupTitleKm || ""}
                    onChange={(e) => setSettings({ ...settings, popupTitleKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Popup Title (English)</label>
                  <input
                    type="text"
                    placeholder="Get a Special Gift from Broteach!"
                    value={settings.popupTitleEn || ""}
                    onChange={(e) => setSettings({ ...settings, popupTitleEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Popup Description (Khmer)</label>
                  <textarea
                    rows={3}
                    placeholder="បង្កើតគេហទំព័រអាជីវកម្មថ្ងៃនេះ ទទួលបាន Free Domain .com..."
                    value={settings.popupDescKm || ""}
                    onChange={(e) => setSettings({ ...settings, popupDescKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Popup Description (English)</label>
                  <textarea
                    rows={3}
                    placeholder="Build your business website today and receive a Free .com Domain..."
                    value={settings.popupDescEn || ""}
                    onChange={(e) => setSettings({ ...settings, popupDescEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-1">
                  <label className="text-xs font-semibold text-slate-300">Popup Image URL (Optional)</label>
                  <input
                    type="text"
                    placeholder="https://... or /uploads/..."
                    value={settings.popupImageUrl || ""}
                    onChange={(e) => setSettings({ ...settings, popupImageUrl: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
                <div className="sm:col-span-1">
                  <label className="text-xs font-semibold text-slate-300">Button Text (Khmer / English)</label>
                  <input
                    type="text"
                    placeholder="ពិនិត្យកញ្ចប់តម្លៃ / Check Pricing"
                    value={settings.popupButtonTextKm || ""}
                    onChange={(e) => setSettings({ ...settings, popupButtonTextKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
                <div className="sm:col-span-1">
                  <label className="text-xs font-semibold text-slate-300">Button Target URL</label>
                  <input
                    type="text"
                    placeholder="/pricing"
                    value={settings.popupButtonUrl || ""}
                    onChange={(e) => setSettings({ ...settings, popupButtonUrl: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-slate-800/80">
                <div className="sm:col-span-1">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{adminLang === "km" ? "IP Cooldown (បង្ហាញម្ដងទៀតរៀងរាល់ - នាទី)" : "IP Cooldown (Show again every - Minutes)"}</span>
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="1440"
                    placeholder="30"
                    value={settings.popupCooldownMinutes ?? 30}
                    onChange={(e) => setSettings({ ...settings, popupCooldownMinutes: parseInt(e.target.value, 10) || 30 })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:border-cyan-500 focus:outline-none"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    {adminLang === "km" ? "កំណត់ពេលភ្ញៀវចូលមើលម្ដងទៀត (Default: 30 នាទី)" : "Cooldown interval per browser/IP (Default: 30 mins)"}
                  </p>
                </div>

                <div className="sm:col-span-1">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    <span>{adminLang === "km" ? "Auto-Close Delay (បិទដោយខ្លួនឯង - វិនាទី)" : "Auto-Close Delay (Seconds)"}</span>
                  </label>
                  <input
                    type="number"
                    min="2"
                    max="60"
                    placeholder="5"
                    value={settings.popupAutoCloseSeconds ?? 5}
                    onChange={(e) => setSettings({ ...settings, popupAutoCloseSeconds: parseInt(e.target.value, 10) || 5 })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:border-cyan-500 focus:outline-none"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    {adminLang === "km" ? "ផ្ទាំង Popup នឹងបិទដោយស្វ័យប្រវត្តិ (Default: 5 វិនាទី)" : "Popup will close by itself after (Default: 5s)"}
                  </p>
                </div>

                <div className="sm:col-span-1">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-indigo-400" />
                    <span>{adminLang === "km" ? "Scroll Trigger (ចម្ងាយ Scroll ចុះក្រោម - px)" : "Scroll Trigger Distance (px)"}</span>
                  </label>
                  <input
                    type="number"
                    min="50"
                    max="2000"
                    placeholder="200"
                    value={settings.popupTriggerScrollPx ?? 200}
                    onChange={(e) => setSettings({ ...settings, popupTriggerScrollPx: parseInt(e.target.value, 10) || 200 })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:border-cyan-500 focus:outline-none"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    {adminLang === "km" ? "បង្ហាញពេលភ្ញៀវ Scroll ចុះក្រោម (Default: 200px)" : "Pops up when visitor scrolls down (Default: 200px)"}
                  </p>
                </div>
              </div>
            </div>
          </form>
        )}

        {/* TAB: TRASH & RECYCLE BIN (7-DAY RETENTION) */}
        {activeTab === "trash" && (
          <div className="space-y-6 max-w-5xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-black text-white flex items-center gap-2.5">
                  <Trash className="w-7 h-7 text-amber-500" />
                  <span>{adminLang === "km" ? "ធុងសម្រាម (Trash & Recycle Bin)" : "Trash & Recycle Bin"}</span>
                </h1>
                <p className="text-xs sm:text-sm text-slate-400 mt-1">
                  {adminLang === "km"
                    ? "រាល់ទិន្នន័យដែលបានលុប ត្រូវបានរក្សាទុកចំនួន 7 ថ្ងៃ មុនពេលលុបស្វ័យប្រវត្តិ។ អ្នកអាច Restore ឬ Empty បានគ្រប់ពេល។"
                    : "Deleted items are safely retained for 7 days before auto-purge. You can restore or permanently empty them anytime."}
                </p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={loadTrashItems}
                  disabled={loadingTrash}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white border border-slate-700 text-xs font-semibold flex items-center gap-1.5"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingTrash ? "animate-spin text-cyan-400" : ""}`} />
                  <span>{adminLang === "km" ? "ផ្ទុកឡើងវិញ" : "Refresh"}</span>
                </button>
                {trashItems.length > 0 && (
                  <button
                    type="button"
                    onClick={handleEmptyTrash}
                    className="px-4 py-2 rounded-xl bg-red-950/60 border border-red-500/50 text-red-300 hover:bg-red-900/60 hover:text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-lg shadow-red-950/40"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{adminLang === "km" ? "សម្អាតធុងសម្រាមទាំងអស់" : "Empty Trash"}</span>
                  </button>
                )}
              </div>
            </div>

            {/* Retention Notice Box */}
            <div className="rounded-2xl bg-amber-950/20 border border-amber-500/30 p-4 flex items-start gap-3">
              <Clock className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div className="text-xs text-amber-200/90 leading-relaxed">
                <strong>{adminLang === "km" ? "គោលការណ៍រក្សាទុក 7 ថ្ងៃ (7-Day Auto-Retention):" : "7-Day Auto-Retention Policy:"}</strong>{" "}
                {adminLang === "km"
                  ? "នៅពេលអ្នកលុប អត្ថបទ, ផលិតផល, ផ្នែក, ឬឯកសារណាមួយ ប្រព័ន្ធនឹងទុកក្នុងធុងសម្រាមនេះ ៧ ថ្ងៃ។ ប្រសិនបើហួស ៧ ថ្ងៃ ប្រព័ន្ធនឹងសម្អាតចោលស្វ័យប្រវត្តិ។"
                  : "When you delete any article, product, section, or file, it stays here for 7 days. If not restored within 7 days, it is automatically purged."}
              </div>
            </div>

            {/* Trash List */}
            {trashItems.length === 0 ? (
              <div className="rounded-2xl bg-[#061528] border border-slate-800 p-12 text-center">
                <Trash className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                <h3 className="text-base font-bold text-white mb-1">
                  {adminLang === "km" ? "គ្មានទិន្នន័យក្នុងធុងសម្រាមទេ" : "Trash is empty"}
                </h3>
                <p className="text-xs text-slate-400">
                  {adminLang === "km" ? "គ្មានទិន្នន័យដែលបានលុបក្នុងរយៈពេល ៧ ថ្ងៃកន្លងមកនេះឡើយ" : "No deleted items in the past 7 days."}
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="space-y-3">
                  {trashItems
                    .slice((trashPage - 1) * 8, trashPage * 8)
                    .map((item) => {
                      const daysLeft = Math.max(
                        0,
                        Math.ceil((new Date(item.expiresAt).getTime() - mountTime) / (1000 * 60 * 60 * 24))
                      );
                      return (
                          <div
                        key={item.id}
                        className="rounded-2xl bg-[#061528] border border-slate-800 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-slate-700 transition-colors"
                      >
                        <div className="space-y-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-800 text-cyan-300 border border-cyan-500/30">
                              {item.itemType}
                            </span>
                            <span className="text-xs text-slate-400 font-mono">
                              {new Date(item.deletedAt).toLocaleString("km-KH")}
                            </span>
                          </div>
                          <h4 className="text-sm font-bold text-white truncate max-w-lg">
                            {item.title}
                          </h4>
                          <div className="flex items-center gap-1.5 text-[11px] text-amber-400/90 font-medium">
                            <Clock className="w-3 h-3" />
                            <span>
                              {adminLang === "km"
                                ? `នៅសល់ ${daysLeft} ថ្ងៃទៀត នឹងត្រូវលុបស្វ័យប្រវត្តិ`
                                : `Auto-deletes in ${daysLeft} day(s)`}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleRestoreFromTrash(item.id)}
                            className="px-3.5 py-1.5 rounded-xl bg-cyan-600/30 hover:bg-cyan-600 border border-cyan-500/40 text-cyan-300 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                          >
                            <Undo2 className="w-3.5 h-3.5" />
                            <span>{adminLang === "km" ? "ស្តារឡើងវិញ (Restore)" : "Restore"}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDeletePermanentTrash(item.id)}
                            className="px-3 py-1.5 rounded-xl bg-red-950/40 hover:bg-red-900/60 border border-red-500/30 text-red-300 hover:text-white text-xs font-semibold transition-all cursor-pointer"
                            title="Delete Permanently"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
                {renderPagination(trashPage, trashItems.length, 8, setTrashPage)}
              </div>
            )}
          </div>
        )}

        {/* TAB: TELEGRAM BOT INTEGRATION */}
        {activeTab === "telegram" && settings && (
          <form onSubmit={handleSaveSettings} className="space-y-6 max-w-4xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-black text-white flex items-center gap-2.5">
                  <Send className="w-7 h-7 text-sky-400" />
                  <span>{adminLang === "km" ? "កំណត់ Telegram Bot" : "Telegram Bot Integration"}</span>
                </h1>
                <p className="text-xs sm:text-sm text-slate-400 mt-1">
                  {adminLang === "km"
                    ? "ភ្ជាប់ Telegram Bot ដើម្បីទទួលបានការជូនដំណឹងស្វ័យប្រវត្តិនូវរាល់ពេលមានអតិថិជនកុម្ម៉ង់ទិញ"
                    : "Connect your Telegram Bot to receive automated instant alerts whenever a new order is placed."}
                </p>
              </div>

              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-cyan-600/30 flex items-center gap-2 cursor-pointer self-start sm:self-auto"
              >
                <Save className="w-4 h-4" />
                <span>{adminLang === "km" ? "រក្សាទុកការកំណត់" : "Save Settings"}</span>
              </button>
            </div>

            {/* Test Status Banner if triggered */}
            {telegramTestStatus && (
              <div
                className={`p-4 rounded-2xl border flex items-start gap-3 ${
                  telegramTestStatus.success
                    ? "bg-emerald-950/40 border-emerald-500/50 text-emerald-200"
                    : "bg-red-950/40 border-red-500/50 text-red-200"
                }`}
              >
                {telegramTestStatus.success ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                )}
                <div className="text-xs leading-relaxed font-semibold">
                  {telegramTestStatus.message}
                </div>
              </div>
            )}

            <div className="rounded-2xl bg-[#061528] border border-slate-800 p-6 space-y-6">
              <h3 className="text-sm font-bold text-sky-400 uppercase tracking-wider">
                Telegram Credentials
              </h3>

              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-300">
                      Telegram Bot Token *
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowTokenSecret(!showTokenSecret)}
                      className="text-[11px] text-cyan-400 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      {showTokenSecret ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      <span>{showTokenSecret ? (adminLang === "km" ? "លាក់" : "Hide") : (adminLang === "km" ? "បង្ហាញ" : "Show")}</span>
                    </button>
                  </div>
                  <input
                    type={showTokenSecret ? "text" : "password"}
                    placeholder="1234567890:ABCdefGhIJKlmNoPQRsTUVwxyZ..."
                    value={settings.telegramBotToken || ""}
                    onChange={(e) => setSettings({ ...settings, telegramBotToken: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm font-mono text-white placeholder-slate-600"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">
                    {adminLang === "km" ? "ទទួលបានពី @BotFather នៅលើ Telegram" : "Obtained from @BotFather on Telegram"}
                  </p>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300">
                    Telegram Chat ID / Channel ID *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 123456789 or -100123456789"
                    value={settings.telegramChatId || ""}
                    onChange={(e) => setSettings({ ...settings, telegramChatId: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm font-mono text-white placeholder-slate-600"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">
                    {adminLang === "km"
                      ? "Chat ID ផ្ទាល់ខ្លួនរបស់អ្នក ឬ Channel ID សម្រាប់ទទួលដំណឹង"
                      : "Your personal Telegram user ID or group/channel ID"}
                  </p>
                </div>
              </div>

              {/* Action Buttons: Test Button */}
              <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-xs text-slate-400">
                  {adminLang === "km"
                    ? "ចុចតេស្តដើម្បីផ្ញើសារសាកល្បងទៅកាន់ Telegram របស់អ្នកភ្លាមៗ"
                    : "Click test to send an instant verification message to your Telegram"}
                </div>

                <button
                  type="button"
                  onClick={handleTestTelegram}
                  disabled={telegramTesting}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-bold text-xs shadow-md shadow-sky-600/30 flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {telegramTesting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>{adminLang === "km" ? "កំពុងសាកល្បង..." : "Testing..."}</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>{adminLang === "km" ? "ផ្ញើសារតេស្ត (Test Telegram)" : "Test Telegram Notification"}</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Instructions Guide */}
            <div className="rounded-2xl bg-[#040f1d] border border-slate-800/80 p-6 space-y-3">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-300">
                {adminLang === "km" ? "📖 របៀបបង្កើត Telegram Bot ដោយឥតគិតថ្លៃ" : "📖 How to Setup Free Telegram Bot"}
              </h4>
              <ol className="text-xs text-slate-400 space-y-2 list-decimal list-inside leading-relaxed">
                <li>
                  {adminLang === "km" ? "បើកកម្មវិធី Telegram ហើយស្វែងរក" : "Open Telegram and search for"}{" "}
                  <strong className="text-sky-400">@BotFather</strong>.
                </li>
                <li>
                  {adminLang === "km" ? "ផ្ញើសារពាក្យ" : "Send command"}{" "}
                  <code className="bg-slate-900 px-1 py-0.5 rounded text-cyan-300">/newbot</code>{" "}
                  {adminLang === "km" ? "ហើយដាក់ឈ្មោះ Bot និង Username តាមការណែនាំ។" : "and choose a name and username."}
                </li>
                <li>
                  {adminLang === "km" ? "ចម្លងយក (Copy)" : "Copy the provided"}{" "}
                  <strong className="text-white">API Token</strong>{" "}
                  {adminLang === "km" ? "មកបិទភ្ជាប់ (Paste) ក្នុងប្រអប់ Telegram Bot Token ខាងលើ។" : "into the Bot Token field above."}
                </li>
                <li>
                  {adminLang === "km" ? "ស្វែងរក" : "Search for"}{" "}
                  <strong className="text-sky-400">@userinfobot</strong>{" "}
                  {adminLang === "km" ? "នៅលើ Telegram រួចចុច Start ដើម្បីទទួលបាន Chat ID លេខរបស់អ្នក។" : "to retrieve your numeric Chat ID."}
                </li>
                <li>
                  {adminLang === "km" ? "ចុចរក្សាទុក (Save) និងចុច 'ផ្ញើសារតេស្ត' ដើម្បីបញ្ចប់ការតភ្ជាប់!" : "Click Save Settings and Test Telegram Notification to verify!"}
                </li>
              </ol>
            </div>
          </form>
        )}
      </main>
    </div>

      {/* MODAL: ADD / EDIT PRODUCT */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-[#081527] border border-cyan-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h3 className="text-lg font-black text-white">
                {editingProduct.id
                  ? adminLang === "km"
                    ? "កែប្រែផលិតផល"
                    : "Edit Production"
                  : adminLang === "km"
                  ? "បន្ថែមផលិតផលថ្មី"
                  : "Add New Production"}
              </h3>
              <button
                onClick={() => setIsProductModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Title (Khmer) *</label>
                  <input
                    type="text"
                    required
                    value={editingProduct.titleKm || ""}
                    onChange={(e) => setEditingProduct({ ...editingProduct, titleKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Title (English) *</label>
                  <input
                    type="text"
                    required
                    value={editingProduct.titleEn || ""}
                    onChange={(e) => setEditingProduct({ ...editingProduct, titleEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
              </div>

              {/* Product Cover Image (thumbnailUrl) with Live Preview */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                    {adminLang === "km"
                      ? "រូបភាព Mockup / Banner ផលិតផល (Product Image URL)"
                      : "Product Mockup / Cover Image URL"}
                  </label>
                  <div className="flex items-center gap-2">
                    <label className="text-[10px] px-2.5 py-1 rounded-lg bg-purple-600/30 text-purple-300 hover:bg-purple-600 hover:text-white border border-purple-500/40 font-bold transition-all cursor-pointer flex items-center gap-1">
                      <UploadCloud className="w-3 h-3" />
                      <span>{uploadingDirect ? (adminLang === "km" ? "កំពុង Upload..." : "Uploading...") : (adminLang === "km" ? "Upload ពីរូបភាពកុំព្យូទ័រ" : "Upload File")}</span>
                      <input
                        type="file"
                        accept="image/*"
                        disabled={uploadingDirect}
                        className="hidden"
                        onChange={(e) => handleDirectUpload(e, "product")}
                      />
                    </label>

                    <button
                      type="button"
                      onClick={() => {
                        const sampleMockups = [
                          "https://images.unsplash.com/photo-1556742049-0a67c5574f73?w=1200&q=80",
                          "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&q=80",
                          "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200&q=80",
                          "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=1200&q=80",
                          "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=1200&q=80",
                          "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&q=80",
                        ];
                        const pick = sampleMockups[Math.floor(Math.random() * sampleMockups.length)];
                        setEditingProduct((prev) => ({ ...prev, thumbnailUrl: pick }));
                      }}
                      className="text-[10px] px-2.5 py-1 rounded-lg bg-cyan-600/30 text-cyan-300 hover:bg-cyan-600 hover:text-white border border-cyan-500/40 font-bold transition-all cursor-pointer"
                    >
                      Sample Mockup Image
                    </button>
                  </div>
                </div>

                <input
                  type="url"
                  placeholder="https://images.unsplash.com/... or your image link"
                  value={editingProduct.thumbnailUrl || ""}
                  onChange={(e) => setEditingProduct({ ...editingProduct, thumbnailUrl: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
                />

                {/* Live Preview Box */}
                {editingProduct.thumbnailUrl ? (
                  <div className="relative w-full h-44 rounded-xl overflow-hidden bg-slate-950 border border-cyan-500/30 shadow-inner">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={editingProduct.thumbnailUrl}
                      alt="Product Mockup Preview"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
                    <div className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-md bg-cyan-500 text-slate-950 text-[10px] font-black uppercase shadow-md">
                      Live Mockup Preview
                    </div>
                    <div className="absolute bottom-2.5 left-3 right-3 text-white">
                      <p className="text-xs font-bold truncate">{editingProduct.titleEn || editingProduct.titleKm}</p>
                      <p className="text-[10px] text-cyan-300">${editingProduct.price ?? 350}</p>
                    </div>
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-500 italic">
                    {adminLang === "km"
                      ? "បញ្ចូល Link រូបភាពខាងលើដើម្បីឱ្យបង្ហាញរូបភាព Mockup លើផ្ទាំង Popup ផលិតផល"
                      : "Enter an image URL above to display this mockup in the product detail popup."}
                  </p>
                )}
              </div>

              {/* Demo URL & Author */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">
                    Live Preview Demo URL (តំណភ្ជាប់ទស្សនាផ្ទាល់)
                  </label>
                  <input
                    type="url"
                    placeholder="https://demo.broteach.com/..."
                    value={editingProduct.demoUrl || ""}
                    onChange={(e) => setEditingProduct({ ...editingProduct, demoUrl: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300">
                    Developer / Author (អ្នកអភិវឌ្ឍន៍)
                  </label>
                  <input
                    type="text"
                    placeholder="Broteach"
                    value={editingProduct.author || ""}
                    onChange={(e) => setEditingProduct({ ...editingProduct, author: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              {/* Category Labels KM & EN */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Category Tag (Khmer)</label>
                  <input
                    type="text"
                    placeholder="E-Commerce / គេហទំព័រលក់ទំនិញ"
                    value={editingProduct.categoryLabelKm || ""}
                    onChange={(e) => setEditingProduct({ ...editingProduct, categoryLabelKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Category Tag (English)</label>
                  <input
                    type="text"
                    placeholder="E-Commerce / Web App"
                    value={editingProduct.categoryLabelEn || ""}
                    onChange={(e) => setEditingProduct({ ...editingProduct, categoryLabelEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Category</label>
                  <select
                    value={editingProduct.category}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        category: e.target.value as ProductItem["category"],
                      })
                    }
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white cursor-pointer"
                  >
                    <option value="ecommerce">E-Commerce</option>
                    <option value="webapp">Business Web App</option>
                    <option value="enterprise">Enterprise / LMS</option>
                    <option value="hosting">Cloud Hosting</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300">Price ($) *</label>
                  <input
                    type="number"
                    required
                    value={editingProduct.price ?? 350}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, price: Number(e.target.value) })
                    }
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-cyan-300 font-bold"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300">Icon</label>
                  <select
                    value={editingProduct.icon || "Briefcase"}
                    onChange={(e) => setEditingProduct({ ...editingProduct, icon: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white cursor-pointer"
                  >
                    <option value="Briefcase">Briefcase (Corporate)</option>
                    <option value="ShoppingBag">ShoppingBag (E-Commerce)</option>
                    <option value="Home">Home (Real Estate)</option>
                    <option value="GraduationCap">GraduationCap (Education)</option>
                    <option value="Utensils">Utensils (Restaurant/Cafe)</option>
                    <option value="Server">Server (Cloud VPS)</option>
                    <option value="Sparkles">Sparkles (General)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Badge (Khmer)</label>
                  <input
                    type="text"
                    value={editingProduct.badgeKm || ""}
                    onChange={(e) => setEditingProduct({ ...editingProduct, badgeKm: e.target.value })}
                    placeholder="ពេញនិយម / ថ្មី"
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Badge (English)</label>
                  <input
                    type="text"
                    value={editingProduct.badgeEn || ""}
                    onChange={(e) => setEditingProduct({ ...editingProduct, badgeEn: e.target.value })}
                    placeholder="Best Seller / New"
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Description (Khmer)</label>
                  <textarea
                    rows={2}
                    value={editingProduct.descKm || ""}
                    onChange={(e) => setEditingProduct({ ...editingProduct, descKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Description (English)</label>
                  <textarea
                    rows={2}
                    value={editingProduct.descEn || ""}
                    onChange={(e) => setEditingProduct({ ...editingProduct, descEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              {/* Dynamic Feature Bullets Builder */}
              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
                <label className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                  Features List (គុណសម្បត្តិ)
                </label>

                <div className="space-y-2">
                  {(editingProduct.featuresKm || []).map((fKm, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs">
                      <span className="w-5 h-5 rounded-full bg-cyan-950 text-cyan-400 flex items-center justify-center flex-shrink-0">
                        ✓
                      </span>
                      <span className="flex-1 text-slate-300 truncate">
                        {fKm} / {(editingProduct.featuresEn || [])[i] || ""}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          const fKmList = [...(editingProduct.featuresKm || [])];
                          const fEnList = [...(editingProduct.featuresEn || [])];
                          fKmList.splice(i, 1);
                          fEnList.splice(i, 1);
                          setEditingProduct({
                            ...editingProduct,
                            featuresKm: fKmList,
                            featuresEn: fEnList,
                          });
                        }}
                        className="text-red-400 hover:text-red-300 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-800">
                  <input
                    type="text"
                    placeholder="មុខងារ (KM)..."
                    value={newFeatureKm}
                    onChange={(e) => setNewFeatureKm(e.target.value)}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                  />
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Feature (EN)..."
                      value={newFeatureEn}
                      onChange={(e) => setNewFeatureEn(e.target.value)}
                      className="flex-1 px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (!newFeatureKm.trim() && !newFeatureEn.trim()) return;
                        setEditingProduct({
                          ...editingProduct,
                          featuresKm: [...(editingProduct.featuresKm || []), newFeatureKm.trim() || newFeatureEn.trim()],
                          featuresEn: [...(editingProduct.featuresEn || []), newFeatureEn.trim() || newFeatureKm.trim()],
                        });
                        setNewFeatureKm("");
                        setNewFeatureEn("");
                      }}
                      className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs"
                    >
                      Add
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <label className="flex items-center gap-2 text-xs text-white font-semibold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingProduct.isActive !== false}
                    onChange={(e) => setEditingProduct({ ...editingProduct, isActive: e.target.checked })}
                    className="w-4 h-4 rounded text-cyan-500"
                  />
                  <span>{adminLang === "km" ? "ដាក់ឱ្យដំណើរការ (Active)" : "Visible / Active"}</span>
                </label>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsProductModalOpen(false)}
                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-md cursor-pointer"
                  >
                    Save Production
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD / EDIT CONTENT SECTION */}
      {isSectionModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-[#081527] border border-indigo-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h3 className="text-lg font-black text-white">
                {editingSection.id
                  ? adminLang === "km"
                    ? "កែប្រែផ្នែកមាតិកា (Edit Section)"
                    : "Edit Content Section"
                  : adminLang === "km"
                  ? "បន្ថែមផ្នែកមាតិកាថ្មី (New Section)"
                  : "Add New Content Section"}
              </h3>
              <button
                onClick={() => setIsSectionModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSection} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Section Title (Khmer) *</label>
                  <input
                    type="text"
                    required
                    value={editingSection.titleKm || ""}
                    onChange={(e) => setEditingSection({ ...editingSection, titleKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Section Title (English) *</label>
                  <input
                    type="text"
                    required
                    value={editingSection.titleEn || ""}
                    onChange={(e) => setEditingSection({ ...editingSection, titleEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Subtitle (Khmer)</label>
                  <input
                    type="text"
                    value={editingSection.subtitleKm || ""}
                    onChange={(e) => setEditingSection({ ...editingSection, subtitleKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Subtitle (English)</label>
                  <input
                    type="text"
                    value={editingSection.subtitleEn || ""}
                    onChange={(e) => setEditingSection({ ...editingSection, subtitleEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Layout Type</label>
                  <select
                    value={editingSection.layoutType || "cards"}
                    onChange={(e) =>
                      setEditingSection({
                        ...editingSection,
                        layoutType: e.target.value as ContentSection["layoutType"],
                      })
                    }
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white cursor-pointer"
                  >
                    <option value="cards">Cards (Feature Cards Grid)</option>
                    <option value="faq">FAQ (Accordion Q&A)</option>
                    <option value="stats">Stats (Numbers & Metrics)</option>
                    <option value="banner">Banner (Call to action)</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300">Anchor ID (e.g. why-us)</label>
                  <input
                    type="text"
                    value={editingSection.anchorId || ""}
                    onChange={(e) => setEditingSection({ ...editingSection, anchorId: e.target.value })}
                    placeholder="e.g. why-us, faq"
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300">Badge (e.g. FAQ)</label>
                  <input
                    type="text"
                    value={editingSection.badgeKm || ""}
                    onChange={(e) => setEditingSection({ ...editingSection, badgeKm: e.target.value })}
                    placeholder="ចំណុចខ្លាំង"
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              {/* Items in Section */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
                    Items / Cards inside this Section ({editingSection.items?.length || 0})
                  </label>
                  <button
                    type="button"
                    onClick={handleAddSectionItem}
                    className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Item</span>
                  </button>
                </div>

                <div className="space-y-3">
                  {(editingSection.items || []).map((item, idx) => (
                    <div
                      key={item.id || idx}
                      className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-cyan-300">Item #{idx + 1}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveSectionItem(idx)}
                          className="text-red-400 hover:text-red-300 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <input
                          type="text"
                          placeholder="Title (KM)..."
                          value={item.titleKm}
                          onChange={(e) => handleUpdateSectionItem(idx, { titleKm: e.target.value })}
                          className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                        />
                        <input
                          type="text"
                          placeholder="Title (EN)..."
                          value={item.titleEn}
                          onChange={(e) => handleUpdateSectionItem(idx, { titleEn: e.target.value })}
                          className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <textarea
                          rows={2}
                          placeholder="Description (KM)..."
                          value={item.descKm}
                          onChange={(e) => handleUpdateSectionItem(idx, { descKm: e.target.value })}
                          className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                        />
                        <textarea
                          rows={2}
                          placeholder="Description (EN)..."
                          value={item.descEn}
                          onChange={(e) => handleUpdateSectionItem(idx, { descEn: e.target.value })}
                          className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <select
                          value={item.icon || "Sparkles"}
                          onChange={(e) => handleUpdateSectionItem(idx, { icon: e.target.value })}
                          className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white cursor-pointer"
                        >
                          <option value="Sparkles">Sparkles</option>
                          <option value="Zap">Zap (Speed)</option>
                          <option value="Smartphone">Smartphone (Mobile)</option>
                          <option value="ShieldCheck">ShieldCheck (Security)</option>
                          <option value="Star">Star</option>
                          <option value="Layers">Layers</option>
                          <option value="Globe">Globe</option>
                        </select>

                        <input
                          type="text"
                          placeholder="Badge..."
                          value={item.badgeKm || ""}
                          onChange={(e) => handleUpdateSectionItem(idx, { badgeKm: e.target.value })}
                          className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                        />

                        <input
                          type="text"
                          placeholder="Metric (e.g. < 0.8s)..."
                          value={item.metric || ""}
                          onChange={(e) => handleUpdateSectionItem(idx, { metric: e.target.value })}
                          className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-cyan-300"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <label className="flex items-center gap-2 text-xs text-white font-semibold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingSection.isActive !== false}
                    onChange={(e) => setEditingSection({ ...editingSection, isActive: e.target.checked })}
                    className="w-4 h-4 rounded text-indigo-500"
                  />
                  <span>{adminLang === "km" ? "ដាក់ឱ្យដំណើរការ (Active)" : "Visible on Website"}</span>
                </label>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsSectionModalOpen(false)}
                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md cursor-pointer"
                  >
                    Save Section
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD / EDIT PRICING PLAN */}
      {isPricingModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-[#081527] border border-cyan-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h3 className="text-lg font-black text-white">
                {editingPlan.id
                  ? adminLang === "km"
                    ? "កែប្រែគម្រោងតម្លៃ (Edit Pricing Plan)"
                    : "Edit Pricing Plan"
                  : adminLang === "km"
                  ? "បន្ថែមគម្រោងតម្លៃថ្មី (Add Pricing Plan)"
                  : "Add New Pricing Plan"}
              </h3>
              <button
                type="button"
                onClick={() => setIsPricingModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePricingPlan} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Plan Name (Khmer) *</label>
                  <input
                    type="text"
                    required
                    value={editingPlan.nameKm || ""}
                    onChange={(e) => setEditingPlan({ ...editingPlan, nameKm: e.target.value })}
                    placeholder="ឧ. ស្តង់ដារពាណិជ្ជកម្ម"
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Plan Name (English) *</label>
                  <input
                    type="text"
                    required
                    value={editingPlan.nameEn || ""}
                    onChange={(e) => setEditingPlan({ ...editingPlan, nameEn: e.target.value })}
                    placeholder="e.g. Business Pro"
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Price ($) *</label>
                  <input
                    type="number"
                    required
                    value={editingPlan.price ?? 49}
                    onChange={(e) => setEditingPlan({ ...editingPlan, price: Number(e.target.value) })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-cyan-300 font-bold"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Period (Khmer)</label>
                  <input
                    type="text"
                    value={editingPlan.periodKm || "/ខែ"}
                    onChange={(e) => setEditingPlan({ ...editingPlan, periodKm: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Period (English)</label>
                  <input
                    type="text"
                    value={editingPlan.periodEn || "/month"}
                    onChange={(e) => setEditingPlan({ ...editingPlan, periodEn: e.target.value })}
                    className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Theme Style</label>
                  <select
                    value={editingPlan.colorScheme || "red"}
                    onChange={(e) => setEditingPlan({ ...editingPlan, colorScheme: e.target.value as "red" | "silver" })}
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white cursor-pointer"
                  >
                    <option value="red">Red Accent (Highlighted Tier)</option>
                    <option value="silver">Silver Accent (Standard Tier)</option>
                  </select>
                </div>
                <div className="flex items-center pt-6">
                  <label className="flex items-center gap-2 text-xs text-white font-semibold cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingPlan.recommended === true}
                      onChange={(e) => setEditingPlan({ ...editingPlan, recommended: e.target.checked })}
                      className="w-4 h-4 rounded text-cyan-500"
                    />
                    <span>{adminLang === "km" ? "គម្រោងណែនាំ (Recommended Tier)" : "Mark as Recommended"}</span>
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Badge (Khmer)</label>
                  <input
                    type="text"
                    value={editingPlan.badgeKm || ""}
                    onChange={(e) => setEditingPlan({ ...editingPlan, badgeKm: e.target.value })}
                    placeholder="ពេញនិយម"
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Badge (English)</label>
                  <input
                    type="text"
                    value={editingPlan.badgeEn || ""}
                    onChange={(e) => setEditingPlan({ ...editingPlan, badgeEn: e.target.value })}
                    placeholder="Most Popular"
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300">Live Demo URL</label>
                  <input
                    type="text"
                    value={editingPlan.demoUrl || ""}
                    onChange={(e) => setEditingPlan({ ...editingPlan, demoUrl: e.target.value })}
                    placeholder="https://demo.broteach.com or https://t.me/broteach_support"
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-cyan-300 font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300">Order Telegram URL</label>
                  <input
                    type="text"
                    value={editingPlan.orderUrl || ""}
                    onChange={(e) => setEditingPlan({ ...editingPlan, orderUrl: e.target.value })}
                    placeholder="https://t.me/broteach_support"
                    className="w-full mt-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-cyan-300 font-mono"
                  />
                </div>
              </div>

              {/* Dynamic Feature Bullets Builder */}
              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
                <label className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                  Features List (គុណសម្បត្តិរួមបញ្ចូល)
                </label>

                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {(editingPlan.featuresKm || []).map((fKm, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs">
                      <span className="w-5 h-5 rounded-full bg-cyan-950 text-cyan-400 flex items-center justify-center flex-shrink-0">
                        ✓
                      </span>
                      <span className="flex-1 text-slate-300 truncate">
                        {fKm} / {(editingPlan.featuresEn || [])[i] || ""}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          const fKmList = [...(editingPlan.featuresKm || [])];
                          const fEnList = [...(editingPlan.featuresEn || [])];
                          fKmList.splice(i, 1);
                          fEnList.splice(i, 1);
                          setEditingPlan({
                            ...editingPlan,
                            featuresKm: fKmList,
                            featuresEn: fEnList,
                          });
                        }}
                        className="text-red-400 hover:text-red-300 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-800">
                  <input
                    type="text"
                    placeholder="លក្ខណៈពិសេស (KM)..."
                    value={newPlanFeatureKm}
                    onChange={(e) => setNewPlanFeatureKm(e.target.value)}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                  />
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Feature (EN)..."
                      value={newPlanFeatureEn}
                      onChange={(e) => setNewPlanFeatureEn(e.target.value)}
                      className="flex-1 px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (!newPlanFeatureKm.trim() && !newPlanFeatureEn.trim()) return;
                        setEditingPlan({
                          ...editingPlan,
                          featuresKm: [...(editingPlan.featuresKm || []), newPlanFeatureKm.trim() || newPlanFeatureEn.trim()],
                          featuresEn: [...(editingPlan.featuresEn || []), newPlanFeatureEn.trim() || newPlanFeatureKm.trim()],
                        });
                        setNewPlanFeatureKm("");
                        setNewPlanFeatureEn("");
                      }}
                      className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs cursor-pointer"
                    >
                      Add
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsPricingModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Plan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD / EDIT BLOG POST */}
      {isPostModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-3xl max-h-[92vh] overflow-y-auto bg-[#081527] border border-emerald-500/40 rounded-3xl p-5 sm:p-8 shadow-2xl space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-white shadow-md">
                  <PenSquare className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">
                    {editingPost.slug
                      ? adminLang === "km"
                        ? "កែសម្រួលអត្ថបទ"
                        : "Edit Blog Article"
                      : adminLang === "km"
                      ? "សរសេរអត្ថបទថ្មី"
                      : "Write New Blog Article"}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {adminLang === "km"
                      ? "រៀបចំចំណងជើង រូបភាពគម្រប និងមាតិកាពេញលេញសម្រាប់ទំព័រ /blog"
                      : "Configure title, cover image, slug URL, excerpt, and full markdown content."}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsPostModalOpen(false)}
                className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSavePost} className="space-y-4">
              {/* Title EN & Auto Slug */}
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                <div className="sm:col-span-7">
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    English Title <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Modern Web Development Trends in 2026"
                    value={editingPost.titleEn || ""}
                    onChange={(e) => {
                      const val = e.target.value;
                      setEditingPost((prev) => ({
                        ...prev,
                        titleEn: val,
                        // If slug was empty or matches old slug, auto-suggest
                        slug: prev.slug ? prev.slug : val.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""),
                      }));
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <div className="sm:col-span-5">
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-semibold text-slate-300">
                      Slug URL <span className="text-rose-400">*</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        if (!editingPost.titleEn) return;
                        const generated = editingPost.titleEn
                          .toLowerCase()
                          .replace(/[^a-z0-9]+/g, "-")
                          .replace(/^-|-$/g, "");
                        setEditingPost((prev) => ({ ...prev, slug: generated }));
                      }}
                      className="text-[10px] text-cyan-400 hover:underline cursor-pointer"
                    >
                      Auto Generate
                    </button>
                  </div>
                  <div className="flex items-center rounded-xl bg-slate-900 border border-slate-700 overflow-hidden focus-within:border-emerald-400">
                    <span className="px-2.5 py-2.5 bg-slate-800 text-slate-400 text-xs font-mono select-none">
                      /blog/
                    </span>
                    <input
                      type="text"
                      required
                      placeholder="post-slug-url"
                      value={editingPost.slug || ""}
                      onChange={(e) =>
                        setEditingPost((prev) => ({
                          ...prev,
                          slug: e.target.value.toLowerCase().replace(/[^a-z0-9-_]/g, "-"),
                        }))
                      }
                      className="w-full px-2.5 py-2.5 bg-transparent text-white text-xs font-mono focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Title KM */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  ចំណងជើងភាសាខ្មែរ (Khmer Title) <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="ឧ. និន្នាការនៃការអភិវឌ្ឍគេហទំព័រទំនើបក្នុងឆ្នាំ ២០២៦"
                  value={editingPost.titleKm || ""}
                  onChange={(e) => setEditingPost({ ...editingPost, titleKm: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-400"
                />
              </div>

              {/* Category, Author, Reading Time, Featured */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Category</label>
                  <select
                    value={editingPost.category || "Web Development"}
                    onChange={(e) => {
                      const cat = e.target.value;
                      let catKm = "ការអភិវឌ្ឍគេហទំព័រ";
                      if (cat === "Cloud & Hosting") catKm = "Cloud & ម៉ាស៊ីនមេ";
                      if (cat === "Tech & AI") catKm = "បច្ចេកវិទ្យា & AI";
                      if (cat === "Cybersecurity") catKm = "សន្តិសុខបច្ចេកវិទ្យា";
                      if (cat === "Guides") catKm = "ការណែនាំ & មេរៀន";
                      setEditingPost({
                        ...editingPost,
                        category: cat,
                        categoryEn: cat,
                        categoryKm: catKm,
                      });
                    }}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-400 cursor-pointer"
                  >
                    <option value="Web Development">Web Development</option>
                    <option value="Cloud & Hosting">Cloud & Hosting</option>
                    <option value="Tech & AI">Tech & AI</option>
                    <option value="Cybersecurity">Cybersecurity</option>
                    <option value="Guides">Guides & Tutorials</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Author</label>
                  <input
                    type="text"
                    placeholder="Broteach Team"
                    value={editingPost.author || ""}
                    onChange={(e) => setEditingPost({ ...editingPost, author: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Reading Time</label>
                  <input
                    type="text"
                    placeholder="5 min / 5 នាទី"
                    value={editingPost.readTime || ""}
                    onChange={(e) => setEditingPost({ ...editingPost, readTime: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Publish Date</label>
                  <input
                    type="text"
                    placeholder="Mar 15, 2026"
                    value={editingPost.date || ""}
                    onChange={(e) => setEditingPost({ ...editingPost, date: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-400"
                  />
                </div>
              </div>

              {/* Cover Image URL with Live Thumbnail Preview */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Cover Image URL (រូបភាពគម្របអត្ថបទ)
                </label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    placeholder="https://images.unsplash.com/..."
                    value={editingPost.image || ""}
                    onChange={(e) => setEditingPost({ ...editingPost, image: e.target.value })}
                    className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-400"
                  />
                  <label className="px-3 py-2 rounded-xl bg-purple-600/30 text-purple-300 hover:bg-purple-600 hover:text-white border border-purple-500/40 text-xs font-semibold whitespace-nowrap cursor-pointer flex items-center gap-1.5 transition-all">
                    <UploadCloud className="w-3.5 h-3.5" />
                    <span>{uploadingDirect ? (adminLang === "km" ? "កំពុង Upload..." : "Uploading...") : (adminLang === "km" ? "Upload រូបភាព" : "Upload File")}</span>
                    <input
                      type="file"
                      accept="image/*"
                      disabled={uploadingDirect}
                      className="hidden"
                      onChange={(e) => handleDirectUpload(e, "post")}
                    />
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      const samples = [
                        "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1200&q=80",
                        "https://images.unsplash.com/photo-1518770660439-4636190af475?w=1200&q=80",
                        "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&q=80",
                        "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=1200&q=80",
                      ];
                      const pick = samples[Math.floor(Math.random() * samples.length)];
                      setEditingPost((prev) => ({ ...prev, image: pick }));
                    }}
                    className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-semibold whitespace-nowrap cursor-pointer"
                  >
                    Random Image
                  </button>
                </div>

                {editingPost.image && (
                  <div className="mt-2 relative w-full h-32 rounded-xl overflow-hidden bg-slate-900 border border-slate-800">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={editingPost.image}
                      alt="Cover Preview"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur text-[10px] text-white">
                      Live Preview
                    </div>
                  </div>
                )}
              </div>

              {/* Excerpts: KM & EN */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    សេចក្តីសង្ខេប (Khmer Excerpt)
                  </label>
                  <textarea
                    rows={2}
                    placeholder="សេចក្តីសង្ខេបខ្លីៗសម្រាប់បង្ហាញលើកាត និង SEO Google..."
                    value={editingPost.excerptKm || ""}
                    onChange={(e) => setEditingPost({ ...editingPost, excerptKm: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    English Excerpt (SEO Summary)
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Short summary for card previews and Google meta description..."
                    value={editingPost.excerptEn || ""}
                    onChange={(e) => setEditingPost({ ...editingPost, excerptEn: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-400"
                  />
                </div>
              </div>

              {/* Full Article Content: KM & EN (Markdown & Rich HTML/CSS) */}
              <div className="space-y-4 pt-3 border-t border-slate-800">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <label className="block text-xs font-bold text-white">
                      មាតិកាពេញលេញនៃអត្ថបទ (Full Article Body - Markdown & Rich HTML/CSS)
                    </label>
                    <p className="text-[10px] text-slate-400">
                      Add headings, buttons (&lt;a&gt;), frames (&lt;div&gt;), badges, tables, or YouTube videos.
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900 border border-slate-800 self-start sm:self-auto">
                    <button
                      type="button"
                      onClick={() => setPostPreviewMode("edit")}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        postPreviewMode === "edit"
                          ? "bg-emerald-600 text-white shadow-sm"
                          : "text-slate-400 hover:text-white"
                      }`}
                    >
                      ✏️ {adminLang === "km" ? "កែសម្រួល (Edit)" : "Edit"}
                    </button>
                    <button
                      type="button"
                      onClick={() => setPostPreviewMode("preview")}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        postPreviewMode === "preview"
                          ? "bg-cyan-600 text-white shadow-sm"
                          : "text-slate-400 hover:text-white"
                      }`}
                    >
                      👁️ {adminLang === "km" ? "មើលទម្រង់ពិត (Live Preview)" : "Live Preview"}
                    </button>
                  </div>
                </div>

                {postPreviewMode === "edit" ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Khmer Content Editor */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="block text-[11px] font-semibold text-slate-300">
                          មាតិកាជាភាសាខ្មែរ (Khmer Body)
                        </label>
                        <span className="text-[10px] text-cyan-400 font-mono">
                          {(editingPost.contentKm || "").length} chars
                        </span>
                      </div>

                      {/* Snippet Toolbar KM */}
                      <div className="flex flex-wrap items-center gap-1 p-1.5 rounded-xl bg-slate-900/90 border border-slate-800 text-[10px]">
                        <span className="text-slate-500 font-bold px-1">+ Add:</span>
                        <button
                          type="button"
                          onClick={() => handleInsertPostSnippet("contentKm", "btn")}
                          className="px-2 py-0.5 rounded-lg bg-cyan-950/70 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-900 font-semibold cursor-pointer"
                        >
                          + Button
                        </button>
                        <button
                          type="button"
                          onClick={() => handleInsertPostSnippet("contentKm", "frame")}
                          className="px-2 py-0.5 rounded-lg bg-indigo-950/70 border border-indigo-500/40 text-indigo-300 hover:bg-indigo-900 font-semibold cursor-pointer"
                        >
                          + Frame Box
                        </button>
                        <button
                          type="button"
                          onClick={() => handleInsertPostSnippet("contentKm", "video")}
                          className="px-2 py-0.5 rounded-lg bg-red-950/70 border border-red-500/40 text-red-300 hover:bg-red-900 font-semibold cursor-pointer"
                        >
                          + YouTube
                        </button>
                        <button
                          type="button"
                          onClick={() => handleInsertPostSnippet("contentKm", "badge")}
                          className="px-2 py-0.5 rounded-lg bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-900 font-semibold cursor-pointer"
                        >
                          + Badge
                        </button>
                        <button
                          type="button"
                          onClick={() => handleInsertPostSnippet("contentKm", "table")}
                          className="px-2 py-0.5 rounded-lg bg-purple-950/70 border border-purple-500/40 text-purple-300 hover:bg-purple-900 font-semibold cursor-pointer"
                        >
                          + Table
                        </button>
                      </div>

                      <textarea
                        rows={10}
                        placeholder={`## ១. ចំណុចសំខាន់\n- ល្បឿនផ្ទុកលឿន\n- ការពារសុវត្ថិភាព\n\n<a href="..." style="...">ប៊ូតុងសាកល្បង</a>`}
                        value={editingPost.contentKm || ""}
                        onChange={(e) => setEditingPost({ ...editingPost, contentKm: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-xs focus:outline-none focus:border-emerald-400 leading-relaxed"
                      />
                    </div>

                    {/* English Content Editor */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="block text-[11px] font-semibold text-slate-300">
                          English Body (Article Content)
                        </label>
                        <span className="text-[10px] text-cyan-400 font-mono">
                          {(editingPost.contentEn || "").length} chars
                        </span>
                      </div>

                      {/* Snippet Toolbar EN */}
                      <div className="flex flex-wrap items-center gap-1 p-1.5 rounded-xl bg-slate-900/90 border border-slate-800 text-[10px]">
                        <span className="text-slate-500 font-bold px-1">+ Add:</span>
                        <button
                          type="button"
                          onClick={() => handleInsertPostSnippet("contentEn", "btn")}
                          className="px-2 py-0.5 rounded-lg bg-cyan-950/70 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-900 font-semibold cursor-pointer"
                        >
                          + Button
                        </button>
                        <button
                          type="button"
                          onClick={() => handleInsertPostSnippet("contentEn", "frame")}
                          className="px-2 py-0.5 rounded-lg bg-indigo-950/70 border border-indigo-500/40 text-indigo-300 hover:bg-indigo-900 font-semibold cursor-pointer"
                        >
                          + Frame Box
                        </button>
                        <button
                          type="button"
                          onClick={() => handleInsertPostSnippet("contentEn", "video")}
                          className="px-2 py-0.5 rounded-lg bg-red-950/70 border border-red-500/40 text-red-300 hover:bg-red-900 font-semibold cursor-pointer"
                        >
                          + YouTube
                        </button>
                        <button
                          type="button"
                          onClick={() => handleInsertPostSnippet("contentEn", "badge")}
                          className="px-2 py-0.5 rounded-lg bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-900 font-semibold cursor-pointer"
                        >
                          + Badge
                        </button>
                        <button
                          type="button"
                          onClick={() => handleInsertPostSnippet("contentEn", "table")}
                          className="px-2 py-0.5 rounded-lg bg-purple-950/70 border border-purple-500/40 text-purple-300 hover:bg-purple-900 font-semibold cursor-pointer"
                        >
                          + Table
                        </button>
                      </div>

                      <textarea
                        rows={10}
                        placeholder={`## 1. Key Highlights\n- Ultra-fast loading speed\n- High Security\n\n<div style="...">Frame Box</div>`}
                        value={editingPost.contentEn || ""}
                        onChange={(e) => setEditingPost({ ...editingPost, contentEn: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-xs focus:outline-none focus:border-emerald-400 leading-relaxed"
                      />
                    </div>
                  </div>
                ) : (
                  /* Live HTML & Styling Preview */
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-950/90 border border-slate-800">
                    <div>
                      <span className="inline-block px-2.5 py-1 rounded-md bg-emerald-950 border border-emerald-500/30 text-emerald-300 text-[10px] font-bold uppercase mb-3">
                        Khmer Live Rendered Preview
                      </span>
                      <div
                        className="prose prose-invert prose-sm max-w-none text-xs text-slate-300 space-y-3 leading-relaxed border border-slate-800 rounded-xl p-4 bg-[#081525]"
                        dangerouslySetInnerHTML={{
                          __html: (editingPost.contentKm || "")
                            .replace(/^## (.*$)/gim, '<h2 style="font-size:16px;font-weight:bold;color:#38bdf8;margin:14px 0 6px;">$1</h2>')
                            .replace(/^# (.*$)/gim, '<h1 style="font-size:18px;font-weight:bold;color:#ffffff;margin:16px 0 8px;">$1</h1>')
                            .replace(/^\- (.*$)/gim, '<li style="margin-left:16px;color:#cbd5e1;">$1</li>')
                            || "<p style='color:#64748b;'>មិនទាន់មានមាតិកាទេ (No content yet)</p>",
                        }}
                      />
                    </div>

                    <div>
                      <span className="inline-block px-2.5 py-1 rounded-md bg-cyan-950 border border-cyan-500/30 text-cyan-300 text-[10px] font-bold uppercase mb-3">
                        English Live Rendered Preview
                      </span>
                      <div
                        className="prose prose-invert prose-sm max-w-none text-xs text-slate-300 space-y-3 leading-relaxed border border-slate-800 rounded-xl p-4 bg-[#081525]"
                        dangerouslySetInnerHTML={{
                          __html: (editingPost.contentEn || "")
                            .replace(/^## (.*$)/gim, '<h2 style="font-size:16px;font-weight:bold;color:#38bdf8;margin:14px 0 6px;">$1</h2>')
                            .replace(/^# (.*$)/gim, '<h1 style="font-size:18px;font-weight:bold;color:#ffffff;margin:16px 0 8px;">$1</h1>')
                            .replace(/^\- (.*$)/gim, '<li style="margin-left:16px;color:#cbd5e1;">$1</li>')
                            || "<p style='color:#64748b;'>No content yet</p>",
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Featured Toggle and Actions */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <label className="flex items-center gap-2.5 text-xs text-white font-semibold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingPost.featured || false}
                    onChange={(e) => setEditingPost({ ...editingPost, featured: e.target.checked })}
                    className="w-4 h-4 rounded text-emerald-500 cursor-pointer"
                  />
                  <span>
                    {adminLang === "km"
                      ? "ដាក់ជាអត្ថបទពិសេស (Featured on Hero)"
                      : "Feature this article prominently on Blog Hero"}
                  </span>
                </label>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsPostModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:text-white cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-400 hover:to-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-600/30 cursor-pointer flex items-center gap-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>{adminLang === "km" ? "រក្សាទុកអត្ថបទ" : "Publish / Save Article"}</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: RESTORE CONFIRMATION & SELECTIVE OPTIONS */}
      {restoreModalOpen && uploadedBackupData && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-[#081527] border border-cyan-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                  <RotateCcw className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-white">
                    {adminLang === "km"
                      ? "ផ្ទៀងផ្ទាត់ និងបញ្ជាក់ការស្តារទិន្នន័យ (Restore Confirmation)"
                      : "Disaster Recovery & Restore"}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {adminLang === "km"
                      ? "ជ្រើសរើសផ្នែកទិន្នន័យដែលអ្នកចង់ស្តារឡើងវិញ"
                      : "Preview contents and select which collections to restore."}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setRestoreModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Source Information */}
            <div className="rounded-xl bg-slate-900/90 border border-slate-800 p-4 space-y-2 text-xs">
              <div className="flex items-center justify-between text-slate-300">
                <span className="font-semibold text-slate-400">{adminLang === "km" ? "ប្រភពទិន្នន័យ (Source):" : "Source Archive:"}</span>
                <span className="font-mono text-cyan-300 font-bold truncate max-w-xs">{uploadedFileName}</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span className="font-semibold text-slate-400">{adminLang === "km" ? "កាលបរិច្ឆេទបង្កើត Backup:" : "Backup Date:"}</span>
                <span>{uploadedBackupData.timestamp ? new Date(uploadedBackupData.timestamp).toLocaleString() : "Unknown"}</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span className="font-semibold text-slate-400">{adminLang === "km" ? "ទម្រង់ (Version):" : "Schema Version:"}</span>
                <span className="font-mono text-emerald-400">{uploadedBackupData.version || "1.0"}</span>
              </div>
            </div>

            {/* Selective Category Checklist */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-white uppercase tracking-wider">
                  {adminLang === "km" ? "ជ្រើសរើសផ្នែកទិន្នន័យដែលត្រូវស្តារ (Select Collections to Restore):" : "Collections to Restore:"}
                </label>
                <div className="flex items-center gap-2 text-[11px]">
                  <button
                    type="button"
                    onClick={() => handleToggleSelectAll(true)}
                    className="text-cyan-400 hover:underline cursor-pointer font-semibold"
                  >
                    {adminLang === "km" ? "ជ្រើសរើសទាំងអស់" : "Select All"}
                  </button>
                  <span className="text-slate-600">|</span>
                  <button
                    type="button"
                    onClick={() => handleToggleSelectAll(false)}
                    className="text-slate-400 hover:underline cursor-pointer"
                  >
                    {adminLang === "km" ? "ដោះទាំងអស់" : "Deselect All"}
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                {/* Site Settings */}
                <label className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                  selectiveRestore.settings ? "bg-slate-900/90 border-cyan-500/50 text-white" : "bg-slate-950/40 border-slate-800 text-slate-500"
                }`}>
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      checked={selectiveRestore.settings}
                      onChange={(e) => setSelectiveRestore({ ...selectiveRestore, settings: e.target.checked })}
                      className="w-4 h-4 rounded text-cyan-500 cursor-pointer"
                    />
                    <span className="font-semibold">{adminLang === "km" ? "ការកំណត់ & Branding" : "Site Settings & Branding"}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {uploadedBackupData.data?.settings ? "Included" : "None"}
                  </span>
                </label>

                {/* Productions / Products */}
                <label className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                  selectiveRestore.products ? "bg-slate-900/90 border-cyan-500/50 text-white" : "bg-slate-950/40 border-slate-800 text-slate-500"
                }`}>
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      checked={selectiveRestore.products}
                      onChange={(e) => setSelectiveRestore({ ...selectiveRestore, products: e.target.checked })}
                      className="w-4 h-4 rounded text-cyan-500 cursor-pointer"
                    />
                    <span className="font-semibold">{adminLang === "km" ? "ផលិតផល (Productions)" : "Productions / Products"}</span>
                  </div>
                  <span className="text-[10px] text-cyan-300 font-mono font-bold">
                    {uploadedBackupData.data?.products?.length || 0} items
                  </span>
                </label>

                {/* Pricing Plans */}
                <label className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                  selectiveRestore.pricing ? "bg-slate-900/90 border-cyan-500/50 text-white" : "bg-slate-950/40 border-slate-800 text-slate-500"
                }`}>
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      checked={selectiveRestore.pricing}
                      onChange={(e) => setSelectiveRestore({ ...selectiveRestore, pricing: e.target.checked })}
                      className="w-4 h-4 rounded text-cyan-500 cursor-pointer"
                    />
                    <span className="font-semibold">{adminLang === "km" ? "កញ្ចប់តម្លៃ (Pricing)" : "Pricing Plans"}</span>
                  </div>
                  <span className="text-[10px] text-cyan-300 font-mono font-bold">
                    {uploadedBackupData.data?.pricing?.length || 0} plans
                  </span>
                </label>

                {/* Content Sections */}
                <label className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                  selectiveRestore.sections ? "bg-slate-900/90 border-cyan-500/50 text-white" : "bg-slate-950/40 border-slate-800 text-slate-500"
                }`}>
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      checked={selectiveRestore.sections}
                      onChange={(e) => setSelectiveRestore({ ...selectiveRestore, sections: e.target.checked })}
                      className="w-4 h-4 rounded text-cyan-500 cursor-pointer"
                    />
                    <span className="font-semibold">{adminLang === "km" ? "ផ្នែកមាតិកា (Sections)" : "Content Sections"}</span>
                  </div>
                  <span className="text-[10px] text-indigo-300 font-mono font-bold">
                    {uploadedBackupData.data?.sections?.length || 0} sections
                  </span>
                </label>

                {/* Blog Posts */}
                <label className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                  selectiveRestore.posts ? "bg-slate-900/90 border-cyan-500/50 text-white" : "bg-slate-950/40 border-slate-800 text-slate-500"
                }`}>
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      checked={selectiveRestore.posts}
                      onChange={(e) => setSelectiveRestore({ ...selectiveRestore, posts: e.target.checked })}
                      className="w-4 h-4 rounded text-cyan-500 cursor-pointer"
                    />
                    <span className="font-semibold">{adminLang === "km" ? "អត្ថបទ Blog & Articles" : "Blog Posts & Articles"}</span>
                  </div>
                  <span className="text-[10px] text-emerald-300 font-mono font-bold">
                    {uploadedBackupData.data?.posts?.length || 0} posts
                  </span>
                </label>

                {/* Customer Orders */}
                <label className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                  selectiveRestore.orders ? "bg-slate-900/90 border-cyan-500/50 text-white" : "bg-slate-950/40 border-slate-800 text-slate-500"
                }`}>
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      checked={selectiveRestore.orders}
                      onChange={(e) => setSelectiveRestore({ ...selectiveRestore, orders: e.target.checked })}
                      className="w-4 h-4 rounded text-cyan-500 cursor-pointer"
                    />
                    <span className="font-semibold">{adminLang === "km" ? "ការកុម្ម៉ង់ទិញ (Orders)" : "Customer Orders"}</span>
                  </div>
                  <span className="text-[10px] text-rose-300 font-mono font-bold">
                    {uploadedBackupData.data?.orders?.length || 0} orders
                  </span>
                </label>

                {/* Newsletter Subscribers */}
                <label className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer sm:col-span-2 ${
                  selectiveRestore.subscribers ? "bg-slate-900/90 border-cyan-500/50 text-white" : "bg-slate-950/40 border-slate-800 text-slate-500"
                }`}>
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      checked={selectiveRestore.subscribers}
                      onChange={(e) => setSelectiveRestore({ ...selectiveRestore, subscribers: e.target.checked })}
                      className="w-4 h-4 rounded text-cyan-500 cursor-pointer"
                    />
                    <span className="font-semibold">{adminLang === "km" ? "អ្នកជាវ Newsletter Subscribers" : "Newsletter Subscribers"}</span>
                  </div>
                  <span className="text-[10px] text-amber-300 font-mono font-bold">
                    {uploadedBackupData.data?.subscribers?.length || 0} subscribers
                  </span>
                </label>
              </div>
            </div>

            {/* Safety Warning Banner */}
            <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-500/40 flex items-start gap-3 text-xs text-amber-200">
              <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-bold">
                  {adminLang === "km"
                    ? "ការស្តារទិន្នន័យនឹងជំនួសទិន្នន័យចាស់ដែលបានជ្រើសរើស"
                    : "Restore will overwrite selected collections with data from this archive."}
                </p>
                <p className="text-[11px] text-amber-300/80">
                  {adminLang === "km"
                    ? "ប្រព័ន្ធនឹងបង្កើត Pre-restore Safety Snapshot មួយដោយស្វ័យប្រវត្តមុនពេលចាប់ផ្តើម។ លោកអ្នកអាចត្រឡប់ទៅវិញគ្រប់ពេលវេលា។"
                    : "An automated safety snapshot will be created before applying changes."}
                </p>
              </div>
            </div>

            {/* Footer Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setRestoreModalOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold cursor-pointer"
              >
                {adminLang === "km" ? "បោះបង់" : "Cancel"}
              </button>
              <button
                type="button"
                onClick={handleExecuteRestore}
                disabled={isRestoring}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/30 flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isRestoring ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>{adminLang === "km" ? "កំពុងស្តារទិន្នន័យ..." : "Restoring Data..."}</span>
                  </>
                ) : (
                  <>
                    <RotateCcw className="w-4 h-4" />
                    <span>{adminLang === "km" ? "ចាប់ផ្តើមស្តារទិន្នន័យ (Confirm & Restore)" : "Confirm & Restore"}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STYLED CUSTOM DELETE CONFIRMATION POPUP MODAL */}
      {deleteConfirmModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-md rounded-3xl bg-gradient-to-b from-[#0e1e33] to-[#071322] border border-red-500/40 p-6 sm:p-7 shadow-[0_20px_60px_rgba(0,0,0,0.85)] space-y-5">
            {/* Header with warning icon */}
            <div className="flex items-start gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-red-950/80 border border-red-500/50 flex items-center justify-center text-red-400 shrink-0 shadow-lg shadow-red-950/50">
                <Trash2 className="w-6 h-6 animate-pulse" />
              </div>
              <div className="space-y-1 min-w-0">
                <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-red-950 text-red-300 border border-red-500/30">
                  {deleteConfirmModal.itemTypeLabel}
                </span>
                <h3 className="text-base sm:text-lg font-bold text-white leading-snug">
                  {deleteConfirmModal.title}
                </h3>
              </div>
            </div>

            {/* Target Item Name Box */}
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 text-slate-200">
              <p className="text-xs text-slate-400 mb-1 font-semibold">
                {adminLang === "km" ? "ឈ្មោះទិន្នន័យដែលត្រូវលុប:" : "Item to delete:"}
              </p>
              <p className="text-sm font-bold text-cyan-300 break-words font-mono">
                &ldquo;{deleteConfirmModal.itemTitle}&rdquo;
              </p>
            </div>

            {/* Retention Notice / Warning */}
            <div className={`p-3.5 rounded-2xl border flex items-start gap-2.5 text-xs ${
              deleteConfirmModal.isPermanent
                ? "bg-red-950/40 border-red-500/40 text-red-200"
                : "bg-emerald-950/30 border-emerald-500/40 text-emerald-200"
            }`}>
              {deleteConfirmModal.isPermanent ? (
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              ) : (
                <Clock className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              )}
              <div className="space-y-0.5">
                <p className="font-bold">
                  {deleteConfirmModal.isPermanent
                    ? adminLang === "km"
                      ? "លុបជាស្ថាពរ (មិនអាចត្រឡប់វិញបានទេ)!"
                      : "Permanent Deletion (Cannot be undone)!"
                    : adminLang === "km"
                      ? "រក្សាទុកក្នុងធុងសម្រាម 7 ថ្ងៃ (Kept in Trash for 7 days)"
                      : "Kept in Trash for 7 days (Safe Auto-Retention)"}
                </p>
                <p className="text-[11px] opacity-80 leading-relaxed">
                  {deleteConfirmModal.warningMessage || (
                    adminLang === "km"
                      ? "ទិន្នន័យនឹងត្រូវផ្លាស់ទីទៅក្នុងធុងសម្រាម ហើយលោកអ្នកអាច Restore មកវិញបានគ្រប់ពេលក្នុងរយៈពេល 7 ថ្ងៃ ព្រមទាំងមានប៊ូតុង Undo 5 វិនាទីភ្លាមៗ។"
                      : "You can restore this item from Trash within 7 days, and an instant 5-second Undo toast will appear."
                  )}
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                disabled={deleteSubmitting}
                onClick={() => setDeleteConfirmModal((prev) => ({ ...prev, isOpen: false }))}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold cursor-pointer transition-colors"
              >
                {adminLang === "km" ? "បោះបង់ (Cancel)" : "Cancel"}
              </button>
              <button
                type="button"
                disabled={deleteSubmitting}
                onClick={async () => {
                  setDeleteSubmitting(true);
                  try {
                    await deleteConfirmModal.onConfirm();
                  } finally {
                    setDeleteSubmitting(false);
                    setDeleteConfirmModal((prev) => ({ ...prev, isOpen: false }));
                  }
                }}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white text-xs font-bold shadow-lg shadow-red-600/30 flex items-center gap-1.5 cursor-pointer disabled:opacity-50 transition-all hover:scale-105"
              >
                {deleteSubmitting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>{adminLang === "km" ? "កំពុងលុប..." : "Deleting..."}</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{adminLang === "km" ? "យល់ព្រមលុប (Yes, Delete)" : "Yes, Delete"}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5-SECOND UNDO COUNTDOWN TOAST */}
      {undoToast && (
        <div className="fixed bottom-6 right-6 z-50 animate-in slide-in-from-bottom duration-300">
          <div className="flex items-center gap-3 px-5 py-3.5 rounded-2xl bg-gradient-to-r from-[#0d2238] to-[#081525] border border-cyan-500/50 shadow-[0_10px_35px_rgba(0,0,0,0.7)] text-white">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-cyan-500/20 text-cyan-400 font-mono text-sm font-bold animate-pulse">
              {undoToast.secondsRemaining}s
            </div>
            <div className="flex flex-col pr-2">
              <span className="text-xs font-bold text-slate-100">
                {adminLang === "km"
                  ? "បានលុប & ទុកក្នុងធុងសម្រាម 7 ថ្ងៃ"
                  : "Moved to Trash (Kept for 7 days)"}
              </span>
              <span className="text-[11px] text-cyan-300/90 truncate max-w-[200px]">
                {undoToast.title}
              </span>
            </div>
            <button
              type="button"
              onClick={async () => {
                await undoToast.restoreHandler();
                setUndoToast(null);
              }}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-black shadow-md shadow-cyan-600/40 transition-all cursor-pointer hover:scale-105"
            >
              <Undo2 className="w-3.5 h-3.5" />
              <span>{adminLang === "km" ? "ត្រឡប់វិញ (Undo)" : "Undo"}</span>
            </button>
            <button
              type="button"
              onClick={() => setUndoToast(null)}
              className="p-1 rounded-lg text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
