import { NextResponse } from "next/server";
import { addOrder, getOrders, deleteOrder } from "@/lib/storage";
import { checkRateLimit, getClientIp, sanitizeText, verifyAdminSession } from "@/lib/security";

export async function GET(req: Request) {
  // Protect viewing all orders to admin only
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized access" }, { status: 401 });
  }
  const orders = getOrders();
  return NextResponse.json({ success: true, count: orders.length, orders });
}

export async function DELETE(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");

  if (!id) {
    return NextResponse.json({ success: false, message: "Order ID is required" }, { status: 400 });
  }

  const deleted = deleteOrder(id);
  if (!deleted) {
    return NextResponse.json({ success: false, message: "Order not found" }, { status: 404 });
  }

  return NextResponse.json({ success: true, message: "Order deleted successfully" });
}

export async function POST(req: Request) {
  const ip = getClientIp(req);
  const rate = checkRateLimit(`order-${ip}`, 15, 10 * 60 * 1000); // 15 orders per 10 minutes max
  if (!rate.allowed) {
    return NextResponse.json(
      {
        success: false,
        message: `Too many requests from this IP. Please wait ${rate.resetIn} seconds.`,
      },
      { status: 429 }
    );
  }

  try {
    const body = await req.json();
    const { planId, planName, price, clientName, email, phone, telegram, notes } = body;

    const cleanName = sanitizeText(clientName);
    const cleanPhone = sanitizeText(phone);

    if (!cleanName || !cleanPhone) {
      return NextResponse.json(
        { success: false, message: "សូមបញ្ចូលឈ្មោះ និងលេខទូរស័ព្ទ (Name and phone number are required)" },
        { status: 400 }
      );
    }

    const newOrder = addOrder({
      planId: sanitizeText(planId || "general"),
      planName: sanitizeText(planName || "ទូទៅ / General Inquiry"),
      price: Math.max(0, Number(price) || 0),
      clientName: cleanName,
      email: sanitizeText(email || ""),
      phone: cleanPhone,
      telegram: sanitizeText(telegram || ""),
      notes: sanitizeText(notes || ""),
    });

    // Notify Admin via Telegram (non-blocking)
    try {
      const { sendTelegramNotification } = await import("@/lib/telegramServer");
      const orderMessage = `🔔 <b>ការបញ្ជាទិញថ្មី (New Order Received)!</b>\n\n` +
        `📦 <b>កញ្ចប់/ទំនិញ:</b> ${newOrder.planName}\n` +
        `💰 <b>តម្លៃ:</b> $${newOrder.price}\n` +
        `👤 <b>អតិថិជន:</b> ${newOrder.clientName}\n` +
        `📞 <b>ទូរស័ព្ទ:</b> ${newOrder.phone}\n` +
        (newOrder.telegram ? `💬 <b>Telegram:</b> @${newOrder.telegram.replace("@", "")}\n` : "") +
        (newOrder.email ? `✉️ <b>Email:</b> ${newOrder.email}\n` : "") +
        (newOrder.notes ? `📝 <b>ចំណាំ:</b> ${newOrder.notes}\n` : "") +
        `⏰ <b>កាលបរិច្ឆេទ:</b> ${new Date().toLocaleString("km-KH", { timeZone: "Asia/Phnom_Penh" })}`;
      
      sendTelegramNotification(orderMessage).catch((e) => console.error("Telegram notification error:", e));
    } catch (e) {
      console.error("Failed to trigger Telegram notification:", e);
    }

    return NextResponse.json({
      success: true,
      message: "ទទួលបានព័ត៌មានដោយជោគជ័យ! ក្រុមការងារយើងនឹងទាក់ទងទៅលោកអ្នកក្នុងពេលឆាប់ៗ។ (Order inquiry received! We will contact you shortly.)",
      order: newOrder,
    });
  } catch (error) {
    console.error("Order processing error:", error);
    return NextResponse.json(
      { success: false, message: "មានបញ្ហាក្នុងការរក្សាទុកទិន្នន័យ (Failed to process order)" },
      { status: 500 }
    );
  }
}
