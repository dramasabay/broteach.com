import { NextResponse } from "next/server";
import { addSubscriber, getSubscribers, deleteSubscriber } from "@/lib/storage";
import { checkRateLimit, getClientIp, sanitizeText, verifyAdminSession } from "@/lib/security";

export async function GET(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized access" }, { status: 401 });
  }
  const subscribers = getSubscribers();
  return NextResponse.json({ success: true, count: subscribers.length, subscribers });
}

export async function POST(req: Request) {
  const ip = getClientIp(req);
  const rate = checkRateLimit(`newsletter-${ip}`, 15, 10 * 60 * 1000); // 15 per 10 mins
  if (!rate.allowed) {
    return NextResponse.json(
      {
        success: false,
        message: `Too many subscription attempts. Please wait ${rate.resetIn} seconds.`,
      },
      { status: 429 }
    );
  }

  try {
    let email = "";
    try {
      const body = await req.json();
      email = typeof body?.email === "string" ? body.email : "";
    } catch {
      return NextResponse.json(
        { success: false, message: "Invalid JSON format" },
        { status: 400 }
      );
    }

    const cleanEmail = sanitizeText(email).toLowerCase();

    const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;

    if (!cleanEmail || cleanEmail.length > 254 || !emailRegex.test(cleanEmail)) {
      return NextResponse.json(
        { success: false, message: "Please enter a valid email address" },
        { status: 400 }
      );
    }

    const result = addSubscriber(cleanEmail);
    return NextResponse.json({
      success: true,
      message: result.message,
      alreadySubscribed: result.alreadySubscribed || false,
      subscriber: result.subscriber,
    });
  } catch (error) {
    console.error("Newsletter subscription error:", error);
    return NextResponse.json(
      { success: false, message: "មានបញ្ហាក្នុងការដំណើរការ សូមព្យាយាមម្តងទៀត (Internal server error)" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ success: false, message: "Subscriber ID required" }, { status: 400 });
    }

    const deleted = deleteSubscriber(id);
    if (!deleted) {
      return NextResponse.json({ success: false, message: "Subscriber not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, message: "Subscriber deleted successfully" });
  } catch (err) {
    console.error("Delete subscriber error:", err);
    return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
  }
}
