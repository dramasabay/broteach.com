import { NextResponse } from "next/server";
import {
  getSiteSettings,
  getProducts,
  getPricingPlans,
  getContentSections,
  getBlogPosts,
} from "@/lib/contentStore";
import { checkRateLimit, getClientIp } from "@/lib/security";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const ip = getClientIp(req);
  const rate = checkRateLimit(`content-${ip}`, 90, 60 * 1000); // 90 requests per minute
  if (!rate.allowed) {
    return NextResponse.json(
      { success: false, message: `Too many requests. Please wait ${rate.resetIn} seconds.` },
      { status: 429 }
    );
  }

  const settings = getSiteSettings();
  const products = getProducts().filter((p) => p.isActive);
  const pricing = getPricingPlans();
  const sections = getContentSections()
    .filter((s) => s.isActive)
    .sort((a, b) => a.sortOrder - b.sortOrder);
  const posts = getBlogPosts().filter((p) => p.isPublished !== false);

  const res = NextResponse.json({
    success: true,
    settings,
    products,
    pricing,
    sections,
    posts,
  });

  // Short edge cache for performance & DDoS absorption
  res.headers.set("Cache-Control", "public, s-maxage=5, stale-while-revalidate=15");
  return res;
}

