import { NextResponse } from "next/server";
import { getBlogPosts, saveBlogPost, deleteBlogPost } from "@/lib/contentStore";
import { verifyAdminSession, sanitizeText } from "@/lib/security";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }
  const posts = getBlogPosts();
  return NextResponse.json({ success: true, posts });
}

export async function POST(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const {
      id,
      slug,
      titleKm,
      titleEn,
      excerptKm,
      excerptEn,
      contentKm,
      contentEn,
      category,
      tagKm,
      tagEn,
      readingTime,
      date,
      featured,
      coverGradient,
      coverImage,
      icon,
      author,
      isPublished,
    } = body;

    if (!titleKm || !titleEn) {
      return NextResponse.json(
        { success: false, message: "Khmer and English titles are required" },
        { status: 400 }
      );
    }

    const saved = saveBlogPost({
      id: id ? sanitizeText(id) : undefined,
      slug: slug ? sanitizeText(slug) : undefined,
      titleKm: sanitizeText(titleKm),
      titleEn: sanitizeText(titleEn),
      excerptKm: excerptKm ? sanitizeText(excerptKm) : "",
      excerptEn: excerptEn ? sanitizeText(excerptEn) : "",
      contentKm: contentKm || "",
      contentEn: contentEn || "",
      category: category ? sanitizeText(category) : "General",
      tagKm: tagKm ? sanitizeText(tagKm) : undefined,
      tagEn: tagEn ? sanitizeText(tagEn) : undefined,
      readingTime: typeof readingTime === "number" ? readingTime : 5,
      date: date ? sanitizeText(date) : undefined,
      featured: Boolean(featured),
      coverGradient: coverGradient ? sanitizeText(coverGradient) : undefined,
      coverImage: coverImage ? sanitizeText(coverImage) : undefined,
      icon: icon ? sanitizeText(icon) : "📝",
      author: author ? sanitizeText(author) : "Broteach Team",
      isPublished: isPublished !== undefined ? Boolean(isPublished) : true,
    });

    return NextResponse.json({ success: true, post: saved });
  } catch {
    return NextResponse.json({ success: false, message: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) {
    return NextResponse.json({ success: false, message: "Post ID is required" }, { status: 400 });
  }

  const deleted = deleteBlogPost(id);
  if (!deleted) {
    return NextResponse.json({ success: false, message: "Post not found" }, { status: 404 });
  }

  return NextResponse.json({ success: true, message: "Post deleted successfully" });
}
