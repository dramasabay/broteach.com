import crypto from "crypto";
import { NextResponse } from "next/server";
import { checkRateLimit, getClientIp } from "@/lib/security";
import { signJwt, verifyJwt, JWT_COOKIE_NAME } from "@/lib/jwt";

export const dynamic = "force-dynamic";

// The admin secret is read only from the environment variable.
// No fallback to any hardcoded string.
function getAdminSecret(): string {
  const secret = process.env.ADMIN_SECRET ?? "";
  // Strip trailing carriage returns (\r from Windows CRLF), surrounding quotes, and whitespace
  return secret.replace(/\r/g, "").replace(/^["']|["']$/g, "").trim();
}

/**
 * GET /api/admin/auth
 * Verify whether the current session is valid.
 * Protected by proxy; handler re-verifies independently.
 */
export async function GET(req: Request) {
  const cookieHeader = req.headers.get("cookie") || "";
  const authHeader = req.headers.get("authorization") || "";

  let token: string | undefined;
  if (authHeader.startsWith("Bearer ")) {
    token = authHeader.slice(7).trim();
  }

  if (!token && cookieHeader) {
    const cookies = Object.fromEntries(
      cookieHeader.split(";").map((c) => {
        const [k, ...v] = c.trim().split("=");
        return [k.trim(), v.join("=")];
      })
    );
    token = cookies[JWT_COOKIE_NAME];
  }

  if (!token) {
    return NextResponse.json({ success: false, authenticated: false }, { status: 401 });
  }

  // Full cryptographic verification — no shortcuts
  const result = await verifyJwt(token);
  if (result.valid) {
    return NextResponse.json({
      success: true,
      authenticated: true,
      payload: {
        role: result.payload?.role,
        sub: result.payload?.sub,
      },
    });
  }

  return NextResponse.json(
    { success: false, authenticated: false, error: "Invalid or expired session" },
    { status: 401 }
  );
}

/**
 * POST /api/admin/auth
 * Admin login — accepts the ADMIN_SECRET environment variable only.
 * Rate-limited to 5 attempts per IP per minute.
 */
export async function POST(req: Request) {
  const ip = getClientIp(req);
  const rate = checkRateLimit(`auth-${ip}`, 5, 60 * 1000);
  if (!rate.allowed) {
    return NextResponse.json(
      {
        success: false,
        message: `Too many login attempts. Please wait ${rate.resetIn} seconds.`,
      },
      { status: 429 }
    );
  }

  const adminSecret = getAdminSecret();

  // Refuse if the admin secret is not configured
  if (!adminSecret || adminSecret.length < 8) {
    console.error("[AUTH] ADMIN_SECRET is not set or too short — login is disabled");
    return NextResponse.json(
      { success: false, message: "Admin login is not configured. Contact the system administrator." },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ success: false, message: "Invalid request body" }, { status: 400 });
  }

  const rawPassword =
    body !== null && typeof body === "object" && "password" in body && typeof (body as Record<string, unknown>).password === "string"
      ? (body as { password: string }).password
      : "";

  const password = rawPassword.replace(/\r/g, "").trim();

  const bufPass = Buffer.from(password);
  const bufSecret = Buffer.from(adminSecret);
  const bufRaw = Buffer.from(rawPassword);

  const isMatch =
    (bufPass.length === bufSecret.length && crypto.timingSafeEqual(bufPass, bufSecret)) ||
    (bufRaw.length === bufSecret.length && crypto.timingSafeEqual(bufRaw, bufSecret));

  if (!isMatch) {
    return NextResponse.json(
      { success: false, message: "Invalid password" },
      { status: 401 }
    );
  }

  // Issue a signed HMAC-SHA256 JWT (7-day validity)
  const jwtToken = await signJwt(
    {
      sub: "admin",
      role: "admin",
      iss: "broteach.com",
    },
    undefined,
    7 * 24 * 60 * 60
  );

  const response = NextResponse.json({
    success: true,
    message: "Authenticated successfully",
    user: { role: "admin" },
  });

  // Set a secure, HTTP-only JWT session cookie.
  // The raw token is NOT returned in the response body to reduce exposure.
  response.cookies.set({
    name: JWT_COOKIE_NAME,
    value: jwtToken,
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 7 * 24 * 60 * 60,
  });

  // Ensure no sensitive admin routes are cached
  response.headers.set("Cache-Control", "no-store");

  return response;
}

/**
 * DELETE /api/admin/auth
 * Logout — clears the session cookie.
 */
export async function DELETE() {
  const response = NextResponse.json({ success: true, message: "Logged out" });
  response.cookies.delete(JWT_COOKIE_NAME);
  // Also clear the legacy cookie if it still exists in the client browser
  response.cookies.set({
    name: "broteach_admin_token",
    value: "",
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 0,
  });
  response.headers.set("Cache-Control", "no-store");
  return response;
}
