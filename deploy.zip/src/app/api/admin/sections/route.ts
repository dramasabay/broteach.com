import { NextResponse } from "next/server";
import {
  getContentSections,
  saveContentSection,
  deleteContentSection,
  reorderContentSections,
} from "@/lib/contentStore";
import { verifyAdminSession, sanitizeText } from "@/lib/security";
import { SectionItem } from "@/types";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }
  const sections = getContentSections();
  return NextResponse.json({ success: true, sections });
}

export async function POST(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const {
      id,
      titleKm,
      titleEn,
      subtitleKm,
      subtitleEn,
      badgeKm,
      badgeEn,
      layoutType,
      items,
      isActive,
      sortOrder,
      anchorId,
    } = body;

    if (!titleKm || !titleEn) {
      return NextResponse.json(
        { success: false, message: "Khmer and English titles are required" },
        { status: 400 }
      );
    }

    const sanitizedItems: SectionItem[] = Array.isArray(items)
      ? items.map((it: Partial<SectionItem>, index: number) => ({
          id: it.id ? sanitizeText(it.id) : `item-${Date.now()}-${index}`,
          titleKm: sanitizeText(it.titleKm || ""),
          titleEn: sanitizeText(it.titleEn || ""),
          descKm: sanitizeText(it.descKm || ""),
          descEn: sanitizeText(it.descEn || ""),
          icon: it.icon ? sanitizeText(it.icon) : undefined,
          badgeKm: it.badgeKm ? sanitizeText(it.badgeKm) : undefined,
          badgeEn: it.badgeEn ? sanitizeText(it.badgeEn) : undefined,
          metric: it.metric ? sanitizeText(it.metric) : undefined,
          imageUrl: it.imageUrl ? sanitizeText(it.imageUrl) : undefined,
          linkUrl: it.linkUrl ? sanitizeText(it.linkUrl) : undefined,
          linkTextKm: it.linkTextKm ? sanitizeText(it.linkTextKm) : undefined,
          linkTextEn: it.linkTextEn ? sanitizeText(it.linkTextEn) : undefined,
        }))
      : [];

    const saved = saveContentSection({
      id: id ? sanitizeText(id) : undefined,
      titleKm: sanitizeText(titleKm),
      titleEn: sanitizeText(titleEn),
      subtitleKm: subtitleKm ? sanitizeText(subtitleKm) : undefined,
      subtitleEn: subtitleEn ? sanitizeText(subtitleEn) : undefined,
      badgeKm: badgeKm ? sanitizeText(badgeKm) : undefined,
      badgeEn: badgeEn ? sanitizeText(badgeEn) : undefined,
      layoutType: layoutType || "cards",
      items: sanitizedItems,
      isActive: isActive !== false,
      sortOrder: Number(sortOrder) || 1,
      anchorId: anchorId ? sanitizeText(anchorId) : undefined,
    });

    return NextResponse.json({
      success: true,
      message: "Section saved successfully",
      section: saved,
    });
  } catch (error) {
    console.error("Save section error:", error);
    return NextResponse.json({ success: false, message: "Failed to save section" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ success: false, message: "Section ID required" }, { status: 400 });
    }

    const deleted = deleteContentSection(id);
    if (!deleted) {
      return NextResponse.json({ success: false, message: "Section not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, message: "Section deleted successfully" });
  } catch {
    return NextResponse.json({ success: false, message: "Error deleting section" }, { status: 500 });
  }
}

export async function PATCH(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { orderedIds } = body;
    if (!Array.isArray(orderedIds)) {
      return NextResponse.json({ success: false, message: "orderedIds array required" }, { status: 400 });
    }

    const reordered = reorderContentSections(orderedIds);
    return NextResponse.json({ success: true, sections: reordered });
  } catch {
    return NextResponse.json({ success: false, message: "Error reordering sections" }, { status: 500 });
  }
}
