import { NextResponse } from "next/server";
import {
  getSiteSettings,
  updateSiteSettings,
  getPricingPlans,
  updatePricingPlan,
} from "@/lib/contentStore";
import { verifyAdminSession, sanitizeText } from "@/lib/security";

export async function GET(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }

  const settings = getSiteSettings();
  const pricing = getPricingPlans();

  return NextResponse.json({ success: true, settings, pricing });
}

export async function POST(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { type, data } = body;

    if (type === "settings") {
      const sanitized: Record<string, unknown> = {};
      for (const [key, val] of Object.entries(data)) {
        if (typeof val === "string") {
          sanitized[key] = sanitizeText(val);
        } else {
          sanitized[key] = val;
        }
      }
      const updated = updateSiteSettings(sanitized);
      return NextResponse.json({ success: true, message: "Site settings updated", settings: updated });
    }

    if (type === "pricing" && data.id) {
      const updated = updatePricingPlan(data.id, data);
      return NextResponse.json({ success: true, message: "Pricing plan updated", plan: updated });
    }

    return NextResponse.json({ success: false, message: "Invalid update type" }, { status: 400 });
  } catch (error) {
    console.error("Content update error:", error);
    return NextResponse.json({ success: false, message: "Failed to update content" }, { status: 500 });
  }
}
