import { NextResponse } from "next/server";
import { verifyAdminSession } from "@/lib/security";
import {
  getTrashItems,
  moveToTrash,
  restoreTrashItem,
  deletePermanently,
  emptyTrash,
} from "@/lib/trashManager";

export async function GET(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }

  const items = getTrashItems();
  return NextResponse.json({ success: true, count: items.length, items });
}

export async function POST(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { action, trashId, itemType, originalId, title, data } = body;

    if (action === "move") {
      if (!itemType || !originalId) {
        return NextResponse.json(
          { success: false, message: "Missing itemType or originalId" },
          { status: 400 }
        );
      }
      const item = moveToTrash(itemType, originalId, title || originalId, data);
      return NextResponse.json({
        success: true,
        message: "Item moved to trash (kept for 7 days)",
        trashId: item.id,
      });
    }

    if (action === "restore") {
      if (!trashId) {
        return NextResponse.json({ success: false, message: "Trash ID required" }, { status: 400 });
      }
      const result = await restoreTrashItem(trashId);
      return NextResponse.json(result, { status: result.success ? 200 : 400 });
    }

    if (action === "delete") {
      if (!trashId) {
        return NextResponse.json({ success: false, message: "Trash ID required" }, { status: 400 });
      }
      const deleted = deletePermanently(trashId);
      return NextResponse.json({ success: deleted, message: "Item permanently deleted" });
    }

    if (action === "empty") {
      emptyTrash();
      return NextResponse.json({ success: true, message: "Trash emptied successfully" });
    }

    return NextResponse.json({ success: false, message: "Invalid action" }, { status: 400 });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json(
      { success: false, message: err?.message || "Internal server error" },
      { status: 500 }
    );
  }
}
