import { NextResponse } from "next/server";
import { verifyAdminSession } from "@/lib/security";
import { sendTelegramNotification } from "@/lib/telegramServer";

export async function POST(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json().catch(() => ({}));
    const { botToken, chatId } = body;

    const testMessage = `🚀 <b>ការសាកល្បងប្រព័ន្ធ Telegram Bot (Broteach Admin Test)</b>\n\n` +
      `✅ ការតភ្ជាប់ប្រព័ន្ធទទួលបានជោគជ័យ 100%!\n` +
      `📡 ប្រព័ន្ធជូនដំណឹងការបញ្ជាទិញ (Order Notifications) ដំណើរការជាធម្មតា។\n\n` +
      `⏰ ម៉ោងសាកល្បង: ${new Date().toLocaleString("km-KH", { timeZone: "Asia/Phnom_Penh" })}`;

    const result = await sendTelegramNotification(testMessage, {
      botToken: botToken || undefined,
      chatId: chatId || undefined,
    });

    if (!result.success) {
      return NextResponse.json(
        { success: false, message: result.error || "Failed to send test message to Telegram" },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "សារតេស្តត្រូវបានផ្ញើទៅកាន់ Telegram របស់អ្នកដោយជោគជ័យ! (Test notification sent successfully!)",
    });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json(
      { success: false, message: err?.message || "Internal server error" },
      { status: 500 }
    );
  }
}
