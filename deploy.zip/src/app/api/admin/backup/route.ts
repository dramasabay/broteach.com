import { NextResponse } from "next/server";
import { verifyAdminSession } from "@/lib/security";
import {
  generateFullBackup,
  createSnapshot,
  listSnapshots,
  getSnapshot,
  deleteSnapshot,
  restoreFromBackup,
} from "@/lib/backup";
import { broadcastCmsUpdate } from "@/lib/realtime";

const noCacheHeaders = {
  "Cache-Control": "no-store, no-cache, must-revalidate",
  Pragma: "no-cache",
};

export async function GET(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json(
      { success: false, message: "Unauthorized" },
      { status: 401, headers: noCacheHeaders }
    );
  }

  const { searchParams } = new URL(req.url);
  const action = searchParams.get("action");
  const file = searchParams.get("file");

  // Export & Download active live system state as a file
  if (action === "export") {
    const backup = generateFullBackup("manual-export");
    const dateStr = new Date().toISOString().split("T")[0];
    const filename = `broteach-backup-${dateStr}.json`;

    return new NextResponse(JSON.stringify(backup, null, 2), {
      status: 200,
      headers: {
        ...noCacheHeaders,
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="${filename}"`,
      },
    });
  }

  // Download a specific server snapshot file
  if (action === "download" && file) {
    const snapshotData = getSnapshot(file);
    if (!snapshotData) {
      return NextResponse.json(
        { success: false, message: "Snapshot not found" },
        { status: 404, headers: noCacheHeaders }
      );
    }

    return new NextResponse(JSON.stringify(snapshotData, null, 2), {
      status: 200,
      headers: {
        ...noCacheHeaders,
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="${file}"`,
      },
    });
  }

  // Default: return snapshot listings and current live entity stats
  const liveBackup = generateFullBackup();
  const snapshots = listSnapshots();

  return NextResponse.json(
    {
      success: true,
      currentStats: liveBackup.stats,
      snapshots,
    },
    { headers: noCacheHeaders }
  );
}

export async function POST(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json(
      { success: false, message: "Unauthorized" },
      { status: 401, headers: noCacheHeaders }
    );
  }

  try {
    const body = await req.json();
    const { action, tag, filename, backupData, selective } = body;

    // 1. Create a server snapshot
    if (action === "create-snapshot") {
      const snapshot = createSnapshot(tag || "manual-dashboard");
      return NextResponse.json(
        {
          success: true,
          message: "Snapshot created successfully",
          snapshot,
          snapshots: listSnapshots(),
        },
        { headers: noCacheHeaders }
      );
    }

    // 2. Restore from server snapshot
    if (action === "restore-snapshot") {
      if (!filename || typeof filename !== "string") {
        return NextResponse.json(
          { success: false, message: "Snapshot filename is required" },
          { status: 400, headers: noCacheHeaders }
        );
      }

      const snapshot = getSnapshot(filename);
      if (!snapshot) {
        return NextResponse.json(
          { success: false, message: "Snapshot file not found" },
          { status: 404, headers: noCacheHeaders }
        );
      }

      const restoreResult = restoreFromBackup(snapshot, { selective });
      if (!restoreResult.success) {
        return NextResponse.json(restoreResult, { status: 400, headers: noCacheHeaders });
      }

      // Notify other clients / revalidate
      try {
        broadcastCmsUpdate("backup-restored");
      } catch {
        // non-blocking
      }

      return NextResponse.json(
        {
          ...restoreResult,
          snapshots: listSnapshots(),
        },
        { headers: noCacheHeaders }
      );
    }

    // 3. Restore from an uploaded backup JSON payload
    if (action === "restore-upload") {
      if (!backupData || typeof backupData !== "object") {
        return NextResponse.json(
          { success: false, message: "Valid backup payload is required" },
          { status: 400, headers: noCacheHeaders }
        );
      }

      const restoreResult = restoreFromBackup(backupData, { selective });
      if (!restoreResult.success) {
        return NextResponse.json(restoreResult, { status: 400, headers: noCacheHeaders });
      }

      // Notify clients
      try {
        broadcastCmsUpdate("backup-restored");
      } catch {
        // non-blocking
      }

      return NextResponse.json(
        {
          ...restoreResult,
          snapshots: listSnapshots(),
        },
        { headers: noCacheHeaders }
      );
    }

    // 4. Delete a server snapshot
    if (action === "delete-snapshot") {
      if (!filename || typeof filename !== "string") {
        return NextResponse.json(
          { success: false, message: "Snapshot filename is required" },
          { status: 400, headers: noCacheHeaders }
        );
      }

      const deleted = deleteSnapshot(filename);
      if (!deleted) {
        return NextResponse.json(
          { success: false, message: "Snapshot could not be deleted or does not exist" },
          { status: 404, headers: noCacheHeaders }
        );
      }

      return NextResponse.json(
        {
          success: true,
          message: "Snapshot deleted successfully",
          snapshots: listSnapshots(),
        },
        { headers: noCacheHeaders }
      );
    }

    return NextResponse.json(
      { success: false, message: "Invalid action" },
      { status: 400, headers: noCacheHeaders }
    );
  } catch (err) {
    console.error("Backup action error:", err);
    return NextResponse.json(
      { success: false, message: "Internal server error" },
      { status: 500, headers: noCacheHeaders }
    );
  }
}
