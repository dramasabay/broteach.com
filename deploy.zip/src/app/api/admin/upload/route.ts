import { NextResponse } from "next/server";
import { verifyAdminSession } from "@/lib/security";
import {
  listUploadedFiles,
  saveUploadedFile,
  deleteUploadedFile,
} from "@/lib/storageManager";

const noCacheHeaders = {
  "Cache-Control": "no-store, no-cache, must-revalidate",
  Pragma: "no-cache",
};

/**
 * GET /api/admin/upload
 * List all uploaded files
 */
export async function GET(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json(
      { success: false, message: "Unauthorized" },
      { status: 401, headers: noCacheHeaders }
    );
  }

  const files = listUploadedFiles();
  return NextResponse.json(
    { success: true, files },
    { headers: noCacheHeaders }
  );
}

/**
 * POST /api/admin/upload
 * Handle file upload (multipart/form-data)
 */
export async function POST(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json(
      { success: false, message: "Unauthorized" },
      { status: 401, headers: noCacheHeaders }
    );
  }

  try {
    const formData = await req.formData();
    const file = formData.get("file") as File | null;

    if (!file) {
      return NextResponse.json(
        { success: false, message: "No file provided" },
        { status: 400, headers: noCacheHeaders }
      );
    }

    const result = await saveUploadedFile(file);
    if (!result.success) {
      return NextResponse.json(
        { success: false, message: result.message || "Failed to save file" },
        { status: 400, headers: noCacheHeaders }
      );
    }

    return NextResponse.json(
      {
        success: true,
        message: "File uploaded successfully",
        file: result.file,
      },
      { headers: noCacheHeaders }
    );
  } catch (error) {
    console.error("File upload error:", error);
    return NextResponse.json(
      { success: false, message: "Error uploading file" },
      { status: 500, headers: noCacheHeaders }
    );
  }
}

/**
 * DELETE /api/admin/upload
 * Delete an uploaded file
 */
export async function DELETE(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json(
      { success: false, message: "Unauthorized" },
      { status: 401, headers: noCacheHeaders }
    );
  }

  try {
    const { searchParams } = new URL(req.url);
    let filename = searchParams.get("file");

    if (!filename) {
      try {
        const body = await req.json();
        filename = body.filename;
      } catch {
        // ignore
      }
    }

    if (!filename) {
      return NextResponse.json(
        { success: false, message: "Filename is required" },
        { status: 400, headers: noCacheHeaders }
      );
    }

    const success = deleteUploadedFile(filename);
    if (!success) {
      return NextResponse.json(
        { success: false, message: "File not found or could not be deleted" },
        { status: 404, headers: noCacheHeaders }
      );
    }

    return NextResponse.json(
      { success: true, message: "File deleted successfully" },
      { headers: noCacheHeaders }
    );
  } catch (error) {
    console.error("Delete file error:", error);
    return NextResponse.json(
      { success: false, message: "Error deleting file" },
      { status: 500, headers: noCacheHeaders }
    );
  }
}
