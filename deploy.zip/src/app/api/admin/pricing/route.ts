import { NextResponse } from "next/server";
import { getPricingPlans, savePricingPlan, deletePricingPlan } from "@/lib/contentStore";
import { verifyAdminSession } from "@/lib/security";
import { broadcastCmsUpdate } from "@/lib/realtime";

export async function GET() {
  const plans = getPricingPlans();
  return NextResponse.json({ success: true, plans });
}

export async function POST(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized access" }, { status: 401 });
  }

  try {
    const body = await req.json();
    if (!body.nameKm || !body.nameEn || typeof body.price !== "number") {
      return NextResponse.json(
        { success: false, message: "Missing required fields (nameKm, nameEn, price)" },
        { status: 400 }
      );
    }

    const saved = savePricingPlan(body);
    broadcastCmsUpdate("pricing");

    return NextResponse.json({
      success: true,
      message: "Pricing plan saved successfully",
      plan: saved,
    });
  } catch (err) {
    console.error("Save pricing plan error:", err);
    return NextResponse.json({ success: false, message: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized access" }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ success: false, message: "Missing plan ID" }, { status: 400 });
    }

    const deleted = deletePricingPlan(id);
    if (!deleted) {
      return NextResponse.json({ success: false, message: "Plan not found" }, { status: 404 });
    }

    broadcastCmsUpdate("pricing");
    return NextResponse.json({ success: true, message: "Pricing plan deleted successfully" });
  } catch (err) {
    console.error("Delete pricing plan error:", err);
    return NextResponse.json({ success: false, message: "Internal server error" }, { status: 500 });
  }
}
