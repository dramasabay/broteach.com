import { NextResponse } from "next/server";
import { getProducts, saveProduct, deleteProduct } from "@/lib/contentStore";
import { verifyAdminSession, sanitizeText } from "@/lib/security";

export async function GET(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }
  const products = getProducts();
  return NextResponse.json({ success: true, count: products.length, products });
}

export async function POST(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const {
      id,
      titleKm,
      titleEn,
      category,
      categoryLabelKm,
      categoryLabelEn,
      price,
      badgeKm,
      badgeEn,
      descKm,
      descEn,
      featuresKm,
      featuresEn,
      icon,
      demoUrl,
      thumbnailUrl,
      isActive,
      sortOrder,
    } = body;

    if (!titleKm || !titleEn || typeof price !== "number") {
      return NextResponse.json(
        { success: false, message: "Title and numeric price are required" },
        { status: 400 }
      );
    }

    const saved = saveProduct({
      id: id ? sanitizeText(id) : undefined,
      titleKm: sanitizeText(titleKm),
      titleEn: sanitizeText(titleEn),
      category: category || "webapp",
      categoryLabelKm: sanitizeText(categoryLabelKm || "សេវាកម្ម"),
      categoryLabelEn: sanitizeText(categoryLabelEn || "Service"),
      price: Math.max(0, Number(price)),
      badgeKm: badgeKm ? sanitizeText(badgeKm) : undefined,
      badgeEn: badgeEn ? sanitizeText(badgeEn) : undefined,
      descKm: sanitizeText(descKm || ""),
      descEn: sanitizeText(descEn || ""),
      featuresKm: Array.isArray(featuresKm) ? featuresKm.map(sanitizeText) : [],
      featuresEn: Array.isArray(featuresEn) ? featuresEn.map(sanitizeText) : [],
      icon: sanitizeText(icon || "Sparkles"),
      demoUrl: demoUrl ? sanitizeText(demoUrl) : undefined,
      thumbnailUrl: thumbnailUrl ? sanitizeText(thumbnailUrl) : undefined,
      isActive: isActive !== false,
      sortOrder: Number(sortOrder) || 1,
    });

    return NextResponse.json({
      success: true,
      message: "Product saved successfully",
      product: saved,
    });
  } catch (error) {
    console.error("Save product error:", error);
    return NextResponse.json({ success: false, message: "Failed to save product" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  if (!(await verifyAdminSession(req))) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ success: false, message: "Product ID required" }, { status: 400 });
    }

    const deleted = deleteProduct(id);
    if (!deleted) {
      return NextResponse.json({ success: false, message: "Product not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, message: "Product deleted successfully" });
  } catch {
    return NextResponse.json({ success: false, message: "Error deleting product" }, { status: 500 });
  }
}
