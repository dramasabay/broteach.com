import { NextResponse } from "next/server";
import { checkRateLimit, getClientIp, sanitizeText } from "@/lib/security";

interface ChatPayload {
  message: string;
  lang?: "km" | "en";
}

export async function POST(req: Request) {
  const ip = getClientIp(req);
  const rate = checkRateLimit(`chat-${ip}`, 30, 60 * 1000); // 30 messages per minute max
  if (!rate.allowed) {
    return NextResponse.json(
      {
        success: false,
        text: "You are sending messages too quickly. Please wait a moment.",
        options: [],
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      },
      { status: 429 }
    );
  }

  try {
    const { message, lang = "km" }: ChatPayload = await req.json();
    const cleanMessage = sanitizeText(message);

    if (!cleanMessage) {
      return NextResponse.json({ error: "Message is required" }, { status: 400 });
    }

    const lower = cleanMessage.toLowerCase();

    let botResponse = "";
    let options: { label: string; action: string }[] = [];

    if (lang === "km") {
      if (lower.includes("តម្លៃ") || lower.includes("ថ្លៃ") || lower.includes("price") || lower.includes("កញ្ចប់")) {
        botResponse = "បាទ! Broteach មាន ៣ កញ្ចប់តម្លៃស្តង់ដារជូនលោកអ្នក៖\n\n1️⃣ **រៀនកូដ (Starter)**: $250 - ស័ក្តិសមសម្រាប់គេហទំព័រផ្ទាល់ខ្លួន\n2️⃣ **ក្រុមហ៊ុន (Popular)**: $450 - កញ្ចប់ពេញនិយមបំផុត មាន CMS Dashboard និង SSD លឿន\n3️⃣ **ស្ថាប័នធំ (Enterprise)**: $850+ - សម្រាប់ក្រុមហ៊ុនធំ ឬ E-commerce ភ្ជាប់ ABA KHQR\n\nតើលោកអ្នកចាប់អារម្មណ៍កញ្ចប់មួយណាដែរ?";
        options = [
          { label: "មើលកញ្ចប់ $450 (ពេញនិយម)", action: "select_plan_company" },
          { label: "មើលកញ្ចប់ $250", action: "select_plan_starter" },
          { label: "កុម្ម៉ង់តាម Telegram ផ្ទាល់", action: "telegram_order" },
        ];
      } else if (lower.includes("telegram") || lower.includes("តេឡេក្រាម")) {
        botResponse = "លោកអ្នកអាចឆាតកុម្ម៉ង់ផ្ទាល់ជាមួយក្រុមការងារតាម Telegram៖ @broteach_support ឬចុចប៊ូតុងខាងក្រោមដើម្បីផ្ញើសារភ្លាមៗ!";
        options = [
          { label: "បើក Telegram ឥឡូវនេះ", action: "telegram_order" },
          { label: "សួរតម្លៃសេវាកម្ម", action: "ask_pricing" },
        ];
      } else if (lower.includes("ហូស្ទីង") || lower.includes("hosting") || lower.includes("domain") || lower.includes("ដូមេន")) {
        botResponse = "រាល់កញ្ចប់គេហទំព័ររបស់ Broteach គឺផ្តល់ជូន **Domain ឥតគិតថ្លៃ ១ ឆ្នាំ** និង **High-Speed Cloud SSD Hosting ឥតគិតថ្លៃ ១ ឆ្នាំពេញ** រួមទាំងប្រព័ន្ធសុវត្ថិភាព SSL Certificate ផងដែរ!";
        options = [
          { label: "សួរពីល្បឿន Server", action: "server_speed" },
          { label: "កុម្ម៉ង់តាម Telegram", action: "telegram_order" },
        ];
      } else if (lower.includes("ទាក់ទង") || lower.includes("លេខ") || lower.includes("contact") || lower.includes("phone")) {
        botResponse = "លោកអ្នកអាចទាក់ទងមកកាន់ក្រុមការងារ Broteach ផ្ទាល់តាមរយៈ៖\n📞 ទូរស័ព្ទ៖ (+855) 098 765 432\n✈️ Telegram: @broteach_support\n📧 អ៊ីមែល: info@broteach.com\nយើងខ្ញុំរីករាយស្វាគមន៍ ២៤/៧!";
        options = [{ label: "ឆាត Telegram ភ្លាមៗ", action: "telegram_order" }];
      } else {
        botResponse = "សូមអរគុណសម្រាប់ការទាក់ទងមក Broteach! តើខ្ញុំអាចជួយផ្តល់ព័ត៌មានបន្ថែមអំពីផលិតផល ឬសេវាកម្មគេហទំព័រអ្វីខ្លះជូនលោកអ្នក?";
        options = [
          { label: "មើលតម្លៃកញ្ចប់គេហទំព័រ", action: "ask_pricing" },
          { label: "ឆាតកុម្ម៉ង់តាម Telegram", action: "telegram_order" },
        ];
      }
    } else {
      if (lower.includes("price") || lower.includes("cost") || lower.includes("plan")) {
        botResponse = "Broteach provides 3 transparent packages:\n\n1️⃣ **Starter**: $250 - Ideal for personal portfolios.\n2️⃣ **Company (Popular)**: $450 - Full CMS Dashboard, SSD hosting.\n3️⃣ **Enterprise**: $850+ - Scalable cloud architecture & payment gateway.\n\nWhich plan would you like to explore?";
        options = [
          { label: "Explore $450 Plan", action: "select_plan_company" },
          { label: "Order via Telegram", action: "telegram_order" },
        ];
      } else if (lower.includes("telegram")) {
        botResponse = "You can chat and order directly with our engineering team on Telegram at @broteach_support!";
        options = [{ label: "Open Telegram Chat", action: "telegram_order" }];
      } else {
        botResponse = "Hello! Welcome to Broteach. How can we help you build and scale your digital presence today?";
        options = [
          { label: "View Pricing Plans", action: "ask_pricing" },
          { label: "Order via Telegram", action: "telegram_order" },
        ];
      }
    }

    return NextResponse.json({
      success: true,
      text: botResponse,
      options,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    });
  } catch (error) {
    console.error("Chat error:", error);
    return NextResponse.json({ error: "Failed to generate response" }, { status: 500 });
  }
}
