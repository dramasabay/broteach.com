import type { Metadata } from "next";
import { Kantumruy_Pro, Inter } from "next/font/google";
import "./globals.css";
import { LanguageProvider } from "@/components/LanguageContext";
import { SiteSettingsProvider } from "@/components/SiteSettingsContext";
import { MobileBottomNav } from "@/components/MobileBottomNav";
import { CookieConsent } from "@/components/CookieConsent";
import { ScreenAdsPopup } from "@/components/ScreenAdsPopup";
import { getSiteSettings } from "@/lib/contentStore";

const kantumruy = Kantumruy_Pro({
  subsets: ["khmer", "latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-kantumruy",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-inter",
  display: "swap",
});

const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://broteach.com";

export async function generateMetadata(): Promise<Metadata> {
  const settings = getSiteSettings();
  const siteTitle =
    settings.seoTitleKm || "Broteach | គេហទំព័រអាជីវកម្មតាមបែបស្តង់ដារ & Cloud Hosting";
  const siteDesc =
    settings.seoDescKm ||
    "សេវាកម្មបង្កើតគេហទំព័រអាជីវកម្មតាមបែបស្តង់ដារ ហាងទំនិញ E-Commerce និង Cloud Hosting NVMe SSD ល្បឿនលឿន និងសុវត្ថិភាពខ្ពស់នៅកម្ពុជា។";
  const keywords = settings.seoKeywords
    ? settings.seoKeywords.split(",").map((s) => s.trim())
    : [
        "Broteach",
        "គេហទំព័រអាជីវកម្ម",
        "បង្កើតគេហទំព័រ",
        "E-commerce Cambodia",
        "ABA KHQR Payment",
        "Cloud Hosting Cambodia",
        "NVMe SSD VPS",
      ];

  const meta: Metadata = {
    metadataBase: new URL(baseUrl),
    title: {
      default: siteTitle,
      template: "%s | Broteach Cambodia",
    },
    description: siteDesc,
    keywords,
    authors: [{ name: "Broteach Engineering Team", url: baseUrl }],
    creator: "Broteach",
    publisher: "Broteach Digital",
    formatDetection: {
      email: false,
      address: false,
      telephone: false,
    },
    alternates: {
      canonical: baseUrl,
      languages: {
        "km-KH": baseUrl,
        "en-US": baseUrl,
      },
    },
    openGraph: {
      title: siteTitle,
      description: siteDesc,
      url: baseUrl,
      siteName: "Broteach Digital",
      locale: "km_KH",
      type: "website",
      images: settings.seoImageUrl
        ? [{ url: settings.seoImageUrl, width: 1200, height: 630, alt: siteTitle }]
        : [{ url: `${baseUrl}/favicon.ico` }],
    },
    twitter: {
      card: "summary_large_image",
      title: siteTitle,
      description: siteDesc,
      creator: "@broteach",
      images: settings.seoImageUrl ? [settings.seoImageUrl] : [`${baseUrl}/favicon.ico`],
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        "max-video-preview": -1,
        "max-image-preview": "large",
        "max-snippet": -1,
      },
    },
    icons: {
      icon: settings.siteIconUrl
        ? [
            { url: settings.siteIconUrl },
            { url: "/favicon.ico", sizes: "32x32" },
            { url: "/favicon.svg", type: "image/svg+xml" },
          ]
        : [
            { url: "/favicon.svg", type: "image/svg+xml" },
            { url: "/icon.svg", type: "image/svg+xml" },
            { url: "/favicon.ico", sizes: "32x32" },
          ],
      shortcut: settings.siteIconUrl || "/favicon.ico",
      apple: settings.siteIconUrl || "/apple-icon.png",
    },
  };

  if (settings.googleConsoleVerification) {
    meta.verification = {
      google: settings.googleConsoleVerification,
    };
  }

  return meta;
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const settings = getSiteSettings();

  // Structured JSON-LD Data for Rich Google Results
  const jsonLd = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "@id": `${baseUrl}/#organization`,
        name: "Broteach",
        url: baseUrl,
        logo: settings.siteLogoUrl || `${baseUrl}/favicon.ico`,
        contactPoint: {
          "@type": "ContactPoint",
          telephone: settings.phone1 || "+855-12-345-678",
          contactType: "customer service",
          areaServed: "KH",
          availableLanguage: ["Khmer", "English"],
        },
        sameAs: [
          `https://t.me/${settings.telegramUsername || "broteach_support"}`,
          "https://facebook.com/broteach",
          "https://youtube.com/@broteach",
        ],
      },
      {
        "@type": "WebSite",
        "@id": `${baseUrl}/#website`,
        url: baseUrl,
        name: "Broteach Digital & Cloud",
        description: "Professional Web Design and Cloud VPS Hosting in Cambodia",
        publisher: {
          "@id": `${baseUrl}/#organization`,
        },
        inLanguage: ["km", "en"],
      },
      {
        "@type": "Product",
        name: "Standard Business Website Package",
        description: "Professional business website with 1 year free domain and fast SSD cloud hosting.",
        brand: {
          "@type": "Brand",
          name: "Broteach",
        },
        offers: {
          "@type": "Offer",
          price: "450.00",
          priceCurrency: "USD",
          availability: "https://schema.org/InStock",
          url: baseUrl,
        },
      },
    ],
  };

  return (
    <html
      lang="km"
      suppressHydrationWarning
      className={`${kantumruy.variable} ${inter.variable} scroll-smooth`}
    >
      <head>
        {settings.googleConsoleVerification && (
          <meta
            name="google-site-verification"
            content={settings.googleConsoleVerification}
          />
        )}
        <link rel="icon" href={settings.siteIconUrl || "/favicon.ico"} sizes="any" />
        <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
        <link rel="apple-touch-icon" href={settings.siteIconUrl || "/apple-icon.png"} />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        {/* Neutralize third-party browser extension DOM mutations and hydration noise (e.g. Bitdefender bis_skin_checked) */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                try {
                  // 1. Filter out console.error hydration warnings caused by browser extensions
                  if (typeof console !== 'undefined' && console.error) {
                    var origConsoleError = console.error;
                    console.error = function() {
                      var args = Array.prototype.slice.call(arguments);
                      var fullMsg = args.map(function(item) {
                        return typeof item === 'string' ? item : (item && (item.message || item.stack)) || '';
                      }).join(' ');
                      if (fullMsg.indexOf('bis_skin_checked') !== -1 || fullMsg.indexOf('bis_') !== -1) {
                        return;
                      }
                      return origConsoleError.apply(console, arguments);
                    };
                  }

                  // 2. Active MutationObserver to remove bis_skin_checked immediately as nodes are created
                  var cleanEl = function(el) {
                    if (el && el.nodeType === 1) {
                      if (el.hasAttribute('bis_skin_checked')) el.removeAttribute('bis_skin_checked');
                      if (el.attributes) {
                        for (var i = el.attributes.length - 1; i >= 0; i--) {
                          var attr = el.attributes[i].name;
                          if (attr && (attr === 'bis_skin_checked' || attr.indexOf('bis_') === 0)) {
                            el.removeAttribute(attr);
                          }
                        }
                      }
                    }
                  };

                  if (typeof MutationObserver !== 'undefined') {
                    var observer = new MutationObserver(function(mutations) {
                      for (var i = 0; i < mutations.length; i++) {
                        var m = mutations[i];
                        if (m.type === 'attributes' && m.attributeName && m.attributeName.indexOf('bis_') === 0) {
                          m.target.removeAttribute(m.attributeName);
                        } else if (m.type === 'childList') {
                          for (var j = 0; j < m.addedNodes.length; j++) {
                            cleanEl(m.addedNodes[j]);
                          }
                        }
                      }
                    });

                    var target = document.documentElement || document;
                    observer.observe(target, {
                      attributes: true,
                      childList: true,
                      subtree: true,
                      attributeFilter: ['bis_skin_checked']
                    });
                  }
                } catch(e) {}
              })();
            `,
          }}
        />
      </head>
      <body
        suppressHydrationWarning
        className="font-sans antialiased bg-[#030d1a] text-slate-100 min-h-screen selection:bg-cyan-500 selection:text-white"
      >
        <SiteSettingsProvider initialSettings={settings}>
          <LanguageProvider>
            {children}
            <ScreenAdsPopup />
            <MobileBottomNav />
            <CookieConsent />
          </LanguageProvider>
        </SiteSettingsProvider>
      </body>
    </html>
  );
}
