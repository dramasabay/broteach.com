import type { Metadata } from "next";

const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://broteach.com";

export const metadata: Metadata = {
  title: "ផលិតផល & ដំណោះស្រាយឌីជីថល | Broteach ThemeForest-Style Digital Solutions",
  description:
    "ទស្សនាបណ្តុំគេហទំព័រអាជីវកម្ម ហាងទំនិញ E-Commerce ABA KHQR ប្រព័ន្ធអចលនទ្រព្យ និង Cloud Hosting ល្បឿនលឿនកម្រិតស្តង់ដារអន្តរជាតិ។",
  alternates: {
    canonical: `${baseUrl}/products`,
    languages: {
      "km-KH": `${baseUrl}/products`,
      "en-US": `${baseUrl}/products`,
    },
  },
  openGraph: {
    title: "Products & Digital Solutions | Broteach Cambodia",
    description:
      "ThemeForest-style verified web solutions, E-Commerce platforms with ABA KHQR payment, and high-performance cloud hosting.",
    url: `${baseUrl}/products`,
    siteName: "Broteach Digital",
    locale: "km_KH",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Broteach Digital Products & Templates",
    description: "Premium web platforms & verified solutions built for business growth.",
  },
};

export default function ProductsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
