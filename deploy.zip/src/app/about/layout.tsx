import type { Metadata } from "next";

const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://broteach.com";

export const metadata: Metadata = {
  title: "អំពីយើង - Broteach Digital Solutions | Professional Web Development & Cloud Cambodia",
  description:
    "ស្វែងយល់អំពី Broteach Digital Solutions ក្រុមការងារវិស្វកម្មគេហទំព័រកម្រិតខ្ពស់ និង Cloud Hosting NVMe SSD ល្បឿនលឿននៅកម្ពុជា ជាមួយការទូទាត់ប្រាក់ ABA KHQR ស្វ័យប្រវត្តិ។",
  alternates: {
    canonical: `${baseUrl}/about`,
    languages: {
      "km-KH": `${baseUrl}/about`,
      "en-US": `${baseUrl}/about`,
    },
  },
  openGraph: {
    title: "About Us | Broteach Digital & Cloud Solutions Cambodia",
    description:
      "Enterprise Web Engineering & High-Speed Cloud Infrastructure in Cambodia with sub-second page performance and 24/7 dedicated support.",
    url: `${baseUrl}/about`,
    siteName: "Broteach Digital",
    locale: "km_KH",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "About Broteach Cambodia",
    description:
      "Strategic Partner in Enterprise Web Engineering & High-Speed Cloud Infrastructure in Cambodia.",
  },
};

export default function AboutLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
