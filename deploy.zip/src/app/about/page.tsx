"use client";

import React, { useEffect } from "react";
import Link from "next/link";
import {
  ShieldCheck,
  Zap,
  Users,
  ArrowLeft,
  Send,
  CheckCircle,
  Globe,
  Sparkles,
  Server,
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { NewsletterBanner } from "@/components/NewsletterBanner";
import { useLanguage } from "@/components/LanguageContext";
import { subscribeCmsUpdates } from "@/lib/realtime";
import { useSiteSettings } from "@/components/SiteSettingsContext";

export default function AboutPage() {
  const { language } = useLanguage();
  const { settings, setSettings } = useSiteSettings();

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const res = await fetch(`/api/content?t=${Date.now()}`);
        if (res.ok) {
          const data = await res.json();
          if (data.settings) {
            setSettings(data.settings);
          }
        }
      } catch (err) {
        console.error("Failed to load settings:", err);
      }
    };

    fetchSettings();
    const unsubscribe = subscribeCmsUpdates(() => {
      fetchSettings();
    });

    return () => unsubscribe();
  }, [setSettings]);

  const telegramUser = settings?.telegramUsername || "broteach_support";
  const cleanTg = telegramUser.replace("@", "");

  const title =
    language === "km"
      ? settings?.aboutTitleKm || "អំពីយើង - Broteach Digital Solutions"
      : settings?.aboutTitleEn || "About Us - Broteach Digital Solutions";

  const subtitle =
    language === "km"
      ? settings?.aboutSubtitleKm ||
        "ដៃគូយុទ្ធសាស្ត្រក្នុងការអភិវឌ្ឍបច្ចេកវិទ្យាគេហទំព័រ និង Cloud Hosting កម្រិតខ្ពស់នៅកម្ពុជា"
      : settings?.aboutSubtitleEn ||
        "Your Strategic Partner in Enterprise Web Engineering & High-Speed Cloud Infrastructure in Cambodia";

  const story =
    language === "km"
      ? settings?.aboutStoryKm ||
        "បង្កើតឡើងក្នុងគោលបំណងលើកកម្ពស់ស្តង់ដារបច្ចេកវិទ្យាគេហទំព័រនៅប្រទេសកម្ពុជា Broteach បានជួយអាជីវកម្ម សហគ្រាស និងស្ថាប័នអប់រំរាប់រយឱ្យមានគេហទំព័រទំនើប លឿន សុវត្ថិភាព និងគាំទ្រការទូទាត់ប្រាក់ ABA KHQR ស្វ័យប្រវត្តិ។"
      : settings?.aboutStoryEn ||
        "Founded with the mission to elevate digital standards in Cambodia, Broteach has empowered hundreds of enterprises, SMEs, and educational institutions with blazing-fast, secure, and modern web platforms integrated with automated ABA KHQR payments.";

  const mission =
    language === "km"
      ? settings?.aboutMissionKm ||
        "ផ្តល់ជូននូវគេហទំព័រ និងប្រព័ន្ធឌីជីថលដែលមានល្បឿនផ្ទុកក្រោម ១ វិនាទី សុវត្ថិភាពខ្ពស់ និងការគាំទ្របច្ចេកទេស ២៤/៧ ដើម្បីឱ្យអាជីវកម្មរបស់អតិថិជនរីកចម្រើនឥតឈប់ឈរ។"
      : settings?.aboutMissionEn ||
        "To deliver sub-second loading web applications with bulletproof security, 99.9% uptime, and round-the-clock dedicated engineering support.";

  return (
    <div className="min-h-screen bg-[#030d1a] flex flex-col text-slate-200 selection:bg-cyan-500 selection:text-white">
      <Navbar />

      {/* Hero Section */}
      <section className="pt-28 pb-14 sm:pt-36 sm:pb-20 bg-gradient-to-b from-[#06162d] via-[#041021] to-[#030d1a] border-b border-cyan-950/60 relative overflow-hidden">
        {/* Glow Spheres */}
        <div className="absolute top-10 left-1/4 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-10 w-96 h-96 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-6">
            <Link href="/" className="hover:text-cyan-400 transition-colors flex items-center gap-1">
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{language === "km" ? "ទំព័រដើម" : "Home"}</span>
            </Link>
            <span>/</span>
            <span className="text-cyan-400 font-semibold">
              {language === "km" ? "អំពីយើង" : "About Us"}
            </span>
          </div>

          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 text-xs font-bold shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>{language === "km" ? "ស្គាល់អំពីយើង" : "Discover Broteach"}</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white leading-tight">
              {title}
            </h1>

            <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
              {subtitle}
            </p>
          </div>
        </div>
      </section>

      {/* Main Content Grid */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 space-y-16">
        {/* Story & Mission Two-Column Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
          {/* Our Story Card */}
          <div className="rounded-3xl bg-[#061528]/90 border border-slate-800 p-6 sm:p-8 flex flex-col justify-between shadow-xl">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-400 flex items-center justify-center">
                <Globe className="w-6 h-6" />
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                {language === "km" ? "ដំណើរដើមទងរបស់យើង" : "Our Journey & Story"}
              </h2>
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                {story}
              </p>
            </div>
            <div className="pt-6 border-t border-slate-800/80 mt-6 flex items-center gap-3 text-xs text-cyan-400 font-semibold">
              <CheckCircle className="w-4 h-4" />
              <span>{language === "km" ? "បទពិសោធន៍លើសពី ៧ ឆ្នាំ" : "7+ Years Industry Experience"}</span>
            </div>
          </div>

          {/* Our Mission Card */}
          <div className="rounded-3xl bg-gradient-to-br from-[#0e223d] to-[#071324] border border-cyan-500/40 p-6 sm:p-8 flex flex-col justify-between shadow-xl">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-red-950/80 border border-red-500/40 text-red-400 flex items-center justify-center">
                <Zap className="w-6 h-6" />
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                {language === "km" ? "បេសកកម្មរបស់យើង" : "Our Core Mission"}
              </h2>
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                {mission}
              </p>
            </div>
            <div className="pt-6 border-t border-slate-800/80 mt-6 flex items-center gap-3 text-xs text-emerald-400 font-semibold">
              <CheckCircle className="w-4 h-4" />
              <span>{language === "km" ? "ល្បឿន & សុវត្ថិភាពជាចម្បង" : "Velocity & Bulletproof Security First"}</span>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          {[
            {
              metric: "99.9%",
              labelKm: "កម្រិត Uptime ធានា",
              labelEn: "Uptime Guaranteed",
              descKm: "Cloud NVMe SSD",
              descEn: "Cloud NVMe SSD",
            },
            {
              metric: "50+",
              labelKm: "អតិថិជនសកម្ម",
              labelEn: "Active Clients",
              descKm: "ទូទាំងប្រទេសកម្ពុជា",
              descEn: "Across Cambodia",
            },
            {
              metric: "< 0.8s",
              labelKm: "ល្បឿនផ្ទុកទំព័រ",
              labelEn: "Page Load Speed",
              descKm: "Google PageSpeed 95+",
              descEn: "Google PageSpeed 95+",
            },
            {
              metric: "24/7",
              labelKm: "ជំនួយបច្ចេកទេស",
              labelEn: "Technical Support",
              descKm: "តាម Telegram ផ្ទាល់",
              descEn: "Direct on Telegram",
            },
          ].map((stat, idx) => (
            <div
              key={idx}
              className="p-5 sm:p-6 rounded-2xl bg-[#061528] border border-slate-800 text-center space-y-1.5 shadow-lg"
            >
              <div className="text-2xl sm:text-3xl font-black text-cyan-400 tracking-tight">
                {stat.metric}
              </div>
              <div className="text-xs sm:text-sm font-bold text-white">
                {language === "km" ? stat.labelKm : stat.labelEn}
              </div>
              <div className="text-[11px] text-slate-400">
                {language === "km" ? stat.descKm : stat.descEn}
              </div>
            </div>
          ))}
        </div>

        {/* Core Capabilities */}
        <div className="space-y-6">
          <div className="text-center max-w-xl mx-auto space-y-2">
            <h3 className="text-2xl sm:text-3xl font-black text-white">
              {language === "km" ? "ហេដ្ឋារចនាសម្ព័ន្ធ & ស្តង់ដារ" : "Our Infrastructure & Standards"}
            </h3>
            <p className="text-xs sm:text-sm text-slate-400">
              {language === "km"
                ? "បច្ចេកវិទ្យាដែលយើងប្រើប្រាស់ដើម្បីធានានូវល្បឿន និងសុវត្ថិភាពខ្ពស់បំផុត"
                : "The advanced tech stack and architecture powering your digital success."}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-3xl bg-[#07162c] border border-slate-800 space-y-3">
              <Server className="w-8 h-8 text-cyan-400" />
              <h4 className="text-lg font-bold text-white">
                {language === "km" ? "Cloud VPS & NVMe SSD" : "Cloud VPS & NVMe SSD"}
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {language === "km"
                  ? "Server បំពាក់ Hard Drive NVMe SSD លឿនជាង SSD ធម្មតា ៥ ដង ជាមួយ Bandwidth គ្មានដែនកំណត់។"
                  : "High-throughput NVMe SSD storage with unmetered bandwidth and low-latency global CDN edge."}
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-[#07162c] border border-slate-800 space-y-3">
              <ShieldCheck className="w-8 h-8 text-emerald-400" />
              <h4 className="text-lg font-bold text-white">
                {language === "km" ? "សុវត្ថិភាពកម្រិតខ្ពស់ & SSL" : "Enterprise Security & SSL"}
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {language === "km"
                  ? "ការការពារការវាយប្រហារ DDoS Firewall, Free SSL Certificate 256-bit និងការបម្រុងទុកទិន្នន័យប្រចាំថ្ងៃ។"
                  : "Real-time DDoS mitigations, automated off-site backups, and bank-grade SSL encryption."}
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-[#07162c] border border-slate-800 space-y-3">
              <Users className="w-8 h-8 text-amber-400" />
              <h4 className="text-lg font-bold text-white">
                {language === "km" ? "វិស្វករកម្ពុជាជំនាញ" : "Expert Local Engineers"}
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {language === "km"
                  ? "ក្រុមការងារត្រៀមជួយដោះស្រាយបញ្ហាបច្ចេកទេស និងកែសម្រួលតាមតម្រូវការជាក់ស្តែងគ្រប់ពេល។"
                  : "Cambodian software engineers ready to support, customize, and optimize your systems 24/7."}
              </p>
            </div>
          </div>
        </div>

        {/* Contact & Telegram CTA */}
        <div className="rounded-3xl bg-gradient-to-r from-[#0a1e3b] via-[#091a33] to-[#0a1e3b] border border-cyan-500/40 p-8 sm:p-12 text-center space-y-6 shadow-2xl">
          <h3 className="text-2xl sm:text-3xl font-black text-white">
            {language === "km"
              ? "ត្រៀមខ្លួនចាប់ផ្តើមជាមួយ Broteach ហើយឬនៅ?"
              : "Ready to Build Something Extraordinary?"}
          </h3>
          <p className="text-sm sm:text-base text-slate-300 max-w-xl mx-auto leading-relaxed">
            {language === "km"
              ? "ទាក់ទងមកកាន់យើងឥឡូវនេះតាមរយៈ Telegram ដើម្បីពិភាក្សាអំពីគម្រោងគេហទំព័រ ឬសេវាកម្ម Hosting របស់អ្នកដោយឥតគិតថ្លៃ។"
              : "Connect directly with our engineering team on Telegram for a free consultation and project roadmap."}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <a
              href={`https://t.me/${cleanTg}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold text-sm shadow-lg shadow-cyan-600/30 transition-all hover:scale-105"
            >
              <Send className="w-4 h-4 fill-current" />
              <span>Telegram: @{cleanTg}</span>
            </a>

            <Link
              href="/products"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-sm border border-slate-700 transition-colors"
            >
              <span>{language === "km" ? "មើលផលិតផលទាំងអស់" : "Explore Products"}</span>
            </Link>
          </div>
        </div>
      </main>

      {/* Newsletter */}
      <NewsletterBanner />

      <Footer />
    </div>
  );
}
