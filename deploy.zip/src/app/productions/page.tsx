"use client";

import React, { useState, useEffect, useMemo } from "react";
import Link from "next/link";
import {
  Search,
  SlidersHorizontal,
  Sparkles,
  ShoppingBag,
  Briefcase,
  Home as HomeIcon,
  GraduationCap,
  Utensils,
  Server,
  ExternalLink,
  ArrowLeft,
  X,
  RefreshCw,
  Zap,
  Eye,
  LayoutGrid,
  Send,
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { ProductDetailModal } from "@/components/ProductDetailModal";
import { useLanguage } from "@/components/LanguageContext";
import { ProductItem, SiteSettings } from "@/types";
import { defaultProducts } from "@/lib/data";
import { subscribeCmsUpdates } from "@/lib/realtime";

export default function ProductionsPage() {
  const { language } = useLanguage();
  const [products, setProducts] = useState<ProductItem[]>(defaultProducts);
  const [settings, setSettings] = useState<SiteSettings | undefined>(undefined);
  const [loading, setLoading] = useState(false);

  // Filter, Search & Layout State
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [sortBy, setSortBy] = useState<"featured" | "price-asc" | "price-desc">("featured");
  const [gridColumns, setGridColumns] = useState<4 | 5>(4);

  // Product Detail Modal
  const [selectedProduct, setSelectedProduct] = useState<ProductItem | null>(null);

  useEffect(() => {
    const fetchContent = async () => {
      try {
        const res = await fetch(`/api/content?t=${Date.now()}`);
        if (res.ok) {
          const data = await res.json();
          if (data.products && data.products.length > 0) {
            setProducts(data.products);
          }
          if (data.settings) {
            setSettings(data.settings);
          }
        }
      } catch (err) {
        console.error("Failed to load productions:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchContent();
    const unsubscribe = subscribeCmsUpdates(() => {
      fetchContent();
    });

    const interval = setInterval(fetchContent, 10000);
    return () => {
      unsubscribe();
      clearInterval(interval);
    };
  }, []);

  const categories = [
    { id: "all", labelKm: "ទាំងអស់", labelEn: "All Productions" },
    { id: "ecommerce", labelKm: "ហាងទំនិញ E-Commerce", labelEn: "E-Commerce" },
    { id: "webapp", labelKm: "គេហទំព័រអាជីវកម្ម", labelEn: "Business Portals" },
    { id: "enterprise", labelKm: "ប្រព័ន្ធស្ថាប័ន & អប់រំ", labelEn: "Enterprise & LMS" },
    { id: "hosting", labelKm: "Cloud Hosting & VPS", labelEn: "Cloud & VPS" },
  ];

  const filteredProducts = useMemo(() => {
    let list = [...products];

    if (selectedCategory !== "all") {
      list = list.filter((p) => p.category === selectedCategory);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter((p) => {
        const matchTitle =
          p.titleKm.toLowerCase().includes(q) || p.titleEn.toLowerCase().includes(q);
        const matchDesc =
          p.descKm.toLowerCase().includes(q) || p.descEn.toLowerCase().includes(q);
        return matchTitle || matchDesc;
      });
    }

    if (sortBy === "price-asc") {
      list.sort((a, b) => a.price - b.price);
    } else if (sortBy === "price-desc") {
      list.sort((a, b) => b.price - a.price);
    } else {
      list.sort((a, b) => a.sortOrder - b.sortOrder);
    }

    return list;
  }, [products, selectedCategory, searchQuery, sortBy]);

  const renderIcon = (iconName: string) => {
    switch (iconName) {
      case "ShoppingBag":
        return <ShoppingBag className="w-5 h-5 text-rose-400" />;
      case "Briefcase":
        return <Briefcase className="w-5 h-5 text-cyan-400" />;
      case "Home":
        return <HomeIcon className="w-5 h-5 text-amber-400" />;
      case "GraduationCap":
        return <GraduationCap className="w-5 h-5 text-purple-400" />;
      case "Utensils":
        return <Utensils className="w-5 h-5 text-emerald-400" />;
      case "Server":
        return <Server className="w-5 h-5 text-blue-400" />;
      default:
        return <Sparkles className="w-5 h-5 text-cyan-400" />;
    }
  };

  const telegramUser = settings?.telegramUsername || "broteach_support";
  const cleanTg = telegramUser.replace("@", "");

  return (
    <div className="min-h-screen bg-[#030d1a] flex flex-col selection:bg-cyan-500 selection:text-white">
      <Navbar />

      {/* Hero Header */}
      <section className="pt-28 pb-12 sm:pt-36 sm:pb-16 bg-gradient-to-b from-[#051428] via-[#030d1a] to-[#030d1a] border-b border-cyan-950/60 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-6">
            <Link href="/" className="hover:text-cyan-400 transition-colors flex items-center gap-1">
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{language === "km" ? "ទំព័រដើម" : "Home"}</span>
            </Link>
            <span>/</span>
            <span className="text-cyan-400 font-semibold">
              {language === "km" ? "ទំព័រ Productions" : "Productions Showcase"}
            </span>
          </div>

          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 text-xs font-bold shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>{language === "km" ? "គម្រោង និងស្នាដៃអភិវឌ្ឍន៍" : "Verified Productions"}</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white leading-tight">
              {language === "km"
                ? "ស្នាដៃ និងគម្រោងគេហទំព័រ (Productions)"
                : "Digital Productions & Live Portfolios"}
            </h1>

            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              {language === "km"
                ? "ទស្សនាគំរូផ្សាយផ្ទាល់ (Live Preview) នៃគម្រោងទាំងអស់ដែលបានអភិវឌ្ឍរួចរាល់។ ទំនាក់ទំនងមកយើងខ្ញុំតាម Telegram សម្រាប់ការកែសម្រួលជាក់ស្តែង។"
                : "Explore live demo previews of our productions. Connect directly with our team on Telegram for inquiries and customized implementations."}
            </p>
          </div>
        </div>
      </section>

      {/* Main Catalog Body */}
      <main className="flex-1 py-10 sm:py-16">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 space-y-8">
          {/* Controls Bar */}
          <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 p-4 sm:p-5 rounded-2xl bg-[#061528]/90 border border-slate-800 shadow-xl">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={
                  language === "km"
                    ? "ស្វែងរកផលិតផល ឬសេវាកម្ម..."
                    : "Search productions..."
                }
                className="w-full pl-10 pr-9 py-2.5 rounded-xl bg-slate-900/90 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="flex flex-wrap items-center justify-between md:justify-end gap-3">
              <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-700 px-2.5 py-1.5 rounded-xl text-xs">
                <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as "featured" | "price-asc" | "price-desc")}
                  className="bg-transparent text-slate-200 text-xs font-semibold focus:outline-none cursor-pointer"
                >
                  <option value="featured" className="bg-slate-900">{language === "km" ? "ពេញនិយម" : "Featured"}</option>
                  <option value="price-asc" className="bg-slate-900">{language === "km" ? "តម្លៃ: ទាបទៅខ្ពស់" : "Price: Low to High"}</option>
                  <option value="price-desc" className="bg-slate-900">{language === "km" ? "តម្លៃ: ខ្ពស់ទៅទាប" : "Price: High to Low"}</option>
                </select>
              </div>

              <div className="hidden lg:flex items-center gap-1.5 bg-slate-900 border border-slate-700 p-1 rounded-xl text-xs">
                <LayoutGrid className="w-3.5 h-3.5 text-cyan-400 ml-1.5" />
                <button
                  type="button"
                  onClick={() => setGridColumns(4)}
                  className={`px-2 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                    gridColumns === 4 ? "bg-cyan-600 text-white shadow-sm" : "text-slate-400"
                  }`}
                >
                  4 / row
                </button>
                <button
                  type="button"
                  onClick={() => setGridColumns(5)}
                  className={`px-2 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                    gridColumns === 5 ? "bg-cyan-600 text-white shadow-sm" : "text-slate-400"
                  }`}
                >
                  5 / row
                </button>
              </div>

              <span className="text-xs text-slate-400 font-medium">
                {language === "km" ? `${filteredProducts.length} ផលិតផល` : `${filteredProducts.length} productions`}
              </span>
            </div>
          </div>

          {/* Category Pills */}
          <div className="flex flex-wrap items-center gap-2">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-full text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  selectedCategory === cat.id
                    ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-600/30 scale-105"
                    : "bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800"
                }`}
              >
                {language === "km" ? cat.labelKm : cat.labelEn}
              </button>
            ))}
          </div>

          {/* ThemeForest Style Grid: No 'Order via Telegram' button on cards as requested! */}
          {loading ? (
            <div className="py-24 text-center space-y-3">
              <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin mx-auto" />
              <p className="text-sm text-slate-400 font-semibold">
                {language === "km" ? "កំពុងផ្ទុក..." : "Loading productions..."}
              </p>
            </div>
          ) : (
            <div
              className={`grid grid-cols-2 sm:grid-cols-2 ${
                gridColumns === 5 ? "lg:grid-cols-4 xl:grid-cols-5" : "lg:grid-cols-4"
              } gap-3 sm:gap-5`}
            >
              {filteredProducts.map((product) => {
                const title = language === "km" ? product.titleKm : product.titleEn;
                const categoryLabel =
                  language === "km" ? product.categoryLabelKm : product.categoryLabelEn;
                const author = product.author || "Broteach";
                const demoUrl = product.demoUrl || "https://demo.broteach.com";

                return (
                  <div
                    key={product.id}
                    className="group relative rounded-2xl bg-[#061528] border border-slate-800 hover:border-cyan-500/50 flex flex-col justify-between transition-all duration-200 hover:-translate-y-1 hover:shadow-[0_12px_30px_rgba(6,182,212,0.15)] overflow-hidden"
                  >
                    <div>
                      {/* Top Thumbnail Banner - Full edge-to-edge, NO padding, NO margin */}
                      <div
                        onClick={() => setSelectedProduct(product)}
                        className="relative w-full h-36 sm:h-48 bg-gradient-to-tr from-[#091b33] to-[#0d284c] flex items-center justify-center p-0 m-0 cursor-pointer overflow-hidden border-b border-slate-800/80"
                      >
                        <div className="absolute top-2 left-2 z-10 pointer-events-none">
                          <span className="w-5 h-5 rounded-md bg-cyan-500 text-slate-950 flex items-center justify-center shadow-md">
                            <Zap className="w-3 h-3 fill-slate-950" />
                          </span>
                        </div>

                        {/* Real Image or Icon Graphic */}
                        {product.thumbnailUrl ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={product.thumbnailUrl}
                            alt={title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 block m-0 p-0"
                          />
                        ) : (
                          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                            {renderIcon(product.icon)}
                          </div>
                        )}

                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                          <span className="px-3 py-1.5 rounded-full bg-cyan-600 text-white text-xs font-bold flex items-center gap-1 shadow-lg">
                            <Eye className="w-3.5 h-3.5" />
                            <span>{language === "km" ? "មើលលម្អិត" : "Details"}</span>
                          </span>
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-3 sm:p-4 space-y-2">
                        <h3
                          onClick={() => setSelectedProduct(product)}
                          className="text-xs sm:text-sm font-bold text-white line-clamp-1 group-hover:text-cyan-400 transition-colors cursor-pointer"
                          title={title}
                        >
                          {title}
                        </h3>

                        <p className="text-[11px] text-slate-400 italic truncate">
                          by <span className="text-slate-300 font-medium">{author}</span> in{" "}
                          <span className="text-cyan-400">{categoryLabel}</span>
                        </p>

                        <div className="pt-1 flex items-baseline gap-0.5">
                          <span className="text-base sm:text-xl font-black text-cyan-400">
                            ${product.price}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Bottom Actions on Productions: ONLY Details and Live Preview! (Order via Telegram button removed per user request) */}
                    <div className="p-3 sm:p-4 pt-0 flex items-center gap-1.5 sm:gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedProduct(product)}
                        className="p-2 sm:px-2.5 sm:py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center justify-center transition-colors cursor-pointer"
                        title="View Details"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>

                      <a
                        href={demoUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 py-1.5 sm:py-2 px-2.5 sm:px-3 rounded-xl border border-cyan-500/50 hover:border-cyan-400 bg-cyan-950/40 hover:bg-cyan-600/30 text-cyan-300 hover:text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-sm cursor-pointer truncate"
                      >
                        <span className="truncate">{language === "km" ? "Live Preview" : "Live Preview"}</span>
                        <ExternalLink className="w-3 h-3 flex-shrink-0" />
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>

      {/* Floating Direct Telegram Support Action */}
      <div className="fixed bottom-6 right-6 z-40">
        <a
          href={`https://t.me/${cleanTg}`}
          target="_blank"
          rel="noopener noreferrer"
          className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 text-white shadow-[0_0_25px_rgba(6,182,212,0.5)] hover:scale-110 transition-all cursor-pointer"
          title="Direct Support on Telegram"
        >
          <Send className="w-6 h-6 fill-current group-hover:rotate-12 transition-transform" />
        </a>
      </div>

      {/* ThemeForest Product Detail Modal */}
      {selectedProduct && (
        <ProductDetailModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          telegramUsername={telegramUser}
        />
      )}

      <Footer />
    </div>
  );
}
