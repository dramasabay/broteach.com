import fs from "fs";
import path from "path";
import { TrashItem } from "@/types";
import {
  saveProduct,
  saveBlogPost,
  saveContentSection,
  savePricingPlan,
} from "./contentStore";

const DATA_DIR = path.join(process.cwd(), ".data");
const TRASH_FILE = path.join(DATA_DIR, "trash.json");
const RETENTION_DAYS = 7;

function ensureDataDir(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

/**
 * Read trash items and automatically prune items expired past 7 days.
 */
export function getTrashItems(): TrashItem[] {
  ensureDataDir();
  if (!fs.existsSync(TRASH_FILE)) {
    return [];
  }

  try {
    const raw = fs.readFileSync(TRASH_FILE, "utf-8");
    const items: TrashItem[] = JSON.parse(raw);
    const now = Date.now();

    // Auto-clean expired items (past 7 days retention)
    const validItems = items.filter((item) => {
      const exp = new Date(item.expiresAt).getTime();
      return exp > now;
    });

    if (validItems.length !== items.length) {
      fs.writeFileSync(TRASH_FILE, JSON.stringify(validItems, null, 2), "utf-8");
    }

    return validItems.sort(
      (a, b) => new Date(b.deletedAt).getTime() - new Date(a.deletedAt).getTime()
    );
  } catch (e) {
    console.error("Error reading trash:", e);
    return [];
  }
}

export function saveTrashItems(items: TrashItem[]): void {
  ensureDataDir();
  fs.writeFileSync(TRASH_FILE, JSON.stringify(items, null, 2), "utf-8");
}

/**
 * Add an item to trash with a 7-day retention period.
 */
export function moveToTrash(
  itemType: TrashItem["itemType"],
  originalId: string,
  title: string,
  data: unknown
): TrashItem {
  const items = getTrashItems();
  const now = new Date();
  const expiresAt = new Date(now.getTime() + RETENTION_DAYS * 24 * 60 * 60 * 1000);

  const trashItem: TrashItem = {
    id: `trash-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    itemType,
    originalId,
    title,
    data,
    deletedAt: now.toISOString(),
    expiresAt: expiresAt.toISOString(),
  };

  // Remove existing trash entry with same originalId if re-deleted
  const filtered = items.filter((i) => !(i.itemType === itemType && i.originalId === originalId));
  filtered.unshift(trashItem);
  saveTrashItems(filtered);

  return trashItem;
}

/**
 * Restore an item from trash back to active database.
 */
export async function restoreTrashItem(trashId: string): Promise<{ success: boolean; message: string }> {
  const items = getTrashItems();
  const item = items.find((i) => i.id === trashId);

  if (!item) {
    return { success: false, message: "Item not found in Trash" };
  }

  try {
    switch (item.itemType) {
      case "product": {
        saveProduct(item.data as Parameters<typeof saveProduct>[0]);
        break;
      }
      case "post": {
        saveBlogPost(item.data as Parameters<typeof saveBlogPost>[0]);
        break;
      }
      case "section": {
        saveContentSection(item.data as Parameters<typeof saveContentSection>[0]);
        break;
      }
      case "plan": {
        savePricingPlan(item.data as Parameters<typeof savePricingPlan>[0]);
        break;
      }
      case "media": {
        // Media files metadata acknowledged
        break;
      }
      default:
        break;
    }

    // Remove from trash
    const remaining = items.filter((i) => i.id !== trashId);
    saveTrashItems(remaining);

    return { success: true, message: `"${item.title}" បានស្តារឡើងវិញដោយជោគជ័យ!` };
  } catch (error: unknown) {
    const err = error as { message?: string };
    return { success: false, message: err?.message || "Failed to restore item" };
  }
}

/**
 * Permanently delete single item from trash.
 */
export function deletePermanently(trashId: string): boolean {
  const items = getTrashItems();
  const remaining = items.filter((i) => i.id !== trashId);
  saveTrashItems(remaining);
  return remaining.length < items.length;
}

/**
 * Empty all items from trash permanently.
 */
export function emptyTrash(): void {
  saveTrashItems([]);
}
