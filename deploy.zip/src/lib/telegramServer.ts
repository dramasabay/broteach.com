import { getSiteSettings } from "./contentStore";

/**
 * Server-only helper to send automated notifications to admin's configured Telegram.
 */
export async function sendTelegramNotification(
  message: string,
  customConfig?: { botToken?: string; chatId?: string }
): Promise<{ success: boolean; error?: string }> {
  try {
    let botToken = customConfig?.botToken?.trim();
    let chatId = customConfig?.chatId?.trim();

    if (!botToken || !chatId) {
      try {
        const settings = getSiteSettings();
        if (!botToken) botToken = settings.telegramBotToken?.trim();
        if (!chatId) chatId = settings.telegramChatId?.trim();
      } catch {
        // Fallback to env
      }
    }

    if (!botToken) botToken = process.env.TELEGRAM_BOT_TOKEN?.trim();
    if (!chatId) chatId = process.env.TELEGRAM_CHAT_ID?.trim();

    if (!botToken || !chatId) {
      return {
        success: false,
        error: "Telegram Bot Token or Chat ID not configured. Configure it in Dashboard Settings.",
      };
    }

    const res = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: "HTML",
      }),
    });

    const data = await res.json();
    if (!res.ok || !data.ok) {
      return {
        success: false,
        error: data.description || `Telegram API error: ${res.statusText}`,
      };
    }

    return { success: true };
  } catch (err: unknown) {
    const errorObj = err as { message?: string };
    return {
      success: false,
      error: errorObj?.message || "Failed to reach Telegram API",
    };
  }
}
