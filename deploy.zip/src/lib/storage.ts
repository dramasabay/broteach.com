import { OrderSubmission, NewsletterSubscriber } from "@/types";
import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), ".data");
const SUBSCRIBERS_FILE = path.join(DATA_DIR, "subscribers.json");
const ORDERS_FILE = path.join(DATA_DIR, "orders.json");

// Default in-memory seed data
let inMemorySubscribers: NewsletterSubscriber[] = [
  { id: "sub-1", email: "client.sample@gmail.com", subscribedAt: new Date().toISOString() },
  { id: "sub-2", email: "business.kh@broteach.com", subscribedAt: new Date().toISOString() },
];

let inMemoryOrders: OrderSubmission[] = [
  {
    id: "ord-1001",
    planId: "company",
    planName: "ក្រុមហ៊ុន ($450)",
    price: 450,
    clientName: "Sokha Heng",
    email: "sokha.heng@example.com",
    phone: "012889977",
    telegram: "@sokha_dev",
    notes: "Need corporate website for logistics company with booking form.",
    createdAt: new Date(Date.now() - 3600000).toISOString(),
    status: "pending",
  },
  {
    id: "ord-1002",
    planId: "starter",
    planName: "រៀនកូដ ($250)",
    price: 250,
    clientName: "Bopha Chan",
    email: "bopha.chan@example.com",
    phone: "098112233",
    telegram: "@bophachan",
    notes: "Personal portfolio website with blog.",
    createdAt: new Date(Date.now() - 7200000).toISOString(),
    status: "contacted",
  },
];

function ensureDataDir() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  } catch {
    // Non-blocking in serverless/read-only environments
  }
}

export function getSubscribers(): NewsletterSubscriber[] {
  try {
    ensureDataDir();
    if (fs.existsSync(SUBSCRIBERS_FILE)) {
      const data = fs.readFileSync(SUBSCRIBERS_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch {
    // Fall back to memory
  }
  return inMemorySubscribers;
}

export function addSubscriber(email: string): {
  success: boolean;
  message: string;
  subscriber?: NewsletterSubscriber;
  alreadySubscribed?: boolean;
} {
  const current = getSubscribers();
  const exists = current.find((s) => s.email.toLowerCase() === email.toLowerCase());
  if (exists) {
    return {
      success: true,
      message: "អ៊ីមែលនេះបានចុះឈ្មោះរួចរាល់ហើយ! (You are already subscribed!)",
      subscriber: exists,
      alreadySubscribed: true,
    };
  }

  const newSub: NewsletterSubscriber = {
    id: `sub-${Date.now()}`,
    email: email.trim().toLowerCase(),
    subscribedAt: new Date().toISOString(),
  };

  current.unshift(newSub);
  inMemorySubscribers = current;

  try {
    ensureDataDir();
    fs.writeFileSync(SUBSCRIBERS_FILE, JSON.stringify(current, null, 2));
  } catch {
    // In-memory fallback is intact
  }

  return { success: true, message: "ចុះឈ្មោះជោគជ័យ! (Subscribed successfully!)", subscriber: newSub };
}

export function deleteSubscriber(id: string): boolean {
  const current = getSubscribers();
  const filtered = current.filter((s) => s.id !== id);
  if (filtered.length === current.length) return false;

  inMemorySubscribers = filtered;
  try {
    ensureDataDir();
    fs.writeFileSync(SUBSCRIBERS_FILE, JSON.stringify(filtered, null, 2));
  } catch {
    // Fallback intact
  }
  return true;
}

export function getOrders(): OrderSubmission[] {
  try {
    ensureDataDir();
    if (fs.existsSync(ORDERS_FILE)) {
      const data = fs.readFileSync(ORDERS_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch {
    // Fall back to memory
  }
  return inMemoryOrders;
}

export function addOrder(order: Omit<OrderSubmission, "id" | "createdAt" | "status">): OrderSubmission {
  const current = getOrders();
  const newOrder: OrderSubmission = {
    ...order,
    id: `ord-${Date.now().toString().slice(-6)}`,
    createdAt: new Date().toISOString(),
    status: "pending",
  };

  current.unshift(newOrder);
  inMemoryOrders = current;

  try {
    ensureDataDir();
    fs.writeFileSync(ORDERS_FILE, JSON.stringify(current, null, 2));
  } catch {
    // In-memory fallback is intact
  }

  return newOrder;
}

export function deleteOrder(id: string): boolean {
  const current = getOrders();
  const filtered = current.filter((o) => o.id !== id);
  if (filtered.length === current.length) return false;

  inMemoryOrders = filtered;
  try {
    ensureDataDir();
    fs.writeFileSync(ORDERS_FILE, JSON.stringify(filtered, null, 2));
  } catch {
    // In-memory fallback is intact
  }
  return true;
}

export function restoreOrders(orders: OrderSubmission[]): void {
  inMemoryOrders = [...orders];
  try {
    ensureDataDir();
    fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2));
  } catch {
    // In-memory fallback is intact
  }
}

export function restoreSubscribers(subscribers: NewsletterSubscriber[]): void {
  inMemorySubscribers = [...subscribers];
  try {
    ensureDataDir();
    fs.writeFileSync(SUBSCRIBERS_FILE, JSON.stringify(subscribers, null, 2));
  } catch {
    // In-memory fallback is intact
  }
}

