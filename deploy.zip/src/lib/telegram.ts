/**
 * Helper to build direct Telegram ordering links with customized pre-filled message.
 * Safe for both Client and Server execution.
 */
export function getTelegramOrderUrl(params: {
  itemName: string;
  price: number;
  itemType?: "product" | "plan";
  telegramUsername?: string;
  notes?: string;
  lang?: "km" | "en";
}): string {
  const username = (params.telegramUsername || "broteach_support").replace("@", "");
  const isKm = params.lang !== "en";

  let message = "";
  if (isKm) {
    message = `សួស្តី Broteach! 🚀\nខ្ញុំមានចំណាប់អារម្មណ៍ចង់កុម្ម៉ង់៖\n• មុខទំនិញ/កញ្ចប់៖ ${params.itemName}\n• តម្លៃ៖ $${params.price}\n\nសូមផ្តល់ព័ត៌មានលម្អិតបន្ថែម និងនីតិវិធីកុម្ម៉ង់ជូនខ្ញុំបាទ/នាងខ្ញុំផង។ អរគុណ!`;
    if (params.notes) {
      message += `\n\nចំណាំបន្ថែម៖ ${params.notes}`;
    }
  } else {
    message = `Hello Broteach! 🚀\nI would like to order:\n• Item / Plan: ${params.itemName}\n• Price: $${params.price}\n\nPlease provide me with more details and setup procedure. Thank you!`;
    if (params.notes) {
      message += `\n\nAdditional notes: ${params.notes}`;
    }
  }

  return `https://t.me/${username}?text=${encodeURIComponent(message)}`;
}
