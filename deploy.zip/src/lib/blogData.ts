export interface BlogPost {
  slug: string;
  titleKm: string;
  titleEn: string;
  excerptKm: string;
  excerptEn: string;
  category: string;
  tagKm: string;
  tagEn: string;
  readingTime: number;
  date: string;
  featured: boolean;
  coverGradient: string;
  icon: string;
  contentKm?: string;
  contentEn?: string;
}

export const BLOG_POSTS: BlogPost[] = [
  {
    slug: "cloud-hosting-cambodia-guide",
    titleKm: "មគ្គុទ្ទេសក៍ Cloud Hosting ល្អបំផុតសម្រាប់អាជីវកម្មនៅកម្ពុជា",
    titleEn: "The Complete Cloud Hosting Guide for Cambodia Businesses",
    excerptKm: "ជ្រើសរើស Cloud Hosting ល្អសម្រាប់គេហទំព័ររបស់អ្នក — NVMe SSD, CDN, ល្បឿន, DDoS Protection — ស្វែងយល់ដំណោះស្រាយល្អបំផុតសម្រាប់ SME កម្ពុជា។",
    excerptEn: "Choosing the right cloud hosting for your website — NVMe SSD, CDN, speed, DDoS protection — find the best solution for Cambodia SMEs.",
    category: "Hosting",
    tagKm: "Cloud Hosting",
    tagEn: "Cloud Hosting",
    readingTime: 5,
    date: "2026-09-20",
    featured: true,
    coverGradient: "from-cyan-600 to-blue-700",
    icon: "🖥️",
  },
  {
    slug: "ecommerce-khqr-payment-cambodia",
    titleKm: "រៀបចំ E-commerce & ABA KHQR Payment ត្រឹមត្រូវ",
    titleEn: "Setting Up E-commerce with ABA KHQR Payment in Cambodia",
    excerptKm: "ការផ្តល់ជម្រើសបង់ប្រាក់ KHQR នៅក្នុងហាង E-commerce របស់អ្នក — ជំហានលំអិត ការរួមបញ្ចូល API និងការតំឡើងដំបូង។",
    excerptEn: "Integrating KHQR payment into your e-commerce store — step by step, API integration and initial setup guide.",
    category: "E-commerce",
    tagKm: "KHQR & E-commerce",
    tagEn: "KHQR & E-commerce",
    readingTime: 7,
    date: "2026-09-15",
    featured: false,
    coverGradient: "from-emerald-600 to-teal-700",
    icon: "💳",
  },
  {
    slug: "web-design-best-practices-2026",
    titleKm: "ការរចនាគេហទំព័រ ២០២៦ — ទ្រិស្ដីការណ៍ & ឧបករណ៍ថ្មី",
    titleEn: "Web Design Best Practices 2026 — Trends & Tools",
    excerptKm: "ស្វែងយល់ពីទ្រិស្ដីការណ៍ Web Design ២០២៦ — Glassmorphism, Dark Mode, Micro-animations, Mobile-first Design ជំរុញការប្រើប្រាស់និងការបំប្លែង។",
    excerptEn: "Discover 2026 web design trends — Glassmorphism, Dark Mode, Micro-animations, Mobile-first Design to boost engagement and conversions.",
    category: "Design",
    tagKm: "Web Design",
    tagEn: "Web Design",
    readingTime: 6,
    date: "2026-09-10",
    featured: false,
    coverGradient: "from-purple-600 to-pink-600",
    icon: "🎨",
  },
  {
    slug: "seo-tips-cambodia-khmer",
    titleKm: "SEO ភាសាខ្មែរ — ធ្វើឱ្យគេហទំព័ររបស់អ្នកលេចចេញក្នុង Google",
    titleEn: "Khmer SEO — Make Your Website Visible in Google Cambodia",
    excerptKm: "ការធ្វើ SEO ជាភាសាខ្មែរ — ការស្វែងរកពាក្យគន្លឹះ ការសរសេរ Meta Tags ត្រឹមត្រូវ Schema Markup និង Local SEO ល្អបំផុត។",
    excerptEn: "Khmer-language SEO — keyword research, writing proper meta tags, schema markup, and local SEO strategies for Cambodia.",
    category: "SEO",
    tagKm: "SEO Khmer",
    tagEn: "Khmer SEO",
    readingTime: 5,
    date: "2026-09-05",
    featured: false,
    coverGradient: "from-amber-600 to-orange-600",
    icon: "🚀",
  },
  {
    slug: "data-security-ddos-protection-tips",
    titleKm: "សុវត្ថិភាពទិន្នន័យ & ការពារ DDoS Shield ២៤/៧",
    titleEn: "Data Security & 24/7 DDoS Shield Protection Guide",
    excerptKm: "វិធីសាស្ត្រការពារប្រព័ន្ធវេបសាយ ម៉ាស៊ីនបម្រើ Cloud និងទិន្នន័យអតិថិជនពីការវាយប្រហារតាមអ៊ីនធឺណិត Cyber Attacks។",
    excerptEn: "Strategies to protect website systems, cloud servers, and customer databases against cyber attacks and ransomware.",
    category: "Security",
    tagKm: "Security",
    tagEn: "Security",
    readingTime: 8,
    date: "2026-08-28",
    featured: false,
    coverGradient: "from-red-600 to-rose-700",
    icon: "🛡️",
  },
  {
    slug: "broteach-updates-september-2026",
    titleKm: "បច្ចុប្បន្នភាព Broteach កញ្ញា ២០២៦: សេវាកម្មថ្មី & ការធ្វើបច្ចុប្បន្នភាព",
    titleEn: "Broteach Updates September 2026: New Products & Next-Gen Cloud",
    excerptKm: "សេចក្តីប្រកាសអំពីដំណោះស្រាយ Cloud ជំនាន់ថ្មី ផ្ទាំងគ្រប់គ្រង Admin Dashboard ថ្មី និងកញ្ចប់តម្លៃពិសេស។",
    excerptEn: "Announcement of our next-generation cloud hosting infrastructure, enhanced admin dashboard, and new startup plans.",
    category: "News",
    tagKm: "News",
    tagEn: "Broteach News",
    readingTime: 4,
    date: "2026-08-20",
    featured: false,
    coverGradient: "from-blue-600 to-indigo-700",
    icon: "📢",
  },
  {
    slug: "mobile-first-pwa-cambodia-market",
    titleKm: "កម្មវិធីទូរស័ព្ទ & Progressive Web Apps (PWA) សម្រាប់ទីផ្សារកម្ពុជា",
    titleEn: "Mobile-First Design & PWA Architecture for Cambodia's Market",
    excerptKm: "អ្នកប្រើប្រាស់អ៊ីនធឺណិតជាង ៨៥% នៅកម្ពុជាចូលប្រើតាមទូរស័ព្ទដៃ — ស្វែងយល់ពីរបៀបរៀបចំគេហទំព័រឱ្យដើរលឿន និងទាញយកជា App បាន។",
    excerptEn: "Over 85% of internet users in Cambodia browse via smartphones — learn how to optimize web apps for instant mobile loading and PWA installs.",
    category: "Design",
    tagKm: "PWA & Mobile",
    tagEn: "PWA & Mobile",
    readingTime: 6,
    date: "2026-08-12",
    featured: false,
    coverGradient: "from-amber-500 to-yellow-600",
    icon: "📱",
  },
  {
    slug: "sub-second-web-performance-guide",
    titleKm: "ការបង្កើនល្បឿនគេហទំព័រឱ្យផ្ទុកក្រោម ១ វិនាទី (Sub-Second Performance)",
    titleEn: "Sub-Second Web Performance Guide: Edge Caching & Asset Tuning",
    excerptKm: "ល្បឿនផ្ទុកទំព័រកំណត់អត្រាលក់ដូរ (Conversion Rate) របស់អាជីវកម្ម — គន្លឹះបច្ចេកទេសបង្រួមទំហំរូបភាព ប្រើប្រាស់ Brotli និង Cloud Edge CDN។",
    excerptEn: "Page speed directly dictates conversion rates — technical guide on image optimization, Brotli compression, and Cloud Edge CDN routing.",
    category: "Hosting",
    tagKm: "Performance",
    tagEn: "Performance",
    readingTime: 5,
    date: "2026-08-05",
    featured: false,
    coverGradient: "from-teal-600 to-emerald-700",
    icon: "⚡",
  },
];
