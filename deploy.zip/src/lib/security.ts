import { verifyJwt, JWT_COOKIE_NAME } from "./jwt";

// ADMIN_SECRET is intentionally NOT exported with a hardcoded fallback.
// It MUST be set as an environment variable.
// In production, the application will log an error if it is missing or too short.
export const ADMIN_COOKIE_NAME = "broteach_admin_token";

// Warn loudly if secrets are weak or missing
const jwtSecret = process.env.JWT_SECRET ?? "";
const adminSecret = process.env.ADMIN_SECRET ?? "";

if (typeof process !== "undefined" && process.env.NODE_ENV === "production") {
  if (!jwtSecret || jwtSecret.length < 32) {
    // In production a short/missing secret is a critical misconfiguration.
    // We do not throw here (to avoid crashing on import in middleware),
    // but every protected handler must also fail fast.
    console.error(
      "[SECURITY] CRITICAL: JWT_SECRET is missing or too short. " +
        "All admin sessions are insecure. Set JWT_SECRET to a random string of at least 32 characters."
    );
  }
  if (!adminSecret || adminSecret.length < 12) {
    console.error(
      "[SECURITY] CRITICAL: ADMIN_SECRET is missing or too short. " +
        "Admin login is insecure. Set ADMIN_SECRET to a strong random password."
    );
  }
} else if (typeof process !== "undefined" && process.env.NODE_ENV !== "test") {
  if (!jwtSecret) {
    console.warn("[SECURITY] WARNING: JWT_SECRET is not set. Using an empty secret is insecure in any environment.");
  }
  if (!adminSecret) {
    console.warn("[SECURITY] WARNING: ADMIN_SECRET is not set. Admin login is disabled.");
  }
}

// In-memory sliding window rate limiter
interface RateLimitRecord {
  count: number;
  resetTime: number;
}

const rateLimitMap = new Map<string, RateLimitRecord>();

// Cleanup stale rate limit records every 5 minutes
if (typeof setInterval !== "undefined") {
  setInterval(() => {
    const now = Date.now();
    for (const [key, record] of rateLimitMap.entries()) {
      if (now > record.resetTime) {
        rateLimitMap.delete(key);
      }
    }
  }, 5 * 60 * 1000);
}

/**
 * Check if a client IP has exceeded the rate limit.
 * @param ip Client IP identifier
 * @param limit Maximum allowed requests in the window
 * @param windowMs Window duration in milliseconds (default 60s)
 */
export function checkRateLimit(
  ip: string,
  limit: number = 30,
  windowMs: number = 60 * 1000
): { allowed: boolean; remaining: number; resetIn: number } {
  const now = Date.now();
  const record = rateLimitMap.get(ip);

  if (!record || now > record.resetTime) {
    rateLimitMap.set(ip, {
      count: 1,
      resetTime: now + windowMs,
    });
    return { allowed: true, remaining: limit - 1, resetIn: Math.ceil(windowMs / 1000) };
  }

  if (record.count >= limit) {
    return {
      allowed: false,
      remaining: 0,
      resetIn: Math.ceil((record.resetTime - now) / 1000),
    };
  }

  record.count += 1;
  return {
    allowed: true,
    remaining: limit - record.count,
    resetIn: Math.ceil((record.resetTime - now) / 1000),
  };
}

/**
 * Extract client IP from standard Next.js / reverse-proxy request headers.
 */
export function getClientIp(req: Request): string {
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) {
    return forwarded.split(",")[0].trim();
  }
  const realIp = req.headers.get("x-real-ip");
  if (realIp) {
    return realIp.trim();
  }
  return "127.0.0.1";
}

/**
 * Sanitize string input to prevent Cross-Site Scripting (XSS) and injection attacks.
 */
export function sanitizeText(input: unknown): string {
  if (typeof input !== "string") return "";
  return input
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
    .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, "")
    .replace(/on\w+="[^"]*"/gi, "")
    .replace(/on\w+='[^']*'/gi, "")
    .replace(/javascript:[^"']*/gi, "")
    .trim();
}

/**
 * Verify admin session from the request.
 *
 * SECURITY: This function performs a full cryptographic JWT verification.
 * It does NOT accept hardcoded secrets, plain tokens, or 3-part string shortcuts.
 * It MUST be called inside every protected Route Handler in addition to the proxy check.
 */
export async function verifyAdminSession(req: Request): Promise<boolean> {
  // 1. If the proxy already verified the JWT, trust its header.
  //    The proxy sets this header only after successful cryptographic verification.
  if (req.headers.get("x-admin-authenticated") === "true") {
    return true;
  }

  // 2. Extract token from Authorization header or JWT cookie.
  let token: string | undefined;

  const authHeader = req.headers.get("authorization");
  if (authHeader?.startsWith("Bearer ")) {
    token = authHeader.slice(7).trim();
  }

  if (!token) {
    const cookieHeader = req.headers.get("cookie");
    if (cookieHeader) {
      const cookies = Object.fromEntries(
        cookieHeader.split(";").map((c) => {
          const [k, ...v] = c.trim().split("=");
          return [k.trim(), v.join("=")];
        })
      );
      token = cookies[JWT_COOKIE_NAME];
    }
  }

  if (!token) {
    return false;
  }

  // 3. Perform full cryptographic JWT verification.
  //    No shortcuts: a 3-part string is NOT a valid token without verified HMAC.
  const result = await verifyJwt(token);
  return result.valid === true;
}
