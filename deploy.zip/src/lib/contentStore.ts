import { ProductItem, SiteSettings, PricingPlan, ContentSection, BlogPostItem, DEFAULT_HOME_SECTIONS } from "@/types";
import { pricingPlans as defaultPlans } from "./data";
import { BLOG_POSTS } from "./blogData";
import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), ".data");
const SETTINGS_FILE = path.join(DATA_DIR, "site_settings.json");
const PRODUCTS_FILE = path.join(DATA_DIR, "products.json");
const PRICING_FILE = path.join(DATA_DIR, "pricing_plans.json");
const SECTIONS_FILE = path.join(DATA_DIR, "content_sections.json");
const POSTS_FILE = path.join(DATA_DIR, "blog_posts.json");

const defaultSettings: SiteSettings = {
  heroTitleKm: "គេហទំព័រអាជីវកម្មតាមបែបស្តង់ដារ",
  heroTitleEn: "Standard Professional Business Website",
  heroSubtitleKm:
    "សេវាកម្មបង្កើតគេហទំព័រនិងដំណោះស្រាយឌីជីថលកម្រិតខ្ពស់ ដើម្បីជំរុញអាជីវកម្មរបស់អ្នកឱ្យរីកចម្រើនយ៉ាងឆាប់រហ័ស ជាមួយបច្ចេកវិទ្យាទំនើប និងសុវត្ថិភាពខ្ពស់។",
  heroSubtitleEn:
    "Premium web development services and digital solutions designed to accelerate your business growth with enterprise speed and bulletproof security.",
  heroBadgeKm: "សេវាកម្មកម្រិតស្តង់ដារអន្តរជាតិ",
  heroBadgeEn: "Enterprise Standard Solutions",
  heroCtaTextKm: "ចាប់ផ្តើមឥឡូវនេះ",
  heroCtaTextEn: "Get Started",
  heroCtaTelegramUrl: "",
  heroSecondaryBtnTextKm: "មើលផលិតផល & សេវា",
  heroSecondaryBtnTextEn: "Explore Products",
  heroSecondaryBtnUrl: "/products",
  heroStat1Number: "99.9%",
  heroStat1LabelKm: "Uptime ធានា",
  heroStat1LabelEn: "Guaranteed Uptime",
  heroStat2Number: "500+",
  heroStat2LabelKm: "អតិថិជនពេញចិត្ត",
  heroStat2LabelEn: "Happy Clients",
  heroStat3Number: "24/7",
  heroStat3LabelKm: "ជំនួយបច្ចេកទេស",
  heroStat3LabelEn: "Live Support",
  homeSections: DEFAULT_HOME_SECTIONS,
  announcementTextKm: "🔥 ប្រូម៉ូសិនពិសេស៖ ចុះឈ្មោះថ្ងៃនេះ ទទួលបាន Domain .com និង Cloud Hosting ឥតគិតថ្លៃ ១ ឆ្នាំ!",
  announcementTextEn: "🔥 Special Promotion: Order today and receive a free .com domain & 1-Year Cloud Hosting!",
  showAnnouncement: true,
  telegramUsername: "broteach_support",
  phone1: "(+855) 098 765 432",
  phone2: "",
  email: "info@broteach.com",
  addressKm: "ផ្ទះលេខ ១២៨, មហាវិថីព្រះមុនីវង្ស, សង្កាត់បឹងរាំង, ខណ្ឌដូនពេញ, រាជធានីភ្នំពេញ",
  addressEn: "No. 128, Preah Monivong Blvd, Daun Penh, Phnom Penh, Cambodia",
  lastUpdated: new Date().toISOString(),
  siteLogoUrl: "",
  siteIconUrl: "",
  siteBrandName: "BROTEACH",
  siteBrandSubtitle: "Digital Solutions",
  siteBrandDotColor: "#ef4444",
  siteBrandBorderStyle: "none",
  downloadAppLink: "",
  seoTitleKm: "Broteach | គេហទំព័រអាជីវកម្មតាមបែបស្តង់ដារ & Cloud Hosting",
  seoTitleEn: "Broteach | Enterprise Web Development & Cloud Hosting Solutions",
  seoDescKm: "សេវាកម្មបង្កើតគេហទំព័រនិងដំណោះស្រាយឌីជីថលកម្រិតខ្ពស់ ដើម្បីជំរុញអាជីវកម្មរបស់អ្នកឱ្យរីកចម្រើនយ៉ាងឆាប់រហ័ស ជាមួយបច្ចេកវិទ្យាទំនើប និងសុវត្ថិភាពខ្ពស់។",
  seoDescEn: "Premium web development services and digital solutions designed to accelerate your business growth with enterprise speed and bulletproof security.",
  seoKeywords: "broteach, web design cambodia, khmer web development, cloud hosting, VPS, KHQR, e-commerce",
  seoImageUrl: "",
  googleConsoleVerification: "",
  googleAnalyticsId: "",
  footerDescKm: "សេវាកម្មបង្កើតគេហទំព័រអាជីវកម្មតាមបែបស្តង់ដារ ហាងទំនិញ E-Commerce និង Cloud Hosting NVMe SSD ល្បឿនលឿន និងសុវត្ថិភាពខ្ពស់នៅកម្ពុជា។",
  footerDescEn: "Enterprise web development and high-speed NVMe SSD cloud hosting solutions with automated ABA KHQR payment in Cambodia.",
  footerCopyrightKm: "© 2026 Broteach Digital Solutions. រក្សាសិទ្ធិគ្រប់យ៉ាង។",
  footerCopyrightEn: "© 2026 Broteach Digital Solutions. All rights reserved.",
  footerContactHeadingKm: "មានចម្ងល់? ទំនាក់ទំនងមកយើង ២៤/៧",
  footerContactHeadingEn: "Have questions? Call us 24/7",
  facebookUrl: "https://facebook.com/broteach",
  youtubeUrl: "https://youtube.com/@broteach",
  telegramChannelUrl: "https://t.me/broteach_support",
  tiktokUrl: "",
  // Services Column
  footerServicesTitleKm: "សេវាកម្ម",
  footerServicesTitleEn: "SERVICES",
  footerService1Km: "ផលិតផលគេហទំព័រ",
  footerService1En: "Web Products",
  footerService1Url: "/products",
  footerService2Km: "បង្កើតគេហទំព័រ",
  footerService2En: "Web Design",
  footerService2Url: "/pricing",
  footerService3Km: "Cloud VPS Hosting",
  footerService3En: "Cloud Hosting",
  footerService3Url: "/products",
  footerService4Km: "E-commerce & KHQR",
  footerService4En: "E-commerce",
  footerService4Url: "/products",
  // Quick Links Column
  footerQuickLinksTitleKm: "តំណភ្ជាប់រហ័ស",
  footerQuickLinksTitleEn: "QUICK LINKS",
  footerQuickLink1Km: "អំពីយើង",
  footerQuickLink1En: "About Us",
  footerQuickLink1Url: "/about",
  footerQuickLink2Km: "ព័ត៌មាន & Blog",
  footerQuickLink2En: "Blog & Articles",
  footerQuickLink2Url: "/blog",
  footerQuickLink3Km: "គំរូផ្សាយផ្ទាល់",
  footerQuickLink3En: "Live Previews",
  footerQuickLink3Url: "/products",
  footerQuickLink4Km: "កញ្ចប់តម្លៃ",
  footerQuickLink4En: "Pricing",
  footerQuickLink4Url: "/pricing",
  aboutTitleKm: "អំពីយើង - Broteach Digital Solutions",
  aboutTitleEn: "About Us - Broteach Digital Solutions",
  aboutSubtitleKm: "ដៃគូយុទ្ធសាស្ត្រក្នុងការអភិវឌ្ឍបច្ចេកវិទ្យាគេហទំព័រ និង Cloud Hosting កម្រិតខ្ពស់នៅកម្ពុជា",
  aboutSubtitleEn: "Your Strategic Partner in Enterprise Web Engineering & High-Speed Cloud Infrastructure in Cambodia",
  aboutStoryKm: "បង្កើតឡើងក្នុងគោលបំណងលើកកម្ពស់ស្តង់ដារបច្ចេកវិទ្យាគេហទំព័រនៅប្រទេសកម្ពុជា Broteach បានជួយអាជីវកម្ម សហគ្រាស និងស្ថាប័នអប់រំរាប់រយឱ្យមានគេហទំព័រទំនើប លឿន សុវត្ថិភាព និងគាំទ្រការទូទាត់ប្រាក់ ABA KHQR ស្វ័យប្រវត្តិ។",
  aboutStoryEn: "Founded with the mission to elevate digital standards in Cambodia, Broteach has empowered hundreds of enterprises, SMEs, and educational institutions with blazing-fast, secure, and modern web platforms integrated with automated ABA KHQR payments.",
  aboutMissionKm: "ផ្តល់ជូននូវគេហទំព័រ និងប្រព័ន្ធឌីជីថលដែលមានល្បឿនផ្ទុកក្រោម ១ វិនាទី សុវត្ថិភាពខ្ពស់ និងការគាំទ្របច្ចេកទេស ២៤/៧ ដើម្បីឱ្យអាជីវកម្មរបស់អតិថិជនរីកចម្រើនឥតឈប់ឈរ។",
  aboutMissionEn: "To deliver sub-second loading web applications with bulletproof security, 99.9% uptime, and round-the-clock dedicated engineering support.",
  // Telegram Bot Settings
  telegramBotToken: "",
  telegramChatId: "",
  // Header Banner Ads
  headerBannerActive: true,
  headerBannerBadgeKm: "🎉 ព្រឹត្តិការណ៍ពិសេស",
  headerBannerBadgeEn: "🎉 SPECIAL EVENT",
  headerBannerTextKm: "អបអរសាទរពិធីបុណ្យចូលឆ្នាំថ្មីប្រពៃណីជាតិខ្មែរ! បញ្ចុះតម្លៃ 20% លើគ្រប់កញ្ចប់គេហទំព័រ និង Cloud Hosting",
  headerBannerTextEn: "Happy Khmer New Year! Enjoy 20% OFF all Web Development & Cloud Hosting Packages",
  headerBannerLink: "/pricing",
  // Screen Ads Popup
  popupActive: false,
  popupBadgeKm: "🎁 ប្រូម៉ូសិនមានកំណត់",
  popupBadgeEn: "🎁 LIMITED OFFER",
  popupTitleKm: "ទទួលកាដូពិសេសពី Broteach!",
  popupTitleEn: "Get a Special Gift from Broteach!",
  popupDescKm: "បង្កើតគេហទំព័រអាជីវកម្មថ្ងៃនេះ ទទួលបាន Free Domain .com, Cloud NVMe Hosting ១ឆ្នាំ និងប្រព័ន្ធ ABA KHQR!",
  popupDescEn: "Build your business website today and receive a Free .com Domain, 1-Year NVMe Cloud Hosting, and automated ABA KHQR!",
  popupImageUrl: "",
  popupButtonTextKm: "ពិនិត្យកញ្ចប់តម្លៃឥឡូវនេះ",
  popupButtonTextEn: "Check Pricing Now",
  popupButtonUrl: "/pricing",
  popupCooldownMinutes: 30,
  popupAutoCloseSeconds: 5,
  popupTriggerScrollPx: 200,
};

const defaultProducts: ProductItem[] = [
  {
    id: "prod-1",
    titleKm: "ប្រព័ន្ធហាងទំនិញអនឡាញ (E-Commerce Store)",
    titleEn: "Modern E-Commerce Store & KHQR",
    category: "ecommerce",
    categoryLabelKm: "E-Commerce",
    categoryLabelEn: "E-Commerce",
    price: 480,
    badgeKm: "ពេញនិយមបំផុត",
    badgeEn: "Best Seller",
    descKm: "គេហទំព័រលក់ទំនិញពេញលេញ មានកាតាឡុកទំនិញ រទេះទំនិញ (Cart) និងប្រព័ន្ធទូទាត់ ABA KHQR ស្វ័យប្រវត្តិ។",
    descEn: "Complete online shop with dynamic product catalog, shopping cart, and integrated automated ABA KHQR payment.",
    featuresKm: [
      "ប្រព័ន្ធទូទាត់ប្រាក់ស្វ័យប្រវត្តិ ABA Pay & KHQR",
      "ផ្ទាំងគ្រប់គ្រងស្តុកទំនិញ និងការបញ្ជាទិញ (Admin CMS)",
      "រចនាបទ Responsive លើទូរស័ព្ទដៃ និងកុំព្យូទ័រ",
      "ភ្ជាប់ប្រព័ន្ធជូនដំណឹងតាម Telegram Bot ពេលមានការកុម្ម៉ង់",
    ],
    featuresEn: [
      "Automated ABA Pay & KHQR payment gateway",
      "Full Inventory & Order management dashboard",
      "Pixel-perfect responsive design for all devices",
      "Instant Telegram Bot notifications on new orders",
    ],
    icon: "ShoppingBag",
    demoUrl: "https://demo.broteach.com/ecommerce",
    thumbnailUrl: "https://images.unsplash.com/photo-1556742049-0a67c5574f73?w=1200&q=80",
    author: "Broteach",
    isActive: true,
    sortOrder: 1,
  },
  {
    id: "prod-2",
    titleKm: "គេហទំព័រក្រុមហ៊ុនស្តង់ដារ (Corporate Business)",
    titleEn: "Corporate Business Portal",
    category: "webapp",
    categoryLabelKm: "គេហទំព័រអាជីវកម្ម",
    categoryLabelEn: "Corporate",
    price: 390,
    badgeKm: "ស្តង់ដារ",
    badgeEn: "Featured",
    descKm: "គេហទំព័រផ្លូវការសម្រាប់ក្រុមហ៊ុន សហគ្រាស និងអង្គភាព ដើម្បីបង្កើនកិត្យានុភាព និងទំនុកចិត្តពីអតិថិជន។",
    descEn: "Official corporate website designed to establish brand credibility, showcase services, and capture qualified leads.",
    featuresKm: [
      "ទំព័រសេវាកម្ម អំពីយើង និងព័ត៌មានក្រុមហ៊ុន",
      "ទម្រង់ស្នើសុំតម្លៃ និងការណាត់ជួបផ្ទាល់",
      "ប្រព័ន្ធ SEO មូលដ្ឋានដើម្បីឱ្យជាប់ចំណាត់ថ្នាក់លើ Google",
      "ល្បឿនផ្ទុកទំព័រក្រោម ១ វិនាទី",
    ],
    featuresEn: [
      "Professional service pages, About Us, and portfolio",
      "Direct consultation inquiry & booking form",
      "Optimized Google SEO foundation",
      "Sub-second page load performance",
    ],
    icon: "Briefcase",
    demoUrl: "https://demo.broteach.com/corporate",
    thumbnailUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&q=80",
    author: "Broteach",
    isActive: true,
    sortOrder: 2,
  },
  {
    id: "prod-3",
    titleKm: "គេហទំព័រអចលនទ្រព្យ (Real Estate Portal)",
    titleEn: "Real Estate & Property Portal",
    category: "enterprise",
    categoryLabelKm: "អចលនទ្រព្យ",
    categoryLabelEn: "Real Estate",
    price: 550,
    badgeKm: "កម្រិតខ្ពស់",
    badgeEn: "High ROI",
    descKm: "វេទិកាផ្សព្វផ្សាយផ្ទះ វីឡា ខុនដូ និងដីធ្លី ជាមួយតម្រងស្វែងរកទីតាំង តម្លៃ និងផែនទី Google Maps។",
    descEn: "Interactive real estate portal with advanced location filters, photo galleries, virtual tours, and Google Maps integration.",
    featuresKm: [
      "តម្រងស្វែងរកតាមប្រភេទ និងកម្រិតតម្លៃ",
      "ប្រព័ន្ធដាក់ផ្សាយអចលនទ្រព្យងាយស្រួល",
      "ប៊ូតុងទាក់ទងភ្នាក់ងារផ្ទាល់តាម Telegram & WhatsApp",
      "ប្រព័ន្ធ Cloud Storage រក្សាទុករូបភាពគុណភាពខ្ពស់",
    ],
    featuresEn: [
      "Advanced filtering by location, property type, price",
      "Easy property listing submission dashboard",
      "Direct Agent click-to-chat Telegram & WhatsApp",
      "High-speed CDN image optimization",
    ],
    icon: "Home",
    demoUrl: "https://demo.broteach.com/realestate",
    thumbnailUrl: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=1200&q=80",
    author: "Broteach",
    isActive: true,
    sortOrder: 3,
  },
  {
    id: "prod-4",
    titleKm: "ប្រព័ន្ធគ្រប់គ្រងសាលារៀន (School & Academy LMS)",
    titleEn: "School & Academy LMS Portal",
    category: "enterprise",
    categoryLabelKm: "អប់រំ / សាលា",
    categoryLabelEn: "Education",
    price: 650,
    badgeKm: "ប្រព័ន្ធធំ",
    badgeEn: "Comprehensive",
    descKm: "គេហទំព័រនិងប្រព័ន្ធគ្រប់គ្រងសាលារៀន វគ្គសិក្សាអនឡាញ ការចុះឈ្មោះសិស្ស និងការតាមដានវត្តមាន។",
    descEn: "All-in-one portal for schools, training centers, and online course academies with student registration.",
    featuresKm: [
      "ប្រព័ន្ធគ្រប់គ្រងសិស្ស គ្រូ និងវគ្គសិក្សា",
      "ការចុះឈ្មោះចូលរៀនអនឡាញ (Online Enrollment)",
      "ប្រព័ន្ធចេញវិញ្ញាបនបត្រឌីជីថលស្វ័យប្រវត្ត",
      "ទូទាត់ថ្លៃសិក្សាតាម KHQR",
    ],
    featuresEn: [
      "Student, instructor & course management system",
      "Online enrollment & registration workflows",
      "Automated digital certificate generation",
      "Tuition fee payment via ABA KHQR",
    ],
    icon: "GraduationCap",
    demoUrl: "https://demo.broteach.com/academy",
    thumbnailUrl: "https://images.unsplash.com/photo-1501504905252-473c47e087f8?w=1200&q=80",
    author: "Broteach",
    isActive: true,
    sortOrder: 4,
  },
  {
    id: "prod-5",
    titleKm: "ប្រព័ន្ធឌីជីថលសម្រាប់ភោជនីយដ្ឋាន & Cafe",
    titleEn: "Restaurant & Cafe Digital Menu POS",
    category: "webapp",
    categoryLabelKm: "ភោជនីយដ្ឋាន",
    categoryLabelEn: "F&B / Cafe",
    price: 320,
    badgeKm: "ងាយស្រួលប្រើ",
    badgeEn: "Easy Setup",
    descKm: "ម៉ឺនុយម្ហូបអាហារតាម QR Code លើតុ ការកុម្ម៉ង់អាហារអនឡាញ និងការកក់តុជាមុន។",
    descEn: "Contactless QR code dining menu, online table reservations, and delivery order dispatch system.",
    featuresKm: [
      "ស្កេន QR Code មើលម៉ឺនុយម្ហូបភ្លាមៗលើទូរស័ព្ទ",
      "ប្រព័ន្ធកក់តុជាមុន (Table Reservation)",
      "ជូនដំណឹងការកុម្ម៉ង់ទៅផ្ទះបាយភ្លាមៗ",
      "ងាយស្រួលផ្លាស់ប្តូរតម្លៃ និងបញ្ជីម្ហូប",
    ],
    featuresEn: [
      "Dine-in contactless QR code digital menu",
      "Table reservation & pre-ordering system",
      "Instant kitchen order dispatch",
      "Real-time menu item & price editing",
    ],
    icon: "Utensils",
    demoUrl: "https://demo.broteach.com/restaurant",
    thumbnailUrl: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&q=80",
    author: "Broteach",
    isActive: true,
    sortOrder: 5,
  },
  {
    id: "prod-6",
    titleKm: "Cloud VPS & NVMe SSD Hosting",
    titleEn: "Cloud VPS & High-Speed Hosting",
    category: "hosting",
    categoryLabelKm: "Hosting & Server",
    categoryLabelEn: "Hosting & Server",
    price: 120,
    badgeKm: "Uptime 99.9%",
    badgeEn: "Ultra Fast",
    descKm: "សេវាកម្ម Cloud VPS និង Hosting ល្បឿនលឿន NVMe SSD ជាមួយ Firewall ការពារសុវត្ថិភាពទិន្នន័យកម្រិតខ្ពស់។",
    descEn: "Enterprise Cloud VPS and NVMe SSD hosting with dedicated IP, daily automated backups, and DDoS protection.",
    featuresKm: [
      "ល្បឿនផ្ទុក NVMe SSD ជំនាន់ចុងក្រោយ",
      "Free SSL Certificates គ្មានដែនកំណត់",
      "ការបម្រុងទុកទិន្នន័យប្រចាំថ្ងៃ (Daily Backup)",
      "ជំនួយបច្ចេកទេស ២៤ ម៉ោងលើ ២៤ ម៉ោង",
    ],
    featuresEn: [
      "Latest generation NVMe SSD cloud drives",
      "Free unlimited SSL certificates",
      "Daily automated off-site backups",
      "24/7 dedicated engineering support",
    ],
    icon: "Server",
    demoUrl: "https://demo.broteach.com/hosting",
    thumbnailUrl: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=1200&q=80",
    author: "Broteach",
    isActive: true,
    sortOrder: 6,
  },
];

let inMemorySettings: SiteSettings = { ...defaultSettings };
let inMemoryProducts: ProductItem[] = [...defaultProducts];
let inMemoryPricing: PricingPlan[] = [...defaultPlans];

const defaultSections: ContentSection[] = [
  {
    id: "sec-why-choose",
    titleKm: "ហេតុអ្វីជ្រើសរើស Broteach?",
    titleEn: "Why Choose Broteach?",
    subtitleKm: "យើងផ្តល់ជូននូវដំណោះស្រាយគេហទំព័រកម្រិតខ្ពស់ និងសេវាកម្មប្រកបដោយទំនុកចិត្តខ្ពស់បំផុត",
    subtitleEn: "We deliver enterprise-grade digital experiences engineered for velocity, reliability, and business growth.",
    badgeKm: "ចំណុចខ្លាំងរបស់យើង",
    badgeEn: "Core Advantages",
    layoutType: "cards",
    isActive: true,
    sortOrder: 1,
    anchorId: "why-us",
    items: [
      {
        id: "item-1",
        titleKm: "ល្បឿនលឿន & Uptime 99.9%",
        titleEn: "Lightning Speed & 99.9% Uptime",
        descKm: "ហេដ្ឋារចនាសម្ព័ន្ធ Cloud NVMe SSD ជំនាន់ចុងក្រោយ បង្កើនល្បឿនផ្ទុកគេហទំព័រឱ្យលឿនក្រោម ១ វិនាទី។",
        descEn: "Powered by modern NVMe SSD cloud instances delivering sub-second load times worldwide.",
        icon: "Zap",
        badgeKm: "លឿនបំផុត",
        badgeEn: "Ultra Fast",
        metric: "< 0.8s",
      },
      {
        id: "item-2",
        titleKm: "រចនាបទទំនើប Responsive 100%",
        titleEn: "100% Responsive & Modern UI",
        descKm: "បង្ហាញយ៉ាងស្អាតឥតខ្ចោះលើគ្រប់ទូរស័ព្ទដៃ iPad និងកុំព្យូទ័រ ជាមួយបទពិសោធន៍រលូនបំផុត។",
        descEn: "Pixel-perfect on smartphones, tablets, and desktops with seamless smooth transitions.",
        icon: "Smartphone",
        badgeKm: "គ្រប់ឧបករណ៍",
        badgeEn: "All Devices",
        metric: "Mobile First",
      },
      {
        id: "item-3",
        titleKm: "ការគាំទ្រ ២៤/៧ & សុវត្ថិភាពខ្ពស់",
        titleEn: "24/7 Dedicated Support & Security",
        descKm: "ក្រុមវិស្វករជំនាញត្រៀមជួយដោះស្រាយរាល់បញ្ហា ២៤ ម៉ោងលើ ២៤ ម៉ោង ជាមួយ SSL & DDoS Firewall។",
        descEn: "Dedicated engineering assistance available around the clock with enterprise SSL & DDoS protection.",
        icon: "ShieldCheck",
        badgeKm: "ជំនួយបច្ចេកទេស",
        badgeEn: "Direct Help",
        metric: "24/7 Live",
      },
    ],
  },
  {
    id: "sec-faq",
    titleKm: "សំណួរដែលសួរញឹកញាប់",
    titleEn: "Frequently Asked Questions",
    subtitleKm: "ចម្លើយចំពោះសំណួរដែលអតិថិជនតែងតែសាកសួរមកកាន់ក្រុមការងារ Broteach",
    subtitleEn: "Quick answers to common questions about our web development and cloud hosting services.",
    badgeKm: "ចម្លើយរហ័ស",
    badgeEn: "FAQ Support",
    layoutType: "faq",
    isActive: true,
    sortOrder: 2,
    anchorId: "faq",
    items: [
      {
        id: "faq-1",
        titleKm: "តើត្រូវចំណាយពេលប៉ុន្មានក្នុងការបង្កើតគេហទំព័រ?",
        titleEn: "How long does it take to deploy a website?",
        descKm: "សម្រាប់គេហទំព័រក្រុមហ៊ុនស្តង់ដារចំណាយពេលចន្លោះពី ៣ ទៅ ៥ ថ្ងៃ។ ចំពោះប្រព័ន្ធ E-commerce ឬប្រព័ន្ធស្ថាប័នធំ ចំណាយពេលពី ៧ ទៅ ១៤ ថ្ងៃនៃថ្ងៃធ្វើការ។",
        descEn: "Standard business websites take approximately 3 to 5 business days. Complex E-Commerce or LMS systems take between 7 to 14 business days.",
      },
      {
        id: "faq-2",
        titleKm: "តើមានការធានា និងបម្រុងទុកទិន្នន័យ (Backups) ដែរឬទេ?",
        titleEn: "Is backup and maintenance included?",
        descKm: "បាទ/ចាស! យើងមានការបម្រុងទុកទិន្នន័យស្វ័យប្រវត្តរាល់ថ្ងៃ (Automated Daily Backups) និងការធានាថែទាំប្រព័ន្ធដោយឥតគិតថ្លៃសម្រាប់រយៈពេល ១ ឆ្នាំពេញ។",
        descEn: "Yes! Automated daily off-site cloud backups and full 1-year free technical maintenance are included with every package.",
      },
      {
        id: "faq-3",
        titleKm: "តើខ្ញុំអាចទូទាត់ប្រាក់តាមវិធីណាខ្លះ?",
        titleEn: "What payment options are available?",
        descKm: "យើងទទួលការទូទាត់តាម ABA KHQR, Bakong, ផ្ទេរប្រាក់តាមធនាគារក្នុងស្រុកទាំងអស់ និងទូទាត់តាមកាត Credit/Debit Card។",
        descEn: "We support ABA KHQR, Bakong cross-bank transfers, local bank wire, and major credit/debit cards.",
      },
    ],
  },
];

let inMemorySections: ContentSection[] = [...defaultSections];


function ensureDataDir() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  } catch {
    // Non-blocking in serverless
  }
}

// Site Settings
export function getSiteSettings(): SiteSettings {
  try {
    ensureDataDir();
    if (fs.existsSync(SETTINGS_FILE)) {
      const data = fs.readFileSync(SETTINGS_FILE, "utf-8");
      const parsed = JSON.parse(data);
      return {
        ...defaultSettings,
        ...parsed,
        homeSections:
          parsed.homeSections && parsed.homeSections.length > 0
            ? parsed.homeSections
            : DEFAULT_HOME_SECTIONS,
      };
    }
  } catch {
    // Fall back to memory
  }
  return inMemorySettings;
}

export function updateSiteSettings(settings: Partial<SiteSettings>): SiteSettings {
  const current = getSiteSettings();
  const updated: SiteSettings = {
    ...current,
    ...settings,
    lastUpdated: new Date().toISOString(),
  };
  inMemorySettings = updated;
  try {
    ensureDataDir();
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(updated, null, 2));
  } catch {
    // Fallback intact
  }
  return updated;
}

// Products
export function getProducts(): ProductItem[] {
  try {
    ensureDataDir();
    if (fs.existsSync(PRODUCTS_FILE)) {
      const data = fs.readFileSync(PRODUCTS_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch {
    // Fall back to memory
  }
  return inMemoryProducts;
}

export function saveProduct(product: Omit<ProductItem, "id"> & { id?: string }): ProductItem {
  const current = getProducts();
  let saved: ProductItem;

  if (product.id) {
    const idx = current.findIndex((p) => p.id === product.id);
    if (idx !== -1) {
      saved = { ...current[idx], ...product };
      current[idx] = saved;
    } else {
      saved = { ...(product as ProductItem) };
      current.push(saved);
    }
  } else {
    saved = {
      ...(product as ProductItem),
      id: `prod-${Date.now().toString().slice(-6)}`,
      sortOrder: current.length + 1,
      isActive: true,
    };
    current.push(saved);
  }

  inMemoryProducts = current;
  try {
    ensureDataDir();
    fs.writeFileSync(PRODUCTS_FILE, JSON.stringify(current, null, 2));
  } catch {
    // Fallback intact
  }
  return saved;
}

export function deleteProduct(id: string): boolean {
  const current = getProducts();
  const filtered = current.filter((p) => p.id !== id);
  if (filtered.length === current.length) return false;

  inMemoryProducts = filtered;
  try {
    ensureDataDir();
    fs.writeFileSync(PRODUCTS_FILE, JSON.stringify(filtered, null, 2));
  } catch {
    // Fallback intact
  }
  return true;
}

// Pricing Plans
export function getPricingPlans(): PricingPlan[] {
  try {
    ensureDataDir();
    if (fs.existsSync(PRICING_FILE)) {
      const data = fs.readFileSync(PRICING_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch {
    // Fall back to memory
  }
  return inMemoryPricing;
}

export function updatePricingPlan(id: string, planData: Partial<PricingPlan>): PricingPlan | null {
  const current = getPricingPlans();
  const idx = current.findIndex((p) => p.id === id);
  if (idx === -1) return null;

  const updated = { ...current[idx], ...planData };
  current[idx] = updated;
  inMemoryPricing = current;

  try {
    ensureDataDir();
    fs.writeFileSync(PRICING_FILE, JSON.stringify(current, null, 2));
  } catch {
    // Fallback intact
  }
  return updated;
}

export function savePricingPlan(plan: Omit<PricingPlan, "id"> & { id?: string }): PricingPlan {
  const current = getPricingPlans();
  let saved: PricingPlan;

  if (plan.id) {
    const idx = current.findIndex((p) => p.id === plan.id);
    if (idx !== -1) {
      saved = { ...current[idx], ...plan };
      current[idx] = saved;
    } else {
      saved = { ...(plan as PricingPlan) };
      current.push(saved);
    }
  } else {
    saved = {
      ...(plan as PricingPlan),
      id: `plan-${Date.now().toString().slice(-6)}`,
    };
    current.push(saved);
  }

  inMemoryPricing = current;
  try {
    ensureDataDir();
    fs.writeFileSync(PRICING_FILE, JSON.stringify(current, null, 2));
  } catch {
    // Fallback intact
  }
  return saved;
}

export function deletePricingPlan(id: string): boolean {
  const current = getPricingPlans();
  const filtered = current.filter((p) => p.id !== id);
  if (filtered.length === current.length) return false;

  inMemoryPricing = filtered;
  try {
    ensureDataDir();
    fs.writeFileSync(PRICING_FILE, JSON.stringify(filtered, null, 2));
  } catch {
    // Fallback intact
  }
  return true;
}

// Content Sections CRUD
export function getContentSections(): ContentSection[] {
  try {
    ensureDataDir();
    if (fs.existsSync(SECTIONS_FILE)) {
      const data = fs.readFileSync(SECTIONS_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch {
    // Fall back to memory
  }
  return inMemorySections;
}

export function saveContentSection(
  section: Omit<ContentSection, "id"> & { id?: string }
): ContentSection {
  const current = getContentSections();
  let saved: ContentSection;

  if (section.id) {
    const idx = current.findIndex((s) => s.id === section.id);
    if (idx !== -1) {
      saved = { ...current[idx], ...section };
      current[idx] = saved;
    } else {
      saved = { ...(section as ContentSection) };
      current.push(saved);
    }
  } else {
    saved = {
      ...(section as ContentSection),
      id: `sec-${Date.now().toString().slice(-6)}`,
      sortOrder: current.length + 1,
      isActive: true,
      items: section.items || [],
    };
    current.push(saved);
  }

  inMemorySections = current;
  try {
    ensureDataDir();
    fs.writeFileSync(SECTIONS_FILE, JSON.stringify(current, null, 2));
  } catch {
    // Fallback intact
  }
  return saved;
}

export function deleteContentSection(id: string): boolean {
  const current = getContentSections();
  const filtered = current.filter((s) => s.id !== id);
  if (filtered.length === current.length) return false;

  inMemorySections = filtered;
  try {
    ensureDataDir();
    fs.writeFileSync(SECTIONS_FILE, JSON.stringify(filtered, null, 2));
  } catch {
    // Fallback intact
  }
  return true;
}

export function reorderContentSections(orderedIds: string[]): ContentSection[] {
  const current = getContentSections();
  const map = new Map(current.map((s) => [s.id, s]));
  const reordered: ContentSection[] = [];

  orderedIds.forEach((id, index) => {
    const item = map.get(id);
    if (item) {
      item.sortOrder = index + 1;
      reordered.push(item);
      map.delete(id);
    }
  });

  // Append any remaining
  for (const remaining of map.values()) {
    remaining.sortOrder = reordered.length + 1;
    reordered.push(remaining);
  }

  inMemorySections = reordered;
  try {
    ensureDataDir();
    fs.writeFileSync(SECTIONS_FILE, JSON.stringify(reordered, null, 2));
  } catch {
    // Fallback intact
  }
  return reordered;
}

// ==========================================
// BLOG POSTS STORE
// ==========================================

const defaultBlogPosts: BlogPostItem[] = BLOG_POSTS.map((p, idx) => ({
  id: `post-${idx + 1}`,
  slug: p.slug,
  titleKm: p.titleKm,
  titleEn: p.titleEn,
  excerptKm: p.excerptKm,
  excerptEn: p.excerptEn,
  contentKm: p.contentKm || p.excerptKm,
  contentEn: p.contentEn || p.excerptEn,
  category: p.category,
  tagKm: p.tagKm,
  tagEn: p.tagEn,
  readingTime: p.readingTime,
  date: p.date,
  featured: p.featured,
  coverGradient: p.coverGradient,
  coverImage: "",
  icon: p.icon,
  author: "Broteach Team",
  isPublished: true,
}));

let inMemoryPosts: BlogPostItem[] = [...defaultBlogPosts];

export function getBlogPosts(): BlogPostItem[] {
  try {
    ensureDataDir();
    if (fs.existsSync(POSTS_FILE)) {
      const data = fs.readFileSync(POSTS_FILE, "utf-8");
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed) && parsed.length > 0) {
        inMemoryPosts = parsed;
        return parsed;
      }
    }
  } catch {
    // fallback
  }
  return inMemoryPosts;
}

export function saveBlogPost(post: Partial<BlogPostItem> & { titleKm: string; titleEn: string }): BlogPostItem {
  const current = getBlogPosts();
  let saved: BlogPostItem;

  const id = post.id || `post-${Date.now()}`;
  const slug =
    post.slug?.trim() ||
    (post.titleEn
      ? post.titleEn.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "")
      : `post-${Date.now()}`);

  const existingIndex = current.findIndex((p) => p.id === id || (post.slug && p.slug === post.slug));

  const postData: BlogPostItem = {
    id,
    slug,
    titleKm: post.titleKm,
    titleEn: post.titleEn,
    excerptKm: post.excerptKm || "",
    excerptEn: post.excerptEn || "",
    contentKm: post.contentKm || post.excerptKm || "",
    contentEn: post.contentEn || post.excerptEn || "",
    category: post.category || "General",
    tagKm: post.tagKm || post.category || "General",
    tagEn: post.tagEn || post.category || "General",
    readingTime: post.readingTime || 5,
    date: post.date || new Date().toISOString().split("T")[0],
    featured: Boolean(post.featured),
    coverGradient: post.coverGradient || "from-cyan-600 to-blue-700",
    coverImage: post.coverImage || "",
    icon: post.icon || "📝",
    author: post.author || "Broteach Team",
    isPublished: post.isPublished !== undefined ? post.isPublished : true,
  };

  if (existingIndex >= 0) {
    current[existingIndex] = postData;
    saved = postData;
  } else {
    current.unshift(postData);
    saved = postData;
  }

  inMemoryPosts = current;
  try {
    ensureDataDir();
    fs.writeFileSync(POSTS_FILE, JSON.stringify(current, null, 2));
  } catch {
    // fallback
  }
  return saved;
}

export function deleteBlogPost(idOrSlug: string): boolean {
  const current = getBlogPosts();
  const filtered = current.filter((p) => p.id !== idOrSlug && p.slug !== idOrSlug);
  if (filtered.length === current.length) return false;

  inMemoryPosts = filtered;
  try {
    ensureDataDir();
    fs.writeFileSync(POSTS_FILE, JSON.stringify(filtered, null, 2));
  } catch {
    // fallback
  }
  return true;
}

// Bulk restore functions for backup and recovery
export function restoreSiteSettings(settings: SiteSettings): void {
  inMemorySettings = { ...settings, lastUpdated: new Date().toISOString() };
  try {
    ensureDataDir();
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(inMemorySettings, null, 2));
  } catch {
    // fallback
  }
}

export function restoreProducts(products: ProductItem[]): void {
  inMemoryProducts = [...products];
  try {
    ensureDataDir();
    fs.writeFileSync(PRODUCTS_FILE, JSON.stringify(products, null, 2));
  } catch {
    // fallback
  }
}

export function restorePricingPlans(plans: PricingPlan[]): void {
  inMemoryPricing = [...plans];
  try {
    ensureDataDir();
    fs.writeFileSync(PRICING_FILE, JSON.stringify(plans, null, 2));
  } catch {
    // fallback
  }
}

export function restoreContentSections(sections: ContentSection[]): void {
  inMemorySections = [...sections];
  try {
    ensureDataDir();
    fs.writeFileSync(SECTIONS_FILE, JSON.stringify(sections, null, 2));
  } catch {
    // fallback
  }
}

export function restoreBlogPosts(posts: BlogPostItem[]): void {
  inMemoryPosts = [...posts];
  try {
    ensureDataDir();
    fs.writeFileSync(POSTS_FILE, JSON.stringify(posts, null, 2));
  } catch {
    // fallback
  }
}


