import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), ".data");
export const UPLOADS_DIR = path.join(DATA_DIR, "uploads");

export interface MediaFileItem {
  name: string;
  url: string;
  sizeBytes: number;
  mimeType: string;
  createdAt: string;
  isImage: boolean;
}

const ALLOWED_EXTENSIONS = new Set([
  "jpg",
  "jpeg",
  "png",
  "webp",
  "gif",
  "svg",
  "ico",
  "pdf",
  "txt",
  "json",
  "zip",
]);

const MIME_MAP: Record<string, string> = {
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  png: "image/png",
  webp: "image/webp",
  gif: "image/gif",
  svg: "image/svg+xml",
  ico: "image/x-icon",
  pdf: "application/pdf",
  txt: "text/plain; charset=utf-8",
  json: "application/json",
  zip: "application/zip",
};

export function ensureUploadsDir(): void {
  try {
    if (!fs.existsSync(UPLOADS_DIR)) {
      fs.mkdirSync(UPLOADS_DIR, { recursive: true });
    }
  } catch (err) {
    console.error("Failed to ensure uploads directory:", err);
  }
}

/**
 * List all uploaded media & storage files
 */
export function listUploadedFiles(): MediaFileItem[] {
  ensureUploadsDir();
  try {
    if (!fs.existsSync(UPLOADS_DIR)) {
      return [];
    }

    const files = fs.readdirSync(UPLOADS_DIR);
    const result: MediaFileItem[] = [];

    for (const filename of files) {
      if (filename.startsWith(".")) continue;
      const filePath = path.join(UPLOADS_DIR, filename);
      try {
        const stat = fs.statSync(filePath);
        if (!stat.isFile()) continue;

        const ext = filename.split(".").pop()?.toLowerCase() || "";
        const isImage = ["jpg", "jpeg", "png", "webp", "gif", "svg", "ico"].includes(ext);
        const mimeType = MIME_MAP[ext] || "application/octet-stream";

        result.push({
          name: filename,
          url: `/uploads/${filename}`,
          sizeBytes: stat.size,
          mimeType,
          createdAt: stat.mtime.toISOString(),
          isImage,
        });
      } catch {
        // Skip unreadable files
      }
    }

    // Sort newest first
    result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return result;
  } catch {
    return [];
  }
}

/**
 * Securely retrieve file path and MIME type
 */
export function getUploadedFilePath(filename: string): { filePath: string; mimeType: string } | null {
  ensureUploadsDir();
  const safeName = path.basename(filename);
  if (safeName.includes("..") || safeName.startsWith(".")) {
    return null;
  }

  const filePath = path.join(UPLOADS_DIR, safeName);
  if (!fs.existsSync(filePath)) {
    return null;
  }

  const ext = safeName.split(".").pop()?.toLowerCase() || "";
  const mimeType = MIME_MAP[ext] || "application/octet-stream";
  return { filePath, mimeType };
}

/**
 * Save an uploaded file with strict validation
 */
export async function saveUploadedFile(file: File): Promise<{
  success: boolean;
  message?: string;
  file?: MediaFileItem;
}> {
  ensureUploadsDir();

  // Maximum file size: 15MB
  const MAX_SIZE = 15 * 1024 * 1024;
  if (file.size > MAX_SIZE) {
    return { success: false, message: "File size exceeds 15MB limit" };
  }

  const originalName = file.name;
  const ext = originalName.split(".").pop()?.toLowerCase() || "";

  if (!ALLOWED_EXTENSIONS.has(ext)) {
    return {
      success: false,
      message: `File extension .${ext} is not allowed. Allowed: ${Array.from(ALLOWED_EXTENSIONS).join(", ")}`,
    };
  }

  // Generate safe filename: slugified_name-timestamp.ext
  const baseName = originalName
    .substring(0, originalName.lastIndexOf("."))
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 40);

  const finalName = `${baseName || "file"}-${Date.now().toString().slice(-6)}.${ext}`;
  const targetPath = path.join(UPLOADS_DIR, finalName);

  const arrayBuffer = await file.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);

  fs.writeFileSync(targetPath, buffer);

  const stat = fs.statSync(targetPath);
  const isImage = ["jpg", "jpeg", "png", "webp", "gif", "svg", "ico"].includes(ext);
  const mimeType = MIME_MAP[ext] || file.type || "application/octet-stream";

  return {
    success: true,
    file: {
      name: finalName,
      url: `/uploads/${finalName}`,
      sizeBytes: stat.size,
      mimeType,
      createdAt: stat.mtime.toISOString(),
      isImage,
    },
  };
}

/**
 * Delete an uploaded file securely
 */
export function deleteUploadedFile(filename: string): boolean {
  ensureUploadsDir();
  const safeName = path.basename(filename);
  if (safeName.includes("..") || safeName.startsWith(".")) {
    return false;
  }

  const targetPath = path.join(UPLOADS_DIR, safeName);
  try {
    if (fs.existsSync(targetPath)) {
      fs.unlinkSync(targetPath);
      return true;
    }
  } catch (err) {
    console.error("Failed to delete file:", err);
  }
  return false;
}
