import fs from "fs";
import path from "path";
import {
  ProductItem,
  SiteSettings,
  PricingPlan,
  ContentSection,
  BlogPostItem,
  OrderSubmission,
  NewsletterSubscriber,
} from "@/types";
import {
  getSiteSettings,
  restoreSiteSettings,
  getProducts,
  restoreProducts,
  getPricingPlans,
  restorePricingPlans,
  getContentSections,
  restoreContentSections,
  getBlogPosts,
  restoreBlogPosts,
} from "./contentStore";
import {
  getOrders,
  restoreOrders,
  getSubscribers,
  restoreSubscribers,
} from "./storage";

const DATA_DIR = path.join(process.cwd(), ".data");
const BACKUPS_DIR = path.join(DATA_DIR, "backups");

export interface BackupData {
  version: "1.0";
  timestamp: string;
  source: string;
  tag?: string;
  stats: {
    productsCount: number;
    pricingCount: number;
    sectionsCount: number;
    postsCount: number;
    ordersCount: number;
    subscribersCount: number;
  };
  data: {
    settings: SiteSettings;
    products: ProductItem[];
    pricing: PricingPlan[];
    sections: ContentSection[];
    posts: BlogPostItem[];
    orders: OrderSubmission[];
    subscribers: NewsletterSubscriber[];
  };
}

export interface SnapshotItem {
  filename: string;
  sizeBytes: number;
  createdAt: string;
  tag?: string;
  stats?: BackupData["stats"];
}

function ensureBackupsDir() {
  try {
    if (!fs.existsSync(BACKUPS_DIR)) {
      fs.mkdirSync(BACKUPS_DIR, { recursive: true });
    }
  } catch {
    // Non-blocking in serverless/read-only environments
  }
}

/**
 * Generate a complete in-memory snapshot of all system data
 */
export function generateFullBackup(tag?: string): BackupData {
  const settings = getSiteSettings();
  const products = getProducts();
  const pricing = getPricingPlans();
  const sections = getContentSections();
  const posts = getBlogPosts();
  const orders = getOrders();
  const subscribers = getSubscribers();

  return {
    version: "1.0",
    timestamp: new Date().toISOString(),
    source: "broteach.com CMS",
    tag: tag?.trim() || undefined,
    stats: {
      productsCount: products.length,
      pricingCount: pricing.length,
      sectionsCount: sections.length,
      postsCount: posts.length,
      ordersCount: orders.length,
      subscribersCount: subscribers.length,
    },
    data: {
      settings,
      products,
      pricing,
      sections,
      posts,
      orders,
      subscribers,
    },
  };
}

/**
 * Create and persist a timestamped snapshot to .data/backups/
 */
export function createSnapshot(tag = "manual"): SnapshotItem {
  ensureBackupsDir();
  const backup = generateFullBackup(tag);
  const now = new Date();
  const dateStr = now.toISOString().replace(/[:.]/g, "-");
  const cleanTag = tag.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 30);
  const filename = `snapshot-${dateStr}-${cleanTag}.json`;
  const filePath = path.join(BACKUPS_DIR, filename);

  const serialized = JSON.stringify(backup, null, 2);
  fs.writeFileSync(filePath, serialized, "utf-8");

  const stat = fs.statSync(filePath);
  return {
    filename,
    sizeBytes: stat.size,
    createdAt: backup.timestamp,
    tag,
    stats: backup.stats,
  };
}

/**
 * List all available server-side snapshots
 */
export function listSnapshots(): SnapshotItem[] {
  ensureBackupsDir();
  try {
    if (!fs.existsSync(BACKUPS_DIR)) {
      return [];
    }

    const files = fs.readdirSync(BACKUPS_DIR);
    const snapshots: SnapshotItem[] = [];

    for (const file of files) {
      if (!file.endsWith(".json")) continue;
      const filePath = path.join(BACKUPS_DIR, file);
      try {
        const stat = fs.statSync(filePath);
        // Attempt quick metadata read
        const content = fs.readFileSync(filePath, "utf-8");
        const parsed = JSON.parse(content);

        snapshots.push({
          filename: file,
          sizeBytes: stat.size,
          createdAt: parsed.timestamp || stat.mtime.toISOString(),
          tag: parsed.tag || "snapshot",
          stats: parsed.stats || undefined,
        });
      } catch {
        // If file is unparseable or corrupted, still include basic stat
        try {
          const stat = fs.statSync(filePath);
          snapshots.push({
            filename: file,
            sizeBytes: stat.size,
            createdAt: stat.mtime.toISOString(),
            tag: "unverified",
          });
        } catch {
          // ignore
        }
      }
    }

    // Sort newest first
    snapshots.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return snapshots;
  } catch {
    return [];
  }
}

/**
 * Securely fetch a single snapshot by filename
 */
export function getSnapshot(filename: string): BackupData | null {
  ensureBackupsDir();
  // Prevent directory traversal attacks
  const safeName = path.basename(filename);
  if (!safeName.endsWith(".json") || safeName.includes("..")) {
    return null;
  }

  const filePath = path.join(BACKUPS_DIR, safeName);
  try {
    if (!fs.existsSync(filePath)) return null;
    const content = fs.readFileSync(filePath, "utf-8");
    return JSON.parse(content) as BackupData;
  } catch {
    return null;
  }
}

/**
 * Securely delete a snapshot file
 */
export function deleteSnapshot(filename: string): boolean {
  ensureBackupsDir();
  const safeName = path.basename(filename);
  if (!safeName.endsWith(".json") || safeName.includes("..")) {
    return false;
  }

  const filePath = path.join(BACKUPS_DIR, safeName);
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      return true;
    }
  } catch {
    // ignore
  }
  return false;
}

/**
 * Restore system from a backup payload with automatic pre-restore safety snapshot
 */
export function restoreFromBackup(
  backup: unknown,
  options?: { selective?: string[] }
): {
  success: boolean;
  message: string;
  restored: Record<string, number | boolean>;
  safetySnapshot?: string;
  error?: string;
} {
  if (!backup || typeof backup !== "object") {
    return { success: false, message: "Invalid backup data: not an object", restored: {} };
  }

  const payload = backup as Partial<BackupData>;
  if (!payload.data || typeof payload.data !== "object") {
    return { success: false, message: "Invalid backup data: missing data property", restored: {} };
  }

  // 1. Automatically create safety snapshot of live data before restoring!
  let safetySnapshotName: string | undefined;
  try {
    const safety = createSnapshot("pre-restore-safety");
    safetySnapshotName = safety.filename;
  } catch (err) {
    console.warn("Could not create pre-restore safety snapshot:", err);
  }

  const selective = options?.selective;
  const shouldRestore = (key: string) => !selective || selective.length === 0 || selective.includes(key);

  const restoredSummary: Record<string, number | boolean> = {};

  try {
    // 2. Settings
    if (shouldRestore("settings") && payload.data.settings && typeof payload.data.settings === "object") {
      restoreSiteSettings(payload.data.settings as SiteSettings);
      restoredSummary.settings = true;
    }

    // 3. Products
    if (shouldRestore("products") && Array.isArray(payload.data.products)) {
      restoreProducts(payload.data.products as ProductItem[]);
      restoredSummary.products = payload.data.products.length;
    }

    // 4. Pricing Plans
    if (shouldRestore("pricing") && Array.isArray(payload.data.pricing)) {
      restorePricingPlans(payload.data.pricing as PricingPlan[]);
      restoredSummary.pricing = payload.data.pricing.length;
    }

    // 5. Content Sections
    if (shouldRestore("sections") && Array.isArray(payload.data.sections)) {
      restoreContentSections(payload.data.sections as ContentSection[]);
      restoredSummary.sections = payload.data.sections.length;
    }

    // 6. Blog Posts
    if (shouldRestore("posts") && Array.isArray(payload.data.posts)) {
      restoreBlogPosts(payload.data.posts as BlogPostItem[]);
      restoredSummary.posts = payload.data.posts.length;
    }

    // 7. Orders
    if (shouldRestore("orders") && Array.isArray(payload.data.orders)) {
      restoreOrders(payload.data.orders as OrderSubmission[]);
      restoredSummary.orders = payload.data.orders.length;
    }

    // 8. Subscribers
    if (shouldRestore("subscribers") && Array.isArray(payload.data.subscribers)) {
      restoreSubscribers(payload.data.subscribers as NewsletterSubscriber[]);
      restoredSummary.subscribers = payload.data.subscribers.length;
    }

    return {
      success: true,
      message: "Data restored successfully",
      restored: restoredSummary,
      safetySnapshot: safetySnapshotName,
    };
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    console.error("Failed to restore backup:", errorMsg);
    return {
      success: false,
      message: "Failed to restore backup: " + errorMsg,
      restored: restoredSummary,
      error: errorMsg,
    };
  }
}
