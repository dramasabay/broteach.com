/**
 * Real-Time CMS Synchronization utility across tabs and client sessions.
 */

const CHANNEL_NAME = "broteach_cms_sync";
const STORAGE_KEY = "broteach_cms_last_updated";

export function broadcastCmsUpdate(type: string = "content_updated") {
  if (typeof window === "undefined") return;

  // 1. BroadcastChannel for active same-origin tabs
  try {
    if (typeof BroadcastChannel !== "undefined") {
      const channel = new BroadcastChannel(CHANNEL_NAME);
      channel.postMessage({ type, timestamp: Date.now() });
      channel.close();
    }
  } catch {
    // Non-critical fallback
  }

  // 2. LocalStorage event trigger
  try {
    localStorage.setItem(STORAGE_KEY, Date.now().toString());
  } catch {
    // Non-critical fallback
  }
}

export function subscribeCmsUpdates(callback: () => void): () => void {
  if (typeof window === "undefined") return () => {};

  let channel: BroadcastChannel | null = null;

  // 1. Listen on BroadcastChannel
  try {
    if (typeof BroadcastChannel !== "undefined") {
      channel = new BroadcastChannel(CHANNEL_NAME);
      channel.onmessage = () => {
        callback();
      };
    }
  } catch {
    // Fallback intact
  }

  // 2. Listen on Storage event
  const handleStorage = (e: StorageEvent) => {
    if (e.key === STORAGE_KEY) {
      callback();
    }
  };

  window.addEventListener("storage", handleStorage);

  return () => {
    if (channel) {
      try {
        channel.close();
      } catch {
        // Ignored
      }
    }
    window.removeEventListener("storage", handleStorage);
  };
}
