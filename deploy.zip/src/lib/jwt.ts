/**
 * Universal HMAC-SHA256 JWT implementation using Web Crypto API.
 * Compatible with Next.js Edge Runtime, Node.js, and Browser.
 */

// JWT_SECRET MUST be set as an environment variable.
// No hardcoded fallback is provided; an empty secret will cause all
// signatures to be generated with a zero-length key, which will not
// match any production secret, effectively disabling admin access until
// the environment variable is properly configured.
const DEFAULT_SECRET = process.env.JWT_SECRET ?? "";
export const JWT_COOKIE_NAME = "broteach_admin_jwt";

function stringToUint8Array(str: string): Uint8Array {
  return new TextEncoder().encode(str);
}

function base64UrlEncode(input: string | Uint8Array): string {
  let base64 = "";
  if (typeof input === "string") {
    if (typeof btoa !== "undefined") {
      base64 = btoa(input);
    } else if (typeof Buffer !== "undefined") {
      base64 = Buffer.from(input, "utf-8").toString("base64");
    }
  } else {
    if (typeof Buffer !== "undefined") {
      base64 = Buffer.from(input).toString("base64");
    } else {
      let binary = "";
      const len = input.byteLength;
      for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(input[i]);
      }
      base64 = btoa(binary);
    }
  }
  return base64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function base64UrlDecode(input: string): string {
  let base64 = input.replace(/-/g, "+").replace(/_/g, "/");
  while (base64.length % 4 !== 0) {
    base64 += "=";
  }
  if (typeof atob !== "undefined") {
    return atob(base64);
  }
  if (typeof Buffer !== "undefined") {
    return Buffer.from(base64, "base64").toString("utf-8");
  }
  throw new Error("Base64 decode unsupported in this environment");
}

async function getCryptoKey(secret: string): Promise<CryptoKey> {
  const keyData = stringToUint8Array(secret);
  return await crypto.subtle.importKey(
    "raw",
    keyData as unknown as BufferSource,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"]
  );
}

/**
 * Sign a JSON Web Token (JWT) with HMAC-SHA256
 */
export async function signJwt(
  payload: Record<string, unknown>,
  secret: string = DEFAULT_SECRET,
  expiresInSeconds: number = 7 * 24 * 60 * 60 // 7 days default
): Promise<string> {
  const header = { alg: "HS256", typ: "JWT" };
  const now = Math.floor(Date.now() / 1000);
  const fullPayload = {
    ...payload,
    iat: now,
    exp: now + expiresInSeconds,
  };

  const encodedHeader = base64UrlEncode(JSON.stringify(header));
  const encodedPayload = base64UrlEncode(JSON.stringify(fullPayload));
  const dataToSign = `${encodedHeader}.${encodedPayload}`;

  const key = await getCryptoKey(secret);
  const signatureBuffer = await crypto.subtle.sign(
    "HMAC",
    key,
    stringToUint8Array(dataToSign) as unknown as BufferSource
  );

  const encodedSignature = base64UrlEncode(new Uint8Array(signatureBuffer));
  return `${dataToSign}.${encodedSignature}`;
}

/**
 * Verify and decode an HMAC-SHA256 JSON Web Token (JWT)
 */
export async function verifyJwt(
  token: string,
  secret: string = DEFAULT_SECRET
): Promise<{ valid: boolean; payload?: Record<string, unknown>; error?: string }> {
  try {
    if (!token || typeof token !== "string") {
      return { valid: false, error: "Empty token" };
    }

    const parts = token.split(".");
    if (parts.length !== 3) {
      return { valid: false, error: "Malformed JWT structure" };
    }

    const [encodedHeader, encodedPayload, encodedSignature] = parts;
    const dataToSign = `${encodedHeader}.${encodedPayload}`;

    // Verify signature
    const key = await getCryptoKey(secret);

    // Decode signature
    let sigBase64 = encodedSignature.replace(/-/g, "+").replace(/_/g, "/");
    while (sigBase64.length % 4 !== 0) {
      sigBase64 += "=";
    }

    let signatureBytes: Uint8Array;
    if (typeof Buffer !== "undefined") {
      signatureBytes = new Uint8Array(Buffer.from(sigBase64, "base64"));
    } else {
      const raw = atob(sigBase64);
      signatureBytes = new Uint8Array(raw.length);
      for (let i = 0; i < raw.length; i++) {
        signatureBytes[i] = raw.charCodeAt(i);
      }
    }

    const isValid = await crypto.subtle.verify(
      "HMAC",
      key,
      signatureBytes as unknown as BufferSource,
      stringToUint8Array(dataToSign) as unknown as BufferSource
    );

    if (!isValid) {
      return { valid: false, error: "Invalid signature" };
    }

    // Decode and check expiration
    const payloadJson = base64UrlDecode(encodedPayload);
    const payload = JSON.parse(payloadJson);

    if (payload.exp && typeof payload.exp === "number") {
      const now = Math.floor(Date.now() / 1000);
      if (now > payload.exp) {
        return { valid: false, error: "Token expired", payload };
      }
    }

    return { valid: true, payload };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Verification error";
    return { valid: false, error: message };
  }
}
